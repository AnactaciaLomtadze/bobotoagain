/**
 * chat.js - Fixed version to prevent unwanted redirects
 */

// DOM Elements
const chatMessages = document.querySelector('.chat-messages');
const chatInput = document.querySelector('.chat-input');
const sendBtn = document.querySelector('.send-btn');
const newChatBtn = document.querySelector('button[aria-label="Start new chat"]');
const saveChatBtn = document.querySelector('button[aria-label="Save conversation"]');

// Chat state
let currentSessionId = null;
let isProcessing = false;
let chatHistory = [];

// Initialize chat on page load
document.addEventListener('DOMContentLoaded', async () => {
  // Protect the page but don't redirect unnecessarily
  if (!isAuthenticated()) {
    console.warn('User not authenticated, but allowing guest chat');
    showWelcomeMessage(false); // Show non-authenticated welcome
  } else {
    // Initialize chat with user context for authenticated users
    await initChatWithAuth();
  }
  
  // Always initialize the chat UI regardless of auth status
  initChat();
});

// Initialize chat with authentication context
async function initChatWithAuth() {
  try {
    // Get user profile for personalization
    const profileData = await API.Profile.get();
    
    if (profileData) {
      // Store profile data for AI personalization
      localStorage.setItem('user_profile_data', JSON.stringify(profileData));
      
      // Update welcome message with user name
      const firstName = profileData.fullName?.split(' ')[0] || 'there';
      updateWelcomeMessage(firstName, profileData);
    }
    
    // Load recent chat session if exists
    await loadRecentChatSession();
    
  } catch (error) {
    console.error('Error initializing chat with auth:', error);
    // Don't throw error, just continue with basic initialization
  }
}

// Initialize chat functionality
function initChat() {
  console.log('Initializing chat functionality...');
  
  // Setup tab switching
  setupTabSwitching();
  
  // Set up event listeners
  setupEventListeners();
  
  // Setup history search
  setupHistorySearch();
  
  // Add CSS variables for theming
  setupThemeVariables();
  
  // Update chat history sidebar for authenticated users
  if (isAuthenticated()) {
    updateChatHistorySidebar();
  }
  
  // Set focus to input
  if (chatInput) {
    chatInput.focus();
  }
}

// Setup event listeners
function setupEventListeners() {
  console.log('Setting up event listeners...');
  
  // Send button click
  if (sendBtn) {
    sendBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      await sendMessage();
    });
  }
  
  // Chat input enter key
  if (chatInput) {
    chatInput.addEventListener('keypress', async (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        e.stopPropagation();
        await sendMessage();
      }
    });
    
    // Auto-resize textarea
    chatInput.addEventListener('input', () => {
      chatInput.style.height = 'auto';
      chatInput.style.height = chatInput.scrollHeight + 'px';
    });
  }
  
  // New chat button
  if (newChatBtn) {
    newChatBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      startNewChat();
    });
  }
  
  // Save chat button
  if (saveChatBtn) {
    saveChatBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      saveChatSession();
    });
  }
  
  // Topic chip click handlers
  document.addEventListener('click', (e) => {
    if (e.target.closest('.topic-chip')) {
      e.preventDefault();
      e.stopPropagation();
      const chip = e.target.closest('.topic-chip');
      if (chatInput) {
        chatInput.value = chip.textContent;
        chatInput.focus();
        // Trigger resize
        const event = new Event('input', { bubbles: true });
        chatInput.dispatchEvent(event);
      }
    }
  });
}

// Fixed sendMessage function with better error handling
async function sendMessage() {
  console.log('sendMessage called...');
  
  if (!chatInput || isProcessing) {
    console.log('Cannot send message: input not ready or already processing');
    return;
  }
  
  const message = chatInput.value.trim();
  if (!message) {
    console.log('Cannot send empty message');
    return;
  }
  
  // Prevent any navigation during send
  const originalHandler = window.onbeforeunload;
  window.onbeforeunload = () => 'Message sending in progress...';
  
  try {
    // Clear the input and reset height
    chatInput.value = '';
    chatInput.style.height = 'auto';
    
    // Show user message
    const timestamp = new Date();
    appendMessage(message, true, timestamp);
    
    // Create new session if needed (only for authenticated users)
    if (isAuthenticated() && !currentSessionId) {
      try {
        const newSession = await API.Chat.createSession(generateSessionTitle(message));
        currentSessionId = newSession.sessionId;
      } catch (error) {
        console.error('Error creating session:', error);
        // Continue without session for non-authenticated users
      }
    }
    
    // Save user message to session (only if we have a session)
    if (currentSessionId) {
      try {
        await API.Chat.addMessage(currentSessionId, message, true);
      } catch (error) {
        console.error('Error saving user message:', error);
        // Continue anyway
      }
    }
    
    // Add to chat history
    chatHistory.push({
      text: message,
      isUser: true,
      timestamp,
      sessionId: currentSessionId
    });
    
    // Show typing indicator
    showTypingIndicator();
    
    // Set processing flag
    isProcessing = true;
    
    // Get user profile data for context (if available)
    const profileData = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
    
    // Prepare chat history for API (last 10 messages)
    const apiChatHistory = chatHistory.slice(-10).map(msg => ({
      text: msg.text,
      isUser: msg.isUser
    }));
    
    console.log('Calling AI API...');
    
    // Call the AI endpoint with proper error handling
    let aiResponse;
    
    try {
      console.log('Making fetch request to:', `${window.serverConfig.apiUrl}/ai/chat`);
      
      const response = await fetch(`${window.serverConfig.apiUrl}/ai/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token') || '' // Send empty string if no token
        },
        body: JSON.stringify({
          message: message,
          chatHistory: apiChatHistory,
          sessionId: currentSessionId
        })
      });
      
      console.log('AI API response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('AI API error response:', errorText);
        
        // If it's an auth error and we're not authenticated, that's expected
        if (response.status === 401 && !isAuthenticated()) {
          // Use fallback response for unauthenticated users
          aiResponse = API.AI.getFallbackResponse(message);
        } else {
          throw new Error(`AI API returned ${response.status}: ${errorText}`);
        }
      } else {
        const data = await response.json();
        console.log('AI API response data:', data);
        
        // Handle different response formats
        aiResponse = data.response || data.message || data;
        
        if (!aiResponse || typeof aiResponse !== 'string') {
          console.error('Invalid AI response format:', data);
          throw new Error('Invalid response format from AI service');
        }
      }
      
    } catch (fetchError) {
      console.error('Fetch error:', fetchError);
      
      // Use fallback response
      aiResponse = API.AI.getFallbackResponse(message);
    }
    
    // Remove typing indicator
    removeTypingIndicator();
    
    // Display AI response
    const aiTimestamp = new Date();
    appendMessage(aiResponse, false, aiTimestamp);
    
    // Save AI response to session (only if we have a session)
    if (currentSessionId) {
      try {
        await API.Chat.addMessage(currentSessionId, aiResponse, false);
      } catch (error) {
        console.error('Error saving AI message:', error);
        // Continue anyway
      }
    }
    
    // Add to chat history
    chatHistory.push({
      text: aiResponse,
      isUser: false,
      timestamp: aiTimestamp,
      sessionId: currentSessionId
    });
    
    // Update chat history sidebar (only for authenticated users)
    if (isAuthenticated()) {
      updateChatHistorySidebar();
    }
    
    // Scroll to bottom
    scrollToBottom();
    
  } catch (error) {
    console.error('Error in sendMessage:', error);
    removeTypingIndicator();
    
    // Show error message
    const errorMessage = "I'm sorry, there was an error processing your message. Please try again.";
    appendMessage(errorMessage, false, new Date());
    showNotification('Error processing message', 'error');
  } finally {
    isProcessing = false;
    window.onbeforeunload = originalHandler;
  }
}

// Check if user is authenticated
function isAuthenticated() {
  const token = localStorage.getItem('auth_token');
  return token && token.length > 0;
}

// Get user info from localStorage
function getUserInfo() {
  const userInfo = localStorage.getItem('user_info');
  return userInfo ? JSON.parse(userInfo) : null;
}

// Show welcome message based on authentication status
function showWelcomeMessage(isAuthenticated) {
  if (!chatMessages) return;
  
  // Clear existing messages
  clearChatMessages();
  
  const welcomeDiv = document.createElement('div');
  welcomeDiv.className = 'welcome-message';
  
  if (isAuthenticated) {
    // Personalized welcome for authenticated users
    const userInfo = getUserInfo();
    const firstName = userInfo?.fullName?.split(' ')[0] || 'there';
    
    welcomeDiv.innerHTML = `
      <h2>Welcome, ${firstName}!</h2>
      <p>I'm Boboto, your academic and career AI assistant powered by DeepSeek. Ask me anything about your studies, career goals, or get personalized recommendations based on your skills and interests.</p>
      
      <div class="suggested-topics">
        <div class="topic-chip">Create a study plan</div>
        <div class="topic-chip">Explore ML career paths</div>
        <div class="topic-chip">Assess my cloud skills</div>
        <div class="topic-chip">Prepare for interviews</div>
        <div class="topic-chip">Find learning resources</div>
        <div class="topic-chip">Build a portfolio</div>
      </div>
    `;
  } else {
    // Generic welcome for non-authenticated users
    welcomeDiv.innerHTML = `
      <h2>Welcome to Boboto Assistant</h2>
      <p>I'm your academic and career AI assistant powered by DeepSeek. To get personalized advice and save your conversations, please <a href="bobotoLogin.html">log in</a> or <a href="bobotoSignup.html">sign up</a>.</p>
      
      <p>You can still chat with me as a guest, but your conversation won't be saved.</p>
      
      <div class="suggested-topics">
        <div class="topic-chip">How can Boboto help me?</div>
        <div class="topic-chip">What are ML career paths?</div>
        <div class="topic-chip">Learning resources for beginners</div>
        <div class="topic-chip">Interview preparation tips</div>
      </div>
    `;
  }
  
  chatMessages.appendChild(welcomeDiv);
}

// Update welcome message with user data
function updateWelcomeMessage(firstName, profileData) {
  if (!chatMessages) return;
  
  const welcomeMessage = chatMessages.querySelector('.welcome-message');
  if (!welcomeMessage) return;
  
  let skillsText = 'Not specified';
  if (profileData.skills && profileData.skills.length > 0) {
    skillsText = profileData.skills.slice(0, 3).map(s => s.name).join(', ');
    if (profileData.skills.length > 3) {
      skillsText += ` +${profileData.skills.length - 3} more`;
    }
  }
  
  welcomeMessage.innerHTML = `
    <h2>Welcome, ${firstName}!</h2>
    <p>I'm Boboto, your academic and career AI assistant powered by DeepSeek. Your profile shows you're studying ${profileData.major || 'Computer Science'} and your skills include: ${skillsText}.</p>
    <p>Ask me anything about your studies, career goals, or get personalized recommendations!</p>
    
    <div class="suggested-topics">
      <div class="topic-chip">Create a study plan for ${profileData.major || 'my field'}</div>
      <div class="topic-chip">What careers match my skills?</div>
      <div class="topic-chip">Learning path for ${profileData.skills?.[0]?.name || 'new technology'}</div>
      <div class="topic-chip">Prepare for ${profileData.careerGoals?.shortTermGoal || 'interviews'}</div>
    </div>
  `;
}

// Generate session title from message
function generateSessionTitle(message) {
  // Take first 50 characters as title
  if (message.length > 50) {
    return message.substring(0, 50) + '...';
  }
  return message;
}

// Load a specific chat session
async function loadChatSession(sessionId) {
  if (!isAuthenticated()) {
    showNotification('Please log in to access saved conversations', 'info');
    return;
  }
  
  try {
    // Get session details
    const sessions = await API.Chat.getSessions();
    const currentSession = sessions.find(s => s._id === sessionId);
    
    if (!currentSession) {
      showNotification('Session not found', 'error');
      return;
    }
    
    // Get messages for this session
    const messages = await API.Chat.getMessages(sessionId);
    
    // Set current session
    currentSessionId = sessionId;
    
    // Clear existing messages
    clearChatMessages();
    
    // Load messages
    chatHistory = messages;
    messages.forEach(message => {
      appendMessage(message.text, message.isUser, new Date(message.timestamp));
    });
    
    // Update session title
    const chatTitle = document.querySelector('.chat-title h2');
    if (chatTitle) {
      chatTitle.textContent = currentSession.title;
    }
    
    scrollToBottom();
    
  } catch (error) {
    console.error('Error loading chat session:', error);
    showNotification('Failed to load chat session', 'error');
  }
}

// Start new chat
function startNewChat() {
  currentSessionId = null;
  chatHistory = [];
  clearChatMessages();
  showWelcomeMessage(isAuthenticated());
  
  // Reset chat title
  const chatTitle = document.querySelector('.chat-title h2');
  if (chatTitle) {
    chatTitle.textContent = 'Boboto Academic & Career Assistant';
  }
}

// Save chat session
async function saveChatSession() {
  if (!isAuthenticated()) {
    showNotification('Please log in to save conversations', 'info');
    return;
  }
  
  if (!currentSessionId) {
    showNotification('No chat session to save', 'info');
    return;
  }
  
  try {
    await API.Chat.saveSessionAsFavorite(currentSessionId);
    showNotification('Chat saved to favorites', 'success');
    updateChatHistorySidebar();
  } catch (error) {
    console.error('Error saving chat session:', error);
    showNotification('Failed to save chat session', 'error');
  }
}

// Append a message to the chat
function appendMessage(text, isUser, timestamp) {
  if (!chatMessages) return;
  
  // Create message element
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${isUser ? 'user' : 'bot'}`;
  
  // Process markdown in bot messages
  const messageContent = isUser ? text : processMarkdown(text);
  
  // Format timestamp
  const timeString = formatTimestamp(timestamp);
  
  // Set message content
  messageDiv.innerHTML = `
    <p>${messageContent}</p>
    <div class="message-timestamp">${timeString}</div>
  `;
  
  // Add to chat
  chatMessages.appendChild(messageDiv);
  
  // Scroll to bottom
  scrollToBottom();
}

// Show typing indicator
function showTypingIndicator() {
  if (!chatMessages) return;
  
  const typingDiv = document.createElement('div');
  typingDiv.className = 'message bot typing-indicator';
  typingDiv.innerHTML = `
    <div class="typing-dots">
      <span></span>
      <span></span>
      <span></span>
    </div>
  `;
  
  chatMessages.appendChild(typingDiv);
  scrollToBottom();
}

// Remove typing indicator
function removeTypingIndicator() {
  const typingIndicator = document.querySelector('.typing-indicator');
  if (typingIndicator) {
    typingIndicator.remove();
  }
}

// Clear all chat messages
function clearChatMessages() {
  if (chatMessages) {
    chatMessages.innerHTML = '';
  }
}

// Scroll chat to bottom
function scrollToBottom() {
  if (chatMessages) {
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }
}

// Process markdown in bot messages
function processMarkdown(text) {
  if (!text) return '';
  
  // Replace code blocks
  text = text.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
  
  // Replace inline code
  text = text.replace(/`([^`]+)`/g, '<code>$1</code>');
  
  // Replace bold text
  text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  
  // Replace italic text
  text = text.replace(/\*([^*]+)\*/g, '<em>$1</em>');
  
  // Convert URLs to links
  text = text.replace(
    /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|])/ig,
    '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>'
  );
  
  // Convert line breaks to <br>
  text = text.replace(/\n/g, '<br>');
  
  return text;
}

// Format timestamp
function formatTimestamp(timestamp) {
  if (!timestamp) return '';
  
  const date = new Date(timestamp);
  const now = new Date();
  const isToday = date.getDate() === now.getDate() && 
                date.getMonth() === now.getMonth() &&
                date.getFullYear() === now.getFullYear();
  
  const options = { hour: 'numeric', minute: 'numeric' };
  
  if (isToday) {
    return date.toLocaleTimeString([], options);
  } else {
    return date.toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric', 
      hour: 'numeric', 
      minute: 'numeric' 
    });
  }
}

// Setup tab switching
function setupTabSwitching() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabContents = document.querySelectorAll('.sidebar-content');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      
      // Remove active class from all buttons and contents
      tabButtons.forEach(b => b.classList.remove('active'));
      tabContents.forEach(c => c.classList.remove('active'));
      
      // Add active class to current button and content
      button.classList.add('active');
      document.getElementById(tabId).classList.add('active');
      
      // Load history when history tab is clicked
      if (tabId === 'history' && isAuthenticated()) {
        updateChatHistorySidebar();
      }
    });
  });
}

// Update chat history sidebar
async function updateChatHistorySidebar() {
  if (!isAuthenticated()) return;
  
  try {
    const sessions = await API.Chat.getSessions();
    
    // Update recent sessions
    const recentSessions = sessions.slice(0, 5);
    updateHistoryDisplay('recent-sessions', recentSessions);
    
    // Update saved sessions
    const savedSessions = sessions.filter(s => s.isSaved).slice(0, 5);
    updateHistoryDisplay('saved-sessions', savedSessions);
    
  } catch (error) {
    console.error('Error updating chat history sidebar:', error);
  }
}

// Update history display
function updateHistoryDisplay(containerId, sessions) {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  container.innerHTML = '';
  
  if (sessions.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>No conversations yet.</p></div>';
    return;
  }
  
  sessions.forEach(session => {
    const sessionElement = createHistoryItem(session);
    container.appendChild(sessionElement);
  });
}

// Create history item element
function createHistoryItem(session) {
  const div = document.createElement('div');
  div.className = 'history-item';
  div.innerHTML = `
    <div class="history-content">
      <h4>${session.title}</h4>
      <p>${formatDate(session.lastUpdated)}</p>
    </div>
    <div class="history-actions">
      <button onclick="loadChatSession('${session._id}')" title="Open">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
          <polyline points="15 3 21 3 21 9"></polyline>
          <line x1="10" y1="14" x2="21" y2="3"></line>
        </svg>
      </button>
    </div>
  `;
  return div;
}

// Format date helper
function formatDate(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) {
    return 'Today';
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays < 7) {
    return `${diffDays} days ago`;
  } else {
    return date.toLocaleDateString();
  }
}

// Load the most recent chat session
async function loadRecentChatSession() {
  if (!isAuthenticated()) return;
  
  try {
    const sessions = await API.Chat.getSessions();
    
    if (sessions && sessions.length > 0) {
      // Get the most recent session
      const recentSession = sessions[0];
      await loadChatSession(recentSession._id);
    }
  } catch (error) {
    console.error('Error loading recent session:', error);
  }
}

// Setup history search
function setupHistorySearch() {
  const searchInput = document.querySelector('#history .search-input');
  if (!searchInput) return;
  
  searchInput.addEventListener('input', async () => {
    if (!isAuthenticated()) return;
    
    const searchTerm = searchInput.value.trim();
    
    if (searchTerm) {
      try {
        const searchResults = await API.Chat.searchSessions(searchTerm);
        updateHistoryDisplay('recent-sessions', searchResults);
      } catch (error) {
        console.error('Error searching sessions:', error);
      }
    } else {
      // If search is empty, show all recent sessions
      updateChatHistorySidebar();
    }
  });
}

// Setup theme variables
function setupThemeVariables() {
  const root = document.documentElement;
  
  // Get primary color from settings or use default
  const primaryColor = localStorage.getItem('theme_primary_color') || '#2563eb';
  
  // Set CSS variables
  root.style.setProperty('--primary-color', primaryColor);
  
  // Set dark/light theme
  const isDarkMode = localStorage.getItem('theme_dark_mode') === 'true';
  if (isDarkMode) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
}

// Make functions globally available
window.loadChatSession = loadChatSession;
window.sendMessage = sendMessage;