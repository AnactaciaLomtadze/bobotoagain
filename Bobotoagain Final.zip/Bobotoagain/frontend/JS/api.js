// JS/api.js 
// API service for Boboto frontend

// Function to get API URL at runtime
function getApiUrl() {
  // First check if serverConfig is available
  if (typeof window !== 'undefined' && window.serverConfig && window.serverConfig.apiUrl) {
    console.log('[API] Using serverConfig API URL:', window.serverConfig.apiUrl);
    return window.serverConfig.apiUrl;
  }
  
  // Fallback to environment detection
  const isLocalhost = window.location.hostname === 'localhost' || 
                     window.location.hostname === '127.0.0.1' || 
                     window.location.hostname === '';
  
  const isFileProtocol = window.location.protocol === 'file:';
  const isHttpLocalhost = window.location.protocol === 'http:' && window.location.hostname === 'localhost';
  
  // If we're running from file protocol or localhost, connect to backend on port 3000
  if (isFileProtocol || isHttpLocalhost || isLocalhost) {
    // Your backend is running on port 3000, so we use that
    console.log('[API] Detected development environment, using localhost:3000');
    return 'http://localhost:3000/api';
  } else {
    console.log('[API] Using relative API URL for production');
    return '/api';
  }
}

// General API error handler
const handleApiError = (error) => {
  console.error('API Error:', error);
  
  if (error.response) {
    // Server responded with an error status
    return Promise.reject({
      status: error.response.status,
      message: error.response.data?.message || error.response.data || 'An error occurred'
    });
  } else if (error.request) {
    // Request was made but no response received
    console.error('No response from server. Check if backend is running on http://localhost:3000');
    return Promise.reject({
      status: 0,
      message: 'No response from server. Please check your connection.'
    });
  } else {
    // Something else caused an error
    return Promise.reject({
      status: 0,
      message: error.message || 'An unexpected error occurred'
    });
  }
};

// DeepSeek API error handler with more detail
const handleDeepSeekError = (error) => {
  console.error('DeepSeek API error details:', {
    message: error.message,
    status: error.status,
    response: error.response,
    stack: error.stack
  });
  
  // Return a user-friendly error message
  let userMessage = 'AI service temporarily unavailable. ';
  
  if (error.status === 401) {
    userMessage += 'Please check your API authentication.';
  } else if (error.status === 429) {
    userMessage += 'Rate limit exceeded. Please try again later.';
  } else if (error.status >= 500) {
    userMessage += 'Server error. Please try again in a few moments.';
  } else {
    userMessage += 'Please try again later.';
  }
  
  return {
    success: false,
    error: userMessage,
    details: error.message
  };
};

// Main API object
const API = {
  // Authentication methods
  Auth: {
    register: async (email, password, fullName, academicLevel, graduationYear, major, university) => {
      try {
        const apiUrl = getApiUrl();
        console.log('[API] Register URL:', `${apiUrl}/auth/register`);
        
        const response = await fetch(`${apiUrl}/auth/register`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ 
            email, 
            password, 
            fullName,
            academicLevel,
            graduationYear,
            major,
            university
          })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    login: async (email, password) => {
      try {
        const apiUrl = getApiUrl(); // Get URL at runtime
        console.log('[API] Login URL:', `${apiUrl}/auth/login`);
        
        const response = await fetch(`${apiUrl}/auth/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    googleLogin: async (idToken) => {
      try {
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/auth/google`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ idToken })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    forgotPassword: async (email) => {
      try {
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/auth/forgot-password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    resetPassword: async (resetToken, password) => {
      try {
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/auth/reset-password/${resetToken}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ password })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    changePassword: async (currentPassword, newPassword) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/auth/change-password`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ currentPassword, newPassword })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getCurrentUser: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/auth`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // Profile methods
  Profile: {
    get: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    update: async (profileData) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(profileData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getLearningPreferences: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/learning-preferences`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    updateLearningPreferences: async (preferences) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/learning-preferences`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(preferences)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getCareerGoals: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/career-goals`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    updateCareerGoals: async (goals) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/career-goals`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(goals)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getSkills: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/skills`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    addSkill: async (name, level) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/skills`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ name, level })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    removeSkill: async (skillId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/skills/${skillId}`, {
          method: 'DELETE',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    uploadProfilePicture: async (formData) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/profile/upload-picture`, {
          method: 'POST',
          headers: {
            'x-auth-token': token
          },
          body: formData
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // Chat methods
  Chat: {
    getSessions: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    createSession: async (title) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ title })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getMessages: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions/${sessionId}/messages`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    addMessage: async (sessionId, text, isUser = true) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions/${sessionId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ text, isUser })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    deleteSession: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions/${sessionId}`, {
          method: 'DELETE',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    saveSessionAsFavorite: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions/${sessionId}/save`, {
          method: 'PUT',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    removeSessionFromFavorites: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/sessions/${sessionId}/unsave`, {
          method: 'PUT',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    searchSessions: async (searchTerm) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/chat/search?searchTerm=${encodeURIComponent(searchTerm)}`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // Academic methods
  Academic: {
    askQuestion: async (subject, question, difficulty) => {
      try {
        const token = localStorage.getItem('auth_token');
        if (!token) throw new Error('No authentication token found');

        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/academic/question`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ subject, question, difficulty })
        });

        const data = await response.json();
        if (!response.ok) throw { response: { status: response.status, data } };
        return data.response;
      } catch (error) {
        return handleApiError(error);
      }
    },

    explainConcept: async (concept, context, breakdownLevel) => {
      try {
        const token = localStorage.getItem('auth_token');
        if (!token) throw new Error('No authentication token found');

        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/academic/explain`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ concept, context, breakdownLevel })
        });

        const data = await response.json();
        if (!response.ok) throw { response: { status: response.status, data } };
        return data.response;
      } catch (error) {
        return handleApiError(error);
      }
    },

    recommendMaterials: async (topic, materialTypes, learningLevel) => {
      try {
        const token = localStorage.getItem('auth_token');
        if (!token) throw new Error('No authentication token found');

        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/academic/materials`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ topic, materialTypes, learningLevel })
        });

        const data = await response.json();
        if (!response.ok) throw { response: { status: response.status, data } };
        return data.response;
      } catch (error) {
        return handleApiError(error);
      }
    },

    assignmentHelp: async (assignment, question, type) => {
      try {
        const token = localStorage.getItem('auth_token');
        if (!token) throw new Error('No authentication token found');

        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/academic/assignment-help`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ assignment, question, type })
        });

        const data = await response.json();
        if (!response.ok) throw { response: { status: response.status, data } };
        return data.response;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    // Get learning resources
    getLearningResources: async (topic, format) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/academic/resources?topic=${encodeURIComponent(topic)}&format=${format || 'all'}`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // DeepSeek AI methods
  AI: {
    // Generate response using DeepSeek
    generateResponse: async (message, chatHistory) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        console.log('AI.generateResponse - API URL:', apiUrl);
        console.log('AI.generateResponse - Message:', message);
        console.log('AI.generateResponse - Chat History:', chatHistory);
        
        const response = await fetch(`${apiUrl}/ai/chat`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ 
            message, 
            chatHistory: chatHistory || []
          })
        });
        
        console.log('AI.generateResponse - Response status:', response.status);
        console.log('AI.generateResponse - Response ok:', response.ok);
        
        if (!response.ok) {
          const errorData = await response.text();
          console.error('AI.generateResponse - Error data:', errorData);
          throw new Error(`AI API returned ${response.status}: ${errorData}`);
        }
        
        const data = await response.json();
        console.log('AI.generateResponse - Response data:', data);
        
        // Return the response directly
        return data.response || data;
      } catch (error) {
        console.error('DeepSeek API error:', error);
        throw error;
      }
    },
    
    // Get AI settings
    getSettings: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/ai/settings`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    // Update AI settings
    updateSettings: async (settings) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const apiUrl = getApiUrl();
        const response = await fetch(`${apiUrl}/ai/settings`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(settings)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    // Get fallback response when API fails
    getFallbackResponse: (message) => {
      const lowerMsg = message.toLowerCase();
      
      if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
        return "Hello! I'm Boboto, your academic and career assistant powered by DeepSeek AI. How can I help you today?";
      } else if (lowerMsg.includes('study plan') || lowerMsg.includes('learning plan')) {
        return "Creating an effective study plan involves understanding your goals, current skill level, and learning style. I'd recommend starting with a clear objective, breaking it down into smaller topics, and allocating time for regular practice and revision. Would you like me to help you create a more detailed study plan for a specific subject?";
      } else if (lowerMsg.includes('career') || lowerMsg.includes('job')) {
        return "The tech field offers many career paths. Based on current trends, roles in AI/ML, cloud architecture, cybersecurity, and full-stack development are particularly in demand. To help you further, could you tell me more about your interests and current skills?";
      } else {
        return "I'm here to help with your academic and career development. Could you tell me more about what you're looking to learn or achieve? Feel free to ask about study plans, career paths, skill development, or interview preparation.";
      }
    }
  }
};

// Authentication utilities for localStorage
// Store auth data in localStorage
function setAuthData(token, user) {
  localStorage.setItem('auth_token', token);
  localStorage.setItem('user_info', JSON.stringify(user));
}

// Clear auth data from localStorage
function clearAuthData() {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_info');
  localStorage.removeItem('learning_preferences');
  localStorage.removeItem('career_goals');
  localStorage.removeItem('user_skills');
  localStorage.removeItem('offline_changes');
}

// Show notification
function showNotification(message, type = 'info') {
  // Create notification element if it doesn't exist
  let notificationContainer = document.querySelector('.notification-container');
  
  if (!notificationContainer) {
    notificationContainer = document.createElement('div');
    notificationContainer.className = 'notification-container';
    document.body.appendChild(notificationContainer);
  }
  
  // Create notification
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</span>
    </div>
    <button class="notification-close">&times;</button>
  `;
  
  // Add to container
  notificationContainer.appendChild(notification);
  
  // Add close button functionality
  const closeBtn = notification.querySelector('.notification-close');
  closeBtn.addEventListener('click', () => {
    notification.classList.add('closing');
    setTimeout(() => {
      notificationContainer.removeChild(notification);
    }, 300);
  });
  
  // Auto close after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.classList.add('closing');
      setTimeout(() => {
        if (notification.parentNode) {
          notificationContainer.removeChild(notification);
        }
      }, 300);
    }
  }, 5000);
}

// 5. Debug checklist - Add this to help troubleshoot
function debugDeepSeekIntegration() {
  console.log('=== DeepSeek Integration Debug ===');
  
  // 1. Check environment variables (backend)
  console.log('1. Environment Variables (check backend console):');
  console.log('   - OPENROUTER_API_KEY should be set');
  
  // 2. Check frontend configuration
  console.log('2. Frontend Configuration:');
  console.log('   - serverConfig:', window.serverConfig);
  console.log('   - API URL:', window.serverConfig?.apiUrl);
  
  // 3. Check authentication
  console.log('3. Authentication:');
  const token = localStorage.getItem('auth_token');
  console.log('   - Auth token exists:', !!token);
  console.log('   - Token length:', token?.length);
  
  // 4. Test API connectivity
  console.log('4. Testing API endpoints...');
  testApiEndpoints();
}

async function testApiEndpoints() {
  const token = localStorage.getItem('auth_token');
  
  if (!token) {
    console.log('   - Cannot test API endpoints: No auth token');
    return;
  }
  
  try {
    // Test AI endpoint
    const aiTestResponse = await fetch(`${window.serverConfig.apiUrl}/ai/test`, {
      headers: { 'x-auth-token': token }
    });
    console.log('   - AI endpoint test:', aiTestResponse.ok ? 'Success' : 'Failed', aiTestResponse.status);
    
    // Test chat endpoint with a simple message
    const chatTestResponse = await fetch(`${window.serverConfig.apiUrl}/ai/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': token
      },
      body: JSON.stringify({
        message: 'Hello, test message',
        chatHistory: []
      })
    });
    console.log('   - Chat endpoint test:', chatTestResponse.ok ? 'Success' : 'Failed', chatTestResponse.status);
    
    if (!chatTestResponse.ok) {
      const errorData = await chatTestResponse.text();
      console.log('   - Chat endpoint error:', errorData);
    }
  } catch (error) {
    console.error('   - API test error:', error);
  }
}


// Add a debug function to verify configuration
function debugApiConfig() {
  console.log('[API DEBUG] serverConfig:', window.serverConfig);
  console.log('[API DEBUG] Current URL:', window.location.href);
  console.log('[API DEBUG] Detected API URL:', getApiUrl());
}

// Make debug function available globally
window.debugApiConfig = debugApiConfig;

// Export functions to window for global access
window.API = API;
window.setAuthData = setAuthData;
window.clearAuthData = clearAuthData;
window.showNotification = showNotification;
window.debugDeepSeekIntegration = debugDeepSeekIntegration;
window.testApiEndpoints = testApiEndpoints;