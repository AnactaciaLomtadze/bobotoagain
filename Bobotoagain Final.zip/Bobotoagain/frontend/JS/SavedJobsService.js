// Example usage in React components

// SavedJobsService.js - Frontend service for saved jobs
export class SavedJobsService {
    static async getSavedJobs() {
      try {
        const token = localStorage.getItem('auth_token');
        const response = await fetch('/api/career/saved-jobs', {
          headers: {
            'x-auth-token': token
          }
        });
  
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
  
        return await response.json();
      } catch (error) {
        console.error('Error getting saved jobs:', error);
        throw error;
      }
    }
  
    static async saveJob(jobData) {
      try {
        const token = localStorage.getItem('auth_token');
        const response = await fetch('/api/career/save-job', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(jobData)
        });
  
        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.message || `Error: ${response.status}`);
        }
  
        return await response.json();
      } catch (error) {
        console.error('Error saving job:', error);
        throw error;
      }
    }
  
    static async removeSavedJob(jobId) {
      try {
        const token = localStorage.getItem('auth_token');
        const response = await fetch(`/api/career/saved-jobs/${jobId}`, {
          method: 'DELETE',
          headers: {
            'x-auth-token': token
          }
        });
  
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
  
        return await response.json();
      } catch (error) {
        console.error('Error removing saved job:', error);
        throw error;
      }
    }
  
    static async updateJobApplication(jobId, status, notes) {
      try {
        const token = localStorage.getItem('auth_token');
        const response = await fetch(`/api/career/job-applications/${jobId}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ status, notes })
        });
  
        if (!response.ok) {
          throw new Error(`Error: ${response.status}`);
        }
  
        return await response.json();
      } catch (error) {
        console.error('Error updating job application:', error);
        throw error;
      }
    }
  }
  
  // Example React Component using the service
  import React, { useState, useEffect } from 'react';
  import { SavedJobsService } from '../services/SavedJobsService';
  import LoadingSpinner from './LoadingSpinner';
  
  const SavedJobsList = () => {
    const [savedJobs, setSavedJobs] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
  
    useEffect(() => {
      loadSavedJobs();
    }, []);
  
    const loadSavedJobs = async () => {
      try {
        setLoading(true);
        const jobs = await SavedJobsService.getSavedJobs();
        setSavedJobs(jobs);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
  
    const handleRemoveJob = async (jobId) => {
      try {
        await SavedJobsService.removeSavedJob(jobId);
        setSavedJobs(savedJobs.filter(job => job.jobId !== jobId));
      } catch (err) {
        setError(err.message);
      }
    };
  
    const handleStatusUpdate = async (jobId, newStatus) => {
      try {
        await SavedJobsService.updateJobApplication(jobId, newStatus);
        setSavedJobs(savedJobs.map(job => 
          job.jobId === jobId 
            ? { ...job, applicationStatus: newStatus }
            : job
        ));
      } catch (err) {
        setError(err.message);
      }
    };
  
    if (loading) return <LoadingSpinner />;
    if (error) return <div className="error">Error: {error}</div>;
  
    return (
      <div className="saved-jobs-list">
        <h2>Saved Jobs ({savedJobs.length})</h2>
        {savedJobs.map(job => (
          <div key={job.jobId} className="job-card">
            <h3>{job.title}</h3>
            <p>{job.company} - {job.location}</p>
            <select 
              value={job.applicationStatus || 'saved'}
              onChange={(e) => handleStatusUpdate(job.jobId, e.target.value)}
            >
              <option value="saved">Saved</option>
              <option value="applied">Applied</option>
              <option value="interviewing">Interviewing</option>
              <option value="rejected">Rejected</option>
              <option value="offer">Offer</option>
              <option value="hired">Hired</option>
            </select>
            <button onClick={() => handleRemoveJob(job.jobId)}>
              Remove
            </button>
          </div>
        ))}
      </div>
    );
  };
  
  export default SavedJobsList;