// JS/auth.js
/**
 * Enhanced auth.js - Authentication functionality for Boboto
 */

// DOM elements
const menuToggle = document.querySelector('.menu-toggle');
const navMenu = document.querySelector('.nav-menu');
const passwordToggles = document.querySelectorAll('.toggle-password');

// Menu toggle for mobile nav
if (menuToggle) {
  menuToggle.addEventListener('click', () => {
    const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', !expanded);
    navMenu.classList.toggle('active');
  });
}

// Password visibility toggle
if (passwordToggles.length > 0) {
  passwordToggles.forEach(toggle => {
    toggle.addEventListener('click', function() {
      const input = this.parentNode.querySelector('input');
      const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
      input.setAttribute('type', type);
      
      // Toggle icon class if needed for visual feedback
      const eyeIcon = this.querySelector('.eye-icon');
      if (eyeIcon) {
        eyeIcon.classList.toggle('visible');
      }
    });
  });
}

// Check if user is authenticated
function isAuthenticated() {
  return !!getToken();
}

// Get authentication token from local storage
function getToken() {
  return localStorage.getItem('auth_token');
}

// Get user info from local storage
function getUserInfo() {
  const userInfo = localStorage.getItem('user_info');
  return userInfo ? JSON.parse(userInfo) : null;
}

// Set authentication data
function setAuthData(token, user) {
  localStorage.setItem('auth_token', token);
  localStorage.setItem('user_info', JSON.stringify(user));
}

// Clear authentication data
function clearAuthData() {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_info');
  // Also clear any other user-related data
  localStorage.removeItem('learning_preferences');
  localStorage.removeItem('career_goals');
  localStorage.removeItem('user_skills');
}

// Check auth status and update UI accordingly
function updateAuthUI() {
  const authButtons = document.querySelector('.auth-buttons');
  const isLoggedIn = isAuthenticated();
  
  if (!authButtons) return;
  
  if (isLoggedIn) {
    // If user is logged in, show user menu dropdown
    const user = getUserInfo();
    authButtons.innerHTML = `
      <div class="user-menu">
        <button class="btn btn-user" id="user-menu-btn">
          <img src="${user?.profilePictureUrl || '/images/default-avatar.png'}" alt="Profile" class="avatar-mini">
          <span>${user?.fullName?.split(' ')[0] || 'User'}</span>
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="18" height="18" class="dropdown-arrow">
            <path fill="none" d="M0 0h24v24H0z"/>
            <path d="M12 15l-4.243-4.243 1.415-1.414L12 12.172l2.828-2.829 1.415 1.414z" fill="currentColor"/>
          </svg>
        </button>
        <div class="user-dropdown" id="userMenuDropdown">
          <a href="bobotoProfile.html"><span class="menu-icon">👤</span> My Profile</a>
          <a href="bobotoSettings.html"><span class="menu-icon">⚙️</span> Settings</a>
          <div class="dropdown-divider"></div>
          <a href="#" id="signout-btn"><span class="menu-icon">🚪</span> Sign Out</a>
        </div>
      </div>
    `;
    
    // Add the dropdown toggle functionality
    const userMenuBtn = document.getElementById('user-menu-btn');
    if (userMenuBtn) {
      userMenuBtn.addEventListener('click', toggleUserMenu);
    }
    
    // Set up sign out listener
    setupSignOutListener();
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(event) {
      const dropdown = document.getElementById('userMenuDropdown');
      const userMenu = document.querySelector('.user-menu');
      
      if (dropdown && userMenu && !userMenu.contains(event.target) && dropdown.classList.contains('active')) {
        dropdown.classList.remove('active');
      }
    });
  } else {
    // If user is not logged in, show login and signup buttons
    const currentPath = window.location.pathname;
    const isLoginPage = currentPath.includes('Login');
    const isSignupPage = currentPath.includes('Signup');
    
    // Adjust paths based on current location
    const loginPath = currentPath.includes('/HTML/') ? 'bobotoLogin.html' : 'HTML/bobotoLogin.html';
    const signupPath = currentPath.includes('/HTML/') ? 'bobotoSignup.html' : 'HTML/bobotoSignup.html';
    
    authButtons.innerHTML = `
      <a href="${loginPath}" class="btn btn-login ${isLoginPage ? 'active' : ''}">Log In</a>
      <a href="${signupPath}" class="btn btn-signup ${isSignupPage ? 'active' : ''}">Sign Up</a>
    `;
  }
}

// Toggle user menu dropdown
function toggleUserMenu() {
  const dropdown = document.getElementById('userMenuDropdown');
  if (dropdown) {
    dropdown.classList.toggle('active');
  }
}

// Logout function
function logout() {
  console.log('Logging out...');
  
  // Clear authentication data
  clearAuthData();
  
  // Show success message
  showNotification('You have been successfully signed out', 'success');
  
  // Find the correct path to redirect to
  const currentPath = window.location.pathname;
  let redirectPath;
  
  if (currentPath.includes('/HTML/')) {
    redirectPath = '../bobotoMain.html';
  } else {
    redirectPath = 'bobotoMain.html';
  }
  
  console.log('Redirecting to:', redirectPath);
  
  // Redirect to main page
  setTimeout(() => {
    window.location.href = redirectPath;
  }, 1000);
}

// Event listener for sign out button
function setupSignOutListener() {
  // Look for the sign-out button after DOM content loaded or after auth UI update
  const signOutBtn = document.getElementById('signout-btn');
  if (signOutBtn) {
    console.log('Sign-out button found, attaching click event');
    signOutBtn.addEventListener('click', function(event) {
      console.log('Sign-out button clicked');
      event.preventDefault();
      logout();
    });
  } else {
    console.log('Sign-out button not found');
  }
}

// Protect authenticated pages
function protectPage() {
  if (!isAuthenticated()) {
    // Determine the correct path to the login page
    const currentPath = window.location.pathname;
    let loginPath;
    
    if (currentPath.includes('/HTML/')) {
      loginPath = 'bobotoLogin.html';
    } else {
      loginPath = 'HTML/bobotoLogin.html';
    }
    
    window.location.href = loginPath;
  }
}

// Check if current page is an authenticated page
function isAuthenticatedPage() {
  const authenticatedPages = [
    'bobotoProfile.html',
    'bobotoPersonal.html',
    'bobotoLearning.html',
    'bobotoCareer.html',
    'bobotoChatHistory.html',
    'bobotoSkill.html',
    'bobotoSettings.html',
    'bobotoChat.html'
  ];
  
  const currentPage = window.location.pathname.split('/').pop();
  return authenticatedPages.includes(currentPage);
}

// Handle login form submission
async function handleLogin(event) {
  event.preventDefault();
  
  // Get form inputs
  const emailInput = document.getElementById('email');
  console.log('Email input:', emailInput?.value);
  const passwordInput = document.getElementById('password');
  
  // Clear previous error messages
  clearInputError(emailInput);
  clearInputError(passwordInput);
  
  // Validate inputs
  let isValid = true;
  
  if (!emailInput.value.trim()) {
    showInputError(emailInput, 'Email is required');
    isValid = false;
  } else if (!isValidEmail(emailInput.value.trim())) {
    showInputError(emailInput, 'Please enter a valid email address');
    isValid = false;
  }
  
  if (!passwordInput.value) {
    showInputError(passwordInput, 'Password is required');
    isValid = false;
  }
  
  if (!isValid) {
    return;
  }
  
  // Show loading state
  const submitBtn = event.target.querySelector('button[type="submit"]');
  const originalBtnText = submitBtn.textContent;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Logging in...';
  
  try {
    console.log('Attempting to log in...');
    
    // Call login API - FIXED: Only pass email and password
    const result = await API.Auth.login(
      emailInput.value.trim(),
      passwordInput.value
    );
    
    if (result && result.token) {
      // Save authentication data
      setAuthData(result.token, result.user);
      
      // Show success message
      showNotification('Login successful! Redirecting...', 'success');
      
      // Redirect to profile page
      setTimeout(() => {
        const redirectPath = window.location.pathname.includes('/HTML/') 
          ? 'bobotoProfile.html' 
          : 'HTML/bobotoProfile.html';
        window.location.href = redirectPath;
      }, 1000);
    } else {
      throw new Error('Invalid response from server');
    }
  } catch (error) {
    console.error('Login error:', error);
    
    // Reset button state
    submitBtn.disabled = false;
    submitBtn.textContent = originalBtnText;
    
    // Show error message
    showNotification(error.message || 'Login failed. Please check your credentials.', 'error');
  }
}

// Fixed handleSignup function (around line 433 in auth.js)
async function handleSignup(event) {
  event.preventDefault();
  
  // Get form inputs
  const nameInput = document.getElementById('full-name');
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const confirmPasswordInput = document.getElementById('confirm-password');
  const termsCheckbox = document.getElementById('terms');
  const academicLevelInput = document.getElementById('academic-level');
  const graduationYearInput = document.getElementById('graduation-year');
  const majorInput = document.getElementById('major');
  const universityInput = document.getElementById('university');

  // Clear previous error messages
  clearInputError(nameInput);
  clearInputError(emailInput);
  clearInputError(passwordInput);
  clearInputError(confirmPasswordInput);
  clearInputError(academicLevelInput);
  clearInputError(graduationYearInput);
  clearInputError(majorInput);
  clearInputError(universityInput);
  const termsError = document.getElementById('terms-error');
  if (termsError) termsError.style.display = 'none';
  
  // Validate inputs - THIS IS WHAT WAS MISSING
  let isValid = true;
  
  if (!nameInput.value.trim()) {
    showInputError(nameInput, 'Full name is required');
    isValid = false;
  }

  if (!academicLevelInput.value.trim()) {
    showInputError(academicLevelInput, 'Academic level is required');
    isValid = false;
  }
  
  if (!graduationYearInput.value.trim()) {
    showInputError(graduationYearInput, 'Graduation year is required');
    isValid = false;
  }
  
  if (!majorInput.value.trim()) {
    showInputError(majorInput, 'Major is required');
    isValid = false;
  }
  
  if (!universityInput.value.trim()) {
    showInputError(universityInput, 'University is required');
    isValid = false;
  }
  
  if (!emailInput.value.trim()) {
    showInputError(emailInput, 'Email is required');
    isValid = false;
  } else if (!isValidEmail(emailInput.value.trim())) {
    showInputError(emailInput, 'Please enter a valid email address');
    isValid = false;
  }

  if (!passwordInput.value) {
    showInputError(passwordInput, 'Password is required');
    isValid = false;
  } else if (passwordInput.value.length < 6) {
    showInputError(passwordInput, 'Password must be at least 6 characters long');
    isValid = false;
  }
  
  if (!confirmPasswordInput.value) {
    showInputError(confirmPasswordInput, 'Please confirm your password');
    isValid = false;
  } else if (passwordInput.value !== confirmPasswordInput.value) {
    showInputError(confirmPasswordInput, 'Passwords do not match');
    isValid = false;
  }
  
  if (termsCheckbox && !termsCheckbox.checked) {
    if (termsError) {
      termsError.textContent = 'You must accept the terms and conditions';
      termsError.style.display = 'block';
    }
    isValid = false;
  }
  
  // Now isValid is properly defined
  if (!isValid) {
    return;
  }
  
  // Show loading state
  const submitBtn = event.target.querySelector('button[type="submit"]');
  const originalBtnText = submitBtn.textContent;
  submitBtn.disabled = true;
  submitBtn.textContent = 'Creating account...';
  
  try {
    console.log('Attempting to register user...');
    
    // Call register API with all required parameters in the correct order
    const result = await API.Auth.register(
      emailInput.value.trim(),         // email
      passwordInput.value,             // password
      nameInput.value.trim(),          // fullName
      academicLevelInput.value.trim(), // academicLevel
      graduationYearInput.value.trim(),// graduationYear
      majorInput.value.trim(),         // major
      universityInput.value.trim()     // university
    );
    
    if (result && result.token) {
      // Save authentication data
      setAuthData(result.token, result.user);
      
      // Show success message
      showNotification('Account created successfully! Redirecting...', 'success');
      
      // Redirect to profile page
      setTimeout(() => {
        const redirectPath = window.location.pathname.includes('/HTML/') 
          ? 'bobotoProfile.html' 
          : 'HTML/bobotoProfile.html';
        window.location.href = redirectPath;
      }, 1000);
    } else {
      throw new Error('Invalid response from server');
    }
  } catch (error) {
    // Reset button state
    submitBtn.disabled = false;
    submitBtn.textContent = originalBtnText;
    
    // Show error message
    showNotification(error.message || 'Registration failed. Please try again.', 'error');
  }
}

async function handleGoogleAuth() {
  try {
    console.log('Starting Google authentication...');
    
    // Ensure GAPI is loaded
    if (typeof gapi === 'undefined') {
      throw new Error('Google API not loaded. Make sure the Google API script is included in your HTML.');
    }
    
    // Get Google Auth instance
    const auth2 = await gapi.auth2.getAuthInstance();
    
    if (!auth2) {
      throw new Error('Google Auth2 instance not found');
    }
    
    console.log('Google Auth2 instance ready');
    
    // Sign in with Google and get user
    const googleUser = await auth2.signIn();
    console.log('Google sign-in successful');
    
    // Get ID token
    const idToken = googleUser.getAuthResponse().id_token;
    
    if (!idToken) {
      throw new Error('Failed to get Google ID token');
    }
    
    console.log('Got Google ID token, sending to server...');
    
    // Show loading indicator
    showNotification('Authenticating with Google...', 'info');
    
    // Send token to backend
    const response = await fetch(`${window.serverConfig.apiUrl}/auth/google`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ idToken })
    });
    
    console.log('Server response status:', response.status);
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Authentication failed');
    }
    
    if (data && data.token) {
      console.log('Authentication successful, saving data...');
      
      // Save authentication data
      setAuthData(data.token, data.user);
      
      // Show success message
      showNotification('Google login successful! Redirecting...', 'success');
      
      // Redirect to profile page
      setTimeout(() => {
        const redirectPath = window.location.pathname.includes('/HTML/') 
          ? 'bobotoProfile.html' 
          : 'HTML/bobotoProfile.html';
        window.location.href = redirectPath;
      }, 1000);
    } else {
      throw new Error('Invalid response from server');
    }
  } catch (error) {
    console.error('Detailed Google auth error:', error);
    
    // Enhanced error messages
    let userMessage = 'Google authentication failed. ';
    
    if (error.message.includes('not loaded')) {
      userMessage += 'Google services could not be loaded. Please check your internet connection.';
    } else if (error.message.includes('popup_blocked')) {
      userMessage += 'Pop-up was blocked. Please allow pop-ups for this site.';
    } else if (error.message.includes('access_denied')) {
      userMessage += 'You denied access. Please try again and grant permission.';
    } else {
      userMessage += error.message || 'Please try again.';
    }
    
    showNotification(userMessage, 'error');
  }
}

// Handle forgot password
async function handleForgotPassword(event) {
  if (event) event.preventDefault();
  
  const emailInput = document.getElementById('reset-email');
  
  if (!emailInput || !emailInput.value.trim()) {
    showNotification('Please enter your email address', 'error');
    return;
  }
  
  if (!isValidEmail(emailInput.value.trim())) {
    showNotification('Please enter a valid email address', 'error');
    return;
  }
  
  try {
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    if (submitBtn) {
      const originalBtnText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending...';
      
      // Reset button state after operation completes
      setTimeout(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = originalBtnText;
      }, 3000);
    }
    
    // Call forgot password API
    const result = await API.Auth.forgotPassword(emailInput.value.trim());
    
    // Show success message
    showNotification('Password reset instructions have been sent to your email', 'success');
    
    // Hide forgot password form and show message
    const forgotForm = document.getElementById('forgot-password-form');
    const successMsg = document.getElementById('reset-success-message');
    
    if (forgotForm && successMsg) {
      forgotForm.style.display = 'none';
      successMsg.style.display = 'block';
    }
  } catch (error) {
    console.error('Forgot password error:', error);
    showNotification(error.message || 'Failed to send reset email. Please try again.', 'error');
  }
}

// Handle reset password
async function handleResetPassword(event) {
  if (event) event.preventDefault();
  
  const passwordInput = document.getElementById('new-password');
  const confirmPasswordInput = document.getElementById('confirm-new-password');
  
  // Clear previous error messages
  clearInputError(passwordInput);
  clearInputError(confirmPasswordInput);
  
  // Validate inputs
  let isValid = true;
  
  if (!passwordInput.value) {
    showInputError(passwordInput, 'Password is required');
    isValid = false;
  } else if (passwordInput.value.length < 6) {
    showInputError(passwordInput, 'Password must be at least 6 characters long');
    isValid = false;
  }
  
  if (!confirmPasswordInput.value) {
    showInputError(confirmPasswordInput, 'Please confirm your password');
    isValid = false;
  } else if (passwordInput.value !== confirmPasswordInput.value) {
    showInputError(confirmPasswordInput, 'Passwords do not match');
    isValid = false;
  }
  
  if (!isValid) {
    return;
  }
  
  try {
    // Get reset token from URL
    const urlParams = new URLSearchParams(window.location.search);
    const resetToken = urlParams.get('token');
    
    if (!resetToken) {
      throw new Error('Reset token not found');
    }
    
    // Show loading state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn ? submitBtn.textContent : 'Reset Password';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Resetting...';
    }
    
    // Call reset password API
    const result = await API.Auth.resetPassword(resetToken, passwordInput.value);
    
    if (result && result.token) {
      // Save authentication data
      setAuthData(result.token, result.user);
      
      // Show success message
      showNotification('Password reset successful! Redirecting...', 'success');
      
      // Redirect to profile page
      setTimeout(() => {
        const redirectPath = window.location.pathname.includes('/HTML/') 
          ? 'bobotoProfile.html' 
          : 'HTML/bobotoProfile.html';
        window.location.href = redirectPath;
      }, 1500);
    } else {
      throw new Error('Invalid response from server');
    }
  } catch (error) {
    console.error('Reset password error:', error);
    
    // Reset button state
    const submitBtn = event.target.querySelector('button[type="submit"]');
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = originalBtnText || 'Reset Password';
    }
    
    // Show error message
    showNotification(error.message || 'Failed to reset password. Please try again.', 'error');
  }
}

// Helper functions
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function showInputError(input, message) {
  const errorElement = document.getElementById(`${input.id}-error`);
  if (errorElement) {
    errorElement.textContent = message;
    errorElement.style.display = 'block';
  }
  input.classList.add('error');
}

function clearInputError(input) {
  const errorElement = document.getElementById(`${input.id}-error`);
  if (errorElement) {
    errorElement.textContent = '';
    errorElement.style.display = 'none';
  }
  input.classList.remove('error');
}

// Enhanced Google Sign-In initialization
function initGoogleAuth() {
  console.log('Initializing Google Auth...');
  
  // Check if gapi is loaded
  if (typeof gapi === 'undefined') {
    console.error('Google API not loaded');
    // Retry after 1 second
    setTimeout(initGoogleAuth, 1000);
    return;
  }
  
  gapi.load('auth2', () => {
    console.log('Google auth2 module loaded');
    
    const clientId = window.serverConfig?.googleClientId;
    if (!clientId) {
      console.error('Google Client ID not configured');
      return;
    }
    
    console.log('Initializing with client ID:', clientId.substring(0, 10) + '...');
    
    gapi.auth2.init({
      client_id: clientId,
      cookiepolicy: 'single_host_origin',
      scope: 'profile email'
    }).then((auth2) => {
      console.log('Google Auth2 initialized successfully');
      
      // Check if user is already signed in
      if (auth2.isSignedIn.get()) {
        console.log('User is already signed in to Google');
      }
      
      // Attach Google Sign-In to buttons
      attachGoogleSignIn();
    }).catch(error => {
      console.error('Error initializing Google Auth:', error);
    });
  });
}

// Attach Google Sign-In to buttons
function attachGoogleSignIn() {
  const googleButtons = document.querySelectorAll('.btn-social.google');
  console.log('Found Google buttons:', googleButtons.length);
  
  googleButtons.forEach(button => {
    button.addEventListener('click', (e) => {
      e.preventDefault();
      handleGoogleAuth();
    });
  });
}

// Call initialize immediately
document.addEventListener('DOMContentLoaded', initGoogleAuth);

// Also try to initialize after a delay in case gapi loads late
setTimeout(initGoogleAuth, 2000);

// Show notification function
function showNotification(message, type = 'info') {
  // Create notification container if it doesn't exist
  let notificationContainer = document.querySelector('.notification-container');
  
  if (!notificationContainer) {
    notificationContainer = document.createElement('div');
    notificationContainer.className = 'notification-container';
    document.body.appendChild(notificationContainer);
  }
  
  // Create notification element
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</span>
    </div>
    <button class="notification-close">&times;</button>
  `;
  
  // Add to container
  notificationContainer.appendChild(notification);
  
  // Add close button functionality
  const closeBtn = notification.querySelector('.notification-close');
  closeBtn.addEventListener('click', () => {
    notification.classList.add('closing');
    setTimeout(() => {
      notificationContainer.removeChild(notification);
    }, 300);
  });
  
  // Auto close after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.classList.add('closing');
      setTimeout(() => {
        if (notification.parentNode) {
          notificationContainer.removeChild(notification);
        }
      }, 300);
    }
  }, 5000);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM loaded, initializing auth...');
  
  // Update authentication UI
  updateAuthUI();
  
  // Initialize login form if exists
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    console.log('Login form found, attaching event listener');
    loginForm.addEventListener('submit', handleLogin);
    
    // Redirect to profile if already logged in
    if (isAuthenticated()) {
      console.log('Already authenticated, redirecting to profile');
      const redirectPath = window.location.pathname.includes('/HTML/') 
        ? 'bobotoProfile.html' 
        : 'HTML/bobotoProfile.html';
      window.location.href = redirectPath;
    }
  }
  
  // Initialize signup form if exists
  const signupForm = document.getElementById('signup-form');
  if (signupForm) {
    console.log('Signup form found, attaching event listener');
    signupForm.addEventListener('submit', handleSignup);
    
    // Redirect to profile if already logged in
    if (isAuthenticated()) {
      console.log('Already authenticated, redirecting to profile');
      const redirectPath = window.location.pathname.includes('/HTML/') 
        ? 'bobotoProfile.html' 
        : 'HTML/bobotoProfile.html';
      window.location.href = redirectPath;
    }
  }
  
  // Initialize forgot password form if exists
  const forgotPasswordForm = document.getElementById('forgot-password-form');
  if (forgotPasswordForm) {
    console.log('Forgot password form found, attaching event listener');
    forgotPasswordForm.addEventListener('submit', handleForgotPassword);
  }
  
  // Initialize reset password form if exists
  const resetPasswordForm = document.getElementById('reset-password-form');
  if (resetPasswordForm) {
    console.log('Reset password form found, attaching event listener');
    resetPasswordForm.addEventListener('submit', handleResetPassword);
  }
  
  // Protect authenticated pages
  if (isAuthenticatedPage()) {
    console.log('This is an authenticated page, checking authorization');
    protectPage();
  }
  
  // Set up sign-out button listener
  setupSignOutListener();
  
  // Initialize Google auth
  initGoogleAuth();
});

// Export functions to window for global access
window.isAuthenticated = isAuthenticated;
window.getToken = getToken;
window.getUserInfo = getUserInfo;
window.setAuthData = setAuthData;
window.clearAuthData = clearAuthData;
window.updateAuthUI = updateAuthUI;
window.toggleUserMenu = toggleUserMenu;
window.logout = logout;
window.protectPage = protectPage;
window.handleLogin = handleLogin;
window.handleSignup = handleSignup;
window.handleGoogleAuth = handleGoogleAuth;
window.handleForgotPassword = handleForgotPassword;
window.handleResetPassword = handleResetPassword;
window.showNotification = showNotification;