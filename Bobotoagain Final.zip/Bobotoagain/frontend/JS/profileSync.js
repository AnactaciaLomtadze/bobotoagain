// JS/profileSync.js
/**
 * profileSync.js - Utility for synchronizing profile data between local storage and server
 */

// Profile synchronization class
class ProfileSynchronizer {
    constructor() {
      this.syncQueue = [];
      this.isSyncing = false;
      this.lastSyncTime = null;
      this.syncInterval = 60000; // 1 minute
      this.offlineChanges = JSON.parse(localStorage.getItem('offline_changes') || '[]');
      
      // Check for offline changes on init
      this.processOfflineChanges();
      
      // Set up periodic sync if user is authenticated
      if (isAuthenticated()) {
        this.schedulePeriodicSync();
      }
      
      // Listen for online/offline events
      window.addEventListener('online', this.handleOnlineStatus.bind(this));
      window.addEventListener('offline', this.handleOfflineStatus.bind(this));
    }
    
    // Handle online status change
    handleOnlineStatus() {
      console.log('App is online. Checking for offline changes...');
      this.processOfflineChanges();
    }
    
    // Handle offline status change
    handleOfflineStatus() {
      console.log('App is offline. Changes will be queued.');
    }
    
    // Schedule periodic sync
    schedulePeriodicSync() {
      setInterval(() => {
        if (isAuthenticated() && navigator.onLine && !this.isSyncing) {
          this.syncWithServer();
        }
      }, this.syncInterval);
    }
    
    // Process any offline changes
    async processOfflineChanges() {
      if (!navigator.onLine || !isAuthenticated() || this.offlineChanges.length === 0) {
        return;
      }
      
      console.log(`Processing ${this.offlineChanges.length} offline changes...`);
      
      this.isSyncing = true;
      
      for (const change of this.offlineChanges) {
        try {
          switch (change.type) {
            case 'learningPreferences':
              await API.Profile.updateLearningPreferences(change.data);
              break;
            case 'careerGoals':
              await API.Profile.updateCareerGoals(change.data);
              break;
            case 'skill.add':
              await API.Profile.addSkill(change.data.name, change.data.level);
              break;
            case 'skill.remove':
              await API.Profile.removeSkill(change.data.skillId);
              break;
            case 'profile':
              await API.Profile.update(change.data);
              break;
          }
          
          // Remove this change from the queue
          this.offlineChanges = this.offlineChanges.filter(c => c !== change);
          localStorage.setItem('offline_changes', JSON.stringify(this.offlineChanges));
          
        } catch (error) {
          console.error(`Error processing offline change (${change.type}):`, error);
          // Keep the change in the queue for next attempt
        }
      }
      
      this.isSyncing = false;
      this.lastSyncTime = new Date();
      
      // Pull latest data from server to ensure we're in sync
      await this.syncWithServer();
    }
    
    // Record offline change
    recordOfflineChange(type, data) {
      this.offlineChanges.push({
        type,
        data,
        timestamp: new Date().toISOString()
      });
      
      localStorage.setItem('offline_changes', JSON.stringify(this.offlineChanges));
      
      // Try to process immediately if online
      if (navigator.onLine && isAuthenticated()) {
        this.processOfflineChanges();
      }
    }
    
    // Sync with server (pull latest data)
    async syncWithServer() {
      if (!navigator.onLine || !isAuthenticated() || this.isSyncing) {
        return false;
      }
      
      console.log('Syncing profile data with server...');
      this.isSyncing = true;
      
      try {
        // Get profile data from server
        const profileData = await API.Profile.get();
        
        if (profileData) {
          // Update local storage with server data
          if (profileData.learningPreferences) {
            localStorage.setItem('learning_preferences', JSON.stringify(profileData.learningPreferences));
          }
          
          if (profileData.careerGoals) {
            localStorage.setItem('career_goals', JSON.stringify(profileData.careerGoals));
          }
          
          if (profileData.skills) {
            localStorage.setItem('user_skills', JSON.stringify(profileData.skills));
          }
          
          // Broadcast event for UI updates
          const syncEvent = new CustomEvent('profile-synced', { detail: profileData });
          document.dispatchEvent(syncEvent);
          
          this.lastSyncTime = new Date();
          return true;
        }
      } catch (error) {
        console.error('Error syncing with server:', error);
      } finally {
        this.isSyncing = false;
      }
      
      return false;
    }
    
    // Update learning preferences
    updateLearningPreferences(preferences) {
      // Update local storage
      const currentPrefs = JSON.parse(localStorage.getItem('learning_preferences') || '{}');
      const updatedPrefs = { ...currentPrefs, ...preferences };
      localStorage.setItem('learning_preferences', JSON.stringify(updatedPrefs));
      
      // Record for server sync
      this.recordOfflineChange('learningPreferences', updatedPrefs);
      
      return updatedPrefs;
    }
    
  // Update career goals
  updateCareerGoals(goals) {
    // Update local storage
    const currentGoals = JSON.parse(localStorage.getItem('career_goals') || '{}');
    const updatedGoals = { ...currentGoals, ...goals };
    localStorage.setItem('career_goals', JSON.stringify(updatedGoals));
    
    // Record for server sync
    this.recordOfflineChange('careerGoals', updatedGoals);
    
    return updatedGoals;
  }
  
  // Add or update skill
  addOrUpdateSkill(name, level) {
    // Update local storage
    const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
    
    // Check if skill already exists
    const existingSkillIndex = skills.findIndex(s => s.name.toLowerCase() === name.toLowerCase());
    
    if (existingSkillIndex >= 0) {
      // Update existing skill
      skills[existingSkillIndex].level = level;
      skills[existingSkillIndex].addedAt = new Date().toISOString();
    } else {
      // Add new skill
      skills.push({
        name,
        level,
        addedAt: new Date().toISOString(),
        _id: 'temp_' + Date.now() // Temporary ID until synced
      });
    }
    
    localStorage.setItem('user_skills', JSON.stringify(skills));
    
    // Record for server sync
    this.recordOfflineChange('skill.add', { name, level });
    
    return skills;
  }
  
  // Remove skill
  removeSkill(skillId) {
    // Update local storage
    const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
    
    // Filter out the skill
    const updatedSkills = skills.filter(skill => skill._id.toString() !== skillId);
    
    localStorage.setItem('user_skills', JSON.stringify(updatedSkills));
    
    // Record for server sync
    this.recordOfflineChange('skill.remove', { skillId });
    
    return updatedSkills;
  }
  
  // Update profile
  updateProfile(profileData) {
    // Record for server sync
    this.recordOfflineChange('profile', profileData);
    
    return profileData;
  }
}

// Initialize the profile synchronizer
const profileSync = new ProfileSynchronizer();

// Export to window object
window.profileSync = profileSync;