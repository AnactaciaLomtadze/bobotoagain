/**
 * chatHistory.js - Chat history page functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', () => {
    // Protect the page
    protectPage();
    
    // Initialize chat history page
    initChatHistoryPage();
    
    // Setup event listeners
    setupChatHistoryEventListeners();
    
    // Initialize charts (placeholder - will implement with Chart.js)
    initializeCharts();
  });
  
  // Initialize the chat history page
  async function initChatHistoryPage() {
    try {
      // Fetch the user's profile data for sidebar
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        showNotification('Failed to load profile data', 'error');
        return;
      }
      
      // Update sidebar user information
      updateSidebarUserInfo(profileData);
      
      // Load chat history
      await loadChatHistory();
      
      // Load analytics data (placeholder)
      await loadChatAnalytics();
      
    } catch (error) {
      console.error('Error initializing chat history page:', error);
      showNotification('Error loading chat history', 'error');
    }
  }
  
  // Update sidebar user information
  function updateSidebarUserInfo(profileData) {
    const userNameElement = document.querySelector('.user-name');
    if (userNameElement) {
      userNameElement.textContent = profileData.fullName;
    }
    
    const userDetailsElement = document.querySelector('.user-details');
    if (userDetailsElement) {
      let detailsText = 'Student';
      if (profileData.major) {
        detailsText = profileData.major;
        if (profileData.academicLevel) {
          detailsText += ' ' + profileData.academicLevel;
        }
        detailsText += ' Student';
      }
      userDetailsElement.textContent = detailsText;
    }
    
    const profilePicElement = document.querySelector('.profile-picture img');
    if (profilePicElement && profileData.profilePictureUrl) {
      profilePicElement.src = profileData.profilePictureUrl;
    }
  }
  
  // Load chat history
  async function loadChatHistory() {
    try {
      // Fetch chat sessions from the API
      const sessions = await API.Chat.getSessions();
      
      if (!sessions || sessions.length === 0) {
        showEmptyChatHistory();
        return;
      }
      
      // Render chat sessions
      renderChatSessions(sessions);
      
    } catch (error) {
      console.error('Error loading chat history:', error);
      showNotification('Failed to load chat history', 'error');
    }
  }
  
  // Render chat sessions
  function renderChatSessions(sessions) {
    const chatHistoryList = document.getElementById('chatHistoryList');
    if (!chatHistoryList) return;
    
    // Clear existing content
    chatHistoryList.innerHTML = '';
    
    // Group sessions by date
    const groupedSessions = groupSessionsByDate(sessions);
    
    // Render each group
    Object.keys(groupedSessions).forEach(date => {
      const dateGroup = document.createElement('div');
      dateGroup.className = 'chat-date-group';
      
      const dateHeader = document.createElement('h3');
      dateHeader.className = 'date-header';
      dateHeader.textContent = date;
      dateGroup.appendChild(dateHeader);
      
      groupedSessions[date].forEach(session => {
        const sessionElement = createChatSessionElement(session);
        dateGroup.appendChild(sessionElement);
      });
      
      chatHistoryList.appendChild(dateGroup);
    });
  }
  
  // Create chat session element
  function createChatSessionElement(session) {
    const sessionDiv = document.createElement('div');
    sessionDiv.className = 'chat-history-item';
    sessionDiv.setAttribute('data-id', session._id);
    
    const formattedDate = formatDate(session.lastUpdated);
    const messageCount = session.messageCount || 0;
    const duration = calculateSessionDuration(session);
    
    sessionDiv.innerHTML = `
      <div class="chat-meta">
        <h3 class="chat-title">${session.title}</h3>
        <div class="chat-details">
          <span class="chat-detail"><span>📅</span> ${formattedDate}</span>
          <span class="chat-detail"><span>💬</span> ${messageCount} messages</span>
          <span class="chat-detail"><span>⏱️</span> ${duration}</span>
        </div>
        <div class="chat-topics">
          ${generateTopicTags(session)}
        </div>
        <div class="chat-snippet">
          "${getSessionPreview(session)}"
        </div>
      </div>
      <div class="chat-actions">
        <button class="action-btn" title="Bookmark" onclick="toggleBookmark('${session._id}', this)">
          ${session.isSaved ? '🔖' : '🔖'}
        </button>
        <button class="action-btn delete-btn" title="Delete" onclick="confirmDelete('${session._id}')">🗑️</button>
        <button class="action-btn continue-btn" title="Continue Chat" onclick="continueChatSession('${session._id}')">➡️</button>
      </div>
    `;
    
    // Add click handler to open session
    sessionDiv.addEventListener('click', (e) => {
      if (!e.target.closest('.chat-actions')) {
        openChatModal(session._id);
      }
    });
    
    return sessionDiv;
  }
  
  // Toggle bookmark
  async function toggleBookmark(sessionId, button) {
    try {
      const isCurrentlyBookmarked = button.style.color === 'gold';
      
      if (isCurrentlyBookmarked) {
        await API.Chat.removeSessionFromFavorites(sessionId);
        button.style.color = '';
        showNotification('Bookmark removed', 'info');
      } else {
        await API.Chat.saveSessionAsFavorite(sessionId);
        button.style.color = 'gold';
        showNotification('Conversation bookmarked', 'success');
      }
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      showNotification('Failed to update bookmark', 'error');
    }
  }
  
  // Confirm delete
  async function confirmDelete(sessionId) {
    const session = document.querySelector(`[data-id="${sessionId}"]`);
    if (!session) return;
    
    const title = session.querySelector('.chat-title').textContent;
    
    if (confirm(`Are you sure you want to delete the chat: "${title}"?`)) {
      try {
        await API.Chat.deleteSession(sessionId);
        session.style.opacity = '0';
        setTimeout(() => {
          session.remove();
          // Check if any sessions remain
          const remainingSessions = document.querySelectorAll('.chat-history-item');
          if (remainingSessions.length === 0) {
            showEmptyChatHistory();
          }
        }, 300);
        showNotification('Chat deleted successfully', 'info');
      } catch (error) {
        console.error('Error deleting session:', error);
        showNotification('Failed to delete chat', 'error');
      }
    }
  }
  
  // Continue chat session
  function continueChatSession(sessionId) {
    window.location.href = `bobotoChat.html?session=${sessionId}`;
  }
  
  // Open chat modal
  async function openChatModal(sessionId) {
    const modal = document.getElementById('chatViewModal');
    if (!modal) return;
    
    try {
      // Get session details
      const session = await getSessionById(sessionId);
      if (!session) return;
      
      // Get session messages
      const messages = await API.Chat.getMessages(sessionId);
      
      // Update modal title
      const modalTitle = modal.querySelector('.modal-title');
      if (modalTitle) {
        modalTitle.textContent = `Chat Session: ${session.title}`;
      }
      
      // Render messages
      const messagesContainer = modal.querySelector('.chat-messages');
      if (messagesContainer) {
        messagesContainer.innerHTML = '';
        messages.forEach(message => {
          const messageElement = createMessageElement(message);
          messagesContainer.appendChild(messageElement);
        });
      }
      
      // Show modal
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      
    } catch (error) {
      console.error('Error opening chat modal:', error);
      showNotification('Failed to load chat details', 'error');
    }
  }
  
  // Close modal
  function closeModal() {
    const modal = document.getElementById('chatViewModal');
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  }
  
  // Create message element
  function createMessageElement(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${message.isUser ? 'user' : 'bot'}`;
    
    const formattedDate = formatMessageDate(message.timestamp);
    
    messageDiv.innerHTML = `
      <div class="message-avatar">${message.isUser ? 'AL' : 'B'}</div>
      <div class="message-content">
        <p>${message.text}</p>
        <div class="message-meta">${formattedDate}</div>
      </div>
    `;
    
    return messageDiv;
  }
  
  // Setup event listeners
  function setupChatHistoryEventListeners() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
      searchInput.addEventListener('input', debounce(handleSearch, 300));
    }
    
    // Filters
    const topicFilter = document.getElementById('topicFilter');
    if (topicFilter) {
      topicFilter.addEventListener('change', handleFilterChange);
    }
    
    const dateFromFilter = document.getElementById('dateFromFilter');
    const dateToFilter = document.getElementById('dateToFilter');
    if (dateFromFilter && dateToFilter) {
      dateFromFilter.addEventListener('change', handleFilterChange);
      dateToFilter.addEventListener('change', handleFilterChange);
    }
    
    // Apply filters button
    const applyFiltersBtn = document.getElementById('applyFilters');
    if (applyFiltersBtn) {
      applyFiltersBtn.addEventListener('click', applyFilters);
    }
    
    // Clear filters button
    const clearFiltersBtn = document.getElementById('clearFilters');
    if (clearFiltersBtn) {
      clearFiltersBtn.addEventListener('click', clearFilters);
    }
    
    // Time range filter for analytics
    const timeRangeFilter = document.getElementById('timeRangeFilter');
    if (timeRangeFilter) {
      timeRangeFilter.addEventListener('change', handleTimeRangeChange);
    }
    
    // Modal close button
    const closeModalBtn = document.querySelector('.close-modal');
    if (closeModalBtn) {
      closeModalBtn.addEventListener('click', closeModal);
    }
    
    // Export buttons in modal
    const exportButtons = document.querySelectorAll('.export-btn');
    exportButtons.forEach(button => {
      button.addEventListener('click', handleExport);
    });
  }
  
  // Handle search
  async function handleSearch(event) {
    const searchTerm = event.target.value.trim();
    
    if (!searchTerm) {
      await loadChatHistory();
      return;
    }
    
    try {
      const results = await API.Chat.searchSessions(searchTerm);
      renderChatSessions(results);
    } catch (error) {
      console.error('Search error:', error);
      showNotification('Search failed', 'error');
    }
  }
  
  // Handle filter change
  function handleFilterChange() {
    // This would trigger filtering when any filter changes
    // For now, we'll just log the change
    console.log('Filters changed');
  }
  
  // Apply filters
  async function applyFilters() {
    const searchTerm = document.getElementById('searchInput').value;
    const topicFilter = document.getElementById('topicFilter').value;
    const dateFrom = document.getElementById('dateFromFilter').value;
    const dateTo = document.getElementById('dateToFilter').value;
    
    try {
      // This would apply multiple filters
      // For now, we'll just use search
      if (searchTerm) {
        const results = await API.Chat.searchSessions(searchTerm);
        renderChatSessions(results);
      } else {
        await loadChatHistory();
      }
      
      showNotification('Filters applied', 'info');
    } catch (error) {
      console.error('Filter error:', error);
      showNotification('Failed to apply filters', 'error');
    }
  }
  
  // Clear filters
  async function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('topicFilter').value = '';
    document.getElementById('dateFromFilter').value = '';
    document.getElementById('dateToFilter').value = '';
    
    await loadChatHistory();
    showNotification('Filters cleared', 'info');
  }
  
  // Handle time range change for analytics
  function handleTimeRangeChange(event) {
    const selectedRange = event.target.value;
    console.log('Time range changed to:', selectedRange);
    // This would update the analytics charts
    loadChatAnalytics(selectedRange);
  }
  
  // Handle export
  function handleExport(event) {
    const exportType = event.currentTarget.textContent.includes('PDF') ? 'pdf' : 'text';
    showNotification(`Exporting as ${exportType}...`, 'info');
    // TODO: Implement actual export functionality
  }
  
  // Load chat analytics
  async function loadChatAnalytics(timeRange = 'month') {
    try {
      // Placeholder for analytics data
      // In a real implementation, this would fetch analytics from the API
      
      // Update analytics cards
      updateAnalyticsCards();
      
      // Update charts (placeholder)
      if (typeof Chart !== 'undefined') {
        updateCharts(timeRange);
      }
      
      // Update AI insights
      updateAIInsights();
      
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  }
  
  // Update analytics cards
  function updateAnalyticsCards() {
    const analyticsCards = document.querySelectorAll('.analytics-value');
    if (analyticsCards.length >= 4) {
      analyticsCards[0].textContent = '42'; // Total Conversations
      analyticsCards[1].textContent = '6.5h'; // Total Time
      analyticsCards[2].textContent = '9.3'; // Avg. Messages per Chat
      analyticsCards[3].textContent = '15m'; // Avg. Session Duration
    }
  }
  
  // Update AI insights
  function updateAIInsights() {
    // These would be dynamically generated based on actual data
    const insights = [
      {
        icon: '📈',
        title: 'Increased Interest in Cloud Computing',
        description: 'You\'ve had 8 conversations about cloud computing in the past month, a 200% increase from the previous month.'
      },
      {
        icon: '🔄',
        title: 'Recurring Pattern: Late Night Learning',
        description: '67% of your chat sessions occur between 9 PM and midnight.'
      },
      {
        icon: '🏆',
        title: 'Knowledge Gap Identified',
        description: 'Based on your recent conversations, you might benefit from exploring distributed systems concepts.'
      }
    ];
    
    // Render insights if container exists
    const insightsContainer = document.querySelector('.insights-list');
    if (insightsContainer) {
      insightsContainer.innerHTML = insights.map(insight => `
        <div class="insight-item">
          <div class="insight-icon">${insight.icon}</div>
          <div class="insight-content">
            <h4>${insight.title}</h4>
            <p>${insight.description}</p>
          </div>
        </div>
      `).join('');
    }
  }
  
  // Initialize charts (placeholder)
  function initializeCharts() {
    // This would initialize Chart.js charts for topics and activity
    console.log('Charts initialized');
  }
  
  // Update charts based on time range
  function updateCharts(timeRange) {
    // This would update the charts with new data
    console.log('Charts updated for time range:', timeRange);
  }
  
  // Show empty chat history state
  function showEmptyChatHistory() {
    const chatHistoryList = document.getElementById('chatHistoryList');
    if (!chatHistoryList) return;
    
    chatHistoryList.innerHTML = `
      <div class="empty-state">
        <h3>No chat history yet</h3>
        <p>Start a conversation with Boboto to see your chat history here.</p>
        <a href="bobotoChat.html" class="btn btn-primary">Start a Chat</a>
      </div>
    `;
  }
  
  // Utility functions
  
  // Group sessions by date
  function groupSessionsByDate(sessions) {
    const grouped = {};
    
    sessions.forEach(session => {
      const date = formatGroupDate(session.lastUpdated);
      if (!grouped[date]) {
        grouped[date] = [];
      }
      grouped[date].push(session);
    });
    
    return grouped;
  }
  
  // Format date for display
  function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return `Today, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays === 1) {
      return `Yesterday, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays < 7) {
      return `${diffDays} days ago, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString([], { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  }
  
  // Format date for grouping
  function formatGroupDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return 'Today';
    } else if (diffDays === 1) {
      return 'Yesterday';
    } else if (diffDays < 7) {
      return 'This Week';
    } else if (diffDays < 30) {
      return 'This Month';
    } else {
      return date.toLocaleDateString([], { year: 'numeric', month: 'long' });
    }
  }
  
  // Format message date
  function formatMessageDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString([], { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit', 
      minute: '2-digit'
    });
  }
  
  // Calculate session duration
  function calculateSessionDuration(session) {
    // This would calculate based on actual message timestamps
    // For now, return a placeholder
    return '15 minutes';
  }
  
  // Generate topic tags
  function generateTopicTags(session) {
    // This would analyze the session content to generate tags
    // For now, return placeholder tags
    const topics = ['Machine Learning', 'Python', 'Career'];
    return topics.map(topic => `<span class="chat-topic">${topic}</span>`).join('');
  }
  
  // Get session preview
  function getSessionPreview(session) {
    // This would get the first user message or a summary
    // For now, return a placeholder
    return 'What are the best resources for learning cloud computing as a beginner?';
  }
  
  // Get session by ID
  async function getSessionById(sessionId) {
    try {
      const sessions = await API.Chat.getSessions();
      return sessions.find(session => session._id === sessionId);
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  }
  
  // Debounce function
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }
  
  // Export functions for global use
  window.toggleBookmark = toggleBookmark;
  window.confirmDelete = confirmDelete;
  window.continueChatSession = continueChatSession;
  window.openChatModal = openChatModal;
  window.closeModal = closeModal;