/**
 * learning.js - Learning preferences page functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', () => {
    // Protect the page - redirect if not logged in
    protectPage();
    
    // Initialize the page
    initLearningPreferencesPage();
    
    // Setup form event listeners
    setupEventListeners();
  });
  
  // Initialize the learning preferences page
  async function initLearningPreferencesPage() {
    try {
      // Fetch the user's profile data for sidebar
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        showNotification('Failed to load profile data', 'error');
        return;
      }
      
      // Update sidebar user information
      updateSidebarUserInfo(profileData);
      
      // Fetch learning preferences
      const learningPrefs = await API.Profile.getLearningPreferences();
      
      if (learningPrefs) {
        // Load learning preferences into the UI
        loadLearningPreferences(learningPrefs);
      }
      
    } catch (error) {
      console.error('Error initializing learning preferences page:', error);
      showNotification('Error loading learning preferences', 'error');
    }
  }
  
  // Update sidebar user information
  function updateSidebarUserInfo(profileData) {
    // Update user name
    const userNameElement = document.querySelector('.user-name');
    if (userNameElement) {
      userNameElement.textContent = profileData.fullName;
    }
    
    // Update user details (major/academic level)
    const userDetailsElement = document.querySelector('.user-details');
    if (userDetailsElement) {
      let detailsText = 'Student';
      if (profileData.major) {
        detailsText = profileData.major;
        if (profileData.academicLevel) {
          detailsText += ' ' + profileData.academicLevel;
        }
        detailsText += ' Student';
      }
      userDetailsElement.textContent = detailsText;
    }
    
    // Update profile picture in sidebar
    const profilePicElement = document.querySelector('.profile-picture img');
    if (profilePicElement && profileData.profilePictureUrl) {
      profilePicElement.src = profileData.profilePictureUrl;
    }
  }
  
  // Load learning preferences into the UI
  function loadLearningPreferences(prefs) {
    // 1. Learning styles
    if (prefs.learningStyles && prefs.learningStyles.length > 0) {
      // Reset all learning styles first
      document.querySelectorAll('.learning-style-option').forEach(option => {
        option.classList.remove('selected');
      });
      
      // Select the user's learning styles
      prefs.learningStyles.forEach(style => {
        const styleOption = document.querySelector(`.learning-style-option .learning-style-title:contains("${style}")`);
        if (styleOption) {
          styleOption.closest('.learning-style-option').classList.add('selected');
        }
      });
    }
    
    // 2. Subject interests
    if (prefs.subjectInterests && prefs.subjectInterests.length > 0) {
      // Clear existing subject tags except the input
      const subjectTags = document.getElementById('subjectTags');
      if (subjectTags) {
        Array.from(subjectTags.children).forEach(child => {
          if (!child.classList.contains('add-tag-input')) {
            subjectTags.removeChild(child);
          }
        });
        
        // Add the user's subject interests
        prefs.subjectInterests.forEach(subject => {
          const tag = document.createElement('span');
          tag.className = 'tag selected';
          tag.onclick = function() { toggleTag(this); };
          tag.innerHTML = subject + '<span class="remove-tag" onclick="removeTag(event, this)">✕</span>';
          subjectTags.appendChild(tag);
        });
      }
    }
    
    // 3. Learning parameters
    if (prefs.learningPace) {
      const paceSelect = document.getElementById('learningPace');
      if (paceSelect) {
        paceSelect.value = prefs.learningPace;
      }
    }
    
    if (prefs.explanationDepth) {
      const depthSelect = document.getElementById('explanationDepth');
      if (depthSelect) {
        depthSelect.value = prefs.explanationDepth;
      }
    }
    
    if (prefs.contentFormat) {
      const formatSelect = document.getElementById('contentFormat');
      if (formatSelect) {
        formatSelect.value = prefs.contentFormat;
      }
    }
    
    if (prefs.learningGoal) {
      const goalSelect = document.getElementById('learningGoal');
      if (goalSelect) {
        goalSelect.value = prefs.learningGoal;
      }
    }
    
    if (prefs.technicalLevel) {
      const techLevelSlider = document.getElementById('technicalLevel');
      if (techLevelSlider) {
        techLevelSlider.value = prefs.technicalLevel;
      }
    }
    
    if (prefs.theoryPractice) {
      const theoryPracticeSlider = document.getElementById('theoryPractice');
      if (theoryPracticeSlider) {
        theoryPracticeSlider.value = prefs.theoryPractice;
      }
    }
    
    // 4. Learning challenges
    if (prefs.challenges && prefs.challenges.length > 0) {
      // Clear existing challenge tags except the input
      const challengeTags = document.getElementById('challengeTags');
      if (challengeTags) {
        Array.from(challengeTags.children).forEach(child => {
          if (!child.classList.contains('add-tag-input')) {
            challengeTags.removeChild(child);
          }
        });
        
        // Add the user's challenges
        prefs.challenges.forEach(challenge => {
          const tag = document.createElement('span');
          tag.className = 'tag selected';
          tag.onclick = function() { toggleTag(this); };
          tag.innerHTML = challenge + '<span class="remove-tag" onclick="removeTag(event, this)">✕</span>';
          challengeTags.appendChild(tag);
        });
      }
    }
    
    // 5. Additional notes
    if (prefs.additionalNotes) {
      const notesTextarea = document.getElementById('additionalNotes');
      if (notesTextarea) {
        notesTextarea.value = prefs.additionalNotes;
      }
    }
    
    // Update AI recommendations based on the preferences
    updateAIInsights(prefs);
  }
  
  // Setup event listeners
  function setupEventListeners() {
    // Learning style selection
    document.querySelectorAll('.learning-style-option').forEach(option => {
      option.addEventListener('click', function() {
        this.classList.toggle('selected');
      });
    });
    
    // Tag-related event listeners
    document.querySelectorAll('.tag').forEach(tag => {
      tag.addEventListener('click', function() {
        toggleTag(this);
      });
    });
    
    // Add new tag input events
    const subjectInput = document.getElementById('newSubjectTag');
    if (subjectInput) {
      subjectInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          addNewTag('subjectTags', 'newSubjectTag');
        }
      });
      
      const addSubjectBtn = subjectInput.nextElementSibling;
      if (addSubjectBtn) {
        addSubjectBtn.addEventListener('click', function() {
          addNewTag('subjectTags', 'newSubjectTag');
        });
      }
    }
    
    const challengeInput = document.getElementById('newChallengeTag');
    if (challengeInput) {
      challengeInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          addNewTag('challengeTags', 'newChallengeTag');
        }
      });
      
      const addChallengeBtn = challengeInput.nextElementSibling;
      if (addChallengeBtn) {
        addChallengeBtn.addEventListener('click', function() {
          addNewTag('challengeTags', 'newChallengeTag');
        });
      }
    }
    
    // Save and reset buttons
    const saveButton = document.querySelector('.form-actions .btn:not(.btn-outline)');
    if (saveButton) {
      saveButton.addEventListener('click', savePreferences);
    }
    
    const resetButton = document.querySelector('.form-actions .btn-outline');
    if (resetButton) {
      resetButton.addEventListener('click', resetPreferences);
    }
  }
  
  // Tag management functions
  function toggleTag(element) {
    element.classList.toggle('selected');
  }
  
  function removeTag(event, element) {
    event.stopPropagation();
    element.parentElement.remove();
  }
  
  function addNewTag(containerId, inputId) {
    const container = document.getElementById(containerId);
    const input = document.getElementById(inputId);
    const value = input.value.trim();
    
    if (value) {
      const tag = document.createElement('span');
      tag.className = 'tag selected';
      tag.onclick = function() { toggleTag(this); };
      
      tag.innerHTML = value + '<span class="remove-tag" onclick="removeTag(event, this)">✕</span>';
      container.appendChild(tag);
      
      input.value = '';
    }
  }
  
  // Save learning preferences
  async function savePreferences() {
    try {
      // 1. Get learning styles
      const selectedStyles = [];
      document.querySelectorAll('.learning-style-option.selected').forEach(option => {
        const titleElement = option.querySelector('.learning-style-title');
        if (titleElement) {
          selectedStyles.push(titleElement.textContent);
        }
      });
      
      // 2. Get subject interests
      const selectedSubjects = [];
      document.querySelectorAll('#subjectTags .tag.selected').forEach(tag => {
        selectedSubjects.push(tag.textContent.replace('✕', '').trim());
      });
      
      // 3. Get learning challenges
      const selectedChallenges = [];
      document.querySelectorAll('#challengeTags .tag.selected').forEach(tag => {
        selectedChallenges.push(tag.textContent.replace('✕', '').trim());
      });
      
      // 4. Get form values
      const preferences = {
        learningStyles: selectedStyles,
        subjectInterests: selectedSubjects,
        challenges: selectedChallenges,
        learningPace: document.getElementById('learningPace').value,
        explanationDepth: document.getElementById('explanationDepth').value,
        contentFormat: document.getElementById('contentFormat').value,
        learningGoal: document.getElementById('learningGoal').value,
        technicalLevel: parseInt(document.getElementById('technicalLevel').value),
        theoryPractice: parseInt(document.getElementById('theoryPractice').value),
        additionalNotes: document.getElementById('additionalNotes').value
      };
      
      // Save to API
      const result = await API.Profile.updateLearningPreferences(preferences);
      
      if (result) {
        showNotification('Learning preferences saved successfully!', 'success');
        
        // Update AI insights based on the new preferences
        updateAIInsights(preferences);
      }
    } catch (error) {
      console.error('Error saving learning preferences:', error);
      showNotification('Error saving learning preferences', 'error');
    }
  }
  
  // Reset preferences form
  function resetPreferences() {
    // Reset form elements
    document.querySelectorAll('select').forEach(select => {
      select.selectedIndex = 0;
    });
    
    document.querySelectorAll('input[type="range"]').forEach(range => {
      range.value = 3;
    });
    
    document.querySelectorAll('textarea').forEach(textarea => {
      textarea.value = '';
    });
    
    // Reset learning style options
    document.querySelectorAll('.learning-style-option').forEach(option => {
      option.classList.remove('selected');
    });
    
    // Reset tags
    document.querySelectorAll('.tag').forEach(tag => {
      tag.classList.remove('selected');
    });
    
    // Clear tag containers
    document.querySelectorAll('#subjectTags, #challengeTags').forEach(container => {
      Array.from(container.children).forEach(child => {
        if (!child.classList.contains('add-tag-input')) {
          container.removeChild(child);
        }
      });
    });
    
    showNotification('All preferences have been reset!', 'info');
  }
  
  // Update AI insights based on user preferences
  function updateAIInsights(prefs) {
    const recommendationsSection = document.querySelector('.recommendations');
    if (!recommendationsSection) return;
    
    // Clear existing recommendations except the title
    const title = recommendationsSection.querySelector('.recommendations-title');
    recommendationsSection.innerHTML = '';
    recommendationsSection.appendChild(title);
    
    // Add insights based on learning styles
    if (prefs.learningStyles.includes('Visual')) {
      addRecommendation('💡', 'Visual Learning Enhancement', 
        'Based on your visual learning preference, I\'ll prioritize diagrams, charts, and visual examples when explaining concepts. I can also recommend visualization tools for complex topics in your areas of interest.');
    }
    
    if (prefs.learningStyles.includes('Hands-on')) {
      addRecommendation('🛠️', 'Practical Learning Approach', 
        'Your hands-on learning style suggests you\'ll benefit from coding exercises, interactive tutorials, and project-based learning. I\'ll focus on providing practical examples and exercises for your interests in ' + 
        (prefs.subjectInterests.slice(0, 2).join(' and ') || 'your chosen subjects') + '.');
    }
    
    // Add insights based on challenges
    if (prefs.challenges.includes('Time management')) {
      addRecommendation('⏱️', 'Time Management Support', 
        'To help with your time management challenge, I can provide structured learning paths with time estimates and help you break down complex topics into manageable study sessions.');
    }
    
    // Add insights based on subject interests
    if (prefs.subjectInterests.includes('Artificial Intelligence')) {
      addRecommendation('🧠', 'AI Learning Pathway', 
        'For your interest in Artificial Intelligence, I\'ve identified key foundational concepts to focus on first: machine learning basics, neural networks, and data preprocessing. I can help create a progressive learning path based on your ' + 
        (prefs.explanationDepth || 'preferred') + ' explanation preference.');
    }
    
    // If no specific recommendations, add a generic one
    if (recommendationsSection.childElementCount <= 1) {
      addRecommendation('📚', 'Personalized Learning Experience', 
        'Based on your preferences, I\'ll tailor explanations and resources to match your learning style. As you interact more with the system, I\'ll adapt my recommendations to better suit your needs.');
    }
  }
  
  // Helper function to add a recommendation item
  function addRecommendation(icon, title, description) {
    const recommendationsSection = document.querySelector('.recommendations');
    if (!recommendationsSection) return;
    
    const recommendationItem = document.createElement('div');
    recommendationItem.className = 'recommendation-item';
    
    recommendationItem.innerHTML = `
      <div class="recommendation-icon">${icon}</div>
      <div class="recommendation-content">
        <h4>${title}</h4>
        <p>${description}</p>
      </div>
    `;
    
    recommendationsSection.appendChild(recommendationItem);
  }
  
  // Add custom selector for text content
  if (!Element.prototype.contains) {
    Element.prototype.contains = function(text) {
      return this.textContent.includes(text);
    };
  }