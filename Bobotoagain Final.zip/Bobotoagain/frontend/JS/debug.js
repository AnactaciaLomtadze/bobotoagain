// JS/debug.js - Frontend debug utilities for DeepSeek integration
/**
 * Debug utilities for DeepSeek chat integration
 * This file should be included in your HTML pages during development
 */

// Debug function to check DeepSeek integration
function debugDeepSeekIntegration() {
    console.log('=== DeepSeek Integration Debug ===');
    
    // 1. Check environment variables (these are backend, but we can note them)
    console.log('1. Environment Variables (check backend console):');
    console.log('   - OPENROUTER_API_KEY should be set');
    
    // 2. Check frontend configuration
    console.log('2. Frontend Configuration:');
    console.log('   - serverConfig:', window.serverConfig);
    console.log('   - API URL:', window.serverConfig?.apiUrl);
    
    // 3. Check authentication
    console.log('3. Authentication:');
    const token = localStorage.getItem('auth_token');
    console.log('   - Auth token exists:', !!token);
    console.log('   - Token length:', token?.length);
    
    // 4. Test API connectivity
    console.log('4. Testing API endpoints...');
    testApiEndpoints();
  }
  
  async function testApiEndpoints() {
    const token = localStorage.getItem('auth_token');
    
    if (!token) {
      console.log('   - Cannot test API endpoints: No auth token');
      return;
    }
    
    try {
      // Test AI endpoint
      const aiTestResponse = await fetch(`${window.serverConfig.apiUrl}/ai/test`, {
        headers: { 'x-auth-token': token }
      });
      console.log('   - AI endpoint test:', aiTestResponse.ok ? 'Success' : 'Failed', aiTestResponse.status);
      
      // Test chat endpoint with a simple message
      const chatTestResponse = await fetch(`${window.serverConfig.apiUrl}/ai/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({
          message: 'Hello, test message',
          chatHistory: []
        })
      });
      console.log('   - Chat endpoint test:', chatTestResponse.ok ? 'Success' : 'Failed', chatTestResponse.status);
      
      if (!chatTestResponse.ok) {
        const errorData = await chatTestResponse.text();
        console.log('   - Chat endpoint error:', errorData);
      } else {
        const successData = await chatTestResponse.json();
        console.log('   - Chat endpoint response:', successData);
      }
    } catch (error) {
      console.error('   - API test error:', error);
    }
  }
  
  // Additional debug function to test chat functionality
  async function testChatMessage(message = 'Hello, this is a test message') {
    console.log('=== Testing Chat Message ===');
    console.log('Message:', message);
    
    const token = localStorage.getItem('auth_token');
    
    if (!token) {
      console.error('No auth token found');
      return;
    }
    
    try {
      const response = await fetch(`${window.serverConfig.apiUrl}/ai/chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({
          message: message,
          chatHistory: []
        })
      });
      
      console.log('Response status:', response.status);
      console.log('Response ok:', response.ok);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Response data:', data);
        console.log('AI Response:', data.response);
      } else {
        const errorData = await response.text();
        console.error('Error response:', errorData);
      }
    } catch (error) {
      console.error('Fetch error:', error);
    }
  }
  
  // Function to check current authentication state
  function checkAuth() {
    console.log('=== Authentication State ===');
    const token = localStorage.getItem('auth_token');
    const userInfo = localStorage.getItem('user_info');
    
    console.log('Token exists:', !!token);
    console.log('Token preview:', token ? token.substring(0, 20) + '...' : 'None');
    console.log('User info:', userInfo ? JSON.parse(userInfo) : 'None');
  }
  
  // Function to check if all required scripts are loaded
  function checkScriptLoading() {
    console.log('=== Script Loading Check ===');
    console.log('API object exists:', typeof API !== 'undefined');
    console.log('serverConfig exists:', typeof window.serverConfig !== 'undefined');
    console.log('Chat functions exist:', typeof sendMessage !== 'undefined');
  }
  
  // Make debug functions available globally
  window.debugDeepSeekIntegration = debugDeepSeekIntegration;
  window.testApiEndpoints = testApiEndpoints;
  window.testChatMessage = testChatMessage;
  window.checkAuth = checkAuth;
  window.checkScriptLoading = checkScriptLoading;
  
  // Auto-run basic checks on page load
  document.addEventListener('DOMContentLoaded', function() {
    if (window.serverConfig?.debug) {
      setTimeout(() => {
        console.log('=== Auto Debug Check ===');
        checkScriptLoading();
        checkAuth();
      }, 1000);
    }
  });