// JS/academicChat.js - New file to handle academic functions in chat

/**
 * academicChat.js - Academic functionality integration for Boboto chat
 */

// Academic context detection and handling for chat
class AcademicChat {
    constructor() {
      // List of educational subjects to detect in messages
      this.subjects = [
        'math', 'mathematics', 'algebra', 'calculus', 'geometry', 'trigonometry',
        'physics', 'chemistry', 'biology', 'anatomy', 'ecology',
        'computer science', 'programming', 'coding', 'algorithm', 'data structure',
        'history', 'geography', 'economics', 'psychology', 'sociology',
        'literature', 'language', 'grammar', 'writing', 'philosophy'
      ];
      
      // Learning levels map
      this.learningLevels = {
        'elementary': 'basic',
        'middle school': 'basic',
        'high school': 'intermediate',
        'undergraduate': 'intermediate',
        'graduate': 'advanced',
        'phd': 'expert'
      };
    }
    
    // Detect if message is an academic question
    isAcademicQuestion(message) {
      const lowercaseMsg = message.toLowerCase();
      
      // Check for academic question patterns
      const academicPatterns = [
        /what is .+\?/i,
        /how do(?:es)? .+ work\??/i,
        /explain .+/i,
        /define .+/i,
        /(?:what (?:are|is) the|difference between) .+/i,
        /compare .+ and .+/i,
        /help(?:.+)with .+/i,
        /homework/i,
        /assignment/i,
        /study(?:ing)? .+/i,
        /learn(?:ing)? .+/i
      ];
      
      // Check if message contains any academic subject
      const containsSubject = this.subjects.some(subject => 
        lowercaseMsg.includes(subject)
      );
      
      // Check if message matches academic patterns
      const matchesPattern = academicPatterns.some(pattern => 
        pattern.test(lowercaseMsg)
      );
      
      return containsSubject || matchesPattern;
    }
    
    // Detect the type of academic query
    detectAcademicQueryType(message) {
      const lowercaseMsg = message.toLowerCase();
      
      // Concept explanation request
      if (
        lowercaseMsg.includes('explain') || 
        lowercaseMsg.includes('what is') || 
        lowercaseMsg.includes('define') ||
        lowercaseMsg.includes('meaning of') ||
        lowercaseMsg.includes('tell me about')
      ) {
        return 'explanation';
      }
      
      // Study materials request
      if (
        lowercaseMsg.includes('resource') || 
        lowercaseMsg.includes('material') || 
        lowercaseMsg.includes('recommend') ||
        lowercaseMsg.includes('book') ||
        lowercaseMsg.includes('course') ||
        lowercaseMsg.includes('tutorial') ||
        lowercaseMsg.includes('video')
      ) {
        return 'materials';
      }
      
      // Homework or assignment help
      if (
        lowercaseMsg.includes('homework') || 
        lowercaseMsg.includes('assignment') || 
        lowercaseMsg.includes('problem') ||
        lowercaseMsg.includes('exercise') ||
        lowercaseMsg.includes('solve')
      ) {
        return 'assignment';
      }
      
      // Default to general subject question
      return 'question';
    }
    
    // Extract subject from message
    extractSubject(message) {
      const lowercaseMsg = message.toLowerCase();
      
      // Find the first subject mentioned in the message
      for (const subject of this.subjects) {
        if (lowercaseMsg.includes(subject)) {
          return subject;
        }
      }
      
      // Default subject
      return 'general';
    }
    
    // Extract concept to explain from message
    extractConcept(message) {
      // Different patterns to extract concepts
      const patterns = [
        // "Explain X"
        /explain\s+(?:what|how|why)?\s*(.+?)(?:\?|$)/i,
        // "What is X"
        /what\s+is\s+(?:a|an|the)?\s*(.+?)(?:\?|$)/i,
        // "Define X"
        /define\s+(?:a|an|the)?\s*(.+?)(?:\?|$)/i,
        // "Meaning of X"
        /meaning\s+of\s+(?:a|an|the)?\s*(.+?)(?:\?|$)/i,
        // "Tell me about X"
        /tell\s+me\s+about\s+(?:a|an|the)?\s*(.+?)(?:\?|$)/i
      ];
      
      // Try each pattern
      for (const pattern of patterns) {
        const match = message.match(pattern);
        if (match && match[1]) {
          return match[1].trim();
        }
      }
      
      // If no specific pattern matches, return the message as is
      return message;
    }
    
    // Extract topic for study materials
    extractTopic(message) {
      // Different patterns to extract topics
      const patterns = [
        // "Resources for X"
        /resources\s+(?:for|on|about)\s+(.+?)(?:\?|$)/i,
        // "Materials on X"
        /materials?\s+(?:for|on|about)\s+(.+?)(?:\?|$)/i,
        // "Recommend X"
        /recommend\s+(?:some|any)?\s*(.+?)(?:\?|$)/i,
        // "Books on X"
        /books?\s+(?:for|on|about)\s+(.+?)(?:\?|$)/i,
        // "I want to learn X"
        /(?:i\s+want\s+to|i'd\s+like\s+to)\s+learn\s+(?:about)?\s*(.+?)(?:\?|$)/i
      ];
      
      // Try each pattern
      for (const pattern of patterns) {
        const match = message.match(pattern);
        if (match && match[1]) {
          return match[1].trim();
        }
      }
      
      // If no specific pattern matches, return the message as is
      return message;
    }
    
    // Get user's learning level from profile
    getUserLearningLevel(profileData) {
      if (!profileData) {
        return 'intermediate';
      }
      
      // Check academic level
      if (profileData.academicLevel) {
        const level = this.learningLevels[profileData.academicLevel.toLowerCase()];
        if (level) {
          return level;
        }
      }
      
      // Check learning preferences
      if (profileData.learningPreferences && profileData.learningPreferences.technicalLevel) {
        const techLevel = parseInt(profileData.learningPreferences.technicalLevel);
        if (!isNaN(techLevel)) {
          if (techLevel >= 4) return 'advanced';
          if (techLevel >= 2) return 'intermediate';
          return 'basic';
        }
      }
      
      // Default level
      return 'intermediate';
    }
    
    // Process academic question and get response
    async processAcademicQuestion(message, profileData) {
      const queryType = this.detectAcademicQueryType(message);
      
      try {
        switch (queryType) {
          case 'explanation':
            const concept = this.extractConcept(message);
            const subject = this.extractSubject(message);
            const level = this.getUserLearningLevel(profileData);
            
            return await API.Academic.explainConcept(
              concept, 
              subject, 
              level
            );
            
          case 'materials':
            const topic = this.extractTopic(message);
            let materialTypes = 'all';
            
            // Check if profile has preferred material types
            if (profileData && profileData.learningPreferences && profileData.learningPreferences.preferredMaterials) {
              materialTypes = profileData.learningPreferences.preferredMaterials.join(',');
            }
            
            return await API.Academic.recommendMaterials(
              topic,
              materialTypes,
              this.getUserLearningLevel(profileData)
            );
            
          case 'assignment':
            // For assignment help, we use the full message as the question
            return await API.Academic.assignmentHelp(
              'Homework help',
              message,
              this.extractSubject(message)
            );
            
          case 'question':
          default:
            // General subject Q&A
            return await API.Academic.askQuestion(
              this.extractSubject(message),
              message,
              this.getUserLearningLevel(profileData)
            );
        }
      } catch (error) {
        console.error('Error processing academic question:', error);
        // Fallback to general AI response
        return API.AI.generateResponse(message, []);
      }
    }
  }
  
  // Create an instance and export
  const academicChat = new AcademicChat();
  window.academicChat = academicChat;