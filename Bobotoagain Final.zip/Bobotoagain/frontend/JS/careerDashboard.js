// frontend/React/CareerDashboard.jsx - Enhanced version with real API integration
import React, { useState, useEffect } from 'react';
import APIService from '../services/APIService';
import CareerSuggestions from './CareerSuggestions';
import JobRecommendations from './JobRecommendations';
import JobMarketTrends from './JobMarketTrends';
import ResumeAnalyzer from './ResumeAnalyzer';
import SkillGapAnalysis from './SkillGapAnalysis';
import ErrorMessage from './ErrorMessage';
import LoadingSpinner from './LoadingSpinner';
import { 
  BriefcaseIcon, 
  ChartBarIcon, 
  TrendingUpIcon, 
  DocumentTextIcon,
  BeakerIcon,
  UserIcon 
} from '@heroicons/react/24/outline';

// Mock user profile - only user data is mocked, API responses are real
const MOCK_USER_PROFILE = {
  id: 'user-123',
  fullName: 'Alex Johnson',
  email: 'alex.johnson@email.com',
  major: 'Computer Science',
  academicLevel: 'Bachelor\'s',
  currentRole: 'Junior Developer',
  yearsExperience: 2,
  location: 'San Francisco, CA',
  careerGoals: {
    shortTermGoal: 'Senior Machine Learning Engineer',
    longTermGoal: 'VP of AI/Data Science',
    targetIndustry: 'Technology',
    locationPreference: 'Remote/Hybrid',
    salaryExpectations: '$120,000 - $160,000'
  },
  skills: [
    { name: 'Python', level: 'Advanced', category: 'Programming' },
    { name: 'JavaScript', level: 'Intermediate', category: 'Programming' },
    { name: 'Machine Learning', level: 'Intermediate', category: 'Technical' },
    { name: 'TensorFlow', level: 'Beginner', category: 'Framework' },
    { name: 'SQL', level: 'Advanced', category: 'Database' },
    { name: 'Data Analysis', level: 'Advanced', category: 'Technical' },
    { name: 'Communication', level: 'Advanced', category: 'Soft Skills' },
    { name: 'Leadership', level: 'Intermediate', category: 'Soft Skills' }
  ],
  interests: ['Artificial Intelligence', 'Data Science', 'Machine Learning', 'Cloud Computing'],
  certifications: [
    { name: 'AWS Certified Data Analytics', issuer: 'Amazon', date: '2023-10', status: 'active' },
    { name: 'Google Cloud Professional Data Engineer', issuer: 'Google', date: '2023-06', status: 'active' }
  ],
  workExperience: [
    {
      title: 'Junior Data Scientist',
      company: 'TechStart Inc',
      duration: '2022-Present',
      description: 'Developed ML models for customer segmentation and predictive analytics'
    },
    {
      title: 'Software Developer Intern',
      company: 'DataFlow Corp',
      duration: '2021-2022',
      description: 'Built web applications using React and Node.js'
    }
  ]
};

const CareerDashboard = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [profile, setProfile] = useState(null);
  const [dashboardData, setDashboardData] = useState({
    careerSuggestions: null,
    jobRecommendations: null,
    marketTrends: null
  });
  const [debugInfo, setDebugInfo] = useState({});

  useEffect(() => {
    initializeDashboard();
  }, []);

  const initializeDashboard = async () => {
    try {
      setLoading(true);
      setError(null);
      
      console.log('🚀 Initializing Career Dashboard...');
      
      // Use mock profile data
      setProfile(MOCK_USER_PROFILE);
      console.log('✅ Profile loaded (mock data)', MOCK_USER_PROFILE);
      
      // Test API connectivity
      const authToken = localStorage.getItem('auth_token');
      setDebugInfo(prev => ({ ...prev, authToken: authToken ? 'Present' : 'Missing' }));
      
      // Initialize with real API data
      await Promise.allSettled([
        loadCareerSuggestions(),
        loadJobRecommendations(),
        loadMarketTrends()
      ]);
      
    } catch (err) {
      console.error('💥 Dashboard initialization error:', err);
      setError(`Dashboard initialization failed: ${err.message}`);
      setDebugInfo(prev => ({ ...prev, initError: err.message }));
    } finally {
      setLoading(false);
    }
  };

  const loadCareerSuggestions = async () => {
    try {
      console.log('📋 Loading career suggestions...');
      const result = await APIService.getCareerSuggestions();
      
      if (result.success) {
        setDashboardData(prev => ({ ...prev, careerSuggestions: result.data }));
        console.log('✅ Career suggestions loaded:', result.data);
      } else {
        console.warn('⚠️ Career suggestions failed:', result.error);
        setDebugInfo(prev => ({ ...prev, careerSuggestionsError: result.error }));
      }
    } catch (error) {
      console.error('❌ Error loading career suggestions:', error);
      setDebugInfo(prev => ({ ...prev, careerSuggestionsError: error.message }));
    }
  };

  const loadJobRecommendations = async () => {
    try {
      console.log('💼 Loading job recommendations...');
      const result = await APIService.getJobRecommendations({
        location: profile?.careerGoals?.locationPreference,
        skills: profile?.skills?.map(s => s.name).join(',')
      });
      
      if (result.success) {
        setDashboardData(prev => ({ ...prev, jobRecommendations: result.data }));
        console.log('✅ Job recommendations loaded:', result.data);
      } else {
        console.warn('⚠️ Job recommendations failed:', result.error);
        setDebugInfo(prev => ({ ...prev, jobRecommendationsError: result.error }));
      }
    } catch (error) {
      console.error('❌ Error loading job recommendations:', error);
      setDebugInfo(prev => ({ ...prev, jobRecommendationsError: error.message }));
    }
  };

  const loadMarketTrends = async () => {
    try {
      console.log('📈 Loading market trends...');
      const result = await APIService.getJobMarketTrends({
        location: profile?.careerGoals?.locationPreference,
        industry: profile?.careerGoals?.targetIndustry
      });
      
      if (result.success) {
        setDashboardData(prev => ({ ...prev, marketTrends: result.data }));
        console.log('✅ Market trends loaded:', result.data);
      } else {
        console.warn('⚠️ Market trends failed:', result.error);
        setDebugInfo(prev => ({ ...prev, marketTrendsError: result.error }));
      }
    } catch (error) {
      console.error('❌ Error loading market trends:', error);
      setDebugInfo(prev => ({ ...prev, marketTrendsError: error.message }));
    }
  };

  const handleTabChange = (tabId) => {
    console.log(`🔄 Switching to tab: ${tabId}`);
    setActiveTab(tabId);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <DashboardOverview profile={profile} data={dashboardData} onTabChange={handleTabChange} />;
      case 'career-suggestions':
        return <CareerSuggestions profile={profile} data={dashboardData.careerSuggestions} />;
      case 'job-recommendations':
        return <JobRecommendations profile={profile} data={dashboardData.jobRecommendations} />;
      case 'market-trends':
        return <JobMarketTrends profile={profile} data={dashboardData.marketTrends} />;
      case 'skill-gap':
        return <SkillGapAnalysis profile={profile} targetRole={profile?.careerGoals?.shortTermGoal} />;
      case 'resume-analyzer':
        return <ResumeAnalyzer profile={profile} />;
      default:
        return <div className="text-center py-8 text-gray-500">Select a tab to view content</div>;
    }
  };

  const tabs = [
    { id: 'overview', name: 'Overview', icon: ChartBarIcon },
    { id: 'career-suggestions', name: 'Career Paths', icon: BriefcaseIcon },
    { id: 'job-recommendations', name: 'Job Matches', icon: TrendingUpIcon },
    { id: 'market-trends', name: 'Market Trends', icon: ChartBarIcon },
    { id: 'skill-gap', name: 'Skill Gap', icon: BeakerIcon },
    { id: 'resume-analyzer', name: 'Resume AI', icon: DocumentTextIcon }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <LoadingSpinner message="Loading your career dashboard..." size="large" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <ErrorMessage 
          message={error} 
          onRetry={initializeDashboard}
          additionalInfo={
            <div className="mt-4">
              <details className="mt-4">
                <summary className="cursor-pointer text-sm font-medium text-gray-700 hover:text-gray-900">
                  Debug Information
                </summary>
                <pre className="mt-2 text-xs bg-gray-100 p-3 rounded overflow-auto max-h-40">
                  {JSON.stringify(debugInfo, null, 2)}
                </pre>
              </details>
            </div>
          }
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center mr-4">
                <UserIcon className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{profile.fullName}</h1>
                <p className="text-gray-600">{profile.currentRole} • {profile.location}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-500">Career Goal</p>
              <p className="font-semibold text-blue-600">{profile.careerGoals.shortTermGoal}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="w-5 h-5 mr-2" />
                {tab.name}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderTabContent()}
      </div>

      {/* Debug Panel (Development only) */}
      {process.env.NODE_ENV === 'development' && (
        <div className="fixed bottom-4 right-4">
          <details className="bg-white rounded-lg shadow-lg border border-gray-200 p-4 max-w-md">
            <summary className="cursor-pointer font-medium text-gray-700 hover:text-gray-900">
              Debug Panel
            </summary>
            <div className="mt-2 max-h-60 overflow-auto">
              <pre className="text-xs text-gray-600">
                {JSON.stringify(debugInfo, null, 2)}
              </pre>
            </div>
          </details>
        </div>
      )}
    </div>
  );
};

// Dashboard Overview Component
const DashboardOverview = ({ profile, data, onTabChange }) => {
  const getSkillLevelColor = (level) => {
    const colors = {
      'Expert': 'bg-green-100 text-green-800',
      'Advanced': 'bg-blue-100 text-blue-800',
      'Intermediate': 'bg-yellow-100 text-yellow-800',
      'Beginner': 'bg-red-100 text-red-800'
    };
    return colors[level] || 'bg-gray-100 text-gray-800';
  };

  const getSkillLevelPercentage = (level) => {
    const percentages = {
      'Expert': 95,
      'Advanced': 80,
      'Intermediate': 60,
      'Beginner': 30
    };
    return percentages[level] || 50;
  };

  return (
    <div className="space-y-8">
      {/* Career Goals Section */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Career Goals Progress</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium text-gray-700 mb-2">Short-term Goal</h3>
            <p className="text-lg text-blue-600 font-medium">{profile.careerGoals.shortTermGoal}</p>
            <button 
              onClick={() => onTabChange('skill-gap')}
              className="mt-2 text-sm text-blue-600 hover:text-blue-800 font-medium"
            >
              View Skill Gap Analysis →
            </button>
          </div>
          <div>
            <h3 className="font-medium text-gray-700 mb-2">Long-term Goal</h3>
            <p className="text-lg text-blue-600 font-medium">{profile.careerGoals.longTermGoal}</p>
            <p className="text-sm text-gray-600 mt-1">Target timeline: 3-5 years</p>
          </div>
        </div>
      </div>

      {/* Current Skills Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Skills</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {profile.skills.map((skill, index) => (
            <div key={index} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-gray-900">{skill.name}</h3>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSkillLevelColor(skill.level)}`}>
                  {skill.level}
                </span>
              </div>
              <div className="text-sm text-gray-600 mb-2">{skill.category}</div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${getSkillLevelPercentage(skill.level)}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Career Suggestions Card */}
        <div 
          onClick={() => onTabChange('career-suggestions')}
          className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex items-center mb-4">
            <BriefcaseIcon className="h-8 w-8 text-blue-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Career Paths</h3>
          </div>
          <p className="text-gray-600 mb-4">AI-powered career suggestions based on your skills and goals</p>
          {data.careerSuggestions && (
            <p className="text-sm text-blue-600 font-medium">
              {data.careerSuggestions.suggestions?.length || 0} personalized suggestions available
            </p>
          )}
        </div>

        {/* Job Recommendations Card */}
        <div 
          onClick={() => onTabChange('job-recommendations')}
          className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex items-center mb-4">
            <TrendingUpIcon className="h-8 w-8 text-green-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Job Matches</h3>
          </div>
          <p className="text-gray-600 mb-4">Real-time job recommendations from multiple sources</p>
          {data.jobRecommendations && (
            <p className="text-sm text-green-600 font-medium">
              {data.jobRecommendations.jobs?.length || 0} matching jobs found
            </p>
          )}
        </div>

        {/* Market Trends Card */}
        <div 
          onClick={() => onTabChange('market-trends')}
          className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex items-center mb-4">
            <ChartBarIcon className="h-8 w-8 text-purple-600 mr-3" />
            <h3 className="text-lg font-semibold text-gray-900">Market Trends</h3>
          </div>
          <p className="text-gray-600 mb-4">Latest insights on demand, salary, and skill trends</p>
          {data.marketTrends && (
            <p className="text-sm text-purple-600 font-medium">
              Updated market data available
            </p>
          )}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
        <div className="space-y-4">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
              <BriefcaseIcon className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Updated career goals</p>
              <p className="text-xs text-gray-500">2 hours ago</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              <DocumentTextIcon className="h-4 w-4 text-green-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Analyzed resume for ML Engineer role</p>
              <p className="text-xs text-gray-500">1 day ago</p>
            </div>
          </div>
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0 w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <ChartBarIcon className="h-4 w-4 text-purple-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Viewed market trends for AI/ML roles</p>
              <p className="text-xs text-gray-500">3 days ago</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CareerDashboard;