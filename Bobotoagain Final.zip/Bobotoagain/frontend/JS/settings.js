/**
 * settings.js - Settings page functionality for Boboto with DeepSeek AI
 */

document.addEventListener('DOMContentLoaded', () => {
    // Protect the page
    protectPage();
    
    // Initialize settings page
    initSettingsPage();
    
    // Setup event listeners
    setupSettingsEventListeners();
    
    // Initialize DeepSeek settings
    initDeepSeekSettings();
    
    // Load all settings
    loadSettings();
});

// Initialize the settings page
async function initSettingsPage() {
    try {
        // Update auth UI
        updateAuthUI();
        
        // Load AI settings and check status
        await loadAISettings();
        
        // Initialize other settings sections
        initializeOtherSettings();
        
    } catch (error) {
        console.error('Error initializing settings page:', error);
        showNotification('Error loading settings', 'error');
    }
}

// Initialize DeepSeek API settings functionality
function initDeepSeekSettings() {
    // DOM elements
    const modelSelect = document.getElementById('aiModel');
    const temperatureSlider = document.getElementById('temperature');
    const temperatureValue = document.getElementById('temperatureValue');
    const maxTokensSelect = document.getElementById('maxTokens');
    const testConnectionBtn = document.getElementById('testConnection');
    const statusDot = document.getElementById('openaiStatusDot'); // Reusing existing elements
    const statusText = document.getElementById('openaiStatusText');
    
    // Update model options to DeepSeek models
    if (modelSelect) {
        populateDeepSeekModels();
    }
    
    // Update temperature value display
    if (temperatureSlider && temperatureValue) {
        temperatureSlider.addEventListener('input', () => {
            temperatureValue.textContent = temperatureSlider.value;
            updateCostEstimate();
        });
    }
    
    // Test API connection
    if (testConnectionBtn) {
        testConnectionBtn.addEventListener('click', testDeepSeekConnection);
    }
}

// Populate DeepSeek model options
function populateDeepSeekModels() {
    const modelSelect = document.getElementById('aiModel');
    if (!modelSelect) return;
    
    const deepseekModels = [
        { value: 'deepseek/deepseek-r1:free', label: 'DeepSeek R1 (Free)' },
        { value: 'deepseek/deepseek-chat', label: 'DeepSeek Chat' },
        { value: 'deepseek/deepseek-coder', label: 'DeepSeek Coder' }
    ];
    
    // Clear existing options
    modelSelect.innerHTML = '';
    
    // Add new options
    deepseekModels.forEach(model => {
        const option = document.createElement('option');
        option.value = model.value;
        option.textContent = model.label;
        modelSelect.appendChild(option);
    });
}

// Setup event listeners
function setupSettingsEventListeners() {
    // Mobile menu toggle
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navMenu.classList.toggle('active');
            this.setAttribute('aria-expanded', 
                this.getAttribute('aria-expanded') === 'false' ? 'true' : 'false'
            );
        });
    }
    
    // Cost calculation triggers
    const costInputs = [
        document.getElementById('aiModel'),
        document.getElementById('maxTokens'),
        document.getElementById('messagesPerDay'),
        document.getElementById('averageMessageLength')
    ];
    
    costInputs.forEach(input => {
        if (input) {
            input.addEventListener('change', updateCostEstimate);
            input.addEventListener('input', updateCostEstimate);
        }
    });
    
    // Save settings button
    const saveSettingsBtn = document.querySelector('.btn-save');
    if (saveSettingsBtn) {
        saveSettingsBtn.addEventListener('click', saveAllSettings);
    }
    
    // Password change form
    const changePasswordForm = document.getElementById('changePasswordForm');
    if (changePasswordForm) {
        changePasswordForm.addEventListener('submit', handlePasswordChange);
    }
}

// Load AI settings for DeepSeek
async function loadAISettings() {
    try {
        // Get AI settings from API
        const aiSettings = await API.AI.getSettings();
        
        // Update form with settings
        const modelSelect = document.getElementById('aiModel');
        const temperatureSlider = document.getElementById('temperature');
        const temperatureValue = document.getElementById('temperatureValue');
        const maxTokensSelect = document.getElementById('maxTokens');
        
        if (modelSelect) modelSelect.value = aiSettings.model || 'deepseek/deepseek-r1:free';
        if (temperatureSlider) {
            temperatureSlider.value = aiSettings.temperature || 0.7;
            if (temperatureValue) temperatureValue.textContent = temperatureSlider.value;
        }
        if (maxTokensSelect) maxTokensSelect.value = aiSettings.maxTokens || 1000;
        
        // Test AI status
        await checkAIStatus();
        
    } catch (error) {
        console.error('Error loading AI settings:', error);
        updateConnectionStatus(false, 'Configuration Error');
    }
}

// Check DeepSeek AI status
async function checkAIStatus() {
    const statusDot = document.getElementById('openaiStatusDot');
    const statusText = document.getElementById('openaiStatusText');
    
    if (!statusDot || !statusText) return;
    
    try {
        statusDot.className = 'status-dot';
        statusText.textContent = 'Checking...';
        
        // Try to generate a simple response
        const testMessage = "Hello, this is a test. Please respond with 'Success'.";
        const response = await API.AI.generateResponse(testMessage, []);
        
        if (response && response.includes('Success')) {
            updateConnectionStatus(true, 'Connected');
            showNotification('DeepSeek AI integration is working correctly', 'success');
        } else {
            updateConnectionStatus(true, 'Connected (Response Unclear)');
            showNotification('DeepSeek AI integration is working but response was unexpected', 'warning');
        }
    } catch (error) {
        console.error('AI status check error:', error);
        updateConnectionStatus(false, 'Connection Failed');
        showNotification('DeepSeek AI integration test failed: ' + error.message, 'error');
    }
}

// Test DeepSeek API connection
async function testDeepSeekConnection() {
    const testButton = document.getElementById('testConnection');
    if (!testButton) return;
    
    const originalText = testButton.textContent;
    testButton.textContent = 'Testing...';
    testButton.disabled = true;
    
    try {
        await checkAIStatus();
    } finally {
        testButton.textContent = originalText;
        testButton.disabled = false;
    }
}

// Update cost estimate for DeepSeek
function updateCostEstimate() {
    const messagesPerDayInput = document.getElementById('messagesPerDay');
    const messageLength = document.getElementById('averageMessageLength');
    const modelSelect = document.getElementById('aiModel');
    const maxTokensSelect = document.getElementById('maxTokens');
    const monthlyCostElem = document.getElementById('monthlyCost');
    
    if (!messagesPerDayInput || !monthlyCostElem) return;
    
    // Get values
    const messagesPerDay = parseInt(messagesPerDayInput.value) || 20;
    const avgMessageLength = messageLength ? messageLength.value : 'medium';
    const model = modelSelect ? modelSelect.value : 'deepseek/deepseek-r1:free';
    const maxTokens = maxTokensSelect ? parseInt(maxTokensSelect.value) : 1000;
    
    // Map message length to tokens
    const tokensMap = {
        'short': 200,
        'medium': 500,
        'long': 1000
    };
    
    // Map DeepSeek models to cost per 1000 tokens
    const costMap = {
        'deepseek/deepseek-r1:free': 0.0, // Free model
        'deepseek/deepseek-chat': 0.002, // Estimated cost
        'deepseek/deepseek-coder': 0.002 // Estimated cost
    };
    
    // Calculate tokens per message
    const inputTokens = tokensMap[avgMessageLength] || 500;
    const outputTokens = maxTokens;
    const totalTokensPerMessage = (inputTokens + outputTokens) * 1.2; // 20% overhead
    
    // Calculate monthly cost
    const costPerToken = costMap[model] || 0.0;
    const dailyTokens = messagesPerDay * totalTokensPerMessage;
    const monthlyTokens = dailyTokens * 30;
    const monthlyCost = (monthlyTokens * costPerToken) / 1000;
    
    // Update display
    monthlyCostElem.textContent = `$${monthlyCost.toFixed(2)}`;
    
    // Show "Free" for free models
    if (costPerToken === 0) {
        monthlyCostElem.textContent = 'Free';
    }
}

// Save all settings
async function saveAllSettings(event) {
    event.preventDefault();
    
    try {
        // Save AI settings
        await saveAISettings();
        
        // Save account settings
        saveAccountSettings();
        
        // Save display settings
        saveDisplaySettings();
        
        // Save notification settings
        saveNotificationSettings();
        
        // Save chatbot preferences
        saveChatbotSettings();
        
        showNotification('All settings saved successfully!', 'success');
        
    } catch (error) {
        console.error('Error saving settings:', error);
        showNotification('Error saving settings: ' + error.message, 'error');
    }
}

// Save AI settings for DeepSeek
async function saveAISettings() {
    const modelSelect = document.getElementById('aiModel');
    const temperatureSlider = document.getElementById('temperature');
    const maxTokensSelect = document.getElementById('maxTokens');
    
    const model = modelSelect ? modelSelect.value : 'deepseek/deepseek-r1:free';
    const temperature = temperatureSlider ? parseFloat(temperatureSlider.value) : 0.7;
    const maxTokens = maxTokensSelect ? parseInt(maxTokensSelect.value) : 1000;
    
    try {
        await API.AI.updateSettings({
            model: model,
            temperature: temperature,
            maxTokens: maxTokens
        });
        
        // Save personalization settings
        const useProfileData = document.getElementById('useProfileData');
        const saveConversations = document.getElementById('saveConversations');
        const chatMemoryLength = document.getElementById('chatMemoryLength');
        
        if (useProfileData) {
            localStorage.setItem('use_profile_data', useProfileData.checked);
        }
        
        if (saveConversations) {
            localStorage.setItem('save_conversations', saveConversations.checked);
        }
        
        if (chatMemoryLength) {
            localStorage.setItem('chat_memory_length', chatMemoryLength.value);
        }
        
    } catch (error) {
        console.error('Error saving AI settings:', error);
        throw error;
    }
}

// Load all settings
async function loadSettings() {
    try {
        // Load user preferences
        const userInfo = getUserInfo();
        
        // Account settings
        loadAccountSettings(userInfo);
        
        // Display settings
        loadDisplaySettings();
        
        // Notification settings
        loadNotificationSettings();
        
        // Load chatbot settings
        loadChatbotSettings();
        
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

// Load account settings
function loadAccountSettings(userInfo) {
    const displayNameInput = document.getElementById('display-name');
    const emailInput = document.getElementById('email');
    const timeZoneSelect = document.getElementById('time-zone');
    
    if (displayNameInput && userInfo) {
        displayNameInput.value = userInfo.fullName || '';
    }
    
    if (emailInput && userInfo) {
        emailInput.value = userInfo.email || '';
    }
    
    if (timeZoneSelect) {
        const timeZone = localStorage.getItem('user_timezone') || 'utc-5';
        timeZoneSelect.value = timeZone;
    }
}

// Load display settings
function loadDisplaySettings() {
    const themeSelect = document.getElementById('theme-selector');
    const fontSizeSelect = document.getElementById('font-size');
    
    if (themeSelect) {
        const theme = localStorage.getItem('theme') || 'light';
        themeSelect.value = theme;
        
        // Apply theme
        document.body.setAttribute('data-theme', theme);
    }
    
    if (fontSizeSelect) {
        const fontSize = localStorage.getItem('font_size') || 'medium';
        fontSizeSelect.value = fontSize;
        
        // Apply font size
        document.documentElement.setAttribute('data-font-size', fontSize);
    }
    
    // Load accessibility settings
    const highContrastToggle = document.querySelector('[name="high-contrast"]');
    const screenReaderToggle = document.querySelector('[name="screen-reader"]');
    const reducedMotionToggle = document.querySelector('[name="reduced-motion"]');
    
    if (highContrastToggle) {
        highContrastToggle.checked = localStorage.getItem('high_contrast') === 'true';
    }
    
    if (screenReaderToggle) {
        screenReaderToggle.checked = localStorage.getItem('screen_reader') === 'true';
    }
    
    if (reducedMotionToggle) {
        reducedMotionToggle.checked = localStorage.getItem('reduced_motion') === 'true';
    }
}

// Load notification settings
function loadNotificationSettings() {
    const emailNotifications = document.querySelector('[name="email-notifications"]');
    const pushNotifications = document.querySelector('[name="push-notifications"]');
    const learningReminders = document.querySelector('[name="learning-reminders"]');
    
    if (emailNotifications) {
        emailNotifications.checked = localStorage.getItem('email_notifications') !== 'false';
    }
    
    if (pushNotifications) {
        pushNotifications.checked = localStorage.getItem('push_notifications') === 'true';
    }
    
    if (learningReminders) {
        learningReminders.checked = localStorage.getItem('learning_reminders') !== 'false';
    }
    
    // Privacy settings
    const conversationHistory = document.querySelector('[name="conversation-history"]');
    const dataAnalytics = document.querySelector('[name="data-analytics"]');
    const thirdPartySharing = document.querySelector('[name="third-party-sharing"]');
    
    if (conversationHistory) {
        conversationHistory.checked = localStorage.getItem('save_conversations') !== 'false';
    }
    
    if (dataAnalytics) {
        dataAnalytics.checked = localStorage.getItem('data_analytics') !== 'false';
    }
    
    if (thirdPartySharing) {
        thirdPartySharing.checked = localStorage.getItem('third_party_sharing') === 'true';
    }
}

// Load chatbot settings
function loadChatbotSettings() {
    // Academic focus level
    const academicFocus = document.getElementById('academic-focus');
    if (academicFocus) {
        academicFocus.value = localStorage.getItem('academic_focus') || 'medium';
    }
    
    // Career guidance focus
    const careerFocus = document.getElementById('career-focus');
    if (careerFocus) {
        careerFocus.value = localStorage.getItem('career_focus') || 'high';
    }
    
    // Response style
    const responseStyle = document.getElementById('response-style');
    if (responseStyle) {
        responseStyle.value = localStorage.getItem('response_style') || 'balanced';
    }
    
    // Study field
    const studyField = document.getElementById('study-field');
    if (studyField) {
        studyField.value = localStorage.getItem('study_field') || 'computer_science';
    }
    
    // Education level
    const educationLevel = document.getElementById('education-level');
    if (educationLevel) {
        educationLevel.value = localStorage.getItem('education_level') || 'undergraduate';
    }
}

// Update connection status
function updateConnectionStatus(isConnected, message = '') {
    const statusDot = document.getElementById('openaiStatusDot');
    const statusText = document.getElementById('openaiStatusText');
    
    if (!statusDot || !statusText) return;
    
    if (isConnected) {
        statusDot.className = 'status-dot connected';
        statusText.textContent = message || 'Connected';
    } else {
        statusDot.className = 'status-dot disconnected';
        statusText.textContent = message || 'Not Connected';
    }
}

// Save account settings
function saveAccountSettings() {
    const displayNameInput = document.getElementById('display-name');
    const emailInput = document.getElementById('email');
    const timeZoneSelect = document.getElementById('time-zone');
    
    if (displayNameInput) {
        // In a real app, we'd save the display name to the backend
        localStorage.setItem('display_name', displayNameInput.value);
    }
    
    if (timeZoneSelect) {
        localStorage.setItem('user_timezone', timeZoneSelect.value);
    }
}

// Save display settings
function saveDisplaySettings() {
    const themeSelect = document.getElementById('theme-selector');
    const fontSizeSelect = document.getElementById('font-size');
    
    if (themeSelect) {
        localStorage.setItem('theme', themeSelect.value);
        document.body.setAttribute('data-theme', themeSelect.value);
    }
    
    if (fontSizeSelect) {
        localStorage.setItem('font_size', fontSizeSelect.value);
        document.documentElement.setAttribute('data-font-size', fontSizeSelect.value);
    }
    
    // Save accessibility settings
    const highContrastToggle = document.querySelector('[name="high-contrast"]');
    const screenReaderToggle = document.querySelector('[name="screen-reader"]');
    const reducedMotionToggle = document.querySelector('[name="reduced-motion"]');
    
    if (highContrastToggle) {
        localStorage.setItem('high_contrast', highContrastToggle.checked);
        if (highContrastToggle.checked) {
            document.body.classList.add('high-contrast');
        } else {
            document.body.classList.remove('high-contrast');
        }
    }
    
    if (screenReaderToggle) {
        localStorage.setItem('screen_reader', screenReaderToggle.checked);
    }
    
    if (reducedMotionToggle) {
        localStorage.setItem('reduced_motion', reducedMotionToggle.checked);
        if (reducedMotionToggle.checked) {
            document.documentElement.style.setProperty('--animation-time', '0.01s');
        } else {
            document.documentElement.style.removeProperty('--animation-time');
        }
    }
}

// Save notification settings
function saveNotificationSettings() {
    const emailNotifications = document.querySelector('[name="email-notifications"]');
    const pushNotifications = document.querySelector('[name="push-notifications"]');
    const learningReminders = document.querySelector('[name="learning-reminders"]');
    
    if (emailNotifications) {
        localStorage.setItem('email_notifications', emailNotifications.checked);
    }
    
    if (pushNotifications) {
        localStorage.setItem('push_notifications', pushNotifications.checked);
        
        // Request permission if enabling push notifications
        if (pushNotifications.checked && 'Notification' in window) {
            if (Notification.permission !== 'granted') {
                Notification.requestPermission();
            }
        }
    }
    
    if (learningReminders) {
        localStorage.setItem('learning_reminders', learningReminders.checked);
    }
    
    // Save privacy settings
    const conversationHistory = document.querySelector('[name="conversation-history"]');
    const dataAnalytics = document.querySelector('[name="data-analytics"]');
    const thirdPartySharing = document.querySelector('[name="third-party-sharing"]');
    
    if (conversationHistory) {
        localStorage.setItem('save_conversations', conversationHistory.checked);
    }
    
    if (dataAnalytics) {
        localStorage.setItem('data_analytics', dataAnalytics.checked);
    }
    
    if (thirdPartySharing) {
        localStorage.setItem('third_party_sharing', thirdPartySharing.checked);
    }
}

// Save chatbot settings
function saveChatbotSettings() {
    // Save all chatbot preferences
    const chatbotSettings = {
        academicFocus: document.getElementById('academic-focus')?.value,
        careerFocus: document.getElementById('career-focus')?.value,
        responseStyle: document.getElementById('response-style')?.value,
        studyField: document.getElementById('study-field')?.value,
        educationLevel: document.getElementById('education-level')?.value
    };
    
    Object.keys(chatbotSettings).forEach(key => {
        if (chatbotSettings[key]) {
            localStorage.setItem(`chatbot_${key.toLowerCase()}`, chatbotSettings[key]);
        }
    });
}

// Handle password change
async function handlePasswordChange(event) {
    event.preventDefault();
    
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    
    // Validate passwords
    if (!currentPassword || !newPassword || !confirmPassword) {
        showNotification('Please fill in all password fields', 'error');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        showNotification('New passwords do not match', 'error');
        return;
    }
    
    if (newPassword.length < 6) {
        showNotification('New password must be at least 6 characters long', 'error');
        return;
    }
    
    try {
        await API.Auth.changePassword(currentPassword, newPassword);
        showNotification('Password changed successfully!', 'success');
        
        // Clear form
        document.getElementById('changePasswordForm').reset();
        
    } catch (error) {
        console.error('Password change error:', error);
        showNotification('Failed to change password: ' + error.message, 'error');
    }
}

// Initialize other settings sections
function initializeOtherSettings() {
    // Apply any custom theme settings
    applyThemeSettings();
    
    // Set up event listeners for toggles
    setupToggleListeners();
    
    // Calculate initial cost estimate
    updateCostEstimate();
}

// Apply theme settings
function applyThemeSettings() {
    const theme = localStorage.getItem('theme') || 'light';
    const fontSize = localStorage.getItem('font_size') || 'medium';
    const highContrast = localStorage.getItem('high_contrast') === 'true';
    const reducedMotion = localStorage.getItem('reduced_motion') === 'true';
    
    document.body.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-font-size', fontSize);
    
    if (highContrast) {
        document.body.classList.add('high-contrast');
    }
    
    if (reducedMotion) {
        document.documentElement.style.setProperty('--animation-time', '0.01s');
    }
}

// Setup toggle listeners
function setupToggleListeners() {
    const toggles = document.querySelectorAll('.toggle-switch input[type="checkbox"]');
    
    toggles.forEach(toggle => {
        toggle.addEventListener('change', function() {
            // Save individual toggle states
            const settingName = this.name.replace(/-/g, '_');
            localStorage.setItem(settingName, this.checked);
            
            // Apply immediate effects if needed
            if (settingName === 'high_contrast') {
                if (this.checked) {
                    document.body.classList.add('high-contrast');
                } else {
                    document.body.classList.remove('high-contrast');
                }
            } else if (settingName === 'reduced_motion') {
                if (this.checked) {
                    document.documentElement.style.setProperty('--animation-time', '0.01s');
                } else {
                    document.documentElement.style.removeProperty('--animation-time');
                }
            }
        });
    });
}

// Export functions for global use
window.testAPIConnection = testDeepSeekConnection;
window.checkAIStatus = checkAIStatus;
window.updateCostEstimate = updateCostEstimate;