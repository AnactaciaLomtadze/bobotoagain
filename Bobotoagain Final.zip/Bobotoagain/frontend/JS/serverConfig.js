// JS/serverConfig.js - Fixed configuration
(function() {
  'use strict';

  // Detect environment based on different criteria
  const isLocalhost = window.location.hostname === 'localhost' || 
                     window.location.hostname === '127.0.0.1' ||
                     window.location.hostname === '';
  
  const isFileProtocol = window.location.protocol === 'file:';
  const isDevelopment = isLocalhost || isFileProtocol;
  const isProduction = !isDevelopment;

  // Configuration based on environment
  const config = {
    // Environment detection
    environment: isProduction ? 'production' : 'development',
    isDevelopment,
    isProduction,

    // API Configuration - fix the API URL for local development
    apiUrl: function() {
      if (isFileProtocol) {
        // If running from file://, assume backend is on localhost:3000
        return 'http://localhost:3000/api';
      } else if (isLocalhost) {
        // If running on localhost, use the same host but port 3000 for API
        return `http://localhost:3000/api`;
      } else {
        // Production
        return '/api';
      }
    }(),

    // Google OAuth
    googleClientId: '553695210966-n0ll7o356saoofcat2rlnvo6ln9u9njq.apps.googleusercontent.com',

    // Frontend URL for email links
    frontendUrl: isLocalhost ? 'http://localhost:5000' : window.location.origin,

    // Debug mode
    debug: isDevelopment || localStorage.getItem('boboto_debug') === 'true',

    // Version
    version: '1.2.0',
    lastUpdated: '2025-01-14'
  };

  // Expose configuration globally
  window.serverConfig = config;

  // Log configuration in development
  if (config.debug) {
    console.log('[Boboto Config] Environment:', config.environment);
    console.log('[Boboto Config] API URL:', config.apiUrl);
    console.log('[Boboto Config] Frontend URL:', config.frontendUrl);
    console.log('[Boboto Config] Current location:', window.location.href);
  }

  // Check backend connectivity
  async function checkBackend() {
    try {
      const response = await fetch(`${config.apiUrl}/auth/test`);
      if (response.ok) {
        console.log('✅ Backend connection successful');
      } else {
        console.warn('⚠️ Backend responded with:', response.status);
      }
    } catch (error) {
      console.error('❌ Backend connection failed:', error.message);
      console.log('Make sure the backend server is running on http://localhost:3000');
    }
  }

  // Check backend when page loads
  window.addEventListener('load', () => {
    if (config.debug) {
      setTimeout(checkBackend, 1000); // Wait 1 second for everything to load
    }
  });

  // Helper to fix relative paths
  window.serverConfig.getFullUrl = function(path) {
    if (path.startsWith('http')) {
      return path;
    }
    if (path.startsWith('/')) {
      return config.frontendUrl + path;
    }
    return config.frontendUrl + '/' + path;
  };
})();