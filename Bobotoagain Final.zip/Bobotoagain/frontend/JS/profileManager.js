// JS/profileManager.js
/**
 * profileManager.js - Managing user profile data and UI updates
 */

class ProfileManager {
    constructor() {
      this.profileData = null;
      this.isLoading = false;
      this.hasLoadedOnce = false;
      
      // Try to load profile on init if authenticated
      if (isAuthenticated()) {
        this.loadProfile();
      }
      
      // Listen for profile sync events
      document.addEventListener('profile-synced', this.handleProfileSync.bind(this));
    }
    
    // Handle profile sync events
    handleProfileSync(event) {
      if (event.detail) {
        this.profileData = event.detail;
        // Update UI if on profile page
        this.updateProfileUI();
      }
    }
    
    // Load profile data
    async loadProfile() {
      if (this.isLoading || !isAuthenticated()) return;
      
      this.isLoading = true;
      
      try {
        // Show loading spinner if first load
        if (!this.hasLoadedOnce) {
          this.showLoadingState();
        }
        
        // Get profile data
        this.profileData = await API.Profile.get();
        this.hasLoadedOnce = true;
        
        // Update UI with profile data
        this.updateProfileUI();
        
        return this.profileData;
      } catch (error) {
        console.error('Error loading profile:', error);
        showNotification('Failed to load profile data', 'error');
        
        // Try to use cached data
        const cachedData = this.getCachedProfile();
        if (cachedData) {
          this.profileData = cachedData;
          this.updateProfileUI();
          return cachedData;
        }
      } finally {
        this.isLoading = false;
        this.hideLoadingState();
      }
    }
    
    // Get cached profile data from localStorage
    getCachedProfile() {
      const userInfo = getUserInfo();
      if (!userInfo) return null;
      
      // Combine available data
      return {
        ...userInfo,
        learningPreferences: JSON.parse(localStorage.getItem('learning_preferences') || '{}'),
        careerGoals: JSON.parse(localStorage.getItem('career_goals') || '{}'),
        skills: JSON.parse(localStorage.getItem('user_skills') || '[]')
      };
    }
    
    // Update UI with profile data
    updateProfileUI() {
      if (!this.profileData) return;
      
      // Update personal info
      this.updatePersonalInfo();
      
      // Update learning preferences
      this.updateLearningPreferences();
      
      // Update career goals
      this.updateCareerGoals();
      
      // Update skills
      this.updateSkills();
      
      // Update profile stats
      this.updateProfileStats();
    }
    
    // Update personal info in UI
    updatePersonalInfo() {
      // Update user name elements
      document.querySelectorAll('.user-name').forEach(el => {
        el.textContent = this.profileData.fullName || 'User';
      });
      
      // Update profile picture
      document.querySelectorAll('.profile-picture img').forEach(el => {
        el.src = this.profileData.profilePictureUrl || '/images/default-avatar.png';
        el.alt = `${this.profileData.fullName || 'User'}'s profile picture`;
      });
      
      // Update user details
      const userDetails = document.querySelector('.user-details');
      if (userDetails && this.profileData.major) {
        userDetails.textContent = `${this.profileData.major || ''} ${this.profileData.academicLevel || 'Student'}`;
      }
      
      // Update personal info card
      const personalInfoCard = document.querySelector('.personal-info .card-content');
      if (personalInfoCard) {
        personalInfoCard.innerHTML = `
          <div class="profile-field">
            <span class="field-label">Name:</span>
            <span class="field-value">${this.profileData.fullName || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Email:</span>
            <span class="field-value">${this.profileData.email || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Phone:</span>
            <span class="field-value">${this.profileData.phone || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">University:</span>
            <span class="field-value">${this.profileData.university || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Major:</span>
            <span class="field-value">${this.profileData.major || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Graduation Year:</span>
            <span class="field-value">${this.profileData.graduationYear || 'Not set'}</span>
          </div>
        `;
      }
      
      // Update form fields if they exist
      const nameInput = document.getElementById('fullName');
      if (nameInput) nameInput.value = this.profileData.fullName || '';
      
      const phoneInput = document.getElementById('phone');
      if (phoneInput) phoneInput.value = this.profileData.phone || '';
      
      const universityInput = document.getElementById('university');
      if (universityInput) universityInput.value = this.profileData.university || '';
      
      const majorInput = document.getElementById('major');
      if (majorInput) majorInput.value = this.profileData.major || '';
      
      const graduationYearInput = document.getElementById('graduationYear');
      if (graduationYearInput) graduationYearInput.value = this.profileData.graduationYear || '';
      
      const academicLevelInput = document.getElementById('academicLevel');
      if (academicLevelInput && this.profileData.academicLevel) {
        // Set select option
        Array.from(academicLevelInput.options).forEach(option => {
          if (option.value === this.profileData.academicLevel) {
            option.selected = true;
          }
        });
      }
    }
    
    // Update learning preferences in UI
    updateLearningPreferences() {
      const learningPrefs = this.profileData.learningPreferences || {};
      
      // Update learning preferences card
      const learningPrefsCard = document.querySelector('.learning-preferences .card-content');
      if (learningPrefsCard) {
        learningPrefsCard.innerHTML = `
          <div class="profile-field">
            <span class="field-label">Learning Style:</span>
            <span class="field-value">${learningPrefs.learningStyle || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Preferred Materials:</span>
            <span class="field-value">${learningPrefs.preferredMaterials?.join(', ') || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Learning Pace:</span>
            <span class="field-value">${learningPrefs.learningPace || 'Not set'}</span>
          </div>
        `;
      }
      
      // Update form fields if they exist
      const learningStyleInput = document.getElementById('learningStyle');
      if (learningStyleInput && learningPrefs.learningStyle) {
        // Set select option
        Array.from(learningStyleInput.options).forEach(option => {
          if (option.value === learningPrefs.learningStyle) {
            option.selected = true;
          }
        });
      }
      
      // Update preferred materials checkboxes
      if (learningPrefs.preferredMaterials) {
        const materials = learningPrefs.preferredMaterials;
        
        materials.forEach(material => {
          const checkbox = document.getElementById(`material-${material.toLowerCase().replace(/\s+/g, '-')}`);
          if (checkbox) {
            checkbox.checked = true;
          }
        });
      }
      
      // Update learning pace radio buttons
      if (learningPrefs.learningPace) {
        const paceRadio = document.querySelector(`input[name="learningPace"][value="${learningPrefs.learningPace}"]`);
        if (paceRadio) {
          paceRadio.checked = true;
        }
      }
    }
    
    // Update career goals in UI
    updateCareerGoals() {
      const careerGoals = this.profileData.careerGoals || {};
      
      // Update career goals card
      const careerGoalsCard = document.querySelector('.career-goals .card-content');
      if (careerGoalsCard) {
        careerGoalsCard.innerHTML = `
          <div class="profile-field">
            <span class="field-label">Short-Term Goal:</span>
            <span class="field-value">${careerGoals.shortTermGoal || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Long-Term Goal:</span>
            <span class="field-value">${careerGoals.longTermGoal || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Skills Focus:</span>
            <span class="field-value">${careerGoals.skillsFocus?.join(', ') || 'Not set'}</span>
          </div>
          <div class="profile-field">
            <span class="field-label">Target Industry:</span>
            <span class="field-value">${careerGoals.targetIndustry || 'Not set'}</span>
          </div>
        `;
      }
      
      // Update form fields if they exist
      const shortTermGoalInput = document.getElementById('shortTermGoal');
      if (shortTermGoalInput) shortTermGoalInput.value = careerGoals.shortTermGoal || '';
      
      const longTermGoalInput = document.getElementById('longTermGoal');
      if (longTermGoalInput) longTermGoalInput.value = careerGoals.longTermGoal || '';
      
      const targetIndustryInput = document.getElementById('targetIndustry');
      if (targetIndustryInput && careerGoals.targetIndustry) {
        // Set select option
        Array.from(targetIndustryInput.options).forEach(option => {
          if (option.value === careerGoals.targetIndustry) {
            option.selected = true;
          }
        });
      }
      
      // Update skills focus checkboxes
      if (careerGoals.skillsFocus) {
        const skillsFocus = careerGoals.skillsFocus;
        
        skillsFocus.forEach(skill => {
          const checkbox = document.getElementById(`skill-${skill.toLowerCase().replace(/\s+/g, '-')}`);
          if (checkbox) {
            checkbox.checked = true;
          }
        });
      }
    }
    
    // Update skills in UI
    updateSkills() {
      const skills = this.profileData.skills || [];
      
      // Update skills progress section
      const progressSection = document.querySelector('.progress-section');
      if (!progressSection) return;
      
      if (skills.length === 0) {
        progressSection.innerHTML = `
          <div class="progress-header">
            <h3 class="progress-title">Skills Progress</h3>
            <a href="bobotoSkill.html" class="btn btn-outline">Add Skills</a>
          </div>
          <p class="empty-state-message">No skills have been added yet. Add skills to track your progress.</p>
        `;
        return;
      }
      
      // Sort skills by level (highest first)
      const sortedSkills = [...skills].sort((a, b) => {
        const levels = ['Novice', 'Beginner', 'Intermediate', 'Advanced', 'Expert'];
        return levels.indexOf(b.level) - levels.indexOf(a.level);
      });
      
      // Get top skills (max 3)
      const topSkills = sortedSkills.slice(0, 3);
      
      // Generate progress bars HTML
      let progressHtml = `
        <div class="progress-header">
          <h3 class="progress-title">Skills Progress</h3>
          <a href="bobotoSkill.html" class="btn btn-outline">View All Skills</a>
        </div>
      `;
      
      topSkills.forEach(skill => {
        // Convert level to percentage
        let percentage;
        switch (skill.level) {
          case 'Expert': percentage = 90; break;
          case 'Advanced': percentage = 75; break;
          case 'Intermediate': percentage = 50; break;
          case 'Beginner': percentage = 25; break;
          case 'Novice': percentage = 10; break;
          default: percentage = 0;
        }
        
        progressHtml += `
          <div class="progress-item">
            <div class="progress-label">
              <span>${skill.name}</span>
              <span>${skill.level}</span>
            </div>
            <div class="progress-bar">
              <div class="progress-value" style="width: ${percentage}%;"></div>
            </div>
          </div>
        `;
      });
      
      progressSection.innerHTML = progressHtml;
      
      // Update skills list if on skills page
      const skillsList = document.querySelector('.skills-list');
      if (skillsList) {
        let skillsHtml = '';
        
        if (skills.length === 0) {
          skillsHtml = `<p class="empty-state-message">No skills have been added yet.</p>`;
        } else {
          skills.forEach(skill => {
            // Convert level to percentage for progress bar
            let percentage;
            switch (skill.level) {
              case 'Expert': percentage = 90; break;
              case 'Advanced': percentage = 75; break;
              case 'Intermediate': percentage = 50; break;
              case 'Beginner': percentage = 25; break;
              case 'Novice': percentage = 10; break;
              default: percentage = 0;
            }
            
            // Format date
            const addedDate = new Date(skill.addedAt).toLocaleDateString();
            
            skillsHtml += `
              <div class="skill-item" data-id="${skill._id}">
                <div class="skill-header">
                  <h4 class="skill-name">${skill.name}</h4>
                  <div class="skill-actions">
                    <button class="btn-icon edit-skill" title="Edit skill">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
                      </svg>
                    </button>
                    <button class="btn-icon delete-skill" title="Delete skill">
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="3 6 5 6 21 6"></polyline>
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                      </svg>
                    </button>
                  </div>
                </div>
                <div class="skill-details">
                  <div class="skill-level">
                    <span>${skill.level}</span>
                    <div class="progress-bar">
                      <div class="progress-value" style="width: ${percentage}%;"></div>
                    </div>
                  </div>
                  <div class="skill-meta">
                    <span>Added: ${addedDate}</span>
                  </div>
                </div>
              </div>
            `;
          });
          
          skillsList.innerHTML = skillsHtml;
          
          // Add event listeners for skill actions
          document.querySelectorAll('.edit-skill').forEach(button => {
            button.addEventListener('click', this.handleEditSkill.bind(this));
          });
          
          document.querySelectorAll('.delete-skill').forEach(button => {
            button.addEventListener('click', this.handleDeleteSkill.bind(this));
          });
        }
      }
    }
    
    // Update profile stats in UI
    updateProfileStats() {
      // Calculate profile completion percentage
      const stats = this.calculateProfileStats();
      
      // Update stats card
      const statsCard = document.querySelector('.profile-stats');
      if (statsCard) {
        statsCard.innerHTML = `
          <div class="stat-item">
            <div class="stat-value">${stats.completionPercentage}%</div>
            <div class="stat-label">Profile Completion</div>
            <div class="progress-bar">
              <div class="progress-value" style="width: ${stats.completionPercentage}%;"></div>
            </div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${stats.skillsCount}</div>
            <div class="stat-label">Skills Added</div>
          </div>
          <div class="stat-item">
            <div class="stat-value">${stats.chatSessionsCount}</div>
            <div class="stat-label">Chat Sessions</div>
          </div>
        `;
      }
    }
    
    // Calculate profile statistics
    calculateProfileStats() {
      // Initialize stats
      const stats = {
        completionPercentage: 0,
        skillsCount: 0,
        chatSessionsCount: 0
      };
      
      // Get skills count
      stats.skillsCount = (this.profileData.skills || []).length;
      
      // Calculate completion percentage
      let totalFields = 0;
      let completedFields = 0;
      
      // Personal info fields
      const personalInfoFields = [
        'fullName', 'email', 'phone', 'university', 'major', 'graduationYear', 'academicLevel'
      ];
      
      totalFields += personalInfoFields.length;
      personalInfoFields.forEach(field => {
        if (this.profileData[field]) completedFields++;
      });
      
      // Learning preferences fields
      const learningPrefs = this.profileData.learningPreferences || {};
      const learningPrefsFields = ['learningStyle', 'preferredMaterials', 'learningPace'];
      
      totalFields += learningPrefsFields.length;
      learningPrefsFields.forEach(field => {
        if (learningPrefs[field] && 
            (typeof learningPrefs[field] !== 'object' || learningPrefs[field].length > 0)) {
          completedFields++;
        }
      });
      
      // Career goals fields
      const careerGoals = this.profileData.careerGoals || {};
      const careerGoalsFields = ['shortTermGoal', 'longTermGoal', 'skillsFocus', 'targetIndustry'];
      
      totalFields += careerGoalsFields.length;
      careerGoalsFields.forEach(field => {
        if (careerGoals[field] && 
            (typeof careerGoals[field] !== 'object' || careerGoals[field].length > 0)) {
          completedFields++;
        }
      });
      
      // Skills completion bonus (up to 3 skills)
      const skillsCount = Math.min(stats.skillsCount, 3);
      totalFields += 3;
      completedFields += skillsCount;
      
      // Calculate percentage
      stats.completionPercentage = Math.round((completedFields / totalFields) * 100);
      
      // Get chat sessions count from localStorage
      try {
        const chatHistory = JSON.parse(localStorage.getItem('boboto_chat_history') || '[]');
        stats.chatSessionsCount = chatHistory.length;
      } catch (error) {
        stats.chatSessionsCount = 0;
      }
      
      return stats;
    }
    
    // Handle edit skill
    handleEditSkill(event) {
      const skillItem = event.currentTarget.closest('.skill-item');
      if (!skillItem) return;
      
      const skillId = skillItem.getAttribute('data-id');
      const skill = this.profileData.skills.find(s => s._id === skillId);
      
      if (!skill) return;
      
      // Get skill modal elements
      const skillModal = document.getElementById('skill-modal');
      const skillNameInput = document.getElementById('skill-name');
      const skillLevelSelect = document.getElementById('skill-level');
      const saveSkillBtn = document.getElementById('save-skill-btn');
      
      if (!skillModal || !skillNameInput || !skillLevelSelect || !saveSkillBtn) return;
      
      // Populate modal with skill data
      skillNameInput.value = skill.name;
      Array.from(skillLevelSelect.options).forEach(option => {
        if (option.value === skill.level) {
          option.selected = true;
        } else {
          option.selected = false;
        }
      });
      
      // Set modal mode to edit
      skillModal.setAttribute('data-mode', 'edit');
      skillModal.setAttribute('data-skill-id', skillId);
      
      // Update modal title
      const modalTitle = skillModal.querySelector('.modal-title');
      if (modalTitle) {
        modalTitle.textContent = 'Edit Skill';
      }
      
      // Show modal
      skillModal.classList.add('active');
      document.body.classList.add('modal-open');
      
      // Focus on first input
      skillNameInput.focus();
    }
    
    // Handle delete skill
    handleDeleteSkill(event) {
      const skillItem = event.currentTarget.closest('.skill-item');
      if (!skillItem) return;
      
      const skillId = skillItem.getAttribute('data-id');
      const skill = this.profileData.skills.find(s => s._id === skillId);
      
      if (!skill) return;
      
      // Confirm deletion
      if (!confirm(`Are you sure you want to delete the "${skill.name}" skill?`)) {
        return;
      }
      
      // Remove skill
      this.deleteSkill(skillId);
    }
    
    // Delete skill
 async deleteSkill(skillId) {
    try {
      // Remove from server
      await API.Profile.removeSkill(skillId);
      
      // Update local data
      this.profileData.skills = this.profileData.skills.filter(s => s._id !== skillId);
      
      // Update UI
      this.updateSkills();
      this.updateProfileStats();
      
      // Show success notification
      showNotification('Skill deleted successfully', 'success');
    } catch (error) {
      console.error('Error deleting skill:', error);
      
      // Use profile synchronizer for offline support
      if (window.profileSync) {
        const updatedSkills = window.profileSync.removeSkill(skillId);
        
        // Update local data
        this.profileData.skills = updatedSkills;
        
        // Update UI
        this.updateSkills();
        this.updateProfileStats();
        
        showNotification('Skill deleted and will sync when online', 'info');
      } else {
        showNotification('Failed to delete skill', 'error');
      }
    }
  }
  
  // Add or update skill
  async addOrUpdateSkill(name, level, skillId = null) {
    try {
      let result;
      
      if (skillId) {
        // Update existing skill
        const existingSkill = this.profileData.skills.find(s => s._id === skillId);
        if (!existingSkill) throw new Error('Skill not found');
        
        // Call API
        result = await API.Profile.addSkill(name, level);
      } else {
        // Add new skill
        result = await API.Profile.addSkill(name, level);
      }
      
      // Update local data with server response
      this.profileData.skills = result;
      
      // Update UI
      this.updateSkills();
      this.updateProfileStats();
      
      // Show success notification
      showNotification(`Skill ${skillId ? 'updated' : 'added'} successfully`, 'success');
      
      return true;
    } catch (error) {
      console.error(`Error ${skillId ? 'updating' : 'adding'} skill:`, error);
      
      // Use profile synchronizer for offline support
      if (window.profileSync) {
        const updatedSkills = window.profileSync.addOrUpdateSkill(name, level);
        
        // Update local data
        this.profileData.skills = updatedSkills;
        
        // Update UI
        this.updateSkills();
        this.updateProfileStats();
        
        showNotification(`Skill ${skillId ? 'updated' : 'added'} and will sync when online`, 'info');
        return true;
      } else {
        showNotification(`Failed to ${skillId ? 'update' : 'add'} skill`, 'error');
        return false;
      }
    }
  }
  
  // Update learning preferences
  async updateLearningPreferences(preferences) {
    try {
      // Call API
      const result = await API.Profile.updateLearningPreferences(preferences);
      
      // Update local data
      this.profileData.learningPreferences = result;
      
      // Update UI
      this.updateLearningPreferences();
      this.updateProfileStats();
      
      // Show success notification
      showNotification('Learning preferences updated successfully', 'success');
      
      return true;
    } catch (error) {
      console.error('Error updating learning preferences:', error);
      
      // Use profile synchronizer for offline support
      if (window.profileSync) {
        const updatedPrefs = window.profileSync.updateLearningPreferences(preferences);
        
        // Update local data
        this.profileData.learningPreferences = updatedPrefs;
        
        // Update UI
        this.updateLearningPreferences();
        this.updateProfileStats();
        
        showNotification('Learning preferences updated and will sync when online', 'info');
        return true;
      } else {
        showNotification('Failed to update learning preferences', 'error');
        return false;
      }
    }
  }
  
  // Update career goals
  async updateCareerGoals(goals) {
    try {
      // Call API
      const result = await API.Profile.updateCareerGoals(goals);
      
      // Update local data
      this.profileData.careerGoals = result;
      
      // Update UI
      this.updateCareerGoals();
      this.updateProfileStats();
      
      // Show success notification
      showNotification('Career goals updated successfully', 'success');
      
      return true;
    } catch (error) {
      console.error('Error updating career goals:', error);
      
      // Use profile synchronizer for offline support
      if (window.profileSync) {
        const updatedGoals = window.profileSync.updateCareerGoals(goals);
        
        // Update local data
        this.profileData.careerGoals = updatedGoals;
        
        // Update UI
        this.updateCareerGoals();
        this.updateProfileStats();
        
        showNotification('Career goals updated and will sync when online', 'info');
        return true;
      } else {
        showNotification('Failed to update career goals', 'error');
        return false;
      }
    }
  }
  
  // Update profile
  async updateProfile(profileData) {
    try {
      // Call API
      const result = await API.Profile.update(profileData);
      
      // Update local data
      Object.assign(this.profileData, result);
      
      // Update user info in localStorage if name changed
      if (profileData.fullName) {
        const userInfo = getUserInfo();
        if (userInfo) {
          userInfo.fullName = profileData.fullName;
          localStorage.setItem('user_info', JSON.stringify(userInfo));
        }
      }
      
      // Update UI
      this.updatePersonalInfo();
      this.updateProfileStats();
      
      // Update auth UI to reflect name change
      if (typeof updateAuthUI === 'function') {
        updateAuthUI();
      }
      
      // Show success notification
      showNotification('Profile updated successfully', 'success');
      
      return true;
    } catch (error) {
      console.error('Error updating profile:', error);
      
      // Use profile synchronizer for offline support
      if (window.profileSync) {
        window.profileSync.updateProfile(profileData);
        
        // Update local data
        Object.assign(this.profileData, profileData);
        
        // Update user info in localStorage if name changed
        if (profileData.fullName) {
          const userInfo = getUserInfo();
          if (userInfo) {
            userInfo.fullName = profileData.fullName;
            localStorage.setItem('user_info', JSON.stringify(userInfo));
          }
        }
        
        // Update UI
        this.updatePersonalInfo();
        this.updateProfileStats();
        
        // Update auth UI to reflect name change
        if (typeof updateAuthUI === 'function') {
          updateAuthUI();
        }
        
        showNotification('Profile updated and will sync when online', 'info');
        return true;
      } else {
        showNotification('Failed to update profile', 'error');
        return false;
      }
    }
  }
  
  // Upload profile picture
  async uploadProfilePicture(fileInput) {
    try {
      if (!fileInput.files || fileInput.files.length === 0) {
        throw new Error('No file selected');
      }
      
      const file = fileInput.files[0];
      
      // Check file type
      const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
      if (!allowedTypes.includes(file.type)) {
        throw new Error('Only JPEG, JPG, and PNG files are allowed');
      }
      
      // Check file size (max 5MB)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        throw new Error('File size too large. Maximum size is 5MB');
      }
      
      // Create form data
      const formData = new FormData();
      formData.append('profilePicture', file);
      
      // Show loading indicator
      this.showLoadingState();
      
      // Call API
      const result = await API.Profile.uploadProfilePicture(formData);
      
      // Update profile data
      this.profileData.profilePictureUrl = result.profilePictureUrl;
      
      // Update user info in localStorage
      const userInfo = getUserInfo();
      if (userInfo) {
        userInfo.profilePictureUrl = result.profilePictureUrl;
        localStorage.setItem('user_info', JSON.stringify(userInfo));
      }
      
      // Update UI
      this.updatePersonalInfo();
      
      // Update auth UI to reflect profile picture change
      if (typeof updateAuthUI === 'function') {
        updateAuthUI();
      }
      
      // Show success notification
      showNotification('Profile picture updated successfully', 'success');
      
      return true;
    } catch (error) {
      console.error('Error uploading profile picture:', error);
      showNotification(error.message || 'Failed to upload profile picture', 'error');
      return false;
    } finally {
      this.hideLoadingState();
    }
  }
  
  // Show loading state
  showLoadingState() {
    // Create loading overlay if it doesn't exist
    let loadingOverlay = document.querySelector('.loading-overlay');
    
    if (!loadingOverlay) {
      loadingOverlay = document.createElement('div');
      loadingOverlay.className = 'loading-overlay';
      loadingOverlay.innerHTML = `
        <div class="loading-spinner">
          <div class="spinner"></div>
          <div class="loading-text">Loading profile...</div>
        </div>
      `;
      document.body.appendChild(loadingOverlay);
    }
    
    loadingOverlay.style.display = 'flex';
  }
  
  // Hide loading state
  hideLoadingState() {
    const loadingOverlay = document.querySelector('.loading-overlay');
    if (loadingOverlay) {
      loadingOverlay.style.display = 'none';
    }
  }
 }
 
 // Initialize profile manager
 const profileManager = new ProfileManager();
 
 // Export to window object
 window.profileManager = profileManager;