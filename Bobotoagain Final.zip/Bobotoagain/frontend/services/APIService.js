// frontend/services/APIService.js - Complete fixed version with enhanced error handling
class APIService {
    constructor() {
      // Dynamic base URL detection
      this.baseURL = this.determineBaseURL();
      this.token = null;
      
      console.log(`[APIService] Using base URL: ${this.baseURL}`);
      this.updateToken();
    }
  
    determineBaseURL() {
      // Try to get API URL from server config first
      if (window.serverConfig && window.serverConfig.apiUrl) {
        return window.serverConfig.apiUrl;
      }
      
      // Auto-detect based on environment
      const currentOrigin = window.location.origin;
      
      // For file:// protocol, use localhost
      if (window.location.protocol === 'file:') {
        return 'http://localhost:3000/api';
      }
      
      // For development ports, use port 3000 for API
      const currentPort = window.location.port;
      if (currentPort === '5000' || currentPort === '3001') {
        return `${window.location.protocol}//${window.location.hostname}:3000/api`;
      }
      
      // Default to same origin with /api
      return `${currentOrigin}/api`;
    }
  
    updateToken() {
      this.token = localStorage.getItem('auth_token');
    }
  
    async makeRequest(endpoint, options = {}) {
      // Always get fresh token
      this.updateToken();
      
      const url = `${this.baseURL}${endpoint}`;
      const config = {
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
        ...options,
      };
  
      // Add auth token to headers
      if (this.token) {
        config.headers['x-auth-token'] = this.token;
      }
  
      // Handle FormData (for file uploads)
      if (options.body instanceof FormData) {
        delete config.headers['Content-Type']; // Let browser set it for FormData
      }
  
      try {
        console.log(`🔵 API Request: ${config.method || 'GET'} ${url}`);
        console.log('🔵 Request headers:', config.headers);
        
        if (config.body && !(config.body instanceof FormData)) {
          console.log('🔵 Request body:', config.body);
        }
        
        const response = await fetch(url, config);
        
        // Enhanced response logging
        console.log(`🔵 Response status: ${response.status} ${response.statusText}`);
        console.log(`🔵 Response headers:`, Object.fromEntries(response.headers.entries()));
        
        // Check if the response is ok
        if (!response.ok) {
          let errorData;
          const contentType = response.headers.get('content-type');
          
          if (contentType && contentType.includes('application/json')) {
            errorData = await response.json();
          } else {
            const textData = await response.text();
            errorData = { 
              message: textData || `HTTP Error ${response.status}: ${response.statusText}`,
              status: response.status
            };
          }
          
          console.error(`❌ API Error (${endpoint}):`, errorData);
          
          // Handle auth errors
          if (response.status === 401) {
            console.warn('🔴 Authentication required - removing token');
            localStorage.removeItem('auth_token');
            this.token = null;
            
            // Optionally redirect to login
            if (window.location.pathname !== '/login' && window.location.pathname !== '/HTML/bobotoLogin.html') {
              window.location.href = '/HTML/bobotoLogin.html';
            }
            
            return { success: false, error: 'Authentication required' };
          }
          
          return {
            success: false,
            error: errorData.message || errorData.error || `Request failed with status ${response.status}`,
            status: response.status,
            data: errorData
          };
        }
  
        let data;
        const contentType = response.headers.get('content-type');
        
        if (contentType && contentType.includes('application/json')) {
          data = await response.json();
        } else {
          data = await response.text();
        }
        
        console.log(`✅ API Success (${endpoint}):`, data);
        
        return {
          success: true,
          data: data,
          status: response.status
        };
      } catch (error) {
        console.error(`❌ API Error (${endpoint}):`, error);
        
        // Enhanced error information
        return {
          success: false,
          error: error.message || 'Network error occurred',
          type: error.name || 'NetworkError',
          stack: error.stack,
          status: 0
        };
      }
    }
  
    // Authentication methods
    async login(email, password) {
      return this.makeRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
    }
  
    async register(userData) {
      return this.makeRequest('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData)
      });
    }
  
    async logout() {
      const result = await this.makeRequest('/auth/logout', {
        method: 'POST'
      });
      
      // Clear local storage
      localStorage.removeItem('auth_token');
      localStorage.removeItem('user_info');
      this.token = null;
      
      return result;
    }
  
    // Profile methods
    async getProfile() {
      return this.makeRequest('/profile');
    }
  
    async updateProfile(profileData) {
      return this.makeRequest('/profile', {
        method: 'PUT',
        body: JSON.stringify(profileData)
      });
    }
  
    async updateSkills(skills) {
      return this.makeRequest('/profile/skills', {
        method: 'PUT',
        body: JSON.stringify({ skills })
      });
    }
  
    // Career-related methods with real API calls
    async getCareerSuggestions() {
      return this.makeRequest('/career/suggestions');
    }
  
    async getSkillGapAnalysis(targetRole) {
      return this.makeRequest('/career/skill-gap-analysis', {
        method: 'POST',
        body: JSON.stringify({ targetRole })
      });
    }
  
    async getJobRecommendations(filters = {}) {
      const params = new URLSearchParams();
      Object.keys(filters).forEach(key => {
        if (filters[key]) params.append(key, filters[key]);
      });
      const queryString = params.toString() ? `?${params.toString()}` : '';
      return this.makeRequest(`/career/jobs${queryString}`);
    }
  
    async getJobMarketTrends(filters = {}) {
      const params = new URLSearchParams();
      Object.keys(filters).forEach(key => {
        if (filters[key]) params.append(key, filters[key]);
      });
      const queryString = params.toString() ? `?${params.toString()}` : '';
      return this.makeRequest(`/career/job-market${queryString}`);
    }
  
    async analyzeResume(file, targetRole) {
      const formData = new FormData();
      formData.append('resume', file);
      if (targetRole) formData.append('targetRole', targetRole);
  
      return this.makeRequest('/career/analyze-resume', {
        method: 'POST',
        body: formData
      });
    }
  
    // Saved jobs methods
    async getSavedJobs() {
      return this.makeRequest('/career/saved-jobs');
    }
  
    async saveJob(jobData) {
      // Ensure we have all required fields
      const requiredData = {
        jobId: jobData.id || jobData.jobId,
        title: jobData.title,
        company: jobData.company,
        location: jobData.location,
        url: jobData.url,
        source: jobData.source,
        salary: jobData.salary,
        description: jobData.description
      };
  
      return this.makeRequest('/career/save-job', {
        method: 'POST',
        body: JSON.stringify(requiredData)
      });
    }
  
    async removeSavedJob(jobId) {
      return this.makeRequest(`/career/saved-jobs/${jobId}`, {
        method: 'DELETE'
      });
    }
  
    // Job applications methods
    async getJobApplications() {
      return this.makeRequest('/career/job-applications');
    }
  
    async updateJobApplication(jobId, status, notes) {
      return this.makeRequest(`/career/job-applications/${jobId}`, {
        method: 'PUT',
        body: JSON.stringify({ status, notes })
      });
    }
  
    // LinkedIn integration methods
    async connectLinkedIn() {
      return this.makeRequest('/career/linkedin/connect');
    }
  
    async importLinkedInSkills() {
      return this.makeRequest('/career/linkedin/import-skills', {
        method: 'POST'
      });
    }
  
    async disconnectLinkedIn() {
      return this.makeRequest('/career/linkedin/disconnect', {
        method: 'DELETE'
      });
    }
  
    // Test and debug methods
    async testConnection() {
      return this.makeRequest('/career/test');
    }
  
    async debugCareer() {
      return this.makeRequest('/career/debug');
    }
  
    async debugAI() {
      return this.makeRequest('/career/debug-ai');
    }
  
    async debugJobAPIs() {
      return this.makeRequest('/career/debug-job-apis');
    }
  
    // Connection validation
    async validateConnection() {
      console.log('🔵 Validating API connection...');
      
      // Test basic connectivity
      try {
        const testResult = await fetch(`${this.baseURL}/health`, {
          method: 'GET',
          timeout: 5000
        });
        
        if (!testResult.ok) {
          return {
            success: false,
            error: `Health check failed with status ${testResult.status}`,
            baseURL: this.baseURL
          };
        }
        
        console.log('✅ API connection validated');
        return { success: true, baseURL: this.baseURL };
      } catch (error) {
        console.error('❌ API connection validation failed:', error);
        return {
          success: false,
          error: `Connection failed: ${error.message}`,
          baseURL: this.baseURL
        };
      }
    }
  
    // Helper method to check if user is logged in
    isAuthenticated() {
      return !!this.token;
    }
  
    // Helper method to get current user from token (simplified)
    getCurrentUser() {
      if (!this.token) return null;
      
      try {
        // Decode JWT token (simplified - you should use a proper JWT library)
        const payload = this.token.split('.')[1];
        const decoded = JSON.parse(atob(payload));
        return decoded;
      } catch (error) {
        console.error('Error decoding token:', error);
        return null;
      }
    }
  }
  
  // Create singleton instance
  const apiService = new APIService();
  
  // Enhanced debugging in development
  if (typeof window !== 'undefined' && window.location.hostname === 'localhost') {
    window.APIService = apiService;
    
    // Add global debug methods
    window.debugAPI = {
      testConnection: () => apiService.testConnection(),
      validateConnection: () => apiService.validateConnection(),
      getCareerSuggestions: () => apiService.getCareerSuggestions(),
      getJobRecommendations: () => apiService.getJobRecommendations(),
      debugCareer: () => apiService.debugCareer(),
      debugAI: () => apiService.debugAI(),
      debugJobAPIs: () => apiService.debugJobAPIs()
    };
    
    console.log('🔧 Debug methods added to window.debugAPI');
  }
  
  // Export for both ES6 and CommonJS
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = apiService;
  } else if (typeof window !== 'undefined') {
    window.APIService = apiService;
  }
  
  // ES6 export
  export default apiService;