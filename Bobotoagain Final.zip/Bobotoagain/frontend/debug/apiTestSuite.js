// frontend/debug/apiTestSuite.js - Comprehensive API Testing Tool
class APITestSuite {
    constructor() {
      this.baseURL = this.determineBaseURL();
      this.token = localStorage.getItem('auth_token');
      this.results = {};
    }
  
    determineBaseURL() {
      const currentPort = window.location.port;
      const isDevelopment = currentPort === '3000' || currentPort === '3001';
      
      if (isDevelopment) {
        return `${window.location.protocol}//${window.location.hostname}:5000/api`;
      } else {
        return `${window.location.origin}/api`;
      }
    }
  
    // Test basic connectivity
    async testBasicConnection() {
      console.log('🔌 Testing basic connection...');
      try {
        const response = await fetch(`${this.baseURL}/health`);
        if (response.ok) {
          const data = await response.json();
          this.results.health = { status: 'success', data };
          console.log('✅ Health check passed:', data);
          return true;
        }
      } catch (error) {
        this.results.health = { status: 'error', error: error.message };
        console.error('❌ Health check failed:', error);
        return false;
      }
    }
  
    // Test authentication
    async testAuthentication() {
      console.log('🔐 Testing authentication...');
      
      // Test without token
      try {
        const response = await fetch(`${this.baseURL}/profile`);
        if (response.status === 401) {
          console.log('✅ Auth protection working - 401 received without token');
        }
      } catch (error) {
        console.log('⚠️ Network error during auth test:', error);
      }
  
      // Test with token
      if (this.token) {
        try {
          const response = await fetch(`${this.baseURL}/profile`, {
            headers: { 'x-auth-token': this.token }
          });
          
          if (response.ok) {
            const data = await response.json();
            this.results.auth = { status: 'success', data };
            console.log('✅ Authentication successful');
            return true;
          } else {
            this.results.auth = { status: 'error', message: 'Invalid token' };
            console.log('❌ Authentication failed - invalid token');
            return false;
          }
        } catch (error) {
          this.results.auth = { status: 'error', error: error.message };
          console.error('❌ Authentication test error:', error);
          return false;
        }
      } else {
        this.results.auth = { status: 'no_token', message: 'No auth token found' };
        console.log('⚠️ No auth token found in localStorage');
        return false;
      }
    }
  
    // Test career endpoints
    async testCareerEndpoints() {
      console.log('💼 Testing career endpoints...');
      const endpoints = [
        { name: 'Career Suggestions', endpoint: '/career/suggestions' },
        { name: 'Job Recommendations', endpoint: '/career/jobs' },
        { name: 'Market Trends', endpoint: '/career/job-market' },
        { name: 'Skill Gap Analysis', endpoint: '/career/skill-gap-analysis', method: 'POST', body: { targetRole: 'Software Engineer' } }
      ];
  
      for (const test of endpoints) {
        try {
          const config = {
            method: test.method || 'GET',
            headers: {
              'Content-Type': 'application/json',
              ...(this.token && { 'x-auth-token': this.token })
            }
          };
  
          if (test.body) {
            config.body = JSON.stringify(test.body);
          }
  
          const response = await fetch(`${this.baseURL}${test.endpoint}`, config);
          
          if (response.ok) {
            const data = await response.json();
            this.results[test.name] = { status: 'success', data };
            console.log(`✅ ${test.name} - Success`);
          } else {
            const errorData = await response.json().catch(() => ({ message: response.statusText }));
            this.results[test.name] = { status: 'error', error: errorData };
            console.log(`❌ ${test.name} - Failed:`, errorData);
          }
        } catch (error) {
          this.results[test.name] = { status: 'error', error: error.message };
          console.error(`❌ ${test.name} - Error:`, error);
        }
      }
    }
  
    // Test LinkedIn integration
    async testLinkedInIntegration() {
      console.log('💼 Testing LinkedIn integration...');
      
      try {
        // Test LinkedIn connect endpoint
        const response = await fetch(`${this.baseURL}/career/linkedin/connect`, {
          headers: { 'x-auth-token': this.token }
        });
        
        if (response.ok) {
          const data = await response.json();
          this.results.linkedIn = { status: 'success', data };
          console.log('✅ LinkedIn integration endpoint working');
        } else {
          const errorData = await response.json().catch(() => ({ message: response.statusText }));
          this.results.linkedIn = { status: 'error', error: errorData };
          console.log('❌ LinkedIn integration failed:', errorData);
        }
      } catch (error) {
        this.results.linkedIn = { status: 'error', error: error.message };
        console.error('❌ LinkedIn integration error:', error);
      }
    }
  
    // Test file upload (resume analysis)
    async testFileUpload() {
      console.log('📄 Testing file upload (resume analysis)...');
      
      // Create a dummy text file for testing
      const blob = new Blob(['Test resume content'], { type: 'text/plain' });
      const testFile = new File([blob], 'test-resume.txt', { type: 'text/plain' });
      
      const formData = new FormData();
      formData.append('resume', testFile);
      formData.append('targetRole', 'Software Engineer');
      
      try {
        const response = await fetch(`${this.baseURL}/career/analyze-resume`, {
          method: 'POST',
          headers: { 'x-auth-token': this.token },
          body: formData
        });
        
        if (response.ok) {
          const data = await response.json();
          this.results.fileUpload = { status: 'success', data };
          console.log('✅ File upload working');
        } else {
          const errorData = await response.json().catch(() => ({ message: response.statusText }));
          this.results.fileUpload = { status: 'error', error: errorData };
          console.log('❌ File upload failed:', errorData);
        }
      } catch (error) {
        this.results.fileUpload = { status: 'error', error: error.message };
        console.error('❌ File upload error:', error);
      }
    }
  
    // Run all tests
    async runAllTests() {
      console.log('🚀 Starting comprehensive API test suite...');
      console.log(`Base URL: ${this.baseURL}`);
      console.log(`Auth Token: ${this.token ? 'Present' : 'Missing'}`);
      
      const startTime = Date.now();
      
      await this.testBasicConnection();
      await this.testAuthentication();
      
      if (this.token) {
        await this.testCareerEndpoints();
        await this.testLinkedInIntegration();
        await this.testFileUpload();
      } else {
        console.log('⚠️ Skipping authenticated tests - no auth token');
      }
      
      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;
      
      console.log(`\n📊 Test Results Summary (Completed in ${duration}s)`);
      console.log('='.repeat(50));
      this.displayResults();
      
      return this.results;
    }
  
    // Display formatted results
    displayResults() {
      const successCount = Object.values(this.results).filter(r => r.status === 'success').length;
      const errorCount = Object.values(this.results).filter(r => r.status === 'error').length;
      const totalTests = Object.keys(this.results).length;
      
      console.log(`✅ Successful: ${successCount}/${totalTests}`);
      console.log(`❌ Failed: ${errorCount}/${totalTests}`);
      console.log(`🔶 Other: ${totalTests - successCount - errorCount}/${totalTests}`);
      
      console.log('\nDetailed Results:');
      console.log('-'.repeat(30));
      
      for (const [test, result] of Object.entries(this.results)) {
        const status = result.status === 'success' ? '✅' : result.status === 'error' ? '❌' : '🔶';
        console.log(`${status} ${test}: ${result.status}`);
        if (result.error) {
          console.log(`   Error: ${result.error.message || result.error}`);
        }
      }
    }
  
    // Generate HTML report
    generateHTMLReport() {
      const successCount = Object.values(this.results).filter(r => r.status === 'success').length;
      const errorCount = Object.values(this.results).filter(r => r.status === 'error').length;
      const totalTests = Object.keys(this.results).length;
      
      return `
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 20px auto; padding: 20px;">
          <h1>API Test Results</h1>
          <div style="background: #f5f5f5; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <h2>Summary</h2>
            <p><strong>Base URL:</strong> ${this.baseURL}</p>
            <p><strong>Auth Token:</strong> ${this.token ? 'Present' : 'Missing'}</p>
            <p><strong>Total Tests:</strong> ${totalTests}</p>
            <p><strong>Successful:</strong> ${successCount}</p>
            <p><strong>Failed:</strong> ${errorCount}</p>
          </div>
          
          <h2>Detailed Results</h2>
          ${Object.entries(this.results).map(([test, result]) => `
            <div style="border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; background: ${result.status === 'success' ? '#f0f8f0' : result.status === 'error' ? '#fdf0f0' : '#fffbf0'}">
              <h3>${result.status === 'success' ? '✅' : result.status === 'error' ? '❌' : '🔶'} ${test}</h3>
              <p><strong>Status:</strong> ${result.status}</p>
              ${result.error ? `<p><strong>Error:</strong> ${JSON.stringify(result.error, null, 2)}</p>` : ''}
              ${result.data ? `<details><summary>Response Data</summary><pre>${JSON.stringify(result.data, null, 2)}</pre></details>` : ''}
            </div>
          `).join('')}
        </div>
      `;
    }
  }
  
  // Make it globally available
  window.APITestSuite = APITestSuite;
  
  // Quick test function
  window.testAPI = async function() {
    const suite = new APITestSuite();
    const results = await suite.runAllTests();
    
    // Display HTML report
    const reportWindow = window.open('', 'API Test Report', 'width=800,height=600');
    reportWindow.document.write(suite.generateHTMLReport());
    reportWindow.document.close();
    
    return results;
  };
  
  export default APITestSuite;