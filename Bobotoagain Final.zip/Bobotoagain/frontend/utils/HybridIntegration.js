// frontend/utils/HybridIntegration.js
/**
 * Bridge between React components and vanilla JavaScript
 */
class HybridIntegration {
    constructor() {
      this.reactComponents = new Map();
      this.eventBridge = new EventTarget();
    }
  
    // Mount React component in vanilla JS page
    mountReactComponent(Component, containerId, props = {}) {
      const container = document.getElementById(containerId);
      if (!container) {
        console.error(`Container ${containerId} not found`);
        return;
      }
  
      // Check if React and ReactDOM are available
      if (typeof React === 'undefined' || typeof ReactDOM === 'undefined') {
        console.error('React libraries not loaded');
        return;
      }
  
      // Create React element and render
      const element = React.createElement(Component, {
        ...props,
        // Add bridge methods for communication
        onDataUpdate: (data) => this.eventBridge.dispatchEvent(new CustomEvent('react-data-update', { detail: data })),
        onAction: (action) => this.eventBridge.dispatchEvent(new CustomEvent('react-action', { detail: action }))
      });
  
      ReactDOM.render(element, container);
      this.reactComponents.set(containerId, { Component, element, props });
      
      console.log(`✅ React component mounted in ${containerId}`);
    }
  
    // Update React component props
    updateReactComponent(containerId, newProps) {
      const component = this.reactComponents.get(containerId);
      if (!component) {
        console.error(`Component ${containerId} not found`);
        return;
      }
  
      const updatedProps = { ...component.props, ...newProps };
      const element = React.createElement(component.Component, updatedProps);
      
      ReactDOM.render(element, document.getElementById(containerId));
      component.props = updatedProps;
    }
  
    // Listen to React component events in vanilla JS
    onReactEvent(eventType, callback) {
      this.eventBridge.addEventListener(eventType, callback);
    }
  
    // Send data from vanilla JS to React
    sendToReact(event, data) {
      this.eventBridge.dispatchEvent(new CustomEvent(`vanilla-${event}`, { detail: data }));
    }
  
    // Create wrapper for career dashboard integration
    createCareerDashboard(containerId) {
      // Check if we're in a React environment or need to load React
      if (typeof React === 'undefined') {
        this.loadReactLibs().then(() => {
          this.mountCareerDashboard(containerId);
        });
      } else {
        this.mountCareerDashboard(containerId);
      }
    }
  
    mountCareerDashboard(containerId) {
      // Create a wrapper component that can be used in vanilla JS
      const CareerDashboardWrapper = (props) => {
        const [activeTab, setActiveTab] = React.useState('career-suggestions');
        const [profile, setProfile] = React.useState(null);
        const [loading, setLoading] = React.useState(true);
  
        React.useEffect(() => {
          // Load profile data
          window.UnifiedAPI.getProfile().then(result => {
            if (result.success) {
              setProfile(result.data);
            }
            setLoading(false);
          });
        }, []);
  
        // Listen for events from vanilla JS
        React.useEffect(() => {
          const handleVanillaEvent = (event) => {
            const { action, data } = event.detail;
            switch (action) {
              case 'changeTab':
                setActiveTab(data.tab);
                break;
              case 'updateProfile':
                setProfile(data.profile);
                break;
            }
          };
  
          window.HybridIntegration.eventBridge.addEventListener('vanilla-action', handleVanillaEvent);
          return () => {
            window.HybridIntegration.eventBridge.removeEventListener('vanilla-action', handleVanillaEvent);
          };
        }, []);
  
        return React.createElement('div', { className: 'career-dashboard-wrapper' },
          // Tab Navigation
          React.createElement('div', { className: 'tab-nav' },
            ['career-suggestions', 'job-recommendations', 'job-trends', 'resume-analyzer'].map(tab =>
              React.createElement('button', {
                key: tab,
                className: `tab-btn ${activeTab === tab ? 'active' : ''}`,
                onClick: () => setActiveTab(tab)
              }, tab.replace('-', ' ').replace(/\b\w/g, l => l.toUpperCase()))
            )
          ),
          
          // Tab Content
          React.createElement('div', { className: 'tab-content' },
            loading 
              ? React.createElement('div', null, 'Loading...')
              : activeTab === 'career-suggestions' && React.createElement(window.CareerSuggestions, { profile })
          )
        );
      };
  
      this.mountReactComponent(CareerDashboardWrapper, containerId);
    }
  
    async loadReactLibs() {
      return new Promise((resolve, reject) => {
        // Load React if not already loaded
        if (typeof React === 'undefined') {
          const reactScript = document.createElement('script');
          reactScript.src = 'https://unpkg.com/react@18/umd/react.production.min.js';
          reactScript.onload = () => {
            const reactDOMScript = document.createElement('script');
            reactDOMScript.src = 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js';
            reactDOMScript.onload = resolve;
            reactDOMScript.onerror = reject;
            document.head.appendChild(reactDOMScript);
          };
          reactScript.onerror = reject;
          document.head.appendChild(reactScript);
        } else {
          resolve();
        }
      });
    }
  }
  
  // Create global instance
  window.HybridIntegration = new HybridIntegration();
  
  // Auto-initialize for career pages
  document.addEventListener('DOMContentLoaded', () => {
    // Check if we're on a career page and mount React components
    const careerContainer = document.getElementById('career-react-container');
    if (careerContainer) {
      window.HybridIntegration.createCareerDashboard('career-react-container');
    }
  });
  
  export default HybridIntegration;