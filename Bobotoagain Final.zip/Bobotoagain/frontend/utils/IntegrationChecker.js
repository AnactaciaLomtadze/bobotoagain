// frontend/utils/IntegrationChecker.js
class IntegrationChecker {
    constructor() {
      this.checkLog = [];
      this.api = window.UnifiedAPI || null;
    }
  
    async runAllChecks() {
      console.log('🔍 Running Frontend-Backend Integration Checks...');
      
      const checks = [
        this.checkAPIConnection(),
        this.checkAuthentication(),
        this.checkProfileEndpoints(),
        this.checkCareerEndpoints(),
        this.checkChatEndpoints(),
        this.checkAcademicEndpoints()
      ];
  
      const results = await Promise.allSettled(checks);
      
      // Summary report
      const summary = {
        total: results.length,
        passed: results.filter(r => r.status === 'fulfilled' && r.value.success).length,
        failed: results.filter(r => r.status === 'rejected' || !r.value.success).length
      };
  
      console.log('\n📊 Integration Check Summary:');
      console.log(`✅ Passed: ${summary.passed}`);
      console.log(`❌ Failed: ${summary.failed}`);
      console.log(`📋 Total: ${summary.total}`);
  
      return summary;
    }
  
    async checkAPIConnection() {
      console.log('\n1. Checking API Connection...');
      try {
        const response = await fetch(`${window.serverConfig.apiUrl}/health`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json'
          }
        });
  
        if (response.ok) {
          console.log('✅ API Connection: WORKING');
          return { success: true, check: 'API Connection' };
        } else {
          console.log('❌ API Connection: FAILED');
          return { success: false, check: 'API Connection', error: 'No response' };
        }
      } catch (error) {
        console.log('❌ API Connection: ERROR', error.message);
        return { success: false, check: 'API Connection', error: error.message };
      }
    }
  
    async checkAuthentication() {
      console.log('\n2. Checking Authentication...');
      try {
        const token = localStorage.getItem('auth_token');
        if (!token) {
          console.log('❌ Auth: No token found');
          return { success: false, check: 'Authentication', error: 'No token' };
        }
  
        const response = await fetch(`${window.serverConfig.apiUrl}/auth`, {
          headers: {
            'x-auth-token': token
          }
        });
  
        if (response.ok) {
          console.log('✅ Auth: Token valid');
          return { success: true, check: 'Authentication' };
        } else {
          console.log('❌ Auth: Token invalid');
          return { success: false, check: 'Authentication', error: 'Invalid token' };
        }
      } catch (error) {
        console.log('❌ Auth: ERROR', error.message);
        return { success: false, check: 'Authentication', error: error.message };
      }
    }
  
    async checkProfileEndpoints() {
      console.log('\n3. Checking Profile Endpoints...');
      const endpoints = [
        { path: '/profile', method: 'GET' },
        { path: '/profile/learning-preferences', method: 'GET' },
        { path: '/profile/career-goals', method: 'GET' },
        { path: '/profile/skills', method: 'GET' }
      ];
  
      let successCount = 0;
      for (const endpoint of endpoints) {
        try {
          const token = localStorage.getItem('auth_token');
          const response = await fetch(`${window.serverConfig.apiUrl}${endpoint.path}`, {
            method: endpoint.method,
            headers: {
              'x-auth-token': token
            }
          });
  
          if (response.ok || response.status === 404) {
            console.log(`✅ ${endpoint.path}: OK`);
            successCount++;
          } else {
            console.log(`❌ ${endpoint.path}: FAILED (${response.status})`);
          }
        } catch (error) {
          console.log(`❌ ${endpoint.path}: ERROR (${error.message})`);
        }
      }
  
      return {
        success: successCount === endpoints.length,
        check: 'Profile Endpoints',
        details: `${successCount}/${endpoints.length} working`
      };
    }
  
    async checkCareerEndpoints() {
      console.log('\n4. Checking Career Endpoints...');
      const endpoints = [
        { path: '/career/path-suggestions', method: 'GET' },
        { path: '/career/jobs', method: 'GET' },
        { path: '/career/job-market', method: 'GET' }
      ];
  
      let successCount = 0;
      for (const endpoint of endpoints) {
        try {
          const token = localStorage.getItem('auth_token');
          const response = await fetch(`${window.serverConfig.apiUrl}${endpoint.path}`, {
            method: endpoint.method,
            headers: {
              'x-auth-token': token
            }
          });
  
          if (response.ok || response.status === 404) {
            console.log(`✅ ${endpoint.path}: OK`);
            successCount++;
          } else {
            console.log(`❌ ${endpoint.path}: FAILED (${response.status})`);
          }
        } catch (error) {
          console.log(`❌ ${endpoint.path}: ERROR (${error.message})`);
        }
      }
  
      return {
        success: successCount === endpoints.length,
        check: 'Career Endpoints',
        details: `${successCount}/${endpoints.length} working`
      };
    }
  
    async checkChatEndpoints() {
      console.log('\n5. Checking Chat Endpoints...');
      const endpoints = [
        { path: '/ai/chat', method: 'POST' },
        { path: '/chat/sessions', method: 'GET' }
      ];
  
      let successCount = 0;
      for (const endpoint of endpoints) {
        try {
          const token = localStorage.getItem('auth_token');
          let config = {
            method: endpoint.method,
            headers: {
              'x-auth-token': token,
              'Content-Type': 'application/json'
            }
          };
  
          if (endpoint.method === 'POST') {
            config.body = JSON.stringify({ message: 'test', chatHistory: [] });
          }
  
          const response = await fetch(`${window.serverConfig.apiUrl}${endpoint.path}`, config);
  
          if (response.ok || response.status === 404) {
            console.log(`✅ ${endpoint.path}: OK`);
            successCount++;
          } else {
            console.log(`❌ ${endpoint.path}: FAILED (${response.status})`);
          }
        } catch (error) {
          console.log(`❌ ${endpoint.path}: ERROR (${error.message})`);
        }
      }
  
      return {
        success: successCount === endpoints.length,
        check: 'Chat Endpoints',
        details: `${successCount}/${endpoints.length} working`
      };
    }
  
    async checkAcademicEndpoints() {
      console.log('\n6. Checking Academic Endpoints...');
      const endpoints = [
        { path: '/academic/progress', method: 'GET' },
        { path: '/academic/resources', method: 'GET' }
      ];
  
      let successCount = 0;
      for (const endpoint of endpoints) {
        try {
          const token = localStorage.getItem('auth_token');
          const response = await fetch(`${window.serverConfig.apiUrl}${endpoint.path}`, {
            method: endpoint.method,
            headers: {
              'x-auth-token': token
            }
          });
  
          if (response.ok || response.status === 404) {
            console.log(`✅ ${endpoint.path}: OK`);
            successCount++;
          } else {
            console.log(`❌ ${endpoint.path}: FAILED (${response.status})`);
          }
        } catch (error) {
          console.log(`❌ ${endpoint.path}: ERROR (${error.message})`);
        }
      }
  
      return {
        success: successCount === endpoints.length,
        check: 'Academic Endpoints',
        details: `${successCount}/${endpoints.length} working`
      };
    }
  
    // Manual testing helper
    generateTestScript() {
      return `
  // Run this in browser console to test integration
  async function testIntegration() {
    const checker = new IntegrationChecker();
    const results = await checker.runAllChecks();
    
    // Test specific functionality
    console.log('\\n🧪 Testing specific features...');
    
    // Test career suggestions
    console.log('\\nTesting Career Suggestions...');
    try {
      const careerResult = await UnifiedAPI.getCareerSuggestions();
      console.log(careerResult.success ? '✅ Career Suggestions: WORKING' : '❌ Career Suggestions: FAILED');
    } catch (e) {
      console.log('❌ Career Suggestions: ERROR', e.message);
    }
    
    // Test profile
    console.log('\\nTesting Profile...');
    try {
      const profileResult = await UnifiedAPI.getProfile();
      console.log(profileResult.success ? '✅ Profile: WORKING' : '❌ Profile: FAILED');
    } catch (e) {
      console.log('❌ Profile: ERROR', e.message);
    }
    
    return results;
  }
  
  // Run the test
  testIntegration();
      `;
    }
  }
  
  // Create global instance
  window.IntegrationChecker = IntegrationChecker;
  
  // Auto-run check in development
  if (window.serverConfig?.debug) {
    window.addEventListener('load', () => {
      setTimeout(() => {
        const checker = new IntegrationChecker();
        checker.runAllChecks();
      }, 2000);
    });
  }