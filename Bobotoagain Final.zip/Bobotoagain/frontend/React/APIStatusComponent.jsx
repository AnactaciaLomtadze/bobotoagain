import React, { useState, useEffect } from 'react';
import { CheckCircleIcon, XCircleIcon, ClockIcon } from '@heroicons/react/24/outline';

const APIStatusComponent = () => {
  const [apiStatus, setApiStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    checkAPIStatus();
  }, []);

  const checkAPIStatus = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/career/debug-apis');
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      setApiStatus(data);
      setError(null);
    } catch (err) {
      console.error('Error checking API status:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (test) => {
    if (!test) return <ClockIcon className="h-5 w-5 text-gray-400" />;
    
    if (test.success) {
      return <CheckCircleIcon className="h-5 w-5 text-green-500" />;
    } else {
      return <XCircleIcon className="h-5 w-5 text-red-500" />;
    }
  };

  const getStatusText = (test) => {
    if (!test) return 'Not tested';
    
    if (test.success) {
      return 'Working';
    } else {
      return 'Error';
    }
  };

  const getStatusColor = (test) => {
    if (!test) return 'text-gray-500';
    
    if (test.success) {
      return 'text-green-600';
    } else {
      return 'text-red-600';
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">API Status</h3>
        <div className="flex items-center justify-center py-4">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="ml-2">Checking API status...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">API Status</h3>
        <div className="bg-red-50 border border-red-200 rounded-md p-4">
          <div className="flex">
            <XCircleIcon className="h-5 w-5 text-red-400" />
            <div className="ml-3">
              <h3 className="text-sm font-medium text-red-800">Error checking API status</h3>
              <p className="text-sm text-red-700 mt-1">{error}</p>
            </div>
          </div>
        </div>
        <button
          onClick={checkAPIStatus}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">API Status</h3>
        <button
          onClick={checkAPIStatus}
          className="px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded"
        >
          Refresh
        </button>
      </div>
      
      <div className="space-y-4">
        {apiStatus && Object.entries(apiStatus.apis).map(([name, api]) => (
          <div key={name} className="border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                {getStatusIcon(api.test)}
                <div className="ml-3">
                  <h4 className="font-medium capitalize">{name}</h4>
                  <p className={`text-sm ${getStatusColor(api.test)}`}>
                    {getStatusText(api.test)}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500">
                  Configured: {api.configured ? '✅' : '❌'}
                </div>
                {api.test && api.test.resultsCount !== undefined && (
                  <div className="text-sm text-gray-600">
                    Results: {api.test.resultsCount}
                  </div>
                )}
              </div>
            </div>
            
            {api.test && !api.test.success && api.test.error && (
              <div className="mt-2 p-2 bg-red-50 rounded text-sm text-red-600">
                Error: {api.test.error}
              </div>
            )}
          </div>
        ))}
      </div>
      
      {apiStatus && (
        <div className="mt-6 pt-4 border-t">
          <h4 className="font-medium mb-2">Debugging Information</h4>
          <div className="text-sm text-gray-600 space-y-1">
            <p>Last checked: {new Date(apiStatus.timestamp).toLocaleString()}</p>
            <p>Environment: {apiStatus.environment?.nodeEnv}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default APIStatusComponent;