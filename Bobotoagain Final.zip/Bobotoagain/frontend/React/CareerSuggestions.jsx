// frontend/React/CareerSuggestions.jsx - Complete implementation
import React, { useState, useEffect } from 'react';
import APIService from '../services/APIService';
import { 
  CheckCircleIcon, 
  XCircleIcon, 
  ClockIcon, 
  BriefcaseIcon, 
  StarIcon,
  ChartBarIcon,
  BookOpenIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

const CareerSuggestions = ({ profile, data }) => {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedCareer, setSelectedCareer] = useState(null);
  const [skillGapAnalysis, setSkillGapAnalysis] = useState(null);
  const [aiAnalysisLoading, setAiAnalysisLoading] = useState(false);

  useEffect(() => {
    if (data) {
      // Use data passed from parent if available
      setSuggestions(data.suggestions || data || []);
    } else {
      // Fetch data if not provided
      fetchCareerSuggestions();
    }
  }, [data]);

  const fetchCareerSuggestions = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const result = await APIService.getCareerSuggestions();
      
      if (result.success) {
        const suggestionsData = result.data.suggestions || result.data || [];
        setSuggestions(Array.isArray(suggestionsData) ? suggestionsData : []);
      } else {
        console.error('Career suggestions error:', result);
        setError(result.error || 'Failed to load career suggestions');
      }
    } catch (err) {
      console.error('Error fetching career suggestions:', err);
      setError('Failed to load career suggestions. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const getSkillGapAnalysis = async (careerTitle) => {
    try {
      setAiAnalysisLoading(true);
      const result = await APIService.getSkillGapAnalysis(careerTitle);
      
      if (result.success) {
        setSkillGapAnalysis(result.data);
      } else {
        console.error('Skill gap analysis error:', result);
        setError(result.error || 'Failed to analyze skill gap. Please try again.');
      }
    } catch (err) {
      console.error('Error getting skill gap analysis:', err);
      setError('Failed to analyze skill gap. Please try again.');
    } finally {
      setAiAnalysisLoading(false);
    }
  };

  const handleCareerSelect = (career) => {
    setSelectedCareer(career);
    setSkillGapAnalysis(null); // Reset previous analysis
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBackgroundColor = (score) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  const getProgressBarColor = (score) => {
    if (score >= 80) return 'bg-green-600';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const formatSalary = (salary) => {
    if (typeof salary === 'string') return salary;
    if (typeof salary === 'number') return `$${salary.toLocaleString()}`;
    return 'Salary not specified';
  };

  if (loading) {
    return <LoadingSpinner message="Loading career suggestions..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onRetry={fetchCareerSuggestions} />;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Suggestions List */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Personalized Career Paths</h2>
              <p className="text-sm text-gray-600 mt-1">Based on your skills and goals</p>
            </div>
            <div className="divide-y divide-gray-200 max-h-[600px] overflow-y-auto">
              {suggestions.length > 0 ? suggestions.map((career, index) => {
                const score = career.score || career.matchScore || 0;
                const isSelected = selectedCareer?.title === career.title;
                
                return (
                  <div
                    key={index}
                    className={`p-4 cursor-pointer transition-all duration-200 ${
                      isSelected
                        ? 'bg-blue-50 border-r-4 border-blue-500'
                        : 'hover:bg-gray-50'
                    }`}
                    onClick={() => handleCareerSelect(career)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 text-lg">{career.title}</h3>
                        <p className="text-sm text-gray-600 mt-1 line-clamp-2">{career.description}</p>
                      </div>
                      <div className="ml-4">
                        <div className="flex items-center space-x-1">
                          <StarIcon className="h-4 w-4 text-blue-500" />
                          <span className={`text-sm font-medium ${getScoreColor(score)}`}>
                            {score}%
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                          {career.growthRate || career.growthPotential || 'N/A'}% growth
                        </span>
                        <span className="text-xs text-gray-500">
                          {formatSalary(career.averageSalary)}
                        </span>
                      </div>
                    </div>

                    {career.matchReasons?.skillMatches && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {career.matchReasons.skillMatches.slice(0, 3).map((skill, idx) => (
                          <span
                            key={idx}
                            className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    )}
                    
                    {/* Preview Skill Alignment */}
                    {career.skillGap && (
                      <div className="mt-2">
                        <div className="text-xs text-gray-500 mb-1">Readiness: {career.skillGap.readinessScore || 0}%</div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className={`h-1.5 rounded-full ${getProgressBarColor(career.skillGap.readinessScore || 0)}`}
                            style={{ width: `${career.skillGap.readinessScore || 0}%` }}
                          ></div>
                        </div>
                      </div>
                    )}
                  </div>
                )
              }) : (
                <div className="p-8 text-center text-gray-500">
                  <BriefcaseIcon className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-lg font-medium">No career suggestions available</p>
                  <p className="text-sm">Complete your profile to get personalized recommendations</p>
                  <button 
                    onClick={fetchCareerSuggestions}
                    className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
                  >
                    Retry Loading
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Selected Career Details */}
        <div className="lg:col-span-2">
          {selectedCareer ? (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900">{selectedCareer.title}</h2>
                    <p className="text-gray-600 mt-1">AI-Powered Analysis</p>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2">
                      <StarIcon className="h-6 w-6 text-blue-500" />
                      <span className={`text-2xl font-bold ${getScoreColor(selectedCareer.score || selectedCareer.matchScore || 0)}`}>
                        {selectedCareer.score || selectedCareer.matchScore || 0}%
                      </span>
                    </div>
                    <p className="text-sm text-gray-500">Match Score</p>
                  </div>
                </div>
              </div>

              <div className="p-6">
                <p className="text-gray-700 mb-6 leading-relaxed">{selectedCareer.description}</p>

                {/* Market Overview & Skill Alignment Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Market Overview</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Average Salary:</span>
                        <span className="font-medium text-green-600">
                          {formatSalary(selectedCareer.averageSalary)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Job Growth:</span>
                        <span className="font-medium text-blue-600">
                          {selectedCareer.growthRate || selectedCareer.growthPotential || 'N/A'}% annually
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600">Market Demand:</span>
                        <span className="font-medium text-purple-600">High</span>
                      </div>
                    </div>
                  </div>

                  {/* Skill Alignment if available */}
                  {selectedCareer.alignment && (
                    <div className="bg-gray-50 rounded-lg p-4">
                      <h3 className="text-lg font-semibold text-gray-900 mb-3">Skill Alignment</h3>
                      <div className="space-y-3">
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm text-gray-600">Technical Skills</span>
                            <span className="text-sm font-medium">{selectedCareer.alignment.technicalSkills}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${selectedCareer.alignment.technicalSkills}%` }}
                            ></div>
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm text-gray-600">Experience Level</span>
                            <span className="text-sm font-medium">{selectedCareer.alignment.experienceLevel}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-yellow-500 h-2 rounded-full" 
                              style={{ width: `${selectedCareer.alignment.experienceLevel}%` }}
                            ></div>
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-sm text-gray-600">Soft Skills</span>
                            <span className="text-sm font-medium">{selectedCareer.alignment.softSkills}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${selectedCareer.alignment.softSkills}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Required Skills */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Required Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedCareer.requiredSkills?.map((skill, index) => {
                      const userHasSkill = profile?.skills?.some(userSkill => 
                        userSkill.name.toLowerCase() === skill.toLowerCase()
                      );
                      return (
                        <span
                          key={index}
                          className={`px-3 py-1 rounded-full text-sm border ${
                            userHasSkill 
                              ? 'bg-green-100 text-green-800 border-green-200'
                              : 'bg-gray-100 text-gray-700 border-gray-200'
                          }`}
                        >
                          {skill}
                          {userHasSkill && <CheckCircleIcon className="w-3 h-3 ml-1 inline" />}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Next Steps */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Recommended Next Steps</h3>
                  <ul className="list-none space-y-2">
                    {selectedCareer.nextSteps?.map((step, index) => (
                      <li key={index} className="flex items-start">
                        <ArrowRightIcon className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{step}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-4">
                  <button
                    onClick={() => getSkillGapAnalysis(selectedCareer.title)}
                    disabled={aiAnalysisLoading}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center transition-colors"
                  >
                    {aiAnalysisLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <ChartBarIcon className="h-4 w-4 mr-2" />
                        Detailed Skill Gap Analysis
                      </>
                    )}
                  </button>
                  <button className="border-2 border-gray-300 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-50 transition-colors">
                    <BriefcaseIcon className="h-4 w-4 mr-2 inline" />
                    Find Similar Jobs
                  </button>
                </div>

                {/* Skill Gap Analysis Results */}
                {skillGapAnalysis && (
                  <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">
                      <ChartBarIcon className="h-5 w-5 mr-2 inline text-blue-600" />
                      Detailed Skill Gap Analysis
                    </h3>
                    
                    {/* Overall Readiness Score */}
                    <div className="mb-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-700">Overall Readiness Score</span>
                        <span className="text-sm font-medium text-gray-900">
                          {skillGapAnalysis.readinessScore}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className={`h-3 rounded-full ${getProgressBarColor(skillGapAnalysis.readinessScore)}`}
                          style={{ width: `${skillGapAnalysis.readinessScore}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Skill Alignment Details */}
                    {skillGapAnalysis.skillAlignment && (
                      <div className="mb-6">
                        <h4 className="font-medium text-gray-900 mb-3">Skill Alignment Breakdown</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {Object.entries(skillGapAnalysis.skillAlignment).map(([key, value]) => (
                            <div key={key} className="text-center">
                              <div className={`text-2xl font-bold ${getScoreColor(value)}`}>{value}%</div>
                              <div className="text-xs text-gray-600 capitalize">
                                {key.replace(/([A-Z])/g, ' $1').trim()}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Skills Comparison */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h4 className="text-md font-medium text-gray-900 mb-3 flex items-center">
                          <CheckCircleIcon className="h-5 w-5 text-green-500 mr-2" />
                          Skills You Have
                        </h4>
                        <div className="space-y-2">
                          {skillGapAnalysis.matchedSkills?.map((skill, index) => (
                            <div key={index} className="flex items-center">
                              <span className="h-2 w-2 bg-green-500 rounded-full mr-3"></span>
                              <span className="text-sm text-gray-700">{skill}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="text-md font-medium text-gray-900 mb-3 flex items-center">
                          <XCircleIcon className="h-5 w-5 text-red-500 mr-2" />
                          Skills to Develop
                        </h4>
                        <div className="space-y-2">
                          {skillGapAnalysis.missingSkills?.map((skill, index) => (
                            <div key={index} className="flex items-center">
                              <span className="h-2 w-2 bg-red-500 rounded-full mr-3"></span>
                              <span className="text-sm text-gray-700">{skill}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Learning Recommendations */}
                    {skillGapAnalysis.skillRecommendations && skillGapAnalysis.skillRecommendations.length > 0 && (
                      <div>
                        <h4 className="text-md font-medium text-gray-900 mb-3">
                          <BookOpenIcon className="h-5 w-5 mr-2 inline text-blue-600" />
                          Learning Recommendations
                        </h4>
                        <div className="space-y-3">
                          {skillGapAnalysis.skillRecommendations.map((rec, index) => (
                            <div key={index} className="border border-gray-200 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <h5 className="font-medium text-gray-900">{rec.skill}</h5>
                                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                                  rec.priority === 'High' ? 'bg-red-100 text-red-800' :
                                  rec.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-blue-100 text-blue-800'
                                }`}>
                                  {rec.priority} Priority
                                </span>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{rec.difficulty?.description}</p>
                              <div className="flex items-center text-sm text-gray-500">
                                <ClockIcon className="h-4 w-4 mr-1" />
                                <span>{rec.difficulty?.estimatedTimeToLearn}</span>
                              </div>
                              {rec.learningResources && rec.learningResources.length > 0 && (
                                <div className="mt-3">
                                  <p className="text-sm font-medium text-gray-700 mb-2">Resources:</p>
                                  <div className="flex flex-wrap gap-2">
                                    {rec.learningResources.slice(0, 3).map((resource, idx) => (
                                      <a
                                        key={idx}
                                        href={resource.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded hover:bg-blue-100 transition-colors"
                                      >
                                        {resource.name} ({resource.platform})
                                      </a>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
              <BriefcaseIcon className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Select a Career Path</h3>
              <p className="text-gray-600">
                Choose a career suggestion from the list to see detailed information and AI-powered analysis.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CareerSuggestions;