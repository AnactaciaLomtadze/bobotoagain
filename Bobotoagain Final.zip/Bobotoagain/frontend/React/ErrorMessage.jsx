import React from 'react';
import { ExclamationTriangleIcon, ArrowPathIcon } from '@heroicons/react/24/outline';

const ErrorMessage = ({ 
  message, 
  onRetry, 
  retryText = 'Try Again',
  additionalInfo = null,
  showIcon = true 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-red-200 p-6">
      <div className="flex items-start">
        {showIcon && (
          <ExclamationTriangleIcon className="h-8 w-8 text-red-500 mr-4 flex-shrink-0" />
        )}
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-red-900 mb-2">
            Something went wrong
          </h3>
          <p className="text-red-700 mb-4">
            {message}
          </p>
          
          {additionalInfo && (
            <div className="mb-4">
              {additionalInfo}
            </div>
          )}
          
          {onRetry && (
            <button
              onClick={onRetry}
              className="inline-flex items-center px-4 py-2 bg-red-600 border border-transparent rounded-md font-medium text-white hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
            >
              <ArrowPathIcon className="h-4 w-4 mr-2" />
              {retryText}
            </button>
          )}
          
          <div className="mt-4 text-sm text-gray-600">
            <details>
              <summary className="cursor-pointer hover:text-gray-800">
                Technical Details
              </summary>
              <div className="mt-2 p-3 bg-gray-50 rounded text-xs font-mono">
                <p>Error: {message}</p>
                <p>Time: {new Date().toISOString()}</p>
                <p>User Agent: {navigator.userAgent}</p>
                <p>URL: {window.location.href}</p>
              </div>
            </details>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ErrorMessage;