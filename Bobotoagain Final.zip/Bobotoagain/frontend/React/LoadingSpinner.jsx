import React from 'react';

const LoadingSpinner = ({ 
  message = 'Loading...', 
  size = 'medium',
  inline = false 
}) => {
  // Size variants
  const sizeClasses = {
    small: 'h-4 w-4',
    medium: 'h-8 w-8',
    large: 'h-12 w-12'
  };

  const textSizeClasses = {
    small: 'text-sm',
    medium: 'text-base',
    large: 'text-lg'
  };

  const spinnerSize = sizeClasses[size] || sizeClasses.medium;
  const textSize = textSizeClasses[size] || textSizeClasses.medium;

  if (inline) {
    return (
      <div className="inline-flex items-center space-x-2">
        <div className={`animate-spin rounded-full border-2 border-gray-300 border-t-blue-600 ${spinnerSize}`}></div>
        <span className={`text-gray-600 ${textSize}`}>{message}</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-[200px] space-y-4">
      <div className={`animate-spin rounded-full border-4 border-gray-300 border-t-blue-600 ${spinnerSize}`}></div>
      <div className="text-center">
        <h3 className={`text-gray-900 font-medium ${textSize}`}>
          {message}
        </h3>
        <p className="text-sm text-gray-500 mt-1">
          Please wait a moment...
        </p>
      </div>
    </div>
  );
};

export default LoadingSpinner;