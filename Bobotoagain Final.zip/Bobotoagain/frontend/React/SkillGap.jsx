import React, { useState, useEffect } from 'react';
import APIService from '../services/APIService';
import { 
  CheckCircleIcon, 
  XCircleIcon, 
  ClockIcon, 
  TrendingUpIcon,
  AcademicCapIcon,
  BriefcaseIcon,
  ChartBarIcon
} from '@heroicons/react/24/outline';
import LoadingSpinner from './LoadingSpinner';
import ErrorMessage from './ErrorMessage';

const SkillGapAnalysis = ({ targetRole, onClose, profile }) => {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedSkill, setSelectedSkill] = useState(null);

  useEffect(() => {
    if (targetRole) {
      fetchSkillGapAnalysis();
    }
  }, [targetRole]);

  const fetchSkillGapAnalysis = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const result = await APIService.getSkillGapAnalysis(targetRole);
      
      if (result.success) {
        setAnalysis(result.data);
      } else {
        setError(result.error || 'Failed to analyze skill gap');
      }
    } catch (err) {
      console.error('Skill gap analysis error:', err);
      setError('Failed to analyze skill gap');
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBackgroundColor = (score) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  const getProgressBarColor = (score) => {
    if (score >= 80) return 'bg-green-600';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getPriorityColor = (priority) => {
    const colors = {
      'High': 'bg-red-100 text-red-800 border-red-200',
      'Medium': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Low': 'bg-blue-100 text-blue-800 border-blue-200'
    };
    return colors[priority] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const CircularProgress = ({ value, size = 120, strokeWidth = 8 }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const offset = circumference - (value / 100) * circumference;

    return (
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#e5e7eb"
            strokeWidth={strokeWidth}
            fill="transparent"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#3b82f6"
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <div className={`text-2xl font-bold ${getScoreColor(value)}`}>{value}%</div>
            <div className="text-sm text-gray-600">Ready</div>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return <LoadingSpinner message="Analyzing your skill gap..." />;
  }

  if (error) {
    return <ErrorMessage message={error} onRetry={fetchSkillGapAnalysis} />;
  }

  if (!analysis) {
    return null;
  }

  return (
    <div className="skill-gap-analysis-container bg-white rounded-lg shadow-lg border border-gray-200 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Skill Gap Analysis</h2>
          <p className="text-blue-600 font-medium">{targetRole}</p>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 p-2 rounded-full hover:bg-gray-100 transition-colors"
            aria-label="Close"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      <div className="p-6 space-y-6">
        {/* Overall Readiness Score */}
        <div className="text-center py-6">
          <CircularProgress value={analysis.readinessScore} />
          <p className="mt-4 text-gray-600">Overall readiness for {targetRole}</p>
        </div>

        {/* Skill Alignment Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { 
              title: 'Technical Skills Match', 
              value: analysis.skillAlignment?.technicalSkills || 0, 
              icon: ChartBarIcon,
              color: 'blue'
            },
            { 
              title: 'Experience Level Match', 
              value: analysis.skillAlignment?.experienceLevel || 0, 
              icon: BriefcaseIcon,
              color: 'yellow'
            },
            { 
              title: 'Certification Requirements', 
              value: analysis.skillAlignment?.certificationRequirements || 0, 
              icon: AcademicCapIcon,
              color: 'purple'
            },
            { 
              title: 'Soft Skills Match', 
              value: analysis.skillAlignment?.softSkills || 0, 
              icon: TrendingUpIcon,
              color: 'green'
            }
          ].map((item, index) => (
            <div key={index} className={`bg-white p-4 rounded-lg shadow border-l-4 border-${item.color}-500`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{item.title}</p>
                  <div className="flex items-center mt-1">
                    <p className={`text-2xl font-bold ${getScoreColor(item.value)}`}>{item.value}%</p>
                    <item.icon className="w-5 h-5 ml-2 text-gray-400" />
                  </div>
                </div>
              </div>
              <div className="mt-3">
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full ${getProgressBarColor(item.value)} transition-all duration-1000`}
                    style={{ width: `${item.value}%` }}
                  ></div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Skills Comparison */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Skills You Have */}
          <div className="bg-green-50 p-6 rounded-lg border border-green-200">
            <div className="flex items-center mb-4">
              <CheckCircleIcon className="w-6 h-6 text-green-600 mr-2" />
              <h3 className="text-lg font-semibold text-green-800">Skills You Have</h3>
            </div>
            <div className="space-y-3">
              {analysis.matchedSkills?.map((skill, index) => (
                <div key={index} className="flex items-center p-3 bg-white rounded-lg border border-green-200">
                  <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3">
                    <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="font-medium text-gray-900">{skill}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Skills to Develop */}
          <div className="bg-red-50 p-6 rounded-lg border border-red-200">
            <div className="flex items-center mb-4">
              <XCircleIcon className="w-6 h-6 text-red-600 mr-2" />
              <h3 className="text-lg font-semibold text-red-800">Skills to Develop</h3>
            </div>
            <div className="space-y-3">
              {analysis.missingSkills?.map((skill, index) => (
                <div key={index} className="flex items-center p-3 bg-white rounded-lg border border-red-200">
                  <div className="w-8 h-8 border-2 border-red-500 rounded-full flex items-center justify-center mr-3">
                    <span className="text-red-500 text-xs">•</span>
                  </div>
                  <span className="font-medium text-gray-900">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Focus Areas */}
        {analysis.focusAreas && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">Recommended Focus Areas</h3>
            {analysis.focusAreas.map((area, index) => (
              <div key={index} className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-lg font-semibold text-blue-900">{area.area}</h4>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getPriorityColor(area.priority)}`}>
                    {area.priority} Priority
                  </span>
                </div>
                <p className="text-gray-700 mb-3">{area.description}</p>
                <ul className="space-y-2">
                  {area.recommendations?.map((rec, idx) => (
                    <li key={idx} className="flex items-start">
                      <span className="text-blue-500 mr-2 mt-1">→</span>
                      <span className="text-gray-700">{rec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        )}

        {/* Learning Recommendations */}
        {analysis.skillRecommendations && (
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-gray-900">Learning Recommendations</h3>
            {analysis.skillRecommendations.map((rec, index) => (
              <div key={index} className="bg-white p-6 rounded-lg border border-gray-200 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-lg font-semibold text-gray-900">{rec.skill}</h4>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getPriorityColor(rec.priority)}`}>
                    {rec.priority} Priority
                  </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div className="flex items-center">
                    <ChartBarIcon className="w-5 h-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">Difficulty Level</p>
                      <p className="text-gray-600">{rec.difficulty?.description}</p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    <ClockIcon className="w-5 h-5 text-gray-400 mr-2" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">Estimated Time</p>
                      <p className="text-gray-600">{rec.difficulty?.estimatedTimeToLearn}</p>
                    </div>
                  </div>
                </div>

                {rec.learningResources && rec.learningResources.length > 0 && (
                  <div>
                    <p className="text-sm font-medium text-gray-700 mb-3">Recommended Resources</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {rec.learningResources.map((resource, idx) => (
                        <a
                          key={idx}
                          href={resource.url || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-3 bg-blue-50 rounded-lg border border-blue-200 hover:bg-blue-100 transition-colors cursor-pointer"
                        >
                          <p className="font-medium text-sm text-blue-900">{resource.name}</p>
                          <p className="text-xs text-blue-600">{resource.platform}</p>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-4 pt-6 border-t border-gray-200">
          <button
            onClick={() => window.print()}
            className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors font-medium"
          >
            📄 Download Report
          </button>
          <button
            onClick={() => {/* TODO: Navigate to learning resources */}}
            className="flex-1 bg-green-600 text-white py-3 px-6 rounded-lg hover:bg-green-700 transition-colors font-medium"
          >
            🚀 Start Learning Path
          </button>
        </div>
      </div>
    </div>
  );
};

export default SkillGapAnalysis;