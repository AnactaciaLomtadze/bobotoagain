//frontend/React/JobRecommendations.jsx
import React, { useState, useEffect } from 'react';

const JobRecommendations = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filters, setFilters] = useState({
    location: '',
    source: 'all'
  });
  const [selectedJob, setSelectedJob] = useState(null);
  const [savedJobs, setSavedJobs] = useState([]);

  useEffect(() => {
    fetchJobRecommendations();
    fetchSavedJobs();
  }, []);

  const fetchJobRecommendations = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('auth_token');
      
      // Build query params
      const params = new URLSearchParams();
      if (filters.source !== 'all') params.append('source', filters.source);
      if (filters.location) params.append('location', filters.location);
      
      const queryString = params.toString() ? `?${params.toString()}` : '';
      
      const response = await fetch(`/api/career/jobs${queryString}`, {
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      setJobs(data.jobs || []);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching job recommendations:', err);
      setError('Failed to load job recommendations. Please try again later.');
      setLoading(false);
    }
  };

  const fetchSavedJobs = async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/career/saved-jobs', {
        headers: {
          'x-auth-token': token
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setSavedJobs(data.map(job => job.id));
      }
    } catch (err) {
      console.error('Error fetching saved jobs:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({
      ...filters,
      [name]: value
    });
  };

  const handleJobSelect = (job) => {
    setSelectedJob(job);
  };

  const handleSaveJob = async (job) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/career/save-job', {
        method: 'POST',
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ jobId: job.id })
      });
      
      if (response.ok) {
        setSavedJobs([...savedJobs, job.id]);
      }
    } catch (err) {
      console.error('Error saving job:', err);
    }
  };

  const isJobSaved = (jobId) => {
    return savedJobs.includes(jobId);
  };

  const filteredJobs = jobs.filter(job => {
    // Filter by location
    if (filters.location && !job.location.toLowerCase().includes(filters.location.toLowerCase())) {
      return false;
    }
    
    // Filter by source
    if (filters.source !== 'all' && job.source !== filters.source) {
      return false;
    }
    
    return true;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <div className="bg-white rounded-lg shadow mb-6">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Job Filters</h2>
          </div>
          <div className="p-4">
            <div className="mb-4">
              <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                Location
              </label>
              <input
                type="text"
                id="location"
                name="location"
                value={filters.location}
                onChange={handleFilterChange}
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="e.g. San Francisco, CA or 'remote'"
              />
            </div>
            
            <div className="mb-4">
              <label htmlFor="source" className="block text-sm font-medium text-gray-700 mb-1">
                Job Source
              </label>
              <select
                id="source"
                name="source"
                value={filters.source}
                onChange={handleFilterChange}
                className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              >
                <option value="all">All Sources</option>
                <option value="Adzuna">Adzuna</option>
                <option value="The Muse">The Muse</option>
                <option value="LinkedIn">LinkedIn</option>
                <option value="Remotok">Remotok</option>
              </select>
            </div>
            
            <button 
              onClick={fetchJobRecommendations}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition duration-150"
            >
              Apply Filters
            </button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Job Recommendations</h2>
            <p className="text-sm text-gray-500">Based on your skills and preferences</p>
          </div>
          <div className="p-2 overflow-y-auto max-h-[600px]">
            {filteredJobs.length > 0 ? (
              filteredJobs.map((job) => (
                <div 
                  key={job.id}
                  className={`p-3 mb-2 rounded cursor-pointer transition duration-150 ${
                    selectedJob && selectedJob.id === job.id 
                      ? 'bg-blue-100 border-l-4 border-blue-500' 
                      : 'hover:bg-gray-50'
                  }`}
                  onClick={() => handleJobSelect(job)}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="font-medium">{job.title}</h3>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${
                      job.source === 'Adzuna' ? 'bg-green-100 text-green-800' :
                      job.source === 'The Muse' ? 'bg-purple-100 text-purple-800' :
                      job.source === 'LinkedIn' ? 'bg-blue-100 text-blue-800' :
                      job.source === 'Remotok' ? 'bg-orange-100 text-orange-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {job.source}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{job.company}</p>
                  <div className="flex items-center text-xs text-gray-500 mt-1">
                    <span className="mr-3">{job.location}</span>
                    <span>{formatTimeAgo(job.postedAt)}</span>
                  </div>
                  {job.relevanceScore && (
                    <div className="mt-2">
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div 
                          className="h-1.5 rounded-full bg-blue-600" 
                          style={{ width: `${job.relevanceScore}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-end mt-1">
                        <span className="text-xs text-gray-500">{job.relevanceScore}% match</span>
                      </div>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>No matching jobs found.</p>
                <p className="text-sm mt-2">Try adjusting your filters or check back later.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="lg:col-span-2">
        {selectedJob ? (
          <div className="bg-white rounded-lg shadow">
            <div className="p-4 border-b border-gray-200">
              <div className="flex justify-between">
                <h2 className="text-2xl font-semibold text-gray-800">{selectedJob.title}</h2>
                <div>
                  <button
                    className={`ml-2 p-2 rounded-full ${
                      isJobSaved(selectedJob.id) 
                        ? 'text-yellow-500 hover:text-yellow-600' 
                        : 'text-gray-400 hover:text-gray-500'
                    }`}
                    onClick={() => !isJobSaved(selectedJob.id) && handleSaveJob(selectedJob)}
                    disabled={isJobSaved(selectedJob.id)}
                  >
                    <svg className="h-6 w-6" fill={isJobSaved(selectedJob.id) ? "currentColor" : "none"} viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                    </svg>
                  </button>
                  <a
                    href={selectedJob.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-2 inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Apply Now
                  </a>
                </div>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center">
                  <svg className="h-5 w-5 text-gray-400 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                  <span className="text-gray-700">{selectedJob.company}</span>
                </div>
                
                <div className="flex items-center">
                  <svg className="h-5 w-5 text-gray-400 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-gray-700">{selectedJob.location}</span>
                </div>
                
                <div className="flex items-center">
                  <svg className="h-5 w-5 text-gray-400 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-700">Posted {formatTimeAgo(selectedJob.postedAt)}</span>
                </div>
                
                <div className="flex items-center">
                  <svg className="h-5 w-5 text-gray-400 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-700">{selectedJob.salary}</span>
                </div>
                
                <div className="flex items-center">
                  <svg className="h-5 w-5 text-gray-400 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  <span className="text-gray-700">Source: {selectedJob.source}</span>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-medium mb-3">Job Description</h3>
                <div className="text-gray-700 space-y-2">
                  <p>{selectedJob.description}</p>
                </div>
              </div>
              
              {selectedJob.relevanceScore && (
                <div className="mb-6">
                  <h3 className="text-lg font-medium mb-3">Match Analysis</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Overall Match</span>
                      <span className="text-sm font-medium">{selectedJob.relevanceScore}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full" 
                        style={{ width: `${selectedJob.relevanceScore}%` }}
                      ></div>
                    </div>
                    
                    <div className="text-sm text-gray-600">
                      <p>This job matches your profile based on your skills, location preferences, and career goals.</p>
                    </div>
                  </div>
                </div>
              )}
              
              <div className="flex justify-between items-center">
                <a 
                  href={selectedJob.url} 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Apply on {selectedJob.source}
                  <svg className="ml-2 -mr-1 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
                
                <button
                  type="button"
                  onClick={() => !isJobSaved(selectedJob.id) && handleSaveJob(selectedJob)}
                  disabled={isJobSaved(selectedJob.id)}
                  className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-md shadow-sm ${
                    isJobSaved(selectedJob.id)
                      ? 'border-gray-300 text-gray-700 bg-gray-100'
                      : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
                  }`}
                >
                  {isJobSaved(selectedJob.id) ? (
                    <>
                      <svg className="mr-2 h-5 w-5 text-yellow-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M5 4a2 2 0 012-2h6a2 2 0 012 2v14l-5-2.5L5 18V4z" />
                      </svg>
                      Saved
                    </>
                  ) : (
                    <>
                      <svg className="mr-2 h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                      </svg>
                      Save Job
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center h-full">
            <svg className="h-24 w-24 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
            </svg>
            <h3 className="mt-4 text-lg font-medium text-gray-500">Select a job to view details</h3>
            <p className="mt-1 text-sm text-gray-500">Choose from the list of recommended jobs on the left.</p>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to format time ago
function formatTimeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) {
    const diffHours = Math.floor(diffTime / (1000 * 60 * 60));
    if (diffHours === 0) {
      const diffMinutes = Math.floor(diffTime / (1000 * 60));
      return `${diffMinutes} minute${diffMinutes !== 1 ? 's' : ''} ago`;
    }
    return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays < 7) {
    return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
  } else if (diffDays < 30) {
    const diffWeeks = Math.floor(diffDays / 7);
    return `${diffWeeks} week${diffWeeks !== 1 ? 's' : ''} ago`;
  } else {
    return date.toLocaleDateString();
  }
}

export default JobRecommendations;