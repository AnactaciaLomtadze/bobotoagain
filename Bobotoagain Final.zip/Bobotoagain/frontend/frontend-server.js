// frontend-server.js - Simple version without route patterns that cause issues
const express = require('express');
const path = require('path');
const cors = require('cors');
const fs = require('fs');

const app = express();
const PORT = process.env.FRONTEND_PORT || 5000;

// Adjust the path to find the frontend directory
// Since you're running from /home/acer/Desktop/Bobotoagain/frontend
const frontendDir = __dirname; // Current directory

console.log('Current directory:', __dirname);
console.log('Serving files from:', frontendDir);

// Check if we can find the files
const mainFile = path.join(frontendDir, 'bobotoMain.html');
const loginFile = path.join(frontendDir, 'HTML/bobotoLogin.html');

console.log('Looking for bobotoMain.html at:', mainFile);
console.log('bobotoMain.html exists:', fs.existsSync(mainFile));
console.log('Looking for login page at:', loginFile);
console.log('Login page exists:', fs.existsSync(loginFile));

// Enable CORS
app.use(cors({
  origin: ['http://localhost:3000', 'http://localhost:5000'],
  credentials: true
}));

// Serve static files
app.use(express.static(frontendDir));

// Simple routes without parameters
app.get('/', (req, res) => {
  const filePath = path.join(frontendDir, 'bobotoMain.html');
  res.sendFile(filePath);
});

app.get('/bobotoMain.html', (req, res) => {
  const filePath = path.join(frontendDir, 'bobotoMain.html');
  res.sendFile(filePath);
});

// Routes for HTML files
app.get('/HTML/bobotoLogin.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoLogin.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoSignup.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoSignup.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoProfile.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoProfile.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoChat.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoChat.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoSettings.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoSettings.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoCareer.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoCareer.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoLearning.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoLearning.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoSkill.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoSkill.html');
  res.sendFile(filePath);
});

app.get('/HTML/bobotoAcademic.html', (req, res) => {
  const filePath = path.join(frontendDir, 'HTML/bobotoAcademic.html');
  res.sendFile(filePath);
});

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    directory: frontendDir,
    files: {
      main: fs.existsSync(path.join(frontendDir, 'bobotoMain.html')),
      login: fs.existsSync(path.join(frontendDir, 'HTML/bobotoLogin.html')),
      htmlDir: fs.existsSync(path.join(frontendDir, 'HTML'))
    }
  });
});

// List files for debugging
app.get('/debug', (req, res) => {
  try {
    const files = {
      root: fs.readdirSync(frontendDir),
      html: fs.existsSync(path.join(frontendDir, 'HTML')) ? 
        fs.readdirSync(path.join(frontendDir, 'HTML')) : [],
      css: fs.existsSync(path.join(frontendDir, 'CSS')) ? 
        fs.readdirSync(path.join(frontendDir, 'CSS')) : [],
      js: fs.existsSync(path.join(frontendDir, 'JS')) ? 
        fs.readdirSync(path.join(frontendDir, 'JS')) : []
    };
    res.json(files);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Frontend server running on http://localhost:${PORT}`);
  console.log('Available routes:');
  console.log(`  - Main page: http://localhost:${PORT}/`);
  console.log(`  - Main page: http://localhost:${PORT}/bobotoMain.html`);
  console.log(`  - Login: http://localhost:${PORT}/HTML/bobotoLogin.html`);
  console.log(`  - Signup: http://localhost:${PORT}/HTML/bobotoSignup.html`);
  console.log(`  - Profile: http://localhost:${PORT}/HTML/bobotoProfile.html`);
  console.log(`  - Health: http://localhost:${PORT}/health`);
  console.log(`  - Debug: http://localhost:${PORT}/debug`);
});

// Error handling
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).send('Internal Server Error');
});