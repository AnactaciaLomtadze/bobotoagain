// server.js - Fixed CORS configuration
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const path = require('path');
require('dotenv').config();

// Import middleware
const errorHandler = require('./middleware/errorHandler');

// Import routes
const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profile');
const academicRoutes = require('./routes/academic');
const chatRoutes = require('./routes/chat');
const aiRoutes = require('./routes/ai');
const careerRoutes = require('./routes/career');
const skillsRoutes = require('./routes/skills');

// Create Express app
const app = express();

// Configure CORS properly
app.use(cors({
  origin: function(origin, callback) {
    // List of allowed origins
    const allowedOrigins = [
      'http://localhost:3000',
      'http://localhost:5000',
      'http://127.0.0.1:3000',
      'http://127.0.0.1:5000',
      'file://', // Allow file:// protocol
    ];
    
    // Allow requests with no origin (mobile apps, curl, etc.)
    if (!origin) return callback(null, true);
    
    // Check if origin is allowed
    const isAllowed = allowedOrigins.some(allowedOrigin => 
      origin.startsWith(allowedOrigin)
    );
    
    if (isAllowed) {
      callback(null, true);
    } else {
      console.log('CORS blocked origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
  allowedHeaders: ['Content-Type', 'x-auth-token', 'Authorization'],
  exposedHeaders: ['Content-Length', 'X-Foo', 'X-Bar']
}));

// Enhanced preflight handling
app.options('*', (req, res) => {
  console.log('Preflight request from:', req.get('origin'));
  res.header('Access-Control-Allow-Origin', req.get('origin') || '*');
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS,PATCH');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, x-auth-token, Authorization');
  res.header('Access-Control-Allow-Credentials', true);
  res.header('Access-Control-Max-Age', '3600');
  res.sendStatus(200);
});

// Body parser middleware with increased limits
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Enhanced request logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
  console.log('Origin:', req.get('origin') || 'no origin');
  console.log('User-Agent:', req.get('user-agent') || 'no user-agent');
  console.log('Auth token present:', !!req.get('x-auth-token'));
  
  // Add CORS headers to all responses
  res.header('Access-Control-Allow-Origin', req.get('origin') || '*');
  res.header('Access-Control-Allow-Credentials', true);
  
  next();
});

// Connect to MongoDB with better error handling
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/boboto', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 5000,
      family: 4 // Use IPv4, skip trying IPv6
    });
    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    console.error('Full error object:', JSON.stringify(error, null, 2));
    process.exit(1);
  }
};

// Initialize database connection
connectDB();

// API Routes with enhanced error handling
app.use('/api/auth', (req, res, next) => {
  console.log('Auth route accessed:', req.path);
  next();
}, authRoutes);

app.use('/api/profile', (req, res, next) => {
  console.log('Profile route accessed:', req.path);
  next();
}, profileRoutes);

app.use('/api/career', (req, res, next) => {
  console.log('Career route accessed:', req.path);
  next();
}, careerRoutes);

app.use('/api/academic', academicRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/skills', skillsRoutes);

// Root endpoint with more detailed info
app.get('/', (req, res) => {
  res.json({
    message: 'Boboto Backend API',
    status: 'running',
    version: '1.2.0',
    timestamp: new Date().toISOString(),
    corsEnabled: true,
    endpoints: {
      auth: '/api/auth',
      profile: '/api/profile', 
      academic: '/api/academic',
      chat: '/api/chat',
      ai: '/api/ai',
      career: '/api/career'
    },
    environment: {
      node: process.version,
      platform: process.platform,
      mongooseConnected: mongoose.connection.readyState === 1
    }
  });
});

// Enhanced health check endpoint
app.get('/api/health', (req, res) => {
  const healthStatus = {
    status: 'OK',
    message: 'Boboto API is running',
    timestamp: new Date().toISOString(),
    version: '1.2.0',
    database: {
      status: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
      host: mongoose.connection.host,
      name: mongoose.connection.name
    },
    environment: {
      nodeEnv: process.env.NODE_ENV || 'development',
      port: process.env.PORT || 3000
    },
    cors: {
      enabled: true,
      origins: ['http://localhost:3000', 'http://localhost:5000', 'file://']
    },
    apis: {
      openrouter: !!process.env.OPENROUTER_API_KEY,
      adzuna: !!(process.env.ADZUNA_APP_ID && process.env.ADZUNA_APP_KEY),
      muse: !!process.env.MUSE_API_KEY,
      linkedin: !!(process.env.LINKEDIN_CLIENT_ID && process.env.LINKEDIN_CLIENT_SECRET)
    }
  };
  
  res.json(healthStatus);
});

// Debug endpoint to check configuration
app.get('/api/debug', (req, res) => {
  const debug = {
    timestamp: new Date().toISOString(),
    headers: req.headers,
    method: req.method,
    url: req.url,
    body: req.body,
    query: req.query,
    params: req.params,
    origin: req.get('origin'),
    userAgent: req.get('user-agent'),
    environment: {
      NODE_ENV: process.env.NODE_ENV,
      MONGODB_URI: process.env.MONGODB_URI ? 'Set' : 'Not set',
      OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY ? 'Set' : 'Not set',
      ADZUNA_CONFIGURED: !!(process.env.ADZUNA_APP_ID && process.env.ADZUNA_APP_KEY),
      MUSE_CONFIGURED: !!process.env.MUSE_API_KEY,
      LINKEDIN_CONFIGURED: !!(process.env.LINKEDIN_CLIENT_ID && process.env.LINKEDIN_CLIENT_SECRET)
    },
    database: {
      connected: mongoose.connection.readyState === 1,
      readyState: mongoose.connection.readyState,
      host: mongoose.connection.host,
      name: mongoose.connection.name
    }
  };
  
  res.json(debug);
});

// Serve static files
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

// Catch-all for unhandled API routes
app.get('/api/*', (req, res) => {
  console.log('Unhandled API route:', req.path);
  res.status(404).json({ 
    message: 'API endpoint not found',
    path: req.path,
    method: req.method,
    availableEndpoints: [
      'GET /api/health',
      'GET /api/debug',
      'POST /api/auth/login',
      'POST /api/auth/register',
      'GET /api/profile',
      'GET /api/career/suggestions',
      'GET /api/career/jobs',
      'POST /api/career/skill-gap-analysis'
    ]
  });
});

// Enhanced error handling middleware
app.use((err, req, res, next) => {
  console.error('Global error handler:', err);
  console.error('Stack trace:', err.stack);
  
  // Handle CORS errors
  if (err.message === 'Not allowed by CORS') {
    return res.status(403).json({
      error: 'CORS Error',
      message: 'Your origin is not allowed to access this API',
      origin: req.get('origin'),
      allowedOrigins: ['http://localhost:3000', 'http://localhost:5000']
    });
  }
  
  // Handle validation errors
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      error: 'Validation Error',
      message: err.message,
      details: err.errors
    });
  }
  
  // Handle MongoDB errors
  if (err.name === 'MongoError' || err.name === 'MongooseError') {
    return res.status(500).json({
      error: 'Database Error',
      message: 'Database operation failed',
      type: err.name
    });
  }
  
  // Generic error response
  res.status(err.status || 500).json({
    error: err.name || 'Internal Server Error',
    message: err.message || 'Something went wrong',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// Start server with better error handling
const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, (err) => {
  if (err) {
    console.error('❌ Server failed to start:', err);
    process.exit(1);
  }
  
  console.log(`\n=== 🚀 Boboto Backend Server ===`);
  console.log(`✅ Server running on port ${PORT}`);
  console.log(`📍 API Base URL: http://localhost:${PORT}/api`);
  console.log(`❤️  Health Check: http://localhost:${PORT}/api/health`);
  console.log(`🔧 Debug Info: http://localhost:${PORT}/api/debug`);
  console.log(`📂 Frontend served from: ${frontendPath}`);
  console.log(`🌍 CORS enabled for: localhost:3000, localhost:5000, file://`);
  console.log('===============================\n');
});

// Graceful shutdown
const gracefulShutdown = (signal) => {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  
  server.close((err) => {
    if (err) {
      console.error('Error during server shutdown:', err);
      process.exit(1);
    }
    
    console.log('HTTP server closed.');
    
    // Close MongoDB connection
    mongoose.connection.close((err) => {
      if (err) {
        console.error('Error closing MongoDB connection:', err);
        process.exit(1);
      }
      
      console.log('MongoDB connection closed.');
      console.log('Shutdown complete.');
      process.exit(0);
    });
  });
  
  // Force close after 30 seconds
  setTimeout(() => {
    console.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', err);
  console.error('Stack trace:', err.stack);
  // Don't exit the process, just log the error
});

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  console.error('Stack trace:', err.stack);
  // Exit the process for uncaught exceptions
  gracefulShutdown('Uncaught Exception');
});

module.exports = app;