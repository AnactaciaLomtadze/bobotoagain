// controllers/academicController.js
const Profile = require('../models/Profile');
const User = require('../models/User');
const mongoose = require('mongoose');
const axios = require('axios');
const { generateResponse } = require('./deepseekController');

class AcademicController {
  // Track study time
  async trackStudyTime(req, res) {
    const { subject, minutes, date } = req.body;
    
    console.log('Track study time request received:', { subject, minutes, date });
    
    if (!subject || !minutes) {
      return res.status(400).json({ message: 'Subject and minutes are required' });
    }
    
    try {
      const studyDate = date ? new Date(date) : new Date();
      const minutesInt = parseInt(minutes);
      
      // Find the profile
      let profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        console.log('Creating new profile for user:', req.user.id);
        
        const newProfile = new Profile({
          user: req.user.id,
          academicProgress: {
            subjects: [{
              name: subject,
              proficiency: 10,
              lastStudied: studyDate,
              topics: []
            }],
            studyTime: {
              total: minutesInt,
              bySubject: { [subject]: minutesInt },
              dailyLog: [{
                date: studyDate,
                minutes: minutesInt,
                subject
              }]
            }
          }
        });
        
        await newProfile.save();
        
        return res.json({
          message: 'Study time tracked successfully (new profile)',
          studyTime: newProfile.academicProgress.studyTime
        });
      }
      
      // Initialize academicProgress if needed
      if (!profile.academicProgress) {
        profile.academicProgress = {
          subjects: [],
          studyTime: {
            total: 0,
            bySubject: {},
            dailyLog: []
          }
        };
      }
      
      // Initialize studyTime if needed
      if (!profile.academicProgress.studyTime) {
        profile.academicProgress.studyTime = {
          total: 0,
          bySubject: {},
          dailyLog: []
        };
      }
      
      // Update total study time
      profile.academicProgress.studyTime.total = 
        (profile.academicProgress.studyTime.total || 0) + minutesInt;
      
      // Update bySubject
      if (!profile.academicProgress.studyTime.bySubject) {
        profile.academicProgress.studyTime.bySubject = {};
      }
      
      const currentSubjectTime = profile.academicProgress.studyTime.bySubject[subject] || 0;
      profile.academicProgress.studyTime.bySubject[subject] = currentSubjectTime + minutesInt;
      
      // Update dailyLog
      if (!profile.academicProgress.studyTime.dailyLog) {
        profile.academicProgress.studyTime.dailyLog = [];
      }
      
      profile.academicProgress.studyTime.dailyLog.push({
        date: studyDate,
        minutes: minutesInt,
        subject
      });
      
      // Ensure subject exists in subjects array
      if (!profile.academicProgress.subjects) {
        profile.academicProgress.subjects = [];
      }
      
      const subjectExists = profile.academicProgress.subjects.some(s => s.name === subject);
      
      if (!subjectExists) {
        profile.academicProgress.subjects.push({
          name: subject,
          proficiency: 10,
          lastStudied: studyDate,
          topics: []
        });
      } else {
        // Update lastStudied date for existing subject
        const subjectIndex = profile.academicProgress.subjects.findIndex(s => s.name === subject);
        if (subjectIndex !== -1) {
          profile.academicProgress.subjects[subjectIndex].lastStudied = studyDate;
          // Slightly increase proficiency when studying
          profile.academicProgress.subjects[subjectIndex].proficiency = 
            Math.min(100, (profile.academicProgress.subjects[subjectIndex].proficiency || 10) + 2);
        }
      }
      
      // Save the updated profile
      await profile.save();
      
      return res.json({
        message: 'Study time tracked successfully',
        studyTime: profile.academicProgress.studyTime
      });
    } catch (err) {
      console.error('Study time tracking error:', err);
      return res.status(500).json({ 
        message: 'Error tracking study time',
        error: err.message 
      });
    }
  }

  // Add resource to library
  async addResource(req, res) {
    console.log('Add resource request received:', req.body);
    const { title, url, type, subject, notes } = req.body;
    
    if (!title || !url || !type || !subject) {
      return res.status(400).json({ message: 'Title, URL, type, and subject are required' });
    }
    
    try {
      // Find the user's profile, or create a new one
      let profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        console.log('No profile found for user, creating a new profile');
        profile = new Profile({
          user: req.user.id,
          resourceLibrary: []
        });
      }

      // Ensure resourceLibrary exists and is an array
      if (!profile.resourceLibrary) {
        console.log('Initializing resourceLibrary as an empty array');
        profile.resourceLibrary = [];
      } else if (!Array.isArray(profile.resourceLibrary)) {
        console.log('resourceLibrary exists but is not an array, resetting to empty array');
        profile.resourceLibrary = [];
      }
      
      // Create the new resource document
      const newResource = {
        title,
        url,
        type,
        subject,
        addedAt: new Date(),
        completed: false,
        rating: 0,
        notes: notes || ''
      };
      
      // Check if resource already exists by URL
      const existingIndex = profile.resourceLibrary.findIndex(
        r => r && r.url === url
      );
      
      if (existingIndex !== -1) {
        console.log('Updating existing resource at index', existingIndex);
        profile.resourceLibrary[existingIndex] = {
          ...profile.resourceLibrary[existingIndex],
          title,
          type,
          subject,
          notes: notes || profile.resourceLibrary[existingIndex].notes
        };
      } else {
        console.log('Adding new resource to library');
        profile.resourceLibrary.push(newResource);
      }
      
      // Save with detailed error handling
      try {
        await profile.save();
        console.log('Profile saved successfully with updated resourceLibrary');
        
        return res.json({
          message: 'Resource added successfully',
          resource: existingIndex !== -1 ? profile.resourceLibrary[existingIndex] : newResource,
          resourceCount: profile.resourceLibrary.length
        });
      } catch (saveErr) {
        console.error('Error saving profile:', saveErr);
        
        // If there's a validation error, try a more direct update approach
        if (saveErr.name === 'ValidationError' || saveErr.name === 'CastError') {
          console.log('Validation/Cast error, trying direct MongoDB update');
          
          // Use direct MongoDB operation as a fallback
          const result = await mongoose.connection.db.collection('profiles').updateOne(
            { user: mongoose.Types.ObjectId(req.user.id) },
            existingIndex !== -1 
              ? { $set: { [`resourceLibrary.${existingIndex}`]: newResource } }
              : { $push: { resourceLibrary: newResource } }
          );
          
          console.log('Direct MongoDB update result:', result);
          
          if (result.modifiedCount > 0) {
            return res.json({
              message: 'Resource added successfully (via direct update)',
              resource: newResource,
              resourceCount: existingIndex !== -1 
                ? profile.resourceLibrary.length 
                : profile.resourceLibrary.length + 1
            });
          } else {
            throw new Error('Direct update failed');
          }
        } else {
          // Re-throw other errors
          throw saveErr;
        }
      }
    } catch (err) {
      console.error('Add resource error:', err);
      return res.status(500).json({ 
        message: 'Error adding resource',
        error: err.message 
      });
    }
  }

  // Update resource status (completed/not completed)
  async updateResourceStatus(req, res) {
    const { resourceId } = req.params;
    const { completed } = req.body;
    
    if (completed === undefined) {
      return res.status(400).json({ message: 'Completed status is required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile || !profile.resourceLibrary) {
        return res.status(404).json({ message: 'Profile or resource library not found' });
      }
      
      const resource = profile.resourceLibrary.id(resourceId);
      
      if (!resource) {
        return res.status(404).json({ message: 'Resource not found' });
      }
      
      resource.completed = completed;
      
      // Set completion date if marking as completed
      if (completed) {
        resource.completedAt = new Date();
      } else {
        resource.completedAt = undefined;
      }
      
      await profile.save();
      
      return res.json({
        message: 'Resource status updated successfully',
        resource
      });
    } catch (err) {
      console.error('Update resource status error:', err);
      return res.status(500).json({ 
        message: 'Error updating resource status',
        error: err.message 
      });
    }
  }
  
  // Generate study plan
  async generateStudyPlan(req, res) {
    const { subject, timeFrame, hoursPerWeek } = req.body;
    
    if (!subject || !timeFrame || !hoursPerWeek) {
      return res.status(400).json({ 
        message: 'Subject, time frame, and hours per week are required' 
      });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      // Get user's learning preferences for context
      const learningStyle = profile?.learningPreferences?.learningStyle || 'mixed';
      const preferredMaterials = profile?.learningPreferences?.preferredMaterials || [];
      const technicalLevel = profile?.learningPreferences?.technicalLevel || 3;
      
      // Format learning preferences for prompt
      let learningPrefText = `Learning Style: ${learningStyle}\n`;
      if (preferredMaterials.length > 0) {
        learningPrefText += `Preferred Materials: ${preferredMaterials.join(', ')}\n`;
      }
      
      // Determine difficulty level
      let difficultyLevel = 'intermediate';
      if (technicalLevel >= 4) {
        difficultyLevel = 'advanced';
      } else if (technicalLevel <= 2) {
        difficultyLevel = 'beginner';
      }
      
      // Create prompt for study plan
      const studyPlanPrompt = `Generate a structured study plan for: ${subject}
        Time Frame: ${timeFrame}
        Hours per Week: ${hoursPerWeek}
        Difficulty Level: ${difficultyLevel}
        ${learningPrefText}
        
        Please create a comprehensive study plan that includes:
        1. Clear learning objectives
        2. Weekly breakdown of topics to cover
        3. Recommended learning resources (books, videos, courses)
        4. Practice exercises
        5. Milestones and checkpoints
        6. Assessment methods
        
        Format the plan for clear readability with sections, bullet points, and a logical progression from fundamentals to more advanced topics. Suggest both theoretical learning and practical application approaches.`;
      
      // Generate study plan using DeepSeek
      try {
        const aiResponse = await generateResponse({
          body: {
            message: studyPlanPrompt,
            chatHistory: []
          },
          user: req.user
        });
        
        // Format the response properly
        if (aiResponse && aiResponse.response) {
          return res.json({
            subject,
            timeFrame,
            hoursPerWeek,
            studyPlan: aiResponse.response
          });
        } else {
          throw new Error('No response content from AI service');
        }
      } catch (aiError) {
        console.error('AI service error:', aiError);
        
        // Fallback: Generate a basic study plan if AI fails
        const fallbackPlan = this.generateFallbackStudyPlan(subject, timeFrame, hoursPerWeek, difficultyLevel);
        
        return res.json({
          subject,
          timeFrame,
          hoursPerWeek,
          studyPlan: fallbackPlan,
          note: 'Generated using fallback method due to AI service unavailability'
        });
      }
    } catch (err) {
      console.error('Generate study plan error:', err);
      res.status(500).json({ 
        message: 'Error generating study plan',
        error: err.message 
      });
    }
  }

  // Fallback study plan generator
  generateFallbackStudyPlan(subject, timeFrame, hoursPerWeek, difficultyLevel) {
    const totalHours = this.parseTimeFrame(timeFrame) * parseInt(hoursPerWeek);
    const weeksNum = this.parseTimeFrame(timeFrame);
    
    return `
      <div class="study-plan">
        <h2>Study Plan for ${subject}</h2>
        <p><strong>Duration:</strong> ${timeFrame} (${totalHours} total hours)</p>
        <p><strong>Time Commitment:</strong> ${hoursPerWeek} hours per week</p>
        <p><strong>Difficulty Level:</strong> ${difficultyLevel}</p>
        
        <h3>Learning Objectives</h3>
        <ul>
          <li>Understand the fundamentals of ${subject}</li>
          <li>Develop practical skills through hands-on practice</li>
          <li>Build a portfolio of projects demonstrating your knowledge</li>
          <li>Connect theoretical concepts to real-world applications</li>
        </ul>
        
        <h3>Weekly Breakdown</h3>
        ${this.generateWeeklyBreakdown(subject, weeksNum, difficultyLevel)}
        
        <h3>Recommended Resources</h3>
        <h4>Books</h4>
        <ul>
          <li>Search for highly-rated textbooks on ${subject}</li>
          <li>Look for practical guides and reference materials</li>
        </ul>
        
        <h4>Online Resources</h4>
        <ul>
          <li>Coursera, edX, or Udemy courses on ${subject}</li>
          <li>YouTube channels dedicated to ${subject}</li>
          <li>Official documentation and tutorials</li>
        </ul>
        
        <h3>Practice Exercises</h3>
        <ul>
          <li>Complete exercises at the end of each chapter/module</li>
          <li>Work on small projects to apply concepts</li>
          <li>Join study groups or online communities</li>
          <li>Practice problem-solving regularly</li>
        </ul>
        
        <h3>Milestones & Checkpoints</h3>
        <ul>
          <li>Week ${Math.floor(weeksNum/4)}: Complete foundational concepts</li>
          <li>Week ${Math.floor(weeksNum/2)}: Mid-term self-assessment</li>
          <li>Week ${Math.floor(3*weeksNum/4)}: Complete major project</li>
          <li>Week ${weeksNum}: Final review and assessment</li>
        </ul>
        
        <h3>Assessment Methods</h3>
        <ul>
          <li>Weekly self-quizzes on covered material</li>
          <li>Practical projects demonstrating skills</li>
          <li>Peer review and feedback</li>
          <li>Final comprehensive review</li>
        </ul>
      </div>
    `;
  }

  parseTimeFrame(timeFrame) {
    const match = timeFrame.match(/(\d+)\s+(week|month)/i);
    if (!match) return 4; // default to 4 weeks
    
    const num = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    
    if (unit === 'month') {
      return num * 4; // approximate weeks in months
    }
    return num;
  }

  generateWeeklyBreakdown(subject, weeks, difficulty) {
    let breakdown = '';
    
    for (let i = 1; i <= weeks; i++) {
      if (i <= weeks/4) {
        breakdown += `<h4>Week ${i}: Fundamentals</h4>
        <ul>
          <li>Introduction to ${subject}</li>
          <li>Basic concepts and terminology</li>
          <li>Setup and environment preparation</li>
        </ul>`;
      } else if (i <= weeks/2) {
        breakdown += `<h4>Week ${i}: Core Concepts</h4>
        <ul>
          <li>Deeper dive into key topics</li>
          <li>Hands-on exercises</li>
          <li>Practice problems</li>
        </ul>`;
      } else if (i <= 3*weeks/4) {
        breakdown += `<h4>Week ${i}: Advanced Topics</h4>
        <ul>
          <li>Complex concepts and applications</li>
          <li>Real-world case studies</li>
          <li>Project work</li>
        </ul>`;
      } else {
        breakdown += `<h4>Week ${i}: Integration & Review</h4>
        <ul>
          <li>Combine all learned concepts</li>
          <li>Final project</li>
          <li>Comprehensive review</li>
        </ul>`;
      }
    }
    
    return breakdown;
  }
}

module.exports = new AcademicController();