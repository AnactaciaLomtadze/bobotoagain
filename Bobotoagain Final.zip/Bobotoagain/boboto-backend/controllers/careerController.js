// controllers/careerController.js - FIXED VERSION with proper error handling and authentication
const Profile = require('../models/Profile');
const Resume = require('../models/Resume'); 
const SavedJob = require('../models/SavedJob');
const axios = require('axios');
const fs = require('fs').promises;
const path = require('path');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');
const { OpenAI } = require('openai');
require('dotenv').config();

// Debug logging function
function debugLog(message, data = null) {
  console.log(`[CAREER CONTROLLER DEBUG] ${message}`, data ? JSON.stringify(data, null, 2) : '');
}

// AI Configurations - FIX: Better error checking
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const OPENROUTER_BASE_URL = process.env.OPENROUTER_BASE_URL || 'https://openrouter.ai/api/v1';

// Check if API key exists at startup
if (!OPENROUTER_API_KEY) {
  console.error('❌ OPENROUTER_API_KEY not found in environment variables!');
} else {
  debugLog('✅ OPENROUTER_API_KEY found, length:', OPENROUTER_API_KEY.length);
}

// API Configuration
const ADZUNA_APP_ID = process.env.ADZUNA_APP_ID;
const ADZUNA_APP_KEY = process.env.ADZUNA_APP_KEY;
const MUSE_API_KEY = process.env.MUSE_API_KEY;
const LINKEDIN_CLIENT_ID = process.env.LINKEDIN_CLIENT_ID;
const LINKEDIN_CLIENT_SECRET = process.env.LINKEDIN_CLIENT_SECRET;

// Initialize OpenRouter for AI processing
const openrouter = new OpenAI({
  apiKey: OPENROUTER_API_KEY || 'placeholder-key',
  baseURL: OPENROUTER_BASE_URL
});

// Multer configuration for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|doc|docx|txt|odt/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (extname || mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, DOC, DOCX, ODT, and TXT files are allowed.'));
    }
  }
});

// Export the upload middleware for use in routes
exports.upload = upload;

/**
 * LinkedIn API Integration Service
 */
class LinkedInIntegration {
  static async getAccessToken(code, redirectUri) {
    try {
      const response = await axios.post('https://www.linkedin.com/oauth/v2/accessToken', 
        new URLSearchParams({
          grant_type: 'authorization_code',
          code,
          redirect_uri: redirectUri,
          client_id: LINKEDIN_CLIENT_ID,
          client_secret: LINKEDIN_CLIENT_SECRET,
        }),
        {
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );
      
      return response.data.access_token;
    } catch (error) {
      console.error('LinkedIn token error:', error.response?.data || error.message);
      throw new Error('Failed to get LinkedIn access token');
    }
  }
  
  static async getUserProfile(accessToken) {
    try {
      const [profileResponse, emailResponse] = await Promise.all([
        axios.get('https://api.linkedin.com/v2/people/(id,firstName,lastName,headline,location,summary)', {
          headers: { Authorization: `Bearer ${accessToken}` }
        }),
        axios.get('https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))', {
          headers: { Authorization: `Bearer ${accessToken}` }
        })
      ]);
      
      return {
        profile: profileResponse.data,
        email: emailResponse.data.elements[0]?.['handle~']?.emailAddress
      };
    } catch (error) {
      console.error('LinkedIn profile error:', error.response?.data || error.message);
      throw new Error('Failed to get LinkedIn profile');
    }
  }
  
  static async getUserSkills(accessToken) {
    try {
      const response = await axios.get('https://api.linkedin.com/v2/people/(id,skills)', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      
      return response.data.skills || [];
    } catch (error) {
      console.error('LinkedIn skills error:', error.response?.data || error.message);
      return [];
    }
  }
}

/**
 * Enhanced Adzuna Integration
 */
// Complete fixed AdzunaService class with all methods
class AdzunaService {
  static async getJobs(query, location, page = 1) {
    try {
      if (!ADZUNA_APP_ID || !ADZUNA_APP_KEY) {
        debugLog('❌ Adzuna API credentials not found');
        return [];
      }
      
      // Test credentials first
      try {
        await this.testCredentials();
        debugLog('✅ Adzuna credentials are valid');
      } catch (authError) {
        debugLog('❌ Adzuna credentials test failed:', authError.message);
        return [];
      }
      
      let country = 'us';
      const locationMappings = {
        'united states': 'us', 'usa': 'us',
        'united kingdom': 'gb', 'uk': 'gb',
        'canada': 'ca', 'australia': 'au',
        'germany': 'de', 'france': 'fr',
        'netherlands': 'nl', 'sweden': 'se'
      };
      
      if (location && location !== 'remote') {
        const locationLower = location.toLowerCase();
        for (const [key, value] of Object.entries(locationMappings)) {
          if (locationLower.includes(key)) {
            country = value;
            break;
          }
        }
      }
      
      // Fix the query - transform broad queries to more specific ones
      let searchQuery = query;
      if (query.toLowerCase() === 'computer science') {
        searchQuery = 'software engineer'; // More specific query
      }
      
      // Remove special characters that might cause issues
      searchQuery = searchQuery.replace(/[^a-zA-Z0-9\s-]/g, '');
      
      const params = {
        app_id: ADZUNA_APP_ID,
        app_key: ADZUNA_APP_KEY,
        results_per_page: Math.min(50, 50),
        what: searchQuery,
        sort_by: 'relevance',
        content_type: 'application/json'
      };
      
      // Only add location if not remote
      if (location && location !== 'remote') {
        params.where = location;
      }
      
      debugLog('Adzuna API request params:', params);
      
      const response = await axios.get(`https://api.adzuna.com/v1/api/jobs/${country}/search/${page}`, {
        params,
        timeout: 15000,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Boboto/1.0 (Academic AI Assistant)',
          'Accept-Encoding': 'gzip, deflate'
        }
      });
      
      debugLog('Adzuna API response status:', response.status);
      
      if (!response.data || !response.data.results) {
        debugLog('Adzuna API returned unexpected format');
        return [];
      }
      
      return response.data.results.map(job => ({
        id: `adzuna-${job.id}`,
        title: job.title,
        company: job.company?.display_name || 'Unknown Company',
        location: job.location?.display_name || 'Location not specified',
        description: job.description || 'No description available',
        salary: this.formatSalary(job.salary_min, job.salary_max),
        url: job.redirect_url,
        source: 'Adzuna',
        postedAt: job.created,
        type: job.contract_type || 'Unknown'
      })) || [];
    } catch (error) {
      debugLog('Adzuna API error details:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data?.substring(0, 200) + '...' || 'No response data',
        config: {
          url: error.config?.url,
          params: error.config?.params
        }
      });
      
      if (error.response?.status === 400) {
        console.error('❌ Adzuna API returned 400 - Bad Request. This might be due to:');
        console.error('  - Invalid query parameters');
        console.error('  - Rate limiting');
        console.error('  - Special characters in query');
        console.error('  - Query too broad or specific');
      }
      
      return [];
    }
  }
  
  static async getMarketTrends(location, category) {
    try {
      if (!ADZUNA_APP_ID || !ADZUNA_APP_KEY) {
        debugLog('❌ Adzuna API credentials not found for market trends');
        return null;
      }
      
      let country = 'us';
      
      // Map location to country
      if (location) {
        const locationLower = location.toLowerCase();
        if (locationLower.includes('uk') || locationLower.includes('united kingdom')) {
          country = 'gb';
        } else if (locationLower.includes('canada')) {
          country = 'ca';
        } else if (locationLower.includes('australia')) {
          country = 'au';
        }
      }
      
      const params = {
        app_id: ADZUNA_APP_ID,
        app_key: ADZUNA_APP_KEY,
        months: 6 // Get last 6 months of data
      };
      
      // Add location filter if specified
      if (location && location !== 'remote') {
        params.location = location;
      }
      
      // Add category filter if specified
      if (category) {
        params.category = category;
      }
      
      debugLog('Adzuna market trends request:', params);
      
      const response = await axios.get(`https://api.adzuna.com/v1/api/jobs/${country}/history`, {
        params,
        timeout: 10000,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Boboto/1.0 (Academic AI Assistant)'
        }
      });
      
      debugLog('Adzuna market trends response status:', response.status);
      
      if (!response.data) {
        debugLog('Adzuna market trends returned no data');
        return this.getFallbackMarketData();
      }
      
      return response.data;
    } catch (error) {
      debugLog('Adzuna market trends error:', error.response?.data || error.message);
      
      // Return fallback data instead of null
      return this.getFallbackMarketData();
    }
  }
  
  // Add fallback market data method
  static getFallbackMarketData() {
    return {
      month: {
        '2024-12': { count: 15000 },
        '2024-11': { count: 14500 },
        '2024-10': { count: 14000 },
        '2024-09': { count: 13500 },
        '2024-08': { count: 13000 },
        '2024-07': { count: 12500 }
      },
      fallback: true
    };
  }
  
  static async testCredentials() {
    debugLog('Testing Adzuna credentials...');
    
    const response = await axios.get('https://api.adzuna.com/v1/api/jobs/us/categories', {
      params: {
        app_id: ADZUNA_APP_ID,
        app_key: ADZUNA_APP_KEY
      },
      timeout: 5000,
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Boboto/1.0 (Academic AI Assistant)'
      }
    });
    
    if (response.status === 200) {
      debugLog('✅ Adzuna credentials are valid');
      return true;
    }
    
    throw new Error('Credentials test failed');
  }
  
  static formatSalary(min, max) {
    if (min && max) {
      return `$${min.toLocaleString()} - $${max.toLocaleString()}`;
    } else if (min) {
      return `$${min.toLocaleString()}+`;
    } else {
      return 'Salary not specified';
    }
  }
}

/**
 * The Muse API Integration
 */
class MuseService {
  static async getJobs(query, category, page = 1) {
    try {
      const params = {
        page,
        search: query
      };
      
      if (category) {
        params.category = category;
      }
      
      debugLog('Muse API request:', params);
      
      const response = await axios.get('https://www.themuse.com/api/public/jobs', {
        params,
        timeout: 10000,
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Boboto/1.0 (Academic AI Assistant)'
        }
      });
      
      if (!response.data || !response.data.results) {
        debugLog('Muse API returned unexpected format');
        return [];
      }
      
      return response.data.results.map(job => ({
        id: `muse-${job.id}`,
        title: job.name,
        company: job.company?.name || 'Unknown Company',
        location: job.locations?.map(loc => loc.name).join(', ') || 'Location not specified',
        description: job.description || job.contents || 'No description available',
        salary: 'Please inquire',
        url: job.refs?.landing_page || job.content?.raw_content,
        source: 'The Muse',
        postedAt: job.publication_date,
        type: job.type || 'Unknown'
      }));
    } catch (error) {
      debugLog('Muse API error:', {
        message: error.message,
        status: error.response?.status
      });
      return [];
    }
  }
}

/**
 * RemoteOK API Integration
 */
class RemoteOKService {
  static async getJobs(query, limit = 50) {
    try {
      const response = await axios.get('https://remoteok.io/api', {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Boboto/1.0 (Academic AI Assistant)'
        },
        timeout: 10000
      });
      
      if (!response.data || !Array.isArray(response.data)) {
        debugLog('RemoteOK API returned unexpected format');
        return [];
      }
      
      // First element is metadata, skip it
      const jobs = response.data.slice(1);
      
      // Filter by query if provided
      let filteredJobs = jobs;
      if (query) {
        filteredJobs = jobs.filter(job => 
          job.title?.toLowerCase().includes(query.toLowerCase()) ||
          job.description?.toLowerCase().includes(query.toLowerCase()) ||
          job.tags?.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
        );
      }
      
      return filteredJobs.slice(0, limit).map(job => {
        // Handle date conversion safely
        let postedAt;
        try {
          // RemoteOK provides dates in different formats
          if (job.date) {
            // Check if it's already a valid date string
            const testDate = new Date(job.date);
            if (!isNaN(testDate.getTime())) {
              postedAt = testDate.toISOString();
            } else {
              // Try parsing as unix timestamp
              const timestamp = parseInt(job.date);
              if (!isNaN(timestamp)) {
                // If it's a large number, assume it's in seconds
                const secondsTimestamp = timestamp > 1000000000000 ? timestamp / 1000 : timestamp;
                postedAt = new Date(secondsTimestamp * 1000).toISOString();
              } else {
                throw new Error('Invalid date format');
              }
            }
          } else {
            // Use current date if no date provided
            postedAt = new Date().toISOString();
          }
        } catch (dateError) {
          debugLog('Date parsing error for job:', { id: job.id, date: job.date, error: dateError.message });
          // Fallback to current date
          postedAt = new Date().toISOString();
        }
        
        return {
          id: `remoteok-${job.id}`,
          title: job.title,
          company: job.company,
          location: 'Remote',
          description: job.description || 'Remote opportunity',
          salary: job.salary ? `$${job.salary}K` : 'Salary not specified',
          url: job.url,
          source: 'RemoteOK',
          postedAt,
          type: 'Remote',
          tags: job.tags || []
        };
      });
    } catch (error) {
      debugLog('RemoteOK API error:', {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data
      });
      return [];
    }
  }
}

/**
 * AI-Powered Career Analysis using DeepSeek/OpenRouter
 * FIX: Added proper error handling and authentication
 */
class AICareerAnalyst {
// Add this helper function to clean AI responses
static cleanAIResponse(response) {
  if (!response) return null;
  
  // Remove markdown code block syntax
  let cleaned = response.trim();
  
  // Remove ```json prefix and ``` suffix
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '');
  }
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '');
  }
  if (cleaned.endsWith('```')) {
    cleaned = cleaned.replace(/\s*```$/, '');
  }
  
  // Remove any remaining backticks at start/end
  cleaned = cleaned.replace(/^`+|`+$/g, '');
  
  return cleaned.trim();
}

// Enhanced AI prompts with strict JSON format requirements

static async generateCareerSuggestions(profile) {
  debugLog('Starting AI career suggestions generation');
  
  try {
    // Check if API key is available
    if (!OPENROUTER_API_KEY) {
      debugLog('❌ No OpenRouter API key, using fallback');
      return this.getFallbackCareerSuggestions(profile);
    }
    
    const prompt = `
    Analyze this user profile and suggest 5 career paths.
    
    User Profile:
    - Skills: ${profile.skills?.map(s => s.name).join(', ') || 'None specified'}
    - Education: ${profile.major || 'Not specified'} (${profile.academicLevel || 'Not specified'})
    - Career Goals: ${profile.careerGoals?.shortTermGoal || 'Not specified'}
    - Experience: ${profile.workExperience?.length || 0} previous positions
    - Interests: ${profile.interests?.join(', ') || 'Not specified'}
    
    IMPORTANT: Return ONLY a JSON array with NO markdown formatting, NO backticks, NO explanations.
    
    Use EXACTLY these field names for each career:
    [
      {
        "title": "Job Title",
        "description": "Brief 2-3 sentence description",
        "requiredSkills": ["Skill 1", "Skill 2", "Skill 3", "Skill 4"],
        "growthPotential": "1-2 sentence growth description",
        "averageSalary": "$XX,000 - $XX,000",
        "nextSteps": ["Step 1", "Step 2", "Step 3"],
        "score": 85,
        "growthRate": 25
      }
    ]
    
    Make the score (0-100) and growthRate (percentage) numbers, not strings.
    `;
    
    debugLog('Making OpenRouter API call with enhanced prompt');
    
    const response = await openrouter.chat.completions.create({
      model: "deepseek/deepseek-chat",
      messages: [
        { 
          role: "system", 
          content: "You are a career counselor. ALWAYS respond with ONLY valid JSON. NO markdown, NO code blocks, NO explanations. Just the JSON array."
        },
        { role: "user", content: prompt }
      ],
      max_tokens: 2000,
      temperature: 0.7
    });
    
    debugLog('✅ OpenRouter response received');
    
    let aiResponse = response.choices[0].message.content;
    debugLog('AI Response preview:', aiResponse.substring(0, 200));
    
    // Clean the response more aggressively
    aiResponse = this.cleanAIResponse(aiResponse);
    
    // Try to parse
    try {
      const result = JSON.parse(aiResponse);
      
      if (!Array.isArray(result)) {
        debugLog('Response is not an array, checking for nested structure');
        if (result.suggestions && Array.isArray(result.suggestions)) {
          return result.suggestions;
        } else if (result.careers && Array.isArray(result.careers)) {
          return result.careers;
        } else {
          throw new Error('Response is not an array');
        }
      }
      
      debugLog('✅ Successfully parsed AI response:', result.length, 'careers');
      return result;
    } catch (parseError) {
      debugLog('❌ JSON parse failed:', parseError.message);
      debugLog('Attempting regex extraction...');
      
      // Try to extract JSON using regex as last resort
      const jsonMatch = aiResponse.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        try {
          const extracted = JSON.parse(jsonMatch[0]);
          debugLog('✅ Successfully extracted JSON with regex');
          return extracted;
        } catch (regexError) {
          debugLog('❌ Regex extraction also failed');
        }
      }
      
      debugLog('🔄 Using fallback career suggestions');
      return this.getFallbackCareerSuggestions(profile);
    }
  } catch (error) {
    debugLog('❌ AI Career Suggestions error:', error.message);
    console.error('Full error:', error);
    return this.getFallbackCareerSuggestions(profile);
  }
}

static async analyzeSkillGap(userSkills, targetRole) {
  debugLog('Starting skill gap analysis', { userSkills, targetRole });
  
  try {
    if (!OPENROUTER_API_KEY) {
      debugLog('❌ No OpenRouter API key, using fallback');
      return this.getFallbackSkillGap(userSkills, targetRole);
    }
    
    const prompt = `
    Analyze skill gap for: ${targetRole}
    Current skills: ${userSkills.join(', ')}
    
    IMPORTANT: Return ONLY valid JSON with NO markdown formatting.
    
    Use EXACTLY this structure:
    {
      "readinessScore": 75,
      "matchedSkills": ["skill1", "skill2"],
      "missingSkills": ["skill3", "skill4"],
      "skillRecommendations": [
        {
          "skill": "Skill Name",
          "priority": "High",
          "difficulty": {
            "description": "Intermediate",
            "estimatedTimeToLearn": "3-6 months"
          },
          "learningResources": [
            {"name": "Course Name", "platform": "Platform", "url": "#"}
          ]
        }
      ]
    }
    
    Make readinessScore a number (0-100), not a string.
    `;
    
    debugLog('Making skill gap analysis API call');
    
    const response = await openrouter.chat.completions.create({
      model: "deepseek/deepseek-chat",
      messages: [
        { 
          role: "system", 
          content: "You are a career analyst. ALWAYS respond with ONLY valid JSON. NO markdown, NO code blocks, NO explanations."
        },
        { role: "user", content: prompt }
      ],
      max_tokens: 1500,
      temperature: 0.3
    });
    
    debugLog('✅ Skill gap analysis response received');
    
    let aiResponse = response.choices[0].message.content;
    
    // Clean the response
    aiResponse = this.cleanAIResponse(aiResponse);
    
    try {
      const result = JSON.parse(aiResponse);
      debugLog('✅ Successfully parsed skill gap analysis');
      return result;
    } catch (parseError) {
      debugLog('❌ JSON parse failed:', parseError.message);
      debugLog('Raw response:', aiResponse);
      
      // Try regex extraction
      const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const extracted = JSON.parse(jsonMatch[0]);
          debugLog('✅ Successfully extracted JSON with regex');
          return extracted;
        } catch (regexError) {
          debugLog('❌ Regex extraction failed');
        }
      }
      
      debugLog('🔄 Using fallback skill gap analysis');
      return this.getFallbackSkillGap(userSkills, targetRole);
    }
  } catch (error) {
    debugLog('❌ Skill gap analysis error:', error.message);
    console.error('Full error:', error);
    return this.getFallbackSkillGap(userSkills, targetRole);
  }
}
  
  static async analyzeResume(resumeText, targetRole) {
    debugLog('Starting resume analysis', { targetRole });
    
    try {
      if (!OPENROUTER_API_KEY) {
        debugLog('❌ No OpenRouter API key, using fallback');
        return this.getFallbackResumeAnalysis(resumeText);
      }
      
      const prompt = `
      Analyze this resume for the role of ${targetRole || 'general position'}:
      
      ${resumeText.substring(0, 3000)}...
      
      Provide a comprehensive analysis with:
      1. Overall score (0-100)
      2. Component scores:
         - Skills coverage (0-100)
         - Experience quality (0-100)
         - Education relevance (0-100)
      3. Strengths (3-5 bullet points)
      4. Improvement suggestions with:
         - Section to improve
         - Specific suggestion
         - Reason for improvement
         - Priority level (High/Medium/Low)
      5. Skills found in resume
      6. Skills missing for the target role
      7. Experience analysis
      8. Education assessment
      
      Return as valid JSON object.
      `;
      
      debugLog('Making resume analysis API call');
      
      const response = await openrouter.chat.completions.create({
        model: "deepseek/deepseek-chat",
        messages: [
          { role: "system", content: "You are an expert resume reviewer and career coach with deep knowledge of hiring practices." },
          { role: "user", content: prompt }
        ],
        max_tokens: 2000,
        temperature: 0.3
      });
      
      debugLog('✅ Resume analysis response received');
      
      const aiResponse = response.choices[0].message.content;
      
      try {
        const result = JSON.parse(aiResponse);
        debugLog('✅ Successfully parsed resume analysis');
        return result;
      } catch (parseError) {
        debugLog('❌ Failed to parse resume response:', parseError.message);
        return this.getFallbackResumeAnalysis(resumeText);
      }
    } catch (error) {
      debugLog('❌ Resume analysis error:', error.message);
      console.error('Full error:', error);
      return this.getFallbackResumeAnalysis(resumeText);
    }
  }
  
  static async analyzeJobMarketTrends(location, industry, skills) {
    debugLog('Starting job market trends analysis', { location, industry, skills });
    
    try {
      if (!OPENROUTER_API_KEY) {
        debugLog('❌ No OpenRouter API key, using fallback');
        return this.getFallbackMarketTrends();
      }
      
      const prompt = `
      Analyze current job market trends for:
      Location: ${location || 'Global'}
      Industry: ${industry || 'Technology'}
      Skills: ${skills?.join(', ') || 'General tech skills'}
      
      Provide market analysis with:
      1. Demand trends analysis
      2. Salary trends by role
      3. Top 10 in-demand skills with growth rates
      4. Recent market insights and changes
      5. Location-specific insights
      6. Industry growth predictions
      
      Return as valid JSON object with structured data.
      `;
      
      debugLog('Making market trends analysis API call');
      
      const response = await openrouter.chat.completions.create({
        model: "deepseek/deepseek-chat",
        messages: [
          { role: "system", content: "You are a market research analyst specializing in employment trends and salary data." },
          { role: "user", content: prompt }
        ],
        max_tokens: 1500,
        temperature: 0.4
      });
      
      debugLog('✅ Market trends analysis response received');
      
      const aiResponse = response.choices[0].message.content;
      
      try {
        const result = JSON.parse(aiResponse);
        debugLog('✅ Successfully parsed market trends analysis');
        return result;
      } catch (parseError) {
        debugLog('❌ Failed to parse market trends response:', parseError.message);
        return this.getFallbackMarketTrends();
      }
    } catch (error) {
      debugLog('❌ Job market analysis error:', error.message);
      console.error('Full error:', error);
      return this.getFallbackMarketTrends();
    }
  }
  
  // Enhanced fallback methods
  static getFallbackCareerSuggestions(profile) {
    debugLog('🔄 Using fallback career suggestions');
    
    const userSkills = profile.skills?.map(s => s.name.toLowerCase()) || [];
    const fallbackSuggestions = [];
    
    // Suggest careers based on user's skills
    if (userSkills.some(skill => ['javascript', 'python', 'java'].includes(skill))) {
      fallbackSuggestions.push({
        title: "Software Engineer",
        description: "Develop, test, and maintain software applications and systems. Perfect for your programming background.",
        requiredSkills: ["Programming", "Data Structures", "Algorithms", "System Design", "Testing", "Git", "API Development"],
        growthPotential: "High demand with excellent growth opportunities. Software engineering continues to be one of the fastest-growing fields.",
        averageSalary: "$75,000 - $150,000",
        nextSteps: [
          "Build personal projects to showcase your skills",
          "Contribute to open-source projects",
          "Learn system design principles",
          "Practice coding interview problems"
        ],
        score: 85,
        growthRate: 22
      });
    }
    
    if (userSkills.some(skill => ['python', 'machine learning', 'data'].includes(skill))) {
      fallbackSuggestions.push({
        title: "Data Scientist",
        description: "Extract insights from data to drive business decisions. Combines statistical analysis with programming.",
        requiredSkills: ["Python", "Statistics", "Machine Learning", "SQL", "Data Visualization", "R", "Statistical Modeling"],
        growthPotential: "Extremely high demand as companies increasingly rely on data-driven decisions.",
        averageSalary: "$90,000 - $170,000",
        nextSteps: [
          "Complete data science projects with real datasets",
          "Learn advanced statistics and probability",
          "Master popular ML libraries (scikit-learn, pandas)",
          "Build a portfolio on Kaggle or GitHub"
        ],
        score: 78,
        growthRate: 35
      });
    }
    
    // Add more fallback suggestions
    fallbackSuggestions.push({
      title: "Product Manager",
      description: "Bridge the gap between technical and business teams to create successful products.",
      requiredSkills: ["Product Strategy", "User Research", "Data Analysis", "Project Management", "Communication", "Market Research", "Agile"],
      growthPotential: "Strong demand as companies focus on product-led growth strategies.",
      averageSalary: "$85,000 - $160,000",
      nextSteps: [
        "Learn product management frameworks",
        "Practice user research techniques",
        "Build understanding of business metrics",
        "Take on product-oriented projects in current role"
      ],
      score: 70,
      growthRate: 18
    });
    
    // If no specific skills, provide general tech suggestions
    if (fallbackSuggestions.length === 0) {
      fallbackSuggestions.push(
        {
          title: "Web Developer",
          description: "Create and maintain websites and web applications using modern technologies.",
          requiredSkills: ["HTML", "CSS", "JavaScript", "React", "Node.js", "Database Management", "Responsive Design"],
          growthPotential: "Consistent demand with opportunities in various industries.",
          averageSalary: "$60,000 - $120,000",
          nextSteps: [
            "Learn HTML, CSS, and JavaScript fundamentals",
            "Build portfolio projects",
            "Learn a modern framework (React, Vue, Angular)",
            "Practice responsive design principles"
          ],
          score: 75,
          growthRate: 15
        },
        {
          title: "UX/UI Designer",
          description: "Design user interfaces and experiences that are both functional and visually appealing.",
          requiredSkills: ["Design Thinking", "Prototyping", "User Research", "Figma", "Adobe Creative Suite", "Interaction Design", "Usability Testing"],
          growthPotential: "Growing demand as companies prioritize user experience.",
          averageSalary: "$65,000 - $130,000",
          nextSteps: [
            "Learn design principles and tools",
            "Create case studies for portfolio",
            "Practice user research methods",
            "Study successful app and website designs"
          ],
          score: 65,
          growthRate: 20
        }
      );
    }
    
    return fallbackSuggestions.slice(0, 5);
  }
  
  static getFallbackSkillGap(userSkills, targetRole) {
    debugLog('🔄 Using fallback skill gap analysis');
    
    const skillMap = {
      'software engineer': {
        required: ['Programming', 'Data Structures', 'Algorithms', 'System Design', 'Testing', 'Git', 'Database Management'],
        readinessBase: 70
      },
      'data scientist': {
        required: ['Python', 'Machine Learning', 'Statistics', 'SQL', 'Data Visualization', 'R', 'Jupyter Notebooks'],
        readinessBase: 65
      },
      'product manager': {
        required: ['Product Strategy', 'User Research', 'Data Analysis', 'Project Management', 'Communication', 'Market Research'],
        readinessBase: 60
      },
      'web developer': {
        required: ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js', 'Database Management', 'Version Control'],
        readinessBase: 75
      },
      'machine learning engineer': {
        required: ['Python', 'TensorFlow', 'PyTorch', 'MLOps', 'Cloud Computing', 'Statistics', 'Deep Learning'],
        readinessBase: 60
      }
    };
    
    const roleKey = Object.keys(skillMap).find(key => 
      targetRole.toLowerCase().includes(key.replace(' engineer', '').replace(' developer', '').replace(' manager', '').replace(' scientist', ''))
    );
    
    const roleData = roleKey ? skillMap[roleKey] : { required: ['Communication', 'Problem Solving', 'Critical Thinking'], readinessBase: 50 };
    
    const userSkillNames = userSkills.map(s => s.toLowerCase());
    const matchedSkills = roleData.required.filter(skill => 
      userSkillNames.some(userSkill => userSkill.includes(skill.toLowerCase()))
    );
    const missingSkills = roleData.required.filter(skill => 
      !userSkillNames.some(userSkill => userSkill.includes(skill.toLowerCase()))
    );
    
    const readinessScore = roleData.readinessBase + (matchedSkills.length * 5) - (missingSkills.length * 3);
    
    return {
      readinessScore: Math.max(0, Math.min(100, readinessScore)),
      matchedSkills,
      missingSkills,
      skillRecommendations: missingSkills.map(skill => ({
        skill,
        priority: missingSkills.indexOf(skill) < 3 ? 'High' : 'Medium',
        difficulty: {
          description: missingSkills.indexOf(skill) < 2 ? 'Intermediate' : 'Beginner',
          estimatedTimeToLearn: missingSkills.indexOf(skill) < 2 ? '3-6 months' : '1-3 months'
        },
        learningResources: [
          { name: `${skill} Fundamentals Course`, platform: 'Coursera', url: '#' },
          { name: `${skill} Tutorial`, platform: 'YouTube', url: '#' }
        ]
      }))
    };
  }
  
  static getFallbackResumeAnalysis(resumeText) {
    debugLog('🔄 Using fallback resume analysis');
    
    // Basic analysis based on text content
    const wordCount = resumeText.split(' ').length;
    const hasContactInfo = /email|phone|@/.test(resumeText.toLowerCase());
    const hasSkills = /skills|competencies|proficient/i.test(resumeText);
    const hasExperience = /experience|work|employed|position/i.test(resumeText);
    const hasEducation = /education|university|degree|bachelor|master/i.test(resumeText);
    
    let baseScore = 50;
    if (hasContactInfo) baseScore += 10;
    if (hasSkills) baseScore += 15;
    if (hasExperience) baseScore += 15;
    if (hasEducation) baseScore += 10;
    
    // Extract skills from common patterns
    const foundSkills = [];
    const skillPatterns = [
      /javascript/i, /python/i, /java/i, /react/i, /node\.?js/i,
      /sql/i, /html/i, /css/i, /git/i, /aws/i
    ];
    
    skillPatterns.forEach(pattern => {
      if (pattern.test(resumeText)) {
        foundSkills.push(pattern.source.replace(/[\\i]/g, ''));
      }
    });
    
    return {
      assessment: {
        overallScore: {
          overall: Math.min(baseScore, 100),
          components: {
            skills: hasSkills ? 75 : 40,
            experience: hasExperience ? 70 : 35,
            education: hasEducation ? 80 : 50
          }
        },
        skillCoverage: {
          coveragePercent: foundSkills.length > 0 ? 60 : 30,
          missing: ["System Design", "API Development", "Testing Frameworks"]
        }
      },
      improvements: [
        {
          suggestion: "Add quantifiable achievements and metrics to your experience section",
          section: "Experience",
          reason: "Numbers help employers understand your impact",
          priority: "High"
        },
        {
          suggestion: "Include a dedicated technical skills section",
          section: "Skills",
          reason: "Easy scanning for technical requirements",
          priority: "High"
        },
        {
          suggestion: "Add relevant projects or portfolio links",
          section: "Projects",
          reason: "Demonstrates practical application of skills",
          priority: "Medium"
        }
      ],
      sections: {
        skills: foundSkills,
        experience: hasExperience ? "Experience section found" : "No experience section detected",
        education: hasEducation ? "Education section found" : "No education section detected"
      }
    };
  }
  
  static getFallbackMarketTrends() {
    debugLog('🔄 Using fallback market trends');
    
    return {
      demandTrends: [
        {
          skill: "Machine Learning",
          demand: "High",
          growth: "+25%",
          description: "ML skills are in extremely high demand across industries"
        },
        {
          skill: "Cloud Computing",
          demand: "Very High",
          growth: "+30%",
          description: "Cloud skills essential as companies move to digital transformation"
        },
        {
          skill: "React/JavaScript",
          demand: "High",
          growth: "+20%",
          description: "Frontend development continues to grow"
        }
      ],
      salaryTrends: [
        { role: "Software Engineer", avgSalary: "$95,000", growth: "+5%" },
        { role: "Data Scientist", avgSalary: "$115,000", growth: "+8%" },
        { role: "Product Manager", avgSalary: "$110,000", growth: "+6%" }
      ],
      topSkills: [
        { name: "Python", demandScore: 95, growth: "+15%" },
        { name: "JavaScript", demandScore: 90, growth: "+12%" },
        { name: "Machine Learning", demandScore: 88, growth: "+25%" },
        { name: "Cloud Computing", demandScore: 85, growth: "+20%" },
        { name: "React", demandScore: 82, growth: "+18%" }
      ],
      recentTrends: [
        "AI/ML skills see unprecedented demand",
        "Remote work capabilities increasingly valued",
        "Full-stack development skills in high demand",
        "DevOps and cloud expertise essential for most roles"
      ],
      locationInsights: [
        "Remote opportunities increasing across all tech roles",
        "Tech hubs expanding beyond traditional Silicon Valley",
        "Cost-of-living considerations affecting salary negotiations"
      ]
    };
  }
}

/**
 * ENHANCED SKILL GAP ANALYSIS - Main Functions
 */

// Generate comprehensive skill gap analysis
async function generateSkillGapAnalysis(targetRole, userSkills, profile) {
  debugLog('Starting comprehensive skill gap analysis', { targetRole, userSkills: userSkills.length });
  
  try {
    // Use AI for analysis
    const aiAnalysis = await AICareerAnalyst.analyzeSkillGap(userSkills, targetRole);
    
    // Enhanced response with additional calculations
    return {
      ...aiAnalysis,
      generatedAt: new Date(),
      userProfile: {
        skills: userSkills,
        major: profile.major,
        academicLevel: profile.academicLevel
      },
      // Add enhanced metrics
      metrics: {
        skillAlignment: calculateSkillAlignment(aiAnalysis.matchedSkills, aiAnalysis.missingSkills, 'technical'),
        experienceLevel: calculateExperienceAlignment(profile, targetRole),
        certificationRequirements: calculateCertificationAlignment(profile, targetRole),
        softSkills: calculateSoftSkillAlignment(profile, targetRole)
      }
    };
  } catch (error) {
    debugLog('Error in skill gap analysis:', error.message);
    return generateFallbackAnalysis(targetRole, userSkills);
  }
}

// Calculate skill alignment percentages
function calculateSkillAlignment(matchedSkills, missingSkills, category) {
  const total = matchedSkills.length + missingSkills.length;
  if (total === 0) return 0;
  return Math.round((matchedSkills.length / total) * 100);
}

// Calculate experience level alignment
function calculateExperienceAlignment(profile, targetRole) {
  const experienceYears = profile.workExperience?.length || 0;
  
  // Simple heuristic - can be enhanced with more sophisticated logic
  const targetExperienceMap = {
    'junior': 1,
    'entry': 1,
    'senior': 5,
    'lead': 7,
    'principal': 10,
    'architect': 12
  };
  
  const targetLevel = Object.keys(targetExperienceMap).find(level => 
    targetRole.toLowerCase().includes(level)
  );
  
  if (!targetLevel) return 50; // Default if can't determine
  
  const requiredExperience = targetExperienceMap[targetLevel];
  const alignmentPercentage = Math.min((experienceYears / requiredExperience) * 100, 100);
  
  return Math.round(alignmentPercentage);
}

// Calculate certification alignment
function calculateCertificationAlignment(profile, targetRole) {
  // Check if user has certifications related to target role
  const certifications = profile.certifications || [];
  
  // Simple mapping - could be enhanced with more sophisticated matching
  const roleCertificationMap = {
    'machine learning': ['aws ml', 'azure ai', 'google cloud ml', 'tensorflow'],
    'cloud': ['aws', 'azure', 'gcp', 'cloud'],
    'data science': ['python', 'r', 'tableau', 'spark'],
    'security': ['cissp', 'security+', 'ethical hacking'],
    'project management': ['pmp', 'scrum', 'agile']
  };
  
  const relevantCerts = Object.keys(roleCertificationMap).filter(key => 
    targetRole.toLowerCase().includes(key)
  ).reduce((acc, key) => acc.concat(roleCertificationMap[key]), []);
  
  const userCertifications = certifications.map(cert => cert.name.toLowerCase());
  const matchingCerts = relevantCerts.filter(cert => 
    userCertifications.some(userCert => userCert.includes(cert))
  );
  
  if (relevantCerts.length === 0) return 50; // Default if no specific certs needed
  
  return Math.round((matchingCerts.length / relevantCerts.length) * 100);
}

// Calculate soft skills alignment
function calculateSoftSkillAlignment(profile, targetRole) {
  const userSoftSkills = profile.skills?.filter(skill => 
    ['communication', 'leadership', 'problem solving', 'teamwork', 'time management']
      .includes(skill.name.toLowerCase())
  ) || [];
  
  // Different roles emphasize different soft skills
  const roleSoftSkillMap = {
    'lead': ['leadership', 'communication', 'problem solving'],
    'manager': ['leadership', 'communication', 'time management'],
    'senior': ['leadership', 'problem solving', 'communication'],
    'consultant': ['communication', 'problem solving', 'teamwork']
  };
  
  const relevantSoftSkills = Object.keys(roleSoftSkillMap).find(level => 
    targetRole.toLowerCase().includes(level)
  );
  
  if (!relevantSoftSkills) return 75; // Default assumption
  
  const requiredSkills = roleSoftSkillMap[relevantSoftSkills];
  const matchingSkills = userSoftSkills.filter(skill => 
    requiredSkills.some(required => skill.name.toLowerCase().includes(required))
  );
  
  return Math.min(Math.round((matchingSkills.length / requiredSkills.length) * 100), 100);
}

// Generate focus areas
function generateFocusAreas(analysis, targetRole) {
  return [
    {
      area: 'Technical Skills',
      priority: 'High',
      description: 'Strengthen core technical competencies',
      recommendations: analysis.missingSkills.slice(0, 3)
    },
    {
      area: 'Practical Experience',
      priority: 'High',
      description: 'Gain hands-on experience with real projects',
      recommendations: [
        'Build portfolio projects',
        'Contribute to open source',
        'Participate in hackathons'
      ]
    },
    {
      area: 'Industry Knowledge',
      priority: 'Medium',
      description: 'Understand industry trends and best practices',
      recommendations: [
        'Follow industry blogs and publications',
        'Attend relevant conferences and meetups',
        'Network with professionals in the field'
      ]
    }
  ];
}

// Generate learning path
function generateLearningPath(analysis, targetRole) {
  const phases = [
    {
      phase: 1,
      title: 'Foundation Building',
      duration: '1-2 months',
      skills: analysis.missingSkills.filter(skill => 
        analysis.skillRecommendations?.find(rec => 
          rec.skill === skill && rec.priority === 'High'
        )
      ).slice(0, 2)
    },
    {
      phase: 2,
      title: 'Skill Development',
      duration: '2-3 months',
      skills: analysis.missingSkills.slice(2, 4)
    },
    {
      phase: 3,
      title: 'Advanced Topics',
      duration: '2-4 months',
      skills: analysis.missingSkills.slice(4, 6)
    },
    {
      phase: 4,
      title: 'Specialization',
      duration: '3-6 months',
      skills: analysis.missingSkills.slice(6, 8)
    }
  ];
  
  return phases.filter(phase => phase.skills.length > 0);
}

// Generate timeline estimate
function generateTimelineEstimate(analysis, targetRole) {
  const totalMissingSkills = analysis.missingSkills.length;
  const highPrioritySkills = analysis.skillRecommendations?.filter(rec => 
    rec.priority === 'High'
  ).length || 0;
  
  // Estimate based on skill count and priority
  let estimatedMonths = 6; // Base estimate
  
  if (totalMissingSkills > 10) estimatedMonths += 6;
  if (highPrioritySkills > 5) estimatedMonths += 3;
  if (analysis.readinessScore < 50) estimatedMonths += 3;
  
  return {
    estimatedTimeToReady: `${estimatedMonths} months`,
    milestones: [
      { milestone: 'Basic competency', timeframe: `${Math.round(estimatedMonths * 0.3)} months` },
      { milestone: 'Job-ready skills', timeframe: `${Math.round(estimatedMonths * 0.6)} months` },
      { milestone: 'Competitive level', timeframe: `${estimatedMonths} months` }
    ]
  };
}

// Fallback analysis when AI is unavailable
function generateFallbackAnalysis(targetRole, userSkills) {
  debugLog('Generating fallback analysis');
  
  return {
    readinessScore: 65,
    matchedSkills: userSkills.slice(0, Math.min(3, userSkills.length)),
    missingSkills: getCommonSkillsForRole(targetRole),
    skillRecommendations: [
      {
        skill: 'Programming Languages',
        priority: 'High',
        difficulty: {
          description: 'Intermediate',
          estimatedTimeToLearn: '3-6 months'
        },
        learningResources: [
          { name: 'Python for Beginners', platform: 'Coursera', url: '#' },
          { name: 'JavaScript Fundamentals', platform: 'freeCodeCamp', url: '#' }
        ]
      }
    ]
  };
}

// Get common skills for different roles
function getCommonSkillsForRole(role) {
  const skillsMap = {
    'machine learning': ['Python', 'TensorFlow', 'PyTorch', 'Statistics', 'Linear Algebra'],
    'software engineer': ['Programming', 'Data Structures', 'Algorithms', 'System Design', 'Testing'],
    'data scientist': ['Python', 'R', 'Statistics', 'SQL', 'Machine Learning', 'Data Visualization'],
    'web developer': ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js', 'Databases'],
    'cloud engineer': ['AWS', 'Azure', 'Docker', 'Kubernetes', 'Infrastructure as Code', 'DevOps'],
    'product manager': ['Product Strategy', 'Data Analysis', 'UX Design', 'Agile', 'Roadmap Planning']
  };
  
  // Find matching skills based on role keywords
  const roleKey = Object.keys(skillsMap).find(key => 
    role.toLowerCase().includes(key)
  );
  
  return roleKey ? skillsMap[roleKey] : ['Critical Thinking', 'Problem Solving', 'Communication'];
}

// Get market data for a specific role
async function getMarketDataForRole(roleName) {
  try {
    // Simulate market data - replace with actual API calls
    const marketDataMap = {
      'machine learning engineer': {
        demandScore: 95,
        avgSalary: 125000,
        growthRate: 15,
        competition: 'High',
        remoteOpportunities: 85
      },
      'software engineer': {
        demandScore: 90,
        avgSalary: 95000,
        growthRate: 12,
        competition: 'High',
        remoteOpportunities: 80
      },
      'data scientist': {
        demandScore: 85,
        avgSalary: 110000,
        growthRate: 20,
        competition: 'Medium-High',
        remoteOpportunities: 75
      }
    };
    
    const roleKey = Object.keys(marketDataMap).find(key => 
      roleName.toLowerCase().includes(key.split(' ')[0])
    );
    
    return roleKey ? marketDataMap[roleKey] : {
      demandScore: 70,
      avgSalary: 80000,
      growthRate: 10,
      competition: 'Medium',
      remoteOpportunities: 60
    };
  } catch (error) {
    debugLog('Error fetching market data:', error.message);
    return null;
  }
}

// Extract skills from job description
function extractSkillsFromJobDescription(description) {
  const commonSkills = [
    'Python', 'JavaScript', 'Java', 'React', 'Node.js', 'SQL', 'MongoDB',
    'AWS', 'Azure', 'Docker', 'Kubernetes', 'Machine Learning', 'TensorFlow',
    'PyTorch', 'Data Science', 'Statistics', 'HTML', 'CSS', 'Git',
    'Agile', 'Scrum', 'Leadership', 'Communication', 'Problem Solving'
  ];
  
  const foundSkills = commonSkills.filter(skill => 
    description.toLowerCase().includes(skill.toLowerCase())
  );
  
  return foundSkills;
}

// Generate skill gap analysis for a specific job
async function generateJobSkillGap(userSkills, jobRequirements, jobTitle) {
  const userSkillNames = userSkills.map(s => s.name);
  const matchedSkills = jobRequirements.filter(req => 
    userSkillNames.some(skill => skill.toLowerCase() === req.toLowerCase())
  );
  const missingSkills = jobRequirements.filter(req => 
    !userSkillNames.some(skill => skill.toLowerCase() === req.toLowerCase())
  );
  
  const readinessScore = jobRequirements.length > 0 
    ? Math.round((matchedSkills.length / jobRequirements.length) * 100)
    : 50;
  
  return {
    readinessScore,
    matchedSkills,
    missingSkills,
    recommendation: readinessScore >= 70 
      ? 'You are well-matched for this position!'
      : readinessScore >= 50 
        ? 'You have good foundational skills, but may need to develop some areas.'
        : 'Consider focusing on the missing skills before applying.'
  };
}

// Calculate job skill match percentage
function calculateJobSkillMatch(userSkills, jobRequirements) {
  if (jobRequirements.length === 0) return 50;
  
  const userSkillNames = userSkills.map(s => s.name.toLowerCase());
  const matchedCount = jobRequirements.filter(req => 
    userSkillNames.includes(req.toLowerCase())
  ).length;
  
  return Math.round((matchedCount / jobRequirements.length) * 100);
}

// Calculate job experience match
function calculateJobExperienceMatch(profile, job) {
  const userExperience = profile.workExperience?.length || 0;
  
  // Extract experience requirements from job title/description
  const jobLevel = job.title.toLowerCase();
  const experienceMap = {
    'junior': 1,
    'entry': 1,
    'mid': 3,
    'senior': 5,
    'lead': 7,
    'principal': 10
  };
  
  const requiredLevel = Object.keys(experienceMap).find(level => 
    jobLevel.includes(level)
  );
  
  if (!requiredLevel) return 70; // Default for unclear requirements
  
  const requiredExperience = experienceMap[requiredLevel];
  const matchPercentage = Math.min((userExperience / requiredExperience) * 100, 100);
  
  return Math.round(matchPercentage);
}

// Calculate location match
function calculateLocationMatch(preferredLocation, jobLocation) {
  if (!preferredLocation) return 50;
  
  const preferred = preferredLocation.toLowerCase();
  const actual = jobLocation.toLowerCase();
  
  if (preferred === 'remote' && actual.includes('remote')) return 100;
  if (preferred === 'remote' && !actual.includes('remote')) return 30;
  if (preferred !== 'remote' && actual.includes('remote')) return 70;
  if (actual.includes(preferred) || preferred.includes(actual)) return 100;
  
  return 40; // Different locations
}

// Fixed getJobMarketTrends method in careerController.js
exports.getJobMarketTrends = async (req, res) => {
  debugLog('Job market trends endpoint called');
  
  try {
    const { location, industry, jobTitle } = req.query;
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Initialize trends data
    let trends = {
      demandTrends: [],
      salaryTrends: [],
      topSkills: [],
      topIndustries: [],
      locationInsights: [],
      recentTrends: [],
      summary: 'Market trends analysis'
    };
    
    try {
      // Safely call AdzunaService.getMarketTrends
      if (AdzunaService && typeof AdzunaService.getMarketTrends === 'function') {
        debugLog('Calling AdzunaService.getMarketTrends...');
        const adzunaTrends = await AdzunaService.getMarketTrends(location, industry);
        
        if (adzunaTrends && adzunaTrends.month) {
          trends.demandTrends = this.processDemandTrends(adzunaTrends);
          debugLog('✅ Successfully processed Adzuna trends');
        }
      } else {
        debugLog('⚠️ AdzunaService.getMarketTrends not available, using fallback');
        trends.demandTrends = this.getFallbackDemandTrends();
      }
    } catch (adzunaError) {
      debugLog('❌ Adzuna trends error:', adzunaError.message);
      trends.demandTrends = this.getFallbackDemandTrends();
    }
    
    // Get AI analysis of market trends if available
    try {
      if (OPENROUTER_API_KEY) {
        debugLog('Getting AI market trends analysis...');
        const aiAnalysis = await AICareerAnalyst.analyzeJobMarketTrends(
          location, 
          industry, 
          profile?.skills?.map(s => s.name) || []
        );
        
        if (aiAnalysis) {
          trends.topSkills = aiAnalysis.topSkills || this.getFallbackTopSkills();
          trends.salaryTrends = aiAnalysis.salaryTrends || this.getFallbackSalaryTrends();
          trends.recentTrends = aiAnalysis.recentTrends || this.getFallbackRecentTrends();
          trends.topIndustries = aiAnalysis.topIndustries || this.getFallbackTopIndustries();
          trends.locationInsights = aiAnalysis.locationInsights || this.getFallbackLocationInsights();
          debugLog('✅ Successfully got AI analysis');
        }
      } else {
        debugLog('⚠️ No OpenRouter API key, using fallback data');
        this.addFallbackData(trends);
      }
    } catch (aiError) {
      debugLog('❌ AI analysis error:', aiError.message);
      this.addFallbackData(trends);
    }
    
    debugLog('Returning market trends data');
    res.json(trends);
    
  } catch (err) {
    debugLog('Market trends error:', err.message);
    console.error('Full error:', err);
    
    // Return fallback data even on error
    res.status(200).json({
      ...this.getFallbackMarketTrends(),
      meta: {
        error: true,
        message: 'Using sample data due to technical issues',
        fallback: true
      }
    });
  }
};

// Helper methods for fallback data
exports.getFallbackDemandTrends = function() {
  const currentDate = new Date();
  const trends = [];
  
  for (let i = 5; i >= 0; i--) {
    const date = new Date(currentDate);
    date.setMonth(date.getMonth() - i);
    
    trends.push({
      period: date.toISOString().substring(0, 7), // YYYY-MM format
      jobCount: 10000 + Math.floor(Math.random() * 5000),
      change: Math.floor(Math.random() * 20) - 10 // -10 to +10
    });
  }
  
  return trends;
};

exports.getFallbackTopSkills = function() {
  return [
    { name: 'JavaScript', demand: 'Very High', percentageOfJobs: 45, growthRate: '+15%' },
    { name: 'Python', demand: 'Very High', percentageOfJobs: 42, growthRate: '+20%' },
    { name: 'React', demand: 'High', percentageOfJobs: 38, growthRate: '+18%' },
    { name: 'Node.js', demand: 'High', percentageOfJobs: 35, growthRate: '+12%' },
    { name: 'SQL', demand: 'High', percentageOfJobs: 40, growthRate: '+8%' },
    { name: 'AWS', demand: 'High', percentageOfJobs: 30, growthRate: '+25%' },
    { name: 'Docker', demand: 'Medium', percentageOfJobs: 25, growthRate: '+22%' },
    { name: 'Machine Learning', demand: 'Medium', percentageOfJobs: 20, growthRate: '+35%' }
  ];
};

exports.getFallbackSalaryTrends = function() {
  return [
    { role: 'Software Engineer', avgSalary: 95000, growth: '+5%' },
    { role: 'Data Scientist', avgSalary: 115000, growth: '+8%' },
    { role: 'DevOps Engineer', avgSalary: 105000, growth: '+10%' },
    { role: 'Product Manager', avgSalary: 120000, growth: '+6%' },
    { role: 'Front-end Developer', avgSalary: 85000, growth: '+4%' }
  ];
};

exports.getFallbackRecentTrends = function() {
  return [
    {
      trend: 'Remote Work Adoption',
      impact: 'Remote positions increased by 40% compared to last year',
      percentageChange: '+40'
    },
    {
      trend: 'AI/ML Skills in Demand',
      impact: 'Machine learning roles show unprecedented growth',
      percentageChange: '+35'
    },
    {
      trend: 'Cloud Computing Focus',
      impact: 'Cloud-related positions continue strong growth',
      percentageChange: '+25'
    },
    {
      trend: 'Cybersecurity Priority',
      impact: 'Security roles see increased demand amid growing threats',
      percentageChange: '+30'
    }
  ];
};

exports.getFallbackTopIndustries = function() {
  return [
    { name: 'Technology', jobCount: 25000, growthRate: 22 },
    { name: 'Healthcare', jobCount: 18000, growthRate: 15 },
    { name: 'Finance', jobCount: 15000, growthRate: 12 },
    { name: 'E-commerce', jobCount: 12000, growthRate: 18 },
    { name: 'Education', jobCount: 10000, growthRate: 8 }
  ];
};

exports.getFallbackLocationInsights = function() {
  return [
    { location: 'San Francisco, CA', avgSalary: 135000, jobCount: 5000 },
    { location: 'New York, NY', avgSalary: 125000, jobCount: 4500 },
    { location: 'Seattle, WA', avgSalary: 120000, jobCount: 3500 },
    { location: 'Remote', avgSalary: 95000, jobCount: 8000 },
    { location: 'Austin, TX', avgSalary: 100000, jobCount: 2500 }
  ];
};

exports.addFallbackData = function(trends) {
  trends.topSkills = this.getFallbackTopSkills();
  trends.salaryTrends = this.getFallbackSalaryTrends();
  trends.recentTrends = this.getFallbackRecentTrends();
  trends.topIndustries = this.getFallbackTopIndustries();
  trends.locationInsights = this.getFallbackLocationInsights();
};

exports.getFallbackMarketTrends = function() {
  return {
    demandTrends: this.getFallbackDemandTrends(),
    salaryTrends: this.getFallbackSalaryTrends(),
    topSkills: this.getFallbackTopSkills(),
    topIndustries: this.getFallbackTopIndustries(),
    locationInsights: this.getFallbackLocationInsights(),
    recentTrends: this.getFallbackRecentTrends(),
    summary: 'Market analysis shows strong growth in technology sectors with increasing demand for AI/ML and cloud computing skills.'
  };
};

// Helper method to process Adzuna trends data
exports.processDemandTrends = function(trendsData) {
  if (!trendsData || !trendsData.month) return this.getFallbackDemandTrends();
  
  const months = Object.keys(trendsData.month).sort();
  
  return months.map((month, index) => {
    const data = trendsData.month[month];
    const prevMonth = index > 0 ? trendsData.month[months[index - 1]] : null;
    
    let change = 0;
    if (prevMonth && prevMonth.count && data.count) {
      change = Math.round(((data.count - prevMonth.count) / prevMonth.count) * 100);
    }
    
    return {
      period: this.formatMonth(month),
      jobCount: data.count || 0,
      change: change
    };
  });
};

// Helper method to format month strings
exports.formatMonth = function(month) {
  // Convert YYYY-MM to readable format
  try {
    const date = new Date(month + '-01');
    return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  } catch (error) {
    return month;
  }
};

/**
 * ENHANCED ROUTE HANDLERS
 */

// DEBUG ENDPOINTS - ADD THESE TO YOUR ROUTES
exports.debugAI = async (req, res) => {
  debugLog('Debug AI endpoint called');
  
  try {
    // Test AI connection
    const testResult = {
      openrouterKeyExists: !!OPENROUTER_API_KEY,
      keyLength: OPENROUTER_API_KEY ? OPENROUTER_API_KEY.length : 0,
      baseUrl: OPENROUTER_BASE_URL,
      timestamp: new Date()
    };
    
    // Try a simple AI call
    if (OPENROUTER_API_KEY) {
      try {
        const response = await openrouter.chat.completions.create({
          model: "deepseek/deepseek-chat",
          messages: [
            { role: "user", content: "Just respond with 'AI Working' in JSON format: {\"status\": \"AI Working\"}" }
          ],
          max_tokens: 50
        });
        
        testResult.aiResponse = response.choices[0].message.content;
        testResult.aiWorking = true;
      } catch (aiError) {
        testResult.aiError = aiError.message;
        testResult.aiWorking = false;
      }
    }
    
    res.json({
      debug: testResult,
      message: 'AI Debug information'
    });
  } catch (error) {
    debugLog('Debug AI error:', error.message);
    res.status(500).json({ error: error.message });
  }
};

exports.debugJobAPIs = async (req, res) => {
  debugLog('Debug Job APIs endpoint called');
  
  try {
    const results = {
      adzuna: {
        configured: !!(ADZUNA_APP_ID && ADZUNA_APP_KEY),
        appId: ADZUNA_APP_ID ? ADZUNA_APP_ID.substring(0, 4) + '...' : 'Not set',
        test: null
      },
      muse: {
        configured: !!MUSE_API_KEY,
        keyLength: MUSE_API_KEY ? MUSE_API_KEY.length : 0,
        test: null
      },
      remoteok: {
        configured: true,
        test: null
      }
    };
    
    // Test each API
    try {
      const adzunaJobs = await AdzunaService.getJobs('software', 'remote', 1);
      results.adzuna.test = { success: true, jobCount: adzunaJobs.length };
    } catch (e) {
      results.adzuna.test = { success: false, error: e.message };
    }
    
    try {
      const museJobs = await MuseService.getJobs('software', null, 1);
      results.muse.test = { success: true, jobCount: museJobs.length };
    } catch (e) {
      results.muse.test = { success: false, error: e.message };
    }
    
    try {
      const remoteJobs = await RemoteOKService.getJobs('software', 10);
      results.remoteok.test = { success: true, jobCount: remoteJobs.length };
    } catch (e) {
      results.remoteok.test = { success: false, error: e.message };
    }
    
    res.json({
      apis: results,
      message: 'Job API Debug information'
    });
  } catch (error) {
    debugLog('Debug Job APIs error:', error.message);
    res.status(500).json({ error: error.message });
  }
};

// LinkedIn Auth Routes
exports.connectLinkedIn = async (req, res) => {
  try {
    const authUrl = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${LINKEDIN_CLIENT_ID}&redirect_uri=${encodeURIComponent(process.env.LINKEDIN_REDIRECT_URI)}&scope=r_liteprofile%20r_emailaddress`;
    
    res.json({ authUrl });
  } catch (err) {
    console.error('LinkedIn connect error:', err);
    res.status(500).json({ message: 'Error creating LinkedIn connection URL' });
  }
};

exports.linkedInCallback = async (req, res) => {
  try {
    const { code } = req.query;
    
    if (!code) {
      return res.status(400).json({ message: 'Authorization code required' });
    }
    
    // Get access token
    const accessToken = await LinkedInIntegration.getAccessToken(code, process.env.LINKEDIN_REDIRECT_URI);
    
    // Get user profile and email
    const { profile, email } = await LinkedInIntegration.getUserProfile(accessToken);
    
    // Save to user's profile
    const userProfile = await Profile.findOne({ user: req.user.id });
    if (!userProfile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    userProfile.linkedInProfile = {
      accessToken,
      profile,
      email,
      connectedAt: new Date()
    };
    
    await userProfile.save();
    
    res.json({ 
      message: 'LinkedIn connected successfully',
      profile: {
        name: `${profile.firstName.localized.en_US} ${profile.lastName.localized.en_US}`,
        headline: profile.headline?.localized?.en_US,
        location: profile.location?.name,
        email
      }
    });
  } catch (err) {
    console.error('LinkedIn callback error:', err);
    res.status(500).json({ message: 'Error processing LinkedIn callback' });
  }
};

exports.importLinkedInSkills = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile?.linkedInProfile?.accessToken) {
      return res.status(400).json({ message: 'LinkedIn not connected' });
    }
    
    const skills = await LinkedInIntegration.getUserSkills(profile.linkedInProfile.accessToken);
    
    // Add imported skills to user profile
    const importedSkills = skills.map(skill => ({
      name: skill.name,
      level: 'Intermediate',
      source: 'LinkedIn',
      verifiedBy: profile.linkedInProfile.profile.id
    }));
    
    // Merge with existing skills, avoiding duplicates
    const existingSkillNames = profile.skills.map(s => s.name.toLowerCase());
    const newSkills = importedSkills.filter(skill => 
      !existingSkillNames.includes(skill.name.toLowerCase())
    );
    
    profile.skills.push(...newSkills);
    await profile.save();
    
    res.json({ 
      message: `Imported ${newSkills.length} new skills from LinkedIn`,
      skills: newSkills
    });
  } catch (err) {
    console.error('Import LinkedIn skills error:', err);
    res.status(500).json({ message: 'Error importing LinkedIn skills', error: err.message });
  }
};

// Enhanced Skill Gap Analysis
exports.getSkillGapAnalysis = async (req, res) => {
  debugLog('Skill gap analysis endpoint called');
  
  try {
    const { targetRole } = req.body;
    
    if (!targetRole) {
      return res.status(400).json({ message: 'Target role is required' });
    }
    
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    debugLog('Found profile with skills:', profile.skills?.length || 0);
    
    // Extract user skills
    const userSkills = profile.skills?.map(s => s.name) || [];
    
    // Generate AI analysis of skill gap
    const skillGapAnalysis = await generateSkillGapAnalysis(targetRole, userSkills, profile);
    
    // Enhanced response with detailed analysis
    const enhancedAnalysis = {
      ...skillGapAnalysis,
      
      // Add skill alignment percentages
      skillAlignment: {
        technicalSkills: calculateSkillAlignment(skillGapAnalysis.matchedSkills, skillGapAnalysis.missingSkills, 'technical'),
        experienceLevel: calculateExperienceAlignment(profile, targetRole),
        certificationRequirements: calculateCertificationAlignment(profile, targetRole),
        softSkills: calculateSoftSkillAlignment(profile, targetRole)
      },
      
      // Add recommendations with priorities
      focusAreas: generateFocusAreas(skillGapAnalysis, targetRole),
      
      // Add learning path suggestions
      learningPath: generateLearningPath(skillGapAnalysis, targetRole),
      
      // Add timeline estimations
      timeline: generateTimelineEstimate(skillGapAnalysis, targetRole)
    };
    
    debugLog('Returning enhanced analysis with readiness score:', enhancedAnalysis.readinessScore);
    
    res.json(enhancedAnalysis);
  } catch (err) {
    debugLog('Skill gap analysis error:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ message: 'Error analyzing skill gap', error: err.message });
  }
};

// Enhanced Career Suggestions with gap analysis
exports.getCareerPathSuggestions = async (req, res) => {
  debugLog('Career path suggestions endpoint called');
  
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    debugLog('Found profile for career suggestions');
    
    // Generate personalized career suggestions using AI
    const suggestions = await AICareerAnalyst.generateCareerSuggestions(profile);
    
    debugLog('Generated career suggestions:', suggestions.length);
    
    // Enrich suggestions with enhanced gap analysis
    const enrichedSuggestions = await Promise.all(
      suggestions.map(async (suggestion) => {
        try {
          // Get detailed skill gap analysis for each suggestion
          const skillGapAnalysis = await generateSkillGapAnalysis(
            suggestion.title,
            profile.skills?.map(s => s.name) || [],
            profile
          );
          
          // Add enhanced market data
          const marketData = await getMarketDataForRole(suggestion.title);
          
          return {
            ...suggestion,
            skillGap: skillGapAnalysis,
            marketData,
            alignment: {
              technicalSkills: calculateSkillAlignment(
                skillGapAnalysis.matchedSkills, 
                skillGapAnalysis.missingSkills, 
                'technical'
              ),
              experienceLevel: calculateExperienceAlignment(profile, suggestion.title),
              certificationRequirements: calculateCertificationAlignment(profile, suggestion.title),
              softSkills: calculateSoftSkillAlignment(profile, suggestion.title)
            }
          };
        } catch (error) {
          debugLog(`Error enriching suggestion for ${suggestion.title}:`, error.message);
          return suggestion;
        }
      })
    );
    
    res.json({
      suggestions: enrichedSuggestions,
      metadata: {
        generatedAt: new Date(),
        personalizationFactors: ['skills', 'interests', 'careerGoals', 'education'],
        confidence: 0.85
      }
    });
  } catch (err) {
    debugLog('Career suggestions error:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ message: 'Error generating career suggestions', error: err.message });
  }
};

// Enhanced Job Recommendations with gap analysis
exports.getJobRecommendations = async (req, res) => {
  debugLog('Job recommendations endpoint called');
  
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Extract search parameters
    const { source, location, page = 1, limit = 20 } = req.query;
    const careerGoals = profile.careerGoals || {};
    const skills = profile.skills?.map(skill => skill.name) || [];
    
    debugLog('Job search params:', { source, location, page, limit });
    
    // Build search query from career goals and skills
    let query = '';
    if (careerGoals.shortTermGoal) {
      query = careerGoals.shortTermGoal;
    } else if (skills.length > 0) {
      query = skills[0]; // Use primary skill
    } else {
      query = profile.major || 'software developer';
    }
    
    const searchLocation = location || careerGoals.locationPreference || 'remote';
    
    let allJobs = [];
    const promises = [];
    
    // Fetch from all sources unless specific source requested
    if (!source || source === 'adzuna') {
      promises.push(
        AdzunaService.getJobs(query, searchLocation, page)
          .then(jobs => ({ source: 'adzuna', jobs }))
          .catch(error => {
            debugLog('Adzuna error in main function:', error.message);
            return { source: 'adzuna', jobs: [] };
          })
      );
    }
    
    if (!source || source === 'muse') {
      // Map category for The Muse
      const category = careerGoals.targetIndustry === 'technology' ? 'Engineering' : null;
      promises.push(
        MuseService.getJobs(query, category, page)
          .then(jobs => ({ source: 'muse', jobs }))
          .catch(error => {
            debugLog('Muse error in main function:', error.message);
            return { source: 'muse', jobs: [] };
          })
      );
    }
    
    if (!source || source === 'remoteok') {
      promises.push(
        RemoteOKService.getJobs(query, 20)
          .then(jobs => ({ source: 'remoteok', jobs }))
          .catch(error => {
            debugLog('RemoteOK error in main function:', error.message);
            return { source: 'remoteok', jobs: [] };
          })
      );
    }
    
    // Execute all API calls concurrently
    const results = await Promise.allSettled(promises);
    
    // Process results
    const stats = {
      totalFetched: 0,
      sources: {}
    };
    
    results.forEach(result => {
      if (result.status === 'fulfilled' && result.value) {
        const { source: sourceName, jobs } = result.value;
        allJobs.push(...jobs);
        stats.sources[sourceName] = jobs.length;
        stats.totalFetched += jobs.length;
      }
    });
    
    debugLog('Fetched jobs from sources:', stats);
    
    // Remove duplicates if needed
    const uniqueJobs = allJobs.length > 0 ? this.removeDuplicateJobs(allJobs) : [];
    
    // Score jobs based on user profile
    const scoredJobs = uniqueJobs.length > 0 ? this.scoreJobs(uniqueJobs, profile) : [];
    
    // Paginate results
    const startIndex = (page - 1) * limit;
    const paginatedJobs = scoredJobs.slice(startIndex, startIndex + limit);
    
    debugLog('Returning paginated jobs:', {
      total: scoredJobs.length,
      paginated: paginatedJobs.length
    });
    
    // If no jobs found, provide helpful response
    if (paginatedJobs.length === 0) {
      return res.json({
        jobs: [],
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: 0,
          pages: 0
        },
        stats,
        message: 'No jobs found. This might be due to API issues or your search criteria. Try adjusting your search terms or check back later.',
        suggestions: [
          'Try a broader search term',
          'Check if the job APIs are working by looking at the debug endpoints',
          'Make sure your profile is complete with relevant skills'
        ]
      });
    }
    
    res.json({
      jobs: paginatedJobs,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total: scoredJobs.length,
        pages: Math.ceil(scoredJobs.length / limit)
      },
      stats,
      searchParams: {
        query,
        location: searchLocation,
        source
      }
    });
  } catch (err) {
    debugLog('Job recommendations error:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ 
      message: 'Error fetching job recommendations',
      error: err.message,
      suggestions: [
        'Please try again in a few moments',
        'Check if the APIs are configured correctly',
        'Contact support if the issue persists'
      ]
    });
  }
};

// Market Trends Analysis
exports.getJobMarketTrends = async (req, res) => {
  debugLog('Job market trends endpoint called');
  
  try {
    const { location, industry, jobTitle } = req.query;
    const profile = await Profile.findOne({ user: req.user.id });
    
    // Get trends from Adzuna
    const adzunaTrends = await AdzunaService.getMarketTrends(location, industry);
    
    // Get AI analysis of market trends
    const aiAnalysis = await AICareerAnalyst.analyzeJobMarketTrends(
      location, 
      industry, 
      profile?.skills?.map(s => s.name)
    );
    
    const trends = {
      demandTrends: this.processDemandTrends(adzunaTrends || {}),
      salaryTrends: this.processSalaryTrends(adzunaTrends || {}),
      topSkills: aiAnalysis.topSkills || [],
      topIndustries: aiAnalysis.topIndustries || [],
      locationInsights: aiAnalysis.locationInsights || [],
      recentTrends: aiAnalysis.recentTrends || [],
      summary: aiAnalysis.summary || 'Market analysis unavailable'
    };
    
    debugLog('Returning market trends data');
    
    res.json(trends);
  } catch (err) {
    debugLog('Market trends error:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ message: 'Error fetching market trends', error: err.message });
  }
};

// Resume Analysis with AI
exports.analyzeResume = async (req, res) => {
  debugLog('Resume analysis endpoint called');
  
  try {
    upload.single('resume')(req, res, async (err) => {
      if (err) {
        return res.status(400).json({ message: err.message });
      }
      
      if (!req.file) {
        return res.status(400).json({ message: 'No resume file uploaded' });
      }
      
      const { targetRole } = req.body;
      
      debugLog('Processing resume file:', {
        filename: req.file.originalname,
        size: req.file.size,
        mimetype: req.file.mimetype
      });
      
      // Extract text from resume
      let resumeText = '';
      if (req.file.mimetype.includes('pdf')) {
        const pdfData = await pdfParse(req.file.buffer);
        resumeText = pdfData.text;
      } else if (req.file.mimetype.includes('doc')) {
        const docData = await mammoth.extractRawText({ buffer: req.file.buffer });
        resumeText = docData.value;
      } else {
        resumeText = req.file.buffer.toString('utf-8');
      }
      
      debugLog('Extracted resume text length:', resumeText.length);
      
      // Analyze with AI
      const analysis = await AICareerAnalyst.analyzeResume(resumeText, targetRole);
      
      // Save resume to database
      const resume = new Resume({
        user: req.user.id,
        filename: req.file.originalname,
        content: resumeText,
        targetRole,
        analysis,
        analyzedAt: new Date()
      });
      await resume.save();
      
      debugLog('Resume analysis completed and saved');
      
      res.json({
        analysis,
        resumeId: resume._id,
        message: 'Resume analyzed successfully'
      });
    });
  } catch (err) {
    debugLog('Resume analysis error:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ message: 'Error analyzing resume', error: err.message });
  }
};

/**
 * HELPER METHODS
 */
exports.removeDuplicateJobs = function(jobs) {
  const seen = new Set();
  return jobs.filter(job => {
    const identifier = `${job.title}-${job.company}`.toLowerCase();
    if (seen.has(identifier)) {
      return false;
    }
    seen.add(identifier);
    return true;
  });
};

// Enhanced job scoring with gap analysis
exports.scoreJobsWithGapAnalysis = function(jobs, profile) {
  const skills = profile.skills.map(s => s.name.toLowerCase());
  const careerGoals = profile.careerGoals || {};
  
  return jobs.map(job => {
    let score = 0;
    
    // Base score from skill matching (40% weight)
    if (job.skillGap) {
      score += (job.skillGap.readinessScore * 0.4);
    }
    
    // Experience matching (20% weight)
    if (job.matchDetails?.experienceMatch) {
      score += (job.matchDetails.experienceMatch * 0.2);
    }
    
    // Location matching (15% weight)
    if (job.matchDetails?.locationMatch) {
      score += (job.matchDetails.locationMatch * 0.15);
    }
    
    // Career goal alignment (15% weight)
    if (careerGoals.shortTermGoal && 
        job.title.toLowerCase().includes(careerGoals.shortTermGoal.toLowerCase())) {
      score += 15;
    }
    
    // Recency bonus (10% weight)
    const postedDate = new Date(job.postedAt);
    const daysSincePosted = (new Date() - postedDate) / (1000 * 60 * 60 * 24);
    if (daysSincePosted < 7) score += 10;
    else if (daysSincePosted < 30) score += 5;
    
    return { 
      ...job, 
      relevanceScore: Math.min(Math.round(score), 100),
      gapAnalysis: job.skillGap
    };
  }).sort((a, b) => b.relevanceScore - a.relevanceScore);
};

/**
 * Test connection endpoint
 * @route   GET api/career/test
 * @desc    Test if career routes are working
 * @access  Private
 */
exports.testConnection = async (req, res) => {
  debugLog('Test connection endpoint called');
  
  try {
    res.json({ 
      message: 'Career routes are working',
      userId: req.user?.id,
      timestamp: new Date().toISOString(),
      status: 'success'
    });
  } catch (error) {
    debugLog('Test connection error:', error.message);
    res.status(500).json({ 
      message: 'Error in test connection',
      error: error.message 
    });
  }
};

/**
 * Debug career endpoint
 * @route   GET api/career/debug
 * @desc    Debug career functionality
 * @access  Private
 */
exports.debugCareer = async (req, res) => {
  debugLog('Debug career endpoint called');
  
  try {
    // Get user profile
    const Profile = require('../models/Profile');
    const profile = await Profile.findOne({ user: req.user.id });
    
    const debugInfo = {
      timestamp: new Date().toISOString(),
      user: {
        id: req.user.id,
        authenticated: !!req.user
      },
      profile: {
        exists: !!profile,
        skillsCount: profile?.skills?.length || 0,
        hasCareerGoals: !!profile?.careerGoals,
        savedJobsCount: profile?.savedJobs?.length || 0,
        applicationCount: profile?.jobApplications?.length || 0
      },
      environment: {
        openrouterKey: !!OPENROUTER_API_KEY,
        adzunaConfigured: !!(ADZUNA_APP_ID && ADZUNA_APP_KEY),
        museConfigured: !!MUSE_API_KEY,
        linkedinConfigured: !!(LINKEDIN_CLIENT_ID && LINKEDIN_CLIENT_SECRET)
      }
    };
    
    res.json(debugInfo);
  } catch (error) {
    debugLog('Debug career error:', error.message);
    res.status(500).json({ 
      message: 'Error in debug career',
      error: error.message 
    });
  }
};

/**
 * Disconnect LinkedIn integration
 * @route   DELETE api/career/linkedin/disconnect
 * @desc    Disconnect LinkedIn integration
 * @access  Private
 */
exports.disconnectLinkedIn = async (req, res) => {
  debugLog('Disconnect LinkedIn endpoint called');
  
  try {
    const Profile = require('../models/Profile');
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile || !profile.linkedInProfile) {
      return res.status(400).json({ message: 'LinkedIn not connected' });
    }
    
    // Remove LinkedIn profile data
    profile.linkedInProfile = undefined;
    await profile.save();
    
    res.json({ 
      message: 'LinkedIn disconnected successfully',
      timestamp: new Date()
    });
  } catch (error) {
    debugLog('LinkedIn disconnect error:', error.message);
    console.error('Full error:', error);
    res.status(500).json({ 
      message: 'Error disconnecting LinkedIn',
      error: error.message 
    });
  }
};

exports.scoreJobs = function(jobs, profile) {
  const skills = profile.skills.map(s => s.name.toLowerCase());
  const careerGoals = profile.careerGoals || {};
  
  return jobs.map(job => {
    let score = 0;
    
    // Skill matching
    skills.forEach(skill => {
      if (job.title.toLowerCase().includes(skill) || 
          job.description.toLowerCase().includes(skill)) {
        score += 10;
      }
    });
    
    // Career goal alignment
    if (careerGoals.shortTermGoal && 
        job.title.toLowerCase().includes(careerGoals.shortTermGoal.toLowerCase())) {
      score += 20;
    }
    
    // Location preference
    if (careerGoals.locationPreference === 'remote' && 
        job.location.toLowerCase().includes('remote')) {
      score += 15;
    }
    
    // Recency bonus
    const postedDate = new Date(job.postedAt);
    const daysSincePosted = (new Date() - postedDate) / (1000 * 60 * 60 * 24);
    if (daysSincePosted < 7) score += 5;
    
    return { ...job, relevanceScore: Math.min(score, 100) };
  }).sort((a, b) => b.relevanceScore - a.relevanceScore);
};

exports.processDemandTrends = function(trendsData) {
  if (!trendsData || !trendsData.month) return [];
  
  const months = Object.keys(trendsData.month).sort();
  
  return months.map(month => {
    const data = trendsData.month[month];
    return {
      period: this.formatMonth(month),
      jobCount: data.count || 0,
      change: this.calculateMonthlyChange(trendsData.month, months, month)
    };
  });
};

exports.processSalaryTrends = function(trendsData) {
  if (!trendsData || !trendsData.month) return [];
  
  // Create mock salary trends based on available data
  const trends = [
    { role: 'Software Engineer', avgSalary: 85000 },
    { role: 'Data Scientist', avgSalary: 95000 },
    { role: 'DevOps Engineer', avgSalary: 90000 },
    { role: 'Product Manager', avgSalary: 100000 }
  ];
  
  return trends;
};

// Add this debug function to help investigate the empty skills issue
exports.debugProfile = async (req, res) => {
  try {
    console.log('🔍 DEBUG: Checking user profile for skills...');
    console.log('User ID:', req.user.id);
    
    // Get the profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    const debugInfo = {
      userExists: !!req.user,
      userID: req.user.id,
      profileExists: !!profile,
      profileData: profile ? {
        id: profile._id,
        user: profile.user,
        skills: profile.skills,
        skillsCount: profile.skills?.length || 0,
        skillsType: Array.isArray(profile.skills) ? 'array' : typeof profile.skills,
        careerGoals: profile.careerGoals,
        major: profile.major,
        academicLevel: profile.academicLevel
      } : null
    };
    
    console.log('Debug info:', JSON.stringify(debugInfo, null, 2));
    
    res.json(debugInfo);
  } catch (error) {
    console.error('Profile debug error:', error);
    res.status(500).json({ error: error.message });
  }
};

exports.initializeUserSkills = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Initialize skills array if it doesn't exist
    if (!profile.skills || !Array.isArray(profile.skills)) {
      profile.skills = [];
      await profile.save();
      console.log('✅ Initialized empty skills array for user:', req.user.id);
    }
    
    // Add some default skills if completely empty
    if (profile.skills.length === 0 && profile.major) {
      const defaultSkills = this.getDefaultSkillsForMajor(profile.major);
      profile.skills = defaultSkills;
      await profile.save();
      console.log('✅ Added default skills for major:', profile.major);
    }
    
    res.json({
      message: 'Skills initialized',
      skillsCount: profile.skills.length,
      skills: profile.skills
    });
  } catch (error) {
    console.error('Initialize skills error:', error);
    res.status(500).json({ error: error.message });
  }
};

// Helper function to get default skills based on major
exports.getDefaultSkillsForMajor = function(major) {
  const skillsMap = {
    'computer science': [
      { name: 'Programming', level: 'Intermediate', category: 'Technical' },
      { name: 'Problem Solving', level: 'Intermediate', category: 'Soft Skills' },
      { name: 'Mathematics', level: 'Intermediate', category: 'Technical' }
    ],
    'data science': [
      { name: 'Python', level: 'Intermediate', category: 'Programming' },
      { name: 'Statistics', level: 'Intermediate', category: 'Technical' },
      { name: 'Data Analysis', level: 'Intermediate', category: 'Technical' }
    ],
    'engineering': [
      { name: 'Mathematics', level: 'Advanced', category: 'Technical' },
      { name: 'Problem Solving', level: 'Advanced', category: 'Soft Skills' },
      { name: 'Technical Writing', level: 'Intermediate', category: 'Communication' }
    ]
  };
  
  const majorLower = major.toLowerCase();
  
  // Find matching skills or return general skills
  for (const [key, skills] of Object.entries(skillsMap)) {
    if (majorLower.includes(key)) {
      return skills;
    }
  }
  
  // Default skills if no match
  return [
    { name: 'Communication', level: 'Intermediate', category: 'Soft Skills' },
    { name: 'Problem Solving', level: 'Intermediate', category: 'Soft Skills' },
    { name: 'Time Management', level: 'Intermediate', category: 'Soft Skills' }
  ];
};

exports.calculateMonthlyChange = function(monthData, months, currentMonth) {
  const currentIndex = months.indexOf(currentMonth);
  if (currentIndex <= 0) return 0;
  
  const current = monthData[currentMonth]?.count || 0;
  const previous = monthData[months[currentIndex - 1]]?.count || 0;
  
  if (previous === 0) return 0;
  return Math.round((current - previous) / previous * 100);
};

exports.formatMonth = function(month) {
  // Convert YYYY-MM to readable format
  const date = new Date(month + '-01');
  return date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
};

module.exports = exports;