// controllers/savedJobsController.js - Complete fixed version
const Profile = require('../models/Profile');
const SavedJob = require('../models/SavedJob');
const { validationResult } = require('express-validator');

// Debug logging function
function debugLog(message, data = null) {
  console.log(`[SAVED JOBS DEBUG] ${message}`, data ? JSON.stringify(data, null, 2) : '');
}

/**
 * Get user's saved jobs from both Profile and SavedJob collections
 * @route   GET api/career/saved-jobs
 * @desc    Get user's saved jobs
 * @access  Private
 */
exports.getSavedJobs = async (req, res) => {
  try {
    debugLog('Getting saved jobs for user:', req.user.id);
    
    // First, try to get saved jobs from Profile model (legacy method)
    const profile = await Profile.findOne({ user: req.user.id });
    let profileSavedJobs = [];
    
    if (profile && profile.savedJobs) {
      profileSavedJobs = profile.savedJobs;
      debugLog('Found saved jobs in profile:', profileSavedJobs.length);
    }
    
    // Also get saved jobs from the dedicated SavedJob collection
    const savedJobs = await SavedJob.find({ user: req.user.id })
      .sort({ savedAt: -1 })
      .lean();
    
    debugLog('Found saved jobs in SavedJob collection:', savedJobs.length);
    
    // Combine and deduplicate
    const allSavedJobs = [...savedJobs];
    
    // Add profile saved jobs that aren't already in SavedJob collection
    profileSavedJobs.forEach(profileJob => {
      const existsInSavedJobs = savedJobs.some(saved => saved.jobId === profileJob.id);
      if (!existsInSavedJobs) {
        allSavedJobs.push({
          _id: null,
          jobId: profileJob.id,
          title: profileJob.title || 'Unknown Title',
          company: profileJob.company || 'Unknown Company',
          location: profileJob.location || 'Unknown Location',
          savedAt: profileJob.savedAt || new Date(),
          source: 'Profile' // Indicate this came from profile
        });
      }
    });
    
    // Sort by savedAt descending
    allSavedJobs.sort((a, b) => new Date(b.savedAt) - new Date(a.savedAt));
    
    debugLog('Total saved jobs returned:', allSavedJobs.length);
    res.json(allSavedJobs);
  } catch (err) {
    debugLog('Error getting saved jobs:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ 
      message: 'Server error getting saved jobs',
      error: err.message 
    });
  }
};

/**
 * Save a job to both Profile and SavedJob collections
 * @route   POST api/career/save-job
 * @desc    Save a job to user's profile
 * @access  Private
 */
exports.saveJob = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  
  try {
    const { jobId, title, company, location, url, source, salary, description } = req.body;
    
    debugLog('Saving job:', { jobId, title, company, location });
    
    // Check if job is already saved
    const existingSavedJob = await SavedJob.findOne({
      user: req.user.id,
      jobId: jobId
    });
    
    if (existingSavedJob) {
      return res.status(400).json({ message: 'Job already saved' });
    }
    
    // Create new saved job document
    const savedJob = new SavedJob({
      user: req.user.id,
      jobId,
      title: title || 'Unknown Title',
      company: company || 'Unknown Company',
      location: location || 'Unknown Location',
      url: url || '',
      source: source || 'Unknown',
      salary,
      description,
      savedAt: new Date()
    });
    
    await savedJob.save();
    debugLog('Saved job to SavedJob collection');
    
    // Also add to profile for backward compatibility
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (profile) {
      // Initialize savedJobs array if it doesn't exist
      if (!profile.savedJobs) {
        profile.savedJobs = [];
      }
      
      // Check if already exists in profile
      const existsInProfile = profile.savedJobs.some(job => job.id === jobId);
      
      if (!existsInProfile) {
        profile.savedJobs.push({
          id: jobId,
          title,
          company,
          location,
          savedAt: new Date()
        });
        
        await profile.save();
        debugLog('Also saved to profile for backward compatibility');
      }
    }
    
    // Return the saved job
    res.json({ 
      message: 'Job saved successfully',
      job: savedJob,
      profileUpdated: !!profile
    });
  } catch (err) {
    debugLog('Error saving job:', err.message);
    console.error('Full error:', err);
    
    // Handle duplicate key error
    if (err.code === 11000) {
      return res.status(400).json({ message: 'Job already saved' });
    }
    
    res.status(500).json({ 
      message: 'Server error saving job',
      error: err.message 
    });
  }
};

/**
 * Remove a saved job from both collections
 * @route   DELETE api/career/saved-jobs/:jobId
 * @desc    Remove a saved job from user's profile
 * @access  Private
 */
exports.removeSavedJob = async (req, res) => {
  try {
    const { jobId } = req.params;
    
    debugLog('Removing saved job:', jobId);
    
    // Remove from SavedJob collection
    const deletedJob = await SavedJob.findOneAndDelete({
      user: req.user.id,
      jobId: jobId
    });
    
    if (deletedJob) {
      debugLog('Removed from SavedJob collection');
    }
    
    // Also remove from profile for backward compatibility
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (profile && profile.savedJobs) {
      const originalLength = profile.savedJobs.length;
      profile.savedJobs = profile.savedJobs.filter(job => job.id !== jobId);
      
      if (profile.savedJobs.length !== originalLength) {
        await profile.save();
        debugLog('Also removed from profile');
      }
    }
    
    if (!deletedJob && (!profile || !profile.savedJobs || profile.savedJobs.every(job => job.id !== jobId))) {
      return res.status(404).json({ message: 'Saved job not found' });
    }
    
    res.json({ 
      message: 'Job removed from saved jobs',
      removedFromSavedJobs: !!deletedJob,
      removedFromProfile: !!(profile && profile.savedJobs)
    });
  } catch (err) {
    debugLog('Error removing saved job:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ 
      message: 'Server error removing saved job',
      error: err.message 
    });
  }
};

/**
 * Get all job applications with status
 * @route   GET api/career/job-applications
 * @desc    Get all job applications
 * @access  Private
 */
exports.getJobApplications = async (req, res) => {
  try {
    debugLog('Getting job applications for user:', req.user.id);
    
    // Get applications from SavedJob collection
    const applications = await SavedJob.find({ 
      user: req.user.id,
      applicationStatus: { $ne: 'saved' } // Only get jobs that have been applied to
    })
    .sort({ savedAt: -1 })
    .lean();
    
    debugLog('Found job applications:', applications.length);
    
    // Also check profile for legacy applications
    const profile = await Profile.findOne({ user: req.user.id });
    let profileApplications = [];
    
    if (profile && profile.jobApplications) {
      profileApplications = profile.jobApplications;
      debugLog('Found applications in profile:', profileApplications.length);
    }
    
    // Combine and format
    const allApplications = [
      ...applications.map(app => ({
        id: app._id,
        jobId: app.jobId,
        title: app.title,
        company: app.company,
        location: app.location,
        status: app.applicationStatus,
        appliedAt: app.savedAt,
        updatedAt: app.updatedAt || app.savedAt,
        source: app.source
      })),
      ...profileApplications.map(app => ({
        id: app._id,
        jobId: app.jobId,
        title: app.title || 'Unknown Title',
        company: app.company || 'Unknown Company',
        location: app.location || 'Unknown Location',
        status: app.status,
        appliedAt: app.appliedAt,
        updatedAt: app.updatedAt,
        source: 'Profile'
      }))
    ];
    
    // Remove duplicates based on jobId
    const uniqueApplications = allApplications.filter((app, index, self) =>
      index === self.findIndex(a => a.jobId === app.jobId)
    );
    
    // Sort by updated date
    uniqueApplications.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    
    res.json(uniqueApplications);
  } catch (err) {
    debugLog('Error getting job applications:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ 
      message: 'Server error getting job applications',
      error: err.message 
    });
  }
};

/**
 * Update a job application status
 * @route   PUT api/career/job-applications/:jobId
 * @desc    Update a job application status
 * @access  Private
 */
exports.updateJobApplication = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  
  try {
    const { jobId } = req.params;
    const { status, notes } = req.body;
    
    debugLog('Updating job application:', { jobId, status });
    
    // Try to update in SavedJob collection first
    let updatedJob = await SavedJob.findOneAndUpdate(
      { user: req.user.id, jobId: jobId },
      { 
        applicationStatus: status || 'applied',
        notes: notes,
        updatedAt: new Date()
      },
      { new: true }
    );
    
    // If not found in SavedJob collection, check Profile
    if (!updatedJob) {
      const profile = await Profile.findOne({ user: req.user.id });
      
      if (profile) {
        // Initialize jobApplications array if it doesn't exist
        if (!profile.jobApplications) {
          profile.jobApplications = [];
        }
        
        // Find the job application
        const applicationIndex = profile.jobApplications.findIndex(app => app.jobId === jobId);
        
        if (applicationIndex === -1) {
          // Create new application if it doesn't exist
          profile.jobApplications.push({
            jobId,
            status: status || 'applied',
            appliedAt: new Date(),
            updatedAt: new Date()
          });
        } else {
          // Update existing application
          if (status) {
            profile.jobApplications[applicationIndex].status = status;
          }
          profile.jobApplications[applicationIndex].updatedAt = new Date();
        }
        
        await profile.save();
        debugLog('Updated job application in profile');
        
        // Return the updated application
        return res.json({ 
          message: 'Job application updated successfully',
          application: profile.jobApplications[applicationIndex === -1 ? profile.jobApplications.length - 1 : applicationIndex],
          source: 'Profile'
        });
      }
    }
    
    if (updatedJob) {
      res.json({ 
        message: 'Job application updated successfully',
        application: {
          id: updatedJob._id,
          jobId: updatedJob.jobId,
          status: updatedJob.applicationStatus,
          updatedAt: updatedJob.updatedAt
        },
        source: 'SavedJob'
      });
    } else {
      res.status(404).json({ message: 'Job application not found' });
    }
  } catch (err) {
    debugLog('Error updating job application:', err.message);
    console.error('Full error:', err);
    res.status(500).json({ 
      message: 'Server error updating job application',
      error: err.message 
    });
  }
};

module.exports = exports;