// controllers/profileController.js
const Profile = require('../models/Profile');
const User = require('../models/User');
const { validationResult } = require('express-validator');
const fs = require('fs');
const path = require('path');

// Get current user's profile
exports.getProfile = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Get user info for combined response
    const user = await User.findById(req.user.id).select('-password -resetPasswordToken -resetPasswordExpire');
    
    // Combine user and profile data
    const profileData = {
      ...profile.toObject(),
      fullName: user.fullName,
      email: user.email,
      profilePictureUrl: user.profilePictureUrl
    };
    
    res.json(profileData);
  } catch (err) {
    console.error('Get profile error:', err);
    res.status(500).json({ message: 'Server error getting profile' });
  }
};

// Update profile
exports.updateProfile = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const {
    fullName,
    phone,
    university,
    major,
    graduationYear,
    academicLevel,
    bio
  } = req.body;

  // Build profile object
  const profileFields = {};
  if (phone) profileFields.phone = phone;
  if (university) profileFields.university = university;
  if (major) profileFields.major = major;
  if (graduationYear) profileFields.graduationYear = graduationYear;
  if (academicLevel) profileFields.academicLevel = academicLevel;
  if (bio) profileFields.bio = bio;
  profileFields.updatedAt = Date.now();

  try {
    let profile = await Profile.findOne({ user: req.user.id });

    if (profile) {
      // Update profile
      profile = await Profile.findOneAndUpdate(
        { user: req.user.id },
        { $set: profileFields },
        { new: true }
      );
    } else {
      // Create profile
      profile = new Profile({
        user: req.user.id,
        ...profileFields
      });
      await profile.save();
    }
    
    // Update user's name if provided
    if (fullName) {
      let user = await User.findById(req.user.id);
      user.fullName = fullName;
      await user.save();
    }

    res.json(profile);
  } catch (err) {
    console.error('Update profile error:', err);
    res.status(500).json({ message: 'Server error updating profile' });
  }
};

// Upload profile picture
exports.uploadProfilePicture = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }
    
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Set profile picture URL
    const profilePictureUrl = `/uploads/${req.file.filename}`;
    user.profilePictureUrl = profilePictureUrl;
    
    await user.save();
    
    res.json({ 
      message: 'Profile picture uploaded successfully',
      profilePictureUrl 
    });
  } catch (err) {
    console.error('Profile picture upload error:', err);
    res.status(500).json({ message: 'Server error during upload' });
  }
};

// Get learning preferences
exports.getLearningPreferences = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.json(profile.learningPreferences);
  } catch (err) {
    console.error('Get learning preferences error:', err);
    res.status(500).json({ message: 'Server error getting learning preferences' });
  }
};

// Update learning preferences
exports.updateLearningPreferences = async (req, res) => {
  try {
    let profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    profile.learningPreferences = {
      ...profile.learningPreferences,
      ...req.body
    };
    profile.updatedAt = Date.now();
    
    await profile.save();

    res.json(profile.learningPreferences);
  } catch (err) {
    console.error('Update learning preferences error:', err);
    res.status(500).json({ message: 'Server error updating learning preferences' });
  }
};

// Get career goals
exports.getCareerGoals = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.json(profile.careerGoals);
  } catch (err) {
    console.error('Get career goals error:', err);
    res.status(500).json({ message: 'Server error getting career goals' });
  }
};

// Update career goals
exports.updateCareerGoals = async (req, res) => {
  try {
    let profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    profile.careerGoals = {
      ...profile.careerGoals,
      ...req.body
    };
    profile.updatedAt = Date.now();
    
    await profile.save();

    res.json(profile.careerGoals);
  } catch (err) {
    console.error('Update career goals error:', err);
    res.status(500).json({ message: 'Server error updating career goals' });
  }
};

// Get all skills
exports.getSkills = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.json(profile.skills);
  } catch (err) {
    console.error('Get skills error:', err);
    res.status(500).json({ message: 'Server error getting skills' });
  }
};

// Add or update skill
exports.addOrUpdateSkill = async (req, res) => {
  const { name, level } = req.body;

  if (!name || !level) {
    return res.status(400).json({ message: 'Skill name and level are required' });
  }

  try {
    let profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    // Check if skill already exists
    const skillIndex = profile.skills.findIndex(
      skill => skill.name.toLowerCase() === name.toLowerCase()
    );

    if (skillIndex !== -1) {
      // Update existing skill
      profile.skills[skillIndex].level = level;
      profile.skills[skillIndex].addedAt = Date.now();
    } else {
      // Add new skill
      profile.skills.push({
        name,
        level,
        addedAt: Date.now()
      });
    }

    profile.updatedAt = Date.now();
    await profile.save();

    res.json(profile.skills);
  } catch (err) {
    console.error('Add/update skill error:', err);
    res.status(500).json({ message: 'Server error updating skills' });
  }
};

// Remove skill
exports.removeSkill = async (req, res) => {
  const skillId = req.params.skillId;

  try {
    const profile = await Profile.findOne({ user: req.user.id });

    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    // Remove skill
    profile.skills = profile.skills.filter(
      skill => skill._id.toString() !== skillId
    );

    profile.updatedAt = Date.now();
    await profile.save();

    res.json(profile.skills);
  } catch (err) {
    console.error('Remove skill error:', err);
    res.status(500).json({ message: 'Server error removing skill' });
  }
};