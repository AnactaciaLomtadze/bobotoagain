// controllers/chatController.js
const ChatSession = require('../models/ChatSession');
const ChatMessage = require('../models/ChatMessage');
const { validationResult } = require('express-validator');

// Get all chat sessions
exports.getSessions = async (req, res) => {
  try {
    const sessions = await ChatSession.find({ user: req.user.id })
      .sort({ lastUpdated: -1 });
    
    // Add message count to each session
    const sessionsWithCount = await Promise.all(
      sessions.map(async session => {
        const count = await ChatMessage.countDocuments({ session: session._id });
        return {
          ...session.toObject(),
          messageCount: count
        };
      })
    );
    
    res.json(sessionsWithCount);
  } catch (err) {
    console.error('Get sessions error:', err);
    res.status(500).json({ message: 'Server error getting chat sessions' });
  }
};

// Create new chat session
exports.createSession = async (req, res) => {
  const { title } = req.body;
  
  try {
    const newSession = new ChatSession({
      user: req.user.id,
      title: title || 'New Conversation'
    });
    
    await newSession.save();
    
    res.json({
      message: 'Chat session created',
      sessionId: newSession._id,
      session: newSession
    });
  } catch (err) {
    console.error('Create session error:', err);
    res.status(500).json({ message: 'Server error creating chat session' });
  }
};

// Get messages for a session
exports.getMessages = async (req, res) => {
  try {
    const session = await ChatSession.findOne({
      _id: req.params.sessionId,
      user: req.user.id
    });
    
    if (!session) {
      return res.status(404).json({ message: 'Chat session not found' });
    }
    
    const messages = await ChatMessage.find({ session: session._id })
      .sort({ timestamp: 1 });
    
    res.json(messages);
  } catch (err) {
    console.error('Get messages error:', err);
    res.status(500).json({ message: 'Server error getting chat messages' });
  }
};

// Add message to session
exports.addMessage = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  
  const { text, isUser } = req.body;
  
  try {
    // Check if session exists and belongs to user
    const session = await ChatSession.findOne({
      _id: req.params.sessionId,
      user: req.user.id
    });
    
    if (!session) {
      return res.status(404).json({ message: 'Chat session not found' });
    }
    
    // Create new message
    const newMessage = new ChatMessage({
      session: session._id,
      text,
      isUser: isUser !== undefined ? isUser : true
    });
    
    await newMessage.save();
    
    // Update session lastUpdated
    session.lastUpdated = Date.now();
    await session.save();
    
    res.json(newMessage);
  } catch (err) {
    console.error('Add message error:', err);
    res.status(500).json({ message: 'Server error adding chat message' });
  }
};

// Delete chat session
exports.deleteSession = async (req, res) => {
  try {
    // Find session
    const session = await ChatSession.findOne({
      _id: req.params.sessionId,
      user: req.user.id
    });
    
    if (!session) {
      return res.status(404).json({ message: 'Chat session not found' });
    }
    
    // Delete all messages in session
    await ChatMessage.deleteMany({ session: session._id });
    
    // Delete session
    await session.remove();
    
    res.json({ message: 'Chat session deleted' });
  } catch (err) {
    console.error('Delete session error:', err);
    res.status(500).json({ message: 'Server error deleting chat session' });
  }
};

// Save session as favorite
exports.saveSessionAsFavorite = async (req, res) => {
  try {
    const session = await ChatSession.findOne({
      _id: req.params.sessionId,
      user: req.user.id
    });
    
    if (!session) {
      return res.status(404).json({ message: 'Chat session not found' });
    }
    
    session.isSaved = true;
    await session.save();
    
    res.json({ message: 'Chat session saved as favorite' });
  } catch (err) {
    console.error('Save session error:', err);
    res.status(500).json({ message: 'Server error saving chat session' });
  }
};

// Remove session from favorites
exports.removeSessionFromFavorites = async (req, res) => {
  try {
    const session = await ChatSession.findOne({
      _id: req.params.sessionId,
      user: req.user.id
    });
    
    if (!session) {
      return res.status(404).json({ message: 'Chat session not found' });
    }
    
    session.isSaved = false;
    await session.save();
    
    res.json({ message: 'Chat session removed from favorites' });
  } catch (err) {
    console.error('Unsave session error:', err);
    res.status(500).json({ message: 'Server error removing chat session from favorites' });
  }
};

// Search chat sessions
exports.searchSessions = async (req, res) => {
  const searchTerm = req.query.searchTerm;
  
  if (!searchTerm) {
    return res.status(400).json({ message: 'Search term is required' });
  }
  
  try {
    // First find sessions with matching titles
    const sessionResults = await ChatSession.find({
      user: req.user.id,
      title: { $regex: searchTerm, $options: 'i' }
    });
    
    // Then find messages with matching text
    const messageResults = await ChatMessage.find({
      text: { $regex: searchTerm, $options: 'i' }
    }).distinct('session');
    
    // Get sessions for matching messages that belong to user
    const messageSessionResults = await ChatSession.find({
      _id: { $in: messageResults },
      user: req.user.id
    });
    
    // Combine results, removing duplicates
    const sessionIds = new Set();
    const combinedResults = [];
    
    [...sessionResults, ...messageSessionResults].forEach(session => {
      if (!sessionIds.has(session._id.toString())) {
        sessionIds.add(session._id.toString());
        combinedResults.push(session);
      }
    });
    
    res.json(combinedResults);
  } catch (err) {
    console.error('Search sessions error:', err);
    res.status(500).json({ message: 'Server error searching chat sessions' });
  }
};