// controllers/deepseekController.js - Fixed version without browser-specific code
const axios = require('axios');
const Profile = require('../models/Profile');
const User = require('../models/User');
require('dotenv').config();

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const DEEPSEEK_MODEL = 'deepseek/deepseek-r1:free';

console.log('OpenRouter API Key configured:', OPENROUTER_API_KEY ? 'Yes' : 'No');

const generateResponse = async (req, res) => {
  const { message, sessionId, chatHistory } = req.body;
  
  if (!message) {
    return res.status(400).json({ message: 'Message is required' });
  }
  
  try {
    console.log('Generating DeepSeek AI response for message:', message);
    
    if (!OPENROUTER_API_KEY) {
      console.error('OpenRouter API key not configured');
      return res.status(500).json({
        message: 'AI service not properly configured. Please contact administrator.',
        error: 'Missing API key'
      });
    }
    
    // Get user context
    let profile = null;
    let user = null;
    
    try {
      profile = await Profile.findOne({ user: req.user.id });
      user = await User.findById(req.user.id).select('-password');
    } catch (dbError) {
      console.warn('Could not fetch user profile:', dbError.message);
    }
    
    // Prepare system message with user context
    let systemMessage = `You are Boboto, an academic and career AI assistant for students.
    
    Key capabilities:
    1. Personalized academic support based on learning style and knowledge level
    2. Clear explanation of complex concepts with examples
    3. Tailored study recommendations and learning paths
    4. Career guidance based on current market trends
    5. Memory of past interactions to provide continuity
    
    Be concise but thorough. Use examples relevant to the student's field and interests.
    Maintain a professional but supportive tone. Offer specific resources when helpful.
    Today's date: ${new Date().toDateString()}`;
    
    if (profile && user) {
      systemMessage = `You are Boboto, an academic and career AI assistant for students.
    
      Key capabilities:
      1. Personalized academic support based on learning style and knowledge level
      2. Clear explanation of complex concepts with examples matched to the student's field
      3. Tailored study recommendations and learning paths
      4. Career guidance based on current market trends
      5. Memory of past interactions to provide continuity
      
      User profile information:
      Name: ${user.fullName || 'Student'}
      Education: ${profile.major || 'Computer Science'} ${profile.academicLevel || 'Student'}
      Learning Style: ${profile.learningPreferences?.learningStyle || 'Visual'}
      Technical Level: ${profile.learningPreferences?.technicalLevel || 'Intermediate'}
      Career Goals: 
        - Short-term: ${profile.careerGoals?.shortTermGoal || 'Not specified'}
        - Long-term: ${profile.careerGoals?.longTermGoal || 'Not specified'}
      Skills: ${profile.skills?.map(s => `${s.name} (${s.level})`).join(', ') || 'Not specified'}
      
      Today's date: ${new Date().toDateString()}
      
      Be concise but thorough. Use examples relevant to the student's field and interests.
      Maintain a professional but supportive tone. Offer specific resources when helpful.`;
    }
    
    // Format messages for OpenRouter API
    let messages = [
      { role: 'system', content: systemMessage }
    ];
    
    // Add chat history if provided
    if (chatHistory && Array.isArray(chatHistory)) {
      console.log('Processing chat history:', chatHistory.length, 'messages');
      const formattedHistory = chatHistory.slice(-10).map(msg => ({
        role: msg.isUser ? 'user' : 'assistant',
        content: msg.text
      }));
      
      messages = [...messages, ...formattedHistory];
    }
    
    // Add the current message
    messages.push({ role: 'user', content: message });
    
    // Get user's AI settings or use defaults
    const aiSettings = profile?.aiSettings || {};
    
    // Prepare request body
    const requestBody = {
      model: aiSettings.model || DEEPSEEK_MODEL,
      messages: messages,
      temperature: aiSettings.temperature || parseFloat(process.env.AI_TEMPERATURE || "0.7"),
      max_tokens: aiSettings.maxTokens || parseInt(process.env.AI_MAX_TOKENS || "1000"),
    };
    
    console.log('Making API request to OpenRouter...');
    console.log('Request body:', JSON.stringify(requestBody, null, 2));
    
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': process.env.SITE_URL || 'http://localhost:3000',
      'X-Title': process.env.SITE_NAME || 'Boboto - Academic AI Assistant'
    };
    
    const response = await axios.post(OPENROUTER_API_URL, requestBody, { 
      headers,
      timeout: 30000 // 30 second timeout
    });
    
    console.log('DeepSeek API response received successfully');
    console.log('Response status:', response.status);
    console.log('Response data:', JSON.stringify(response.data, null, 2));
    
    // Extract the response content
    const aiResponse = response.data.choices?.[0]?.message?.content;
    
    if (!aiResponse) {
      console.error('No response content from DeepSeek API');
      console.error('Full response:', JSON.stringify(response.data, null, 2));
      throw new Error('No response content from AI service');
    }
    
    console.log('Sending successful response:', aiResponse);
    
    // Send the response in the expected format
    res.json({ response: aiResponse });
    
  } catch (err) {
    console.error('DeepSeek error details:');
    console.error('Error message:', err.message);
    console.error('Error name:', err.name);
    console.error('Error stack:', err.stack);

    if (err.response) {
      console.error('Response status:', err.response.status);
      console.error('Response data:', JSON.stringify(err.response.data, null, 2));
      console.error('Response headers:', err.response.headers);
    }

    // More detailed error information
    let errorMessage = 'I apologize, but I\'m having trouble connecting to the AI service right now. ';
    let statusCode = 500;
    
    if (err.code === 'ENOTFOUND' || err.code === 'ECONNREFUSED') {
      errorMessage += 'Please check your internet connection and try again.';
    } else if (err.response?.status === 401) {
      errorMessage += 'Authentication issue with AI service. Please contact support.';
      statusCode = 401;
    } else if (err.response?.status === 429) {
      errorMessage += 'Too many requests. Please wait a moment and try again.';
      statusCode = 429;
    } else if (err.response?.status >= 500) {
      errorMessage += 'The AI service is temporarily unavailable. Please try again in a few moments.';
    } else if (err.code === 'ECONNABORTED') {
      errorMessage += 'Request timed out. Please try again.';
    } else {
      errorMessage += 'Please try again in a moment.';
    }
    
    const errorInfo = {
      message: errorMessage,
      error: err.message,
      type: err.name || 'Unknown',
      code: err.code || 'Unknown',
      timestamp: new Date().toISOString()
    };
    
    console.error('Sending error response:', errorInfo);
    res.status(statusCode).json(errorInfo);
  }
};

// Get user's AI settings
const getSettings = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Get settings or default values
    const aiSettings = profile.aiSettings || {};
    
    res.json({
      model: aiSettings.model || DEEPSEEK_MODEL,
      temperature: aiSettings.temperature || parseFloat(process.env.AI_TEMPERATURE || '0.7'),
      maxTokens: aiSettings.maxTokens || parseInt(process.env.AI_MAX_TOKENS || '1000')
    });
  } catch (err) {
    console.error('Get AI settings error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update user's AI settings
const updateSettings = async (req, res) => {
  const { model, temperature, maxTokens } = req.body;
  
  try {
    // Validate input
    if (temperature !== undefined && (temperature < 0 || temperature > 1)) {
      return res.status(400).json({ message: 'Temperature must be between 0 and 1' });
    }
    
    if (maxTokens !== undefined && (maxTokens < 100 || maxTokens > 4000)) {
      return res.status(400).json({ message: 'maxTokens must be between 100 and 4000' });
    }
    
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Initialize aiSettings if it doesn't exist
    if (!profile.aiSettings) {
      profile.aiSettings = {};
    }
    
    // Update settings
    if (model) profile.aiSettings.model = model;
    if (temperature !== undefined) profile.aiSettings.temperature = temperature;
    if (maxTokens !== undefined) profile.aiSettings.maxTokens = maxTokens;
    
    await profile.save();
    
    res.json(profile.aiSettings);
  } catch (err) {
    console.error('Update AI settings error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Export the functions properly (removed the debug code that was causing the error)
module.exports = {
  generateResponse,
  getSettings,
  updateSettings
};