#!/bin/bash

# Adzuna API Credential Verification Script

export ADZUNA_APP_ID="41f9e6f1"
export ADZUNA_APP_KEY="8d7e07f62f74ca87667ff948f6e5c59d"


echo "🔍 Verifying Adzuna API Credentials..."
echo "=================================="

# Check if environment variables are set
if [ -z "$ADZUNA_APP_ID" ]; then
    echo "❌ ADZUNA_APP_ID is not set in environment"
    exit 1
fi

if [ -z "$ADZUNA_APP_KEY" ]; then
    echo "❌ ADZUNA_APP_KEY is not set in environment"
    exit 1
fi

echo "✅ Environment variables are set"
echo "APP_ID: ${ADZUNA_APP_ID:0:4}..."
echo "APP_KEY: ${ADZUNA_APP_KEY:0:4}..."

# Test the credentials
echo ""
echo "🔬 Testing credentials with Adzuna API..."

# First test - Get categories (simple endpoint)
echo "Test 1: Fetching job categories..."
response=$(curl -s -w "%{http_code}" -o /tmp/adzuna_test.json \
  "https://api.adzuna.com/v1/api/jobs/us/categories?app_id=${ADZUNA_APP_ID}&app_key=${ADZUNA_APP_KEY}")

if [ "$response" = "200" ]; then
    echo "✅ Categories test passed"
else
    echo "❌ Categories test failed with HTTP $response"
    if [ -f /tmp/adzuna_test.json ]; then
        echo "Response:"
        cat /tmp/adzuna_test.json
    fi
fi

# Second test - Search for jobs
echo ""
echo "Test 2: Searching for jobs..."
response=$(curl -s -w "%{http_code}" -o /tmp/adzuna_search.json \
  "https://api.adzuna.com/v1/api/jobs/us/search/1?app_id=${ADZUNA_APP_ID}&app_key=${ADZUNA_APP_KEY}&results_per_page=1&what=software")

if [ "$response" = "200" ]; then
    echo "✅ Job search test passed"
    
    # Check if we got results
    results=$(grep -o '"count":[0-9]*' /tmp/adzuna_search.json | head -1 | cut -d':' -f2)
    if [ ! -z "$results" ]; then
        echo "📊 Found $results jobs"
    fi
else
    echo "❌ Job search test failed with HTTP $response"
    if [ -f /tmp/adzuna_search.json ]; then
        echo "Response:"
        cat /tmp/adzuna_search.json
    fi
fi

# Clean up
rm -f /tmp/adzuna_test.json /tmp/adzuna_search.json

echo ""
echo "=================================="
echo "✅ Credential verification complete"
echo ""
echo "If tests failed, please check:"
echo "1. Your ADZUNA_APP_ID and ADZUNA_APP_KEY are correct"
echo "2. You haven't exceeded your API limits"
echo "3. Your account is still active"
echo "4. Try regenerating your credentials from the Adzuna dashboard"