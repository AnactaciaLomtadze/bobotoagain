// test-ai-responses.js - Script to test AI response parsing
require('dotenv').config();

const { OpenAI } = require('openai');

const openrouter = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY,
  baseURL: 'https://openrouter.ai/api/v1'
});

// Function to clean AI responses
function cleanAIResponse(response) {
  if (!response) return null;
  
  let cleaned = response.trim();
  
  // Remove markdown code blocks
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '');
  }
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '');
  }
  if (cleaned.endsWith('```')) {
    cleaned = cleaned.replace(/\s*```$/, '');
  }
  
  cleaned = cleaned.replace(/^`+|`+$/g, '');
  
  return cleaned.trim();
}

// Test career suggestions
async function testCareerSuggestions() {
  console.log('🔬 Testing Career Suggestions AI...');
  
  const prompt = `
  Suggest 3 career paths for a Computer Science student.
  
  Return ONLY a JSON array with NO markdown formatting:
  [
    {
      "title": "Job Title",
      "description": "Description",
      "requiredSkills": ["Skill 1", "Skill 2"],
      "growthPotential": "Growth description",
      "averageSalary": "$XX,000 - $XX,000",
      "nextSteps": ["Step 1", "Step 2"],
      "score": 85,
      "growthRate": 25
    }
  ]
  `;
  
  try {
    const response = await openrouter.chat.completions.create({
      model: "deepseek/deepseek-chat",
      messages: [
        { 
          role: "system", 
          content: "Return ONLY valid JSON. NO markdown, NO explanations."
        },
        { role: "user", content: prompt }
      ],
      max_tokens: 1000,
      temperature: 0.7
    });
    
    const aiResponse = response.choices[0].message.content;
    console.log('Raw AI Response:', aiResponse);
    
    const cleaned = cleanAIResponse(aiResponse);
    console.log('Cleaned Response:', cleaned);
    
    const parsed = JSON.parse(cleaned);
    console.log('✅ Successfully parsed:', parsed.length, 'careers');
    console.log('First career:', parsed[0]);
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Test skill gap analysis
async function testSkillGapAnalysis() {
  console.log('\n🔬 Testing Skill Gap Analysis AI...');
  
  const prompt = `
  Analyze skill gap for becoming a Software Engineer.
  Current skills: Python, Mathematics
  
  Return ONLY valid JSON:
  {
    "readinessScore": 75,
    "matchedSkills": ["Python"],
    "missingSkills": ["JavaScript", "SQL"],
    "skillRecommendations": [
      {
        "skill": "JavaScript",
        "priority": "High",
        "difficulty": {
          "description": "Intermediate",
          "estimatedTimeToLearn": "3-6 months"
        },
        "learningResources": [
          {"name": "JS Course", "platform": "Coursera", "url": "#"}
        ]
      }
    ]
  }
  `;
  
  try {
    const response = await openrouter.chat.completions.create({
      model: "deepseek/deepseek-chat",
      messages: [
        { 
          role: "system", 
          content: "Return ONLY valid JSON. NO markdown, NO explanations."
        },
        { role: "user", content: prompt }
      ],
      max_tokens: 1000,
      temperature: 0.3
    });
    
    const aiResponse = response.choices[0].message.content;
    console.log('Raw AI Response:', aiResponse);
    
    const cleaned = cleanAIResponse(aiResponse);
    console.log('Cleaned Response:', cleaned);
    
    const parsed = JSON.parse(cleaned);
    console.log('✅ Successfully parsed skill gap analysis');
    console.log('Readiness Score:', parsed.readinessScore);
    console.log('Missing Skills:', parsed.missingSkills);
    
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Run tests
async function runTests() {
  await testCareerSuggestions();
  await testSkillGapAnalysis();
}

runTests();