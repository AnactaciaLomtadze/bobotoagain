// utils/debugCareerAPI.js
const axios = require('axios');

class CareerAPIDebugger {
  static async checkAPIEndpoints() {
    const results = {
      timestamp: new Date().toISOString(),
      checks: []
    };

    // Test Adzuna API
    try {
      const adzunaTest = await axios.get('https://api.adzuna.com/v1/api/jobs/us/search/1', {
        params: {
          app_id: process.env.ADZUNA_APP_ID,
          app_key: process.env.ADZUNA_API_KEY,
          results_per_page: 1,
          what: 'software engineer'
        },
        timeout: 5000
      });
      
      results.checks.push({
        api: 'Adzuna',
        status: 'success',
        statusCode: adzunaTest.status,
        message: 'API responding correctly'
      });
    } catch (error) {
      results.checks.push({
        api: 'Adzuna',
        status: 'error',
        error: error.message,
        config: error.config?.params || 'No params',
        response: error.response?.data || 'No response data'
      });
    }

    // Test The Muse API (if configured)
    if (process.env.MUSE_API_KEY) {
      try {
        const museTest = await axios.get('https://www.themuse.com/api/public/jobs', {
          params: {
            api_key: process.env.MUSE_API_KEY,
            page: 1
          },
          timeout: 5000
        });
        
        results.checks.push({
          api: 'The Muse',
          status: 'success',
          statusCode: museTest.status,
          message: 'API responding correctly'
        });
      } catch (error) {
        results.checks.push({
          api: 'The Muse',
          status: 'error',
          error: error.message,
          response: error.response?.data || 'No response data'
        });
      }
    } else {
      results.checks.push({
        api: 'The Muse',
        status: 'skipped',
        message: 'No API key configured'
      });
    }

    // Test RemoteOK API
    try {
      const remoteOKTest = await axios.get('https://remoteok.io/api', {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'CareerApp/1.0'
        },
        timeout: 5000
      });
      
      results.checks.push({
        api: 'RemoteOK',
        status: 'success',
        statusCode: remoteOKTest.status,
        message: 'API responding correctly',
        jobCount: Array.isArray(remoteOKTest.data) ? remoteOKTest.data.length - 1 : 0
      });
    } catch (error) {
      results.checks.push({
        api: 'RemoteOK',
        status: 'error',
        error: error.message,
        response: error.response?.data || 'No response data'
      });
    }

    // Test OpenRouter/DeepSeek AI API
    try {
      const aiTest = await axios.post(
        process.env.OPENROUTER_BASE_URL + '/chat/completions',
        {
          model: "deepseek/deepseek-chat",
          messages: [{ role: "user", content: "Hello" }],
          max_tokens: 10
        },
        {
          headers: {
            'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
            'Content-Type': 'application/json'
          },
          timeout: 10000
        }
      );
      
      results.checks.push({
        api: 'OpenRouter/DeepSeek',
        status: 'success',
        statusCode: aiTest.status,
        message: 'AI API responding correctly'
      });
    } catch (error) {
      results.checks.push({
        api: 'OpenRouter/DeepSeek',
        status: 'error',
        error: error.message,
        response: error.response?.data || 'No response data'
      });
    }

    return results;
  }

  static async checkDatabaseConnection() {
    try {
      const mongoose = require('mongoose');
      const connectionState = mongoose.connection.readyState;
      
      const states = {
        0: 'disconnected',
        1: 'connected',
        2: 'connecting',
        3: 'disconnecting'
      };
      
      return {
        status: connectionState === 1 ? 'success' : 'error',
        state: states[connectionState],
        host: mongoose.connection.host,
        name: mongoose.connection.name
      };
    } catch (error) {
      return {
        status: 'error',
        error: error.message
      };
    }
  }

  static async checkEnvironmentVariables() {
    const requiredVars = [
      'ADZUNA_APP_ID',
      'ADZUNA_API_KEY',
      'OPENROUTER_API_KEY',
      'DEEPSEEK_API_KEY',
      'JWT_SECRET',
      'MONGODB_URI'
    ];

    const results = {};
    
    requiredVars.forEach(varName => {
      results[varName] = {
        configured: !!process.env[varName],
        hasValue: process.env[varName] ? 'Yes' : 'No'
      };
    });

    return results;
  }
}

module.exports = CareerAPIDebugger;