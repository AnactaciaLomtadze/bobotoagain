// utils/fallbackJobs.js - Fallback job data when APIs fail

const fallbackJobs = [
    {
      id: 'fallback-1',
      title: 'Software Engineer',
      company: 'TechCorp',
      location: 'Remote',
      description: 'Join our team as a software engineer working on cutting-edge projects. We value innovation and collaboration.',
      salary: '$80,000 - $120,000',
      url: '#',
      source: 'Fallback',
      postedAt: new Date().toISOString(),
      type: 'Full-time',
      tags: ['JavaScript', 'React', 'Node.js']
    },
    {
      id: 'fallback-2',
      title: 'Data Scientist',
      company: 'DataFlow Inc',
      location: 'San Francisco, CA',
      description: 'Analyze large datasets to derive insights and build predictive models that drive business decisions.',
      salary: '$90,000 - $140,000',
      url: '#',
      source: 'Fallback',
      postedAt: new Date().toISOString(),
      type: 'Full-time',
      tags: ['Python', 'Machine Learning', 'SQL']
    },
    {
      id: 'fallback-3',
      title: 'Frontend Developer',
      company: 'WebStudio',
      location: 'New York, NY',
      description: 'Create amazing user experiences with modern frontend technologies. Experience with React preferred.',
      salary: '$70,000 - $110,000',
      url: '#',
      source: 'Fallback',
      postedAt: new Date().toISOString(),
      type: 'Full-time',
      tags: ['React', 'CSS', 'JavaScript']
    },
    {
      id: 'fallback-4',
      title: 'DevOps Engineer',
      company: 'CloudTech',
      location: 'Remote',
      description: 'Build and maintain CI/CD pipelines and cloud infrastructure. Experience with AWS preferred.',
      salary: '$85,000 - $130,000',
      url: '#',
      source: 'Fallback',
      postedAt: new Date().toISOString(),
      type: 'Full-time',
      tags: ['AWS', 'Docker', 'Kubernetes']
    },
    {
      id: 'fallback-5',
      title: 'Product Manager',
      company: 'InnovateNow',
      location: 'Boston, MA',
      description: 'Lead product development from conception to launch. Work closely with engineering and design teams.',
      salary: '$90,000 - $140,000',
      url: '#',
      source: 'Fallback',
      postedAt: new Date().toISOString(),
      type: 'Full-time',
      tags: ['Product Management', 'Agile', 'Analytics']
    }
  ];
  
  // Function to get fallback jobs based on user's profile
  function getFallbackJobs(profile, limit = 20) {
    if (!profile) return fallbackJobs.slice(0, limit);
    
    const userSkills = profile.skills?.map(s => s.name.toLowerCase()) || [];
    const careerGoal = profile.careerGoals?.shortTermGoal?.toLowerCase() || '';
    
    // Score jobs based on user's profile
    const scoredJobs = fallbackJobs.map(job => {
      let score = 0;
      
      // Check if job title matches career goal
      if (careerGoal && job.title.toLowerCase().includes(careerGoal)) {
        score += 50;
      }
      
      // Check skill matches
      job.tags.forEach(tag => {
        if (userSkills.some(skill => skill.includes(tag.toLowerCase()))) {
          score += 20;
        }
      });
      
      return { ...job, relevanceScore: score };
    });
    
    // Sort by relevance and return
    return scoredJobs
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .slice(0, limit);
  }
  
  module.exports = {
    fallbackJobs,
    getFallbackJobs
  };