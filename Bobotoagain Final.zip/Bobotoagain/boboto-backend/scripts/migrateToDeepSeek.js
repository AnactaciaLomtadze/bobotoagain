// scripts/migrateToDeepSeek.js
const mongoose = require('mongoose');
const Profile = require('../models/Profile');
require('dotenv').config();

// Database connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
});

// Model mapping from Claude to DeepSeek
const modelMapping = {
  'claude-3-5-sonnet-20240620': 'deepseek/deepseek-r1:free',
  'claude-3-opus': 'deepseek/deepseek-chat',
  'claude-3-sonnet': 'deepseek/deepseek-chat',
  'claude-3-haiku': 'deepseek/deepseek-r1:free'
};

async function migrateUserSettings() {
  try {
    console.log('Starting migration from Claude to DeepSeek...');
    
    // Find all profiles with AI settings
    const profiles = await Profile.find({ 'aiSettings.model': { $exists: true } });
    
    console.log(`Found ${profiles.length} profiles with AI settings`);
    
    let updatedCount = 0;
    let skippedCount = 0;
    
    for (const profile of profiles) {
      if (profile.aiSettings && profile.aiSettings.model) {
        // Check if the model is a Claude model
        const claudeModel = profile.aiSettings.model;
        const deepseekModel = modelMapping[claudeModel];
        
        if (deepseekModel) {
          // Update to DeepSeek equivalent
          profile.aiSettings.model = deepseekModel;
          profile.aiSettings.preferredAI = 'deepseek';
          
          await profile.save();
          updatedCount++;
          
          console.log(`Updated profile ${profile.user} from ${claudeModel} to ${deepseekModel}`);
        } else {
          // Check if it's already a DeepSeek model or something else
          if (claudeModel.startsWith('deepseek/')) {
            skippedCount++;
            console.log(`Profile ${profile.user} already using DeepSeek model: ${claudeModel}`);
          } else {
            // If it's an unknown model, set to default DeepSeek model
            profile.aiSettings.model = 'deepseek/deepseek-r1:free';
            profile.aiSettings.preferredAI = 'deepseek';
            
            await profile.save();
            updatedCount++;
            
            console.log(`Profile ${profile.user} had unknown model ${claudeModel}, set to deepseek/deepseek-r1:free`);
          }
        }
      }
    }
    
    // Update profiles without AI settings
    console.log('\nChecking profiles without AI settings...');
    const profilesWithoutSettings = await Profile.find({ 
      $or: [
        { aiSettings: { $exists: false } },
        { 'aiSettings.model': { $exists: false } }
      ]
    });
    
    let newSettingsCount = 0;
    
    for (const profile of profilesWithoutSettings) {
      if (!profile.aiSettings) {
        profile.aiSettings = {};
      }
      
      profile.aiSettings.model = 'deepseek/deepseek-r1:free';
      profile.aiSettings.temperature = 0.7;
      profile.aiSettings.maxTokens = 1000;
      profile.aiSettings.preferredAI = 'deepseek';
      
      await profile.save();
      newSettingsCount++;
      
      console.log(`Created new AI settings for profile ${profile.user}`);
    }
    
    console.log('\n=== Migration Summary ===');
    console.log(`Updated from Claude to DeepSeek: ${updatedCount}`);
    console.log(`Already using DeepSeek: ${skippedCount}`);
    console.log(`New AI settings created: ${newSettingsCount}`);
    console.log(`Total processed: ${updatedCount + skippedCount + newSettingsCount}`);
    
    console.log('\nMigration completed successfully!');
    
  } catch (error) {
    console.error('Migration failed:', error);
  } finally {
    // Close database connection
    await mongoose.connection.close();
  }
}

// Create a backup function before migration
async function createBackup() {
  try {
    const dateStr = new Date().toISOString().split('T')[0];
    const backupFile = `backup_profiles_${dateStr}.json`;
    
    console.log('Creating backup before migration...');
    
    const profiles = await Profile.find({});
    const fs = require('fs');
    const path = require('path');
    
    const backupData = profiles.map(profile => ({
      _id: profile._id,
      user: profile.user,
      aiSettings: profile.aiSettings
    }));
    
    const backupPath = path.join(__dirname, '..', 'backups', backupFile);
    
    // Create backups directory if it doesn't exist
    const backupDir = path.dirname(backupPath);
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    fs.writeFileSync(backupPath, JSON.stringify(backupData, null, 2));
    
    console.log(`Backup created: ${backupPath}`);
    return true;
  } catch (error) {
    console.error('Backup failed:', error);
    return false;
  }
}

// Rollback function in case migration needs to be reversed
async function rollbackMigration(backupFile) {
  try {
    console.log('Starting rollback...');
    
    const fs = require('fs');
    const backupData = JSON.parse(fs.readFileSync(backupFile, 'utf8'));
    
    let restoredCount = 0;
    
    for (const backup of backupData) {
      const profile = await Profile.findById(backup._id);
      if (profile) {
        profile.aiSettings = backup.aiSettings;
        await profile.save();
        restoredCount++;
      }
    }
    
    console.log(`Rollback completed. Restored ${restoredCount} profiles.`);
  } catch (error) {
    console.error('Rollback failed:', error);
  } finally {
    await mongoose.connection.close();
  }
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  
  if (args[0] === 'rollback' && args[1]) {
    await rollbackMigration(args[1]);
  } else {
    // Create backup first
    const backupSuccess = await createBackup();
    
    if (backupSuccess) {
      // Proceed with migration
      await migrateUserSettings();
    } else {
      console.log('Migration cancelled due to backup failure');
      process.exit(1);
    }
  }
}

// Run the migration
main();

// Export functions for other scripts
module.exports = {
  migrateUserSettings,
  createBackup,
  rollbackMigration
};