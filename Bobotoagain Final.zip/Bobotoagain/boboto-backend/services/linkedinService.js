// services/linkedInService.js - Fixed ES6 Module
export class LinkedInService {
  /**
   * Initialize LinkedIn OAuth flow
   * @returns {Promise<string>} URL to redirect user for LinkedIn authorization
   */
  static async initiateOAuth() {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch('/api/career/linkedin/connect', {
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.authUrl;
    } catch (error) {
      console.error('Error initiating LinkedIn OAuth:', error);
      throw error;
    }
  }
  
  /**
   * Check if user has connected LinkedIn
   * @returns {Promise<boolean>} True if user has connected LinkedIn
   */
  static async isConnected() {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        return false;
      }
      
      const response = await fetch('/api/profile', {
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        return false;
      }
      
      const profileData = await response.json();
      return !!profileData.linkedInProfile;
    } catch (error) {
      console.error('Error checking LinkedIn connection:', error);
      return false;
    }
  }
  
  /**
   * Get LinkedIn profile information
   * @returns {Promise<Object|null>} LinkedIn profile data or null
   */
  static async getProfileInfo() {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        return null;
      }
      
      const response = await fetch('/api/profile', {
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        return null;
      }
      
      const profileData = await response.json();
      return profileData.linkedInProfile || null;
    } catch (error) {
      console.error('Error getting LinkedIn profile:', error);
      return null;
    }
  }
  
  /**
   * Import skills from LinkedIn profile
   * @returns {Promise<Array>} Imported skills
   */
  static async importSkills() {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch('/api/career/linkedin/import-skills', {
        method: 'POST',
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data.skills || [];
    } catch (error) {
      console.error('Error importing LinkedIn skills:', error);
      throw error;
    }
  }
  
  /**
   * Share job application to LinkedIn
   * @param {Object} job Job information
   * @returns {Promise<Object>} Share result
   */
  static async shareJobApplication(job) {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch('/api/career/linkedin/share', {
        method: 'POST',
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ job })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error sharing to LinkedIn:', error);
      throw error;
    }
  }
  
  /**
   * Disconnect LinkedIn integration
   * @returns {Promise<Object>} Disconnection result
   */
  static async disconnect() {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch('/api/career/linkedin/disconnect', {
        method: 'DELETE',
        headers: {
          'x-auth-token': token
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error disconnecting LinkedIn:', error);
      throw error;
    }
  }
  
  /**
   * Handle LinkedIn OAuth callback
   * @param {string} code OAuth callback code
   * @param {string} state OAuth state parameter
   * @returns {Promise<Object>} OAuth result
   */
  static async handleOAuthCallback(code, state) {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch('/api/career/linkedin/callback', {
        method: 'POST',
        headers: {
          'x-auth-token': token,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ code, state })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error handling LinkedIn OAuth callback:', error);
      throw error;
    }
  }
}

// Export as default for easier importing
export default LinkedInService;