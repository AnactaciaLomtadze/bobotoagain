// middleware/errorHandler.js
const errorHandler = (err, req, res, next) => {
  console.error(err.stack);

  // Handling different types of errors
  if (err.name === 'ValidationError') {
    return res.status(400).json({ 
      message: 'Validation Error', 
      error: err.message,
      details: err.errors || 'Invalid input data'
    });
  }

  if (err.name === 'CastError') {
    return res.status(400).json({ 
      message: 'Invalid ID format' 
    });
  }

  if (err.code === 11000) {
    return res.status(400).json({ 
      message: 'Duplicate field value' 
    });
  }

  if (err.name === 'UnauthorizedError') {
    return res.status(401).json({ 
      message: 'Unauthorized access' 
    });
  }

  // API-specific errors
  if (err.isAxiosError) {
    const status = err.response?.status || 500;
    const message = err.response?.data?.message || 'External API error';
    return res.status(status).json({ 
      message: 'External API Error',
      error: message,
      api: err.config?.baseURL || 'Unknown API'
    });
  }

  // Multer errors (file upload)
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ 
      message: 'File too large',
      error: 'File size exceeds the 10MB limit'
    });
  }

  if (err.code === 'LIMIT_FILE_COUNT') {
    return res.status(400).json({ 
      message: 'Too many files',
      error: 'Only one file is allowed'
    });
  }

  // Default error
  res.status(err.status || 500).json({
    message: 'Internal Server Error',
    error: process.env.NODE_ENV === 'production' ? 'Something went wrong' : err.message
  });
};

module.exports = errorHandler;