// routes/auth.js
const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const authController = require('../controllers/authController');
const auth = require('../middleware/auth');

// @route   POST api/auth/register
// @desc    Register a user
// @access  Public
router.post(
  '/register',
  [
    check('fullName', 'Full name is required').not().isEmpty(),
    check('email', 'Please include a valid email').isEmail(),
    check('password', 'Please enter a password with 6 or more characters').isLength({ min: 6 }),
    check('academicLevel', 'Academic level is required').not().isEmpty(),
    check('graduationYear', 'Graduation year is required').not().isEmpty(),
    check('major', 'Major is required').not().isEmpty(),
    check('university', 'University is required').not().isEmpty()
  ],
  authController.register
);

// @route   POST api/auth/login
// @desc    Authenticate user & get token
// @access  Public
router.post(
  '/login',
  [
    check('email', 'Please include a valid email').isEmail(),
    check('password', 'Password is required').exists()
  ],
  authController.login
);

// @route   POST api/auth/google
// @desc    Login or register with Google
// @access  Public
router.post(
  '/google',
  [
    check('idToken', 'Google ID token is required').not().isEmpty()
  ],
  authController.googleAuth
);

// @route   GET api/auth
// @desc    Get authenticated user
// @access  Private
router.get('/', auth, authController.getCurrentUser);

// @route   POST api/auth/forgot-password
// @desc    Send password reset email
// @access  Public
router.post(
  '/forgot-password',
  [
    check('email', 'Please include a valid email').isEmail()
  ],
  authController.forgotPassword
);

// @route   PUT api/auth/reset-password/:resetToken
// @desc    Reset password with token
// @access  Public
router.put(
  '/reset-password/:resetToken',
  [
    check('password', 'Please enter a password with 6 or more characters').isLength({ min: 6 })
  ],
  authController.resetPassword
);

// @route   PUT api/auth/change-password
// @desc    Change password while logged in
// @access  Private
router.put(
  '/change-password',
  auth,
  [
    check('currentPassword', 'Current password is required').exists(),
    check('newPassword', 'Please enter a new password with 6 or more characters').isLength({ min: 6 })
  ],
  authController.changePassword
);

// @route   GET api/auth/test
// @desc    Test API connection
// @access  Public
router.get('/test', (req, res) => {
  res.json({ 
    message: 'Boboto API is working!',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

module.exports = router;