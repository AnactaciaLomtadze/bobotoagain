// routes/academic.js
const express = require('express');
const router = express.Router();
const academicController = require('../controllers/academicController');
const auth = require('../middleware/auth');

// Subject-specific Q&A
router.post('/question', auth, academicController.handleSubjectQA);

// Concept explanation 
router.post('/explain', auth, academicController.explainConcept);

// Study material recommendations
router.post('/materials', auth, academicController.recommendStudyMaterials);

// Homework and assignment help
router.post('/assignment-help', auth, academicController.assignmentHelp);

// Track study time
router.post('/track-study', auth, academicController.trackStudyTime);

// Add resource to library
router.post('/resources', auth, academicController.addResource);

// Get resources by subject
router.get('/resources', auth, academicController.getResourcesBySubject);

// Generate study plan
router.post('/study-plan', auth, academicController.generateStudyPlan);

module.exports = router;