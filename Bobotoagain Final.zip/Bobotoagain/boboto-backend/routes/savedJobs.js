// routes/savedJobs.js - Fixed version
const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const savedJobsController = require('../controllers/savedJobsController');
const auth = require('../middleware/auth');

// Debug middleware
router.use((req, res, next) => {
  console.log(`[SAVED JOBS ROUTE] ${req.method} ${req.path}`);
  next();
});

// @route   GET /api/career/saved-jobs
// @desc    Get user's saved jobs
// @access  Private
router.get('/', auth, savedJobsController.getSavedJobs);

// @route   POST /api/career/save-job
// @desc    Save a job to user's profile
// @access  Private
router.post(
  '/save-job', 
  auth,
  [
    check('jobId', 'Job ID is required').notEmpty(),
    check('title', 'Job title is required').notEmpty(),
    check('company', 'Company name is required').notEmpty(),
    check('location', 'Location is required').notEmpty(),
    check('url', 'Job URL is required').isURL(),
    check('source', 'Job source is required').notEmpty()
  ],
  savedJobsController.saveJob
);

// @route   DELETE /api/career/saved-jobs/:jobId
// @desc    Remove a saved job from user's profile
// @access  Private
router.delete('/:jobId', auth, savedJobsController.removeSavedJob);

// @route   GET /api/career/job-applications
// @desc    Get all job applications
// @access  Private
router.get('/applications', auth, savedJobsController.getJobApplications);

// @route   PUT /api/career/job-applications/:jobId
// @desc    Update a job application status
// @access  Private
router.put(
  '/applications/:jobId',
  auth,
  [
    check('status', 'Valid status required')
      .optional()
      .isIn(['saved', 'applied', 'interviewing', 'rejected', 'offer', 'hired'])
  ],
  savedJobsController.updateJobApplication
);

module.exports = router;