// routes/ai.js - Proper AI routes without any browser code
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const deepseekController = require('../controllers/deepseekController');

// Add debug logging middleware
router.use((req, res, next) => {
  console.log(`[AI Route] ${req.method} ${req.path}`, req.body);
  next();
});

// @route   POST api/ai/chat
// @desc    Generate AI response using DeepSeek
// @access  Private
router.post('/chat', auth, deepseekController.generateResponse);

// @route   GET api/ai/settings
// @desc    Get AI settings for user
// @access  Private
router.get('/settings', auth, deepseekController.getSettings);

// @route   PUT api/ai/settings
// @desc    Update AI settings for user
// @access  Private
router.put('/settings', auth, deepseekController.updateSettings);

// Add a test endpoint to verify routes are working
router.get('/test', auth, (req, res) => {
  res.json({ 
    message: 'AI routes working',
    user: req.user.id,
    timestamp: new Date()
  });
});

module.exports = router;