// routes/profile.js
const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const profileController = require('../controllers/profileController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');  // Add this import

// @route   GET api/profile
// @desc    Get current user's profile
// @access  Private
router.get('/', auth, profileController.getProfile);

// @route   PUT api/profile
// @desc    Update profile
// @access  Private
router.put('/', auth, profileController.updateProfile);

// @route   POST api/profile/upload-picture
// @desc    Upload profile picture
// @access  Private
router.post('/upload-picture', 
  auth, 
  upload.single('profilePicture'), 
  profileController.uploadProfilePicture
);

// @route   GET api/profile/learning-preferences
// @desc    Get learning preferences
// @access  Private
router.get('/learning-preferences', auth, profileController.getLearningPreferences);

// @route   PUT api/profile/learning-preferences
// @desc    Update learning preferences
// @access  Private
router.put('/learning-preferences', auth, profileController.updateLearningPreferences);

// @route   GET api/profile/career-goals
// @desc    Get career goals
// @access  Private
router.get('/career-goals', auth, profileController.getCareerGoals);

// @route   PUT api/profile/career-goals
// @desc    Update career goals
// @access  Private
router.put('/career-goals', auth, profileController.updateCareerGoals);

// @route   GET api/profile/skills
// @desc    Get all skills
// @access  Private
router.get('/skills', auth, profileController.getSkills);

// @route   POST api/profile/skills
// @desc    Add or update skill
// @access  Private
router.post(
  '/skills',
  [
    auth,
    [
      check('name', 'Skill name is required').not().isEmpty(),
      check('level', 'Skill level is required').isIn([
        'Novice', 'Beginner', 'Intermediate', 'Advanced', 'Expert'
      ])
    ]
  ],
  profileController.addOrUpdateSkill
);

// @route   DELETE api/profile/skills/:skillId
// @desc    Remove skill
// @access  Private
router.delete('/skills/:skillId', auth, profileController.removeSkill);

module.exports = router;