// routes/career.js - Updated to include saved jobs
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const { check } = require('express-validator');

// Enhanced logging middleware
router.use((req, res, next) => {
  console.log(`[CAREER ROUTE] ${req.method} ${req.path}`);
  next();
});

// Check if controllers exist before importing
let careerController, savedJobsController;

try {
  careerController = require('../controllers/careerController');
  console.log('✅ Career controller loaded successfully');
} catch (error) {
  console.error('❌ Error loading career controller:', error);
  careerController = {};
}

try {
  savedJobsController = require('../controllers/savedJobsController');
  console.log('✅ Saved jobs controller loaded successfully');
} catch (error) {
  console.error('❌ Error loading saved jobs controller:', error);
  savedJobsController = {};
}

// Helper function to create safe route handler
const safeHandler = (handler, name) => {
  return (req, res, next) => {
    if (!handler || typeof handler !== 'function') {
      console.error(`❌ Handler ${name} is not defined or not a function`);
      return res.status(500).json({
        error: 'Handler not implemented',
        handler: name,
        message: 'This endpoint is not properly configured'
      });
    }
    
    try {
      const result = handler(req, res, next);
      // Handle async functions
      if (result && typeof result.catch === 'function') {
        result.catch(error => {
          console.error(`❌ Async error in ${name}:`, error);
          if (!res.headersSent) {
            res.status(500).json({
              error: 'Internal server error',
              handler: name,
              message: error.message
            });
          }
        });
      }
    } catch (error) {
      console.error(`❌ Sync error in ${name}:`, error);
      if (!res.headersSent) {
        res.status(500).json({
          error: 'Internal server error',
          handler: name,
          message: error.message
        });
      }
    }
  };
};

async function testAdzunaAPI() {
  try {
    if (!process.env.ADZUNA_APP_ID || !process.env.ADZUNA_APP_KEY) {
      return { success: false, error: 'API credentials not configured' };
    }
    
    const response = await axios.get('https://api.adzuna.com/v1/api/jobs/us/search/1', {
      params: {
        app_id: process.env.ADZUNA_APP_ID,
        app_key: process.env.ADZUNA_APP_KEY,
        results_per_page: 1,
        what: 'software'
      },
      timeout: 5000
    });
    
    return { 
      success: true, 
      status: response.status,
      resultsCount: response.data.results?.length || 0
    };
  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      status: error.response?.status,
      data: error.response?.data?.substring(0, 200)
    };
  }
}


// Test RemoteOK API
async function testRemoteOKAPI() {
  try {
    const response = await axios.get('https://remoteok.io/api', {
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'Boboto/1.0'
      },
      timeout: 5000
    });
    
    const jobs = Array.isArray(response.data) ? response.data.slice(1) : [];
    
    return { 
      success: true, 
      status: response.status,
      resultsCount: jobs.length
    };
  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      status: error.response?.status
    };
  }
}

async function testMuseAPI() {
  try {
    const response = await axios.get('https://www.themuse.com/api/public/jobs', {
      params: {
        page: 1,
        search: 'software'
      },
      timeout: 5000
    });
    
    return { 
      success: true, 
      status: response.status,
      resultsCount: response.data.results?.length || 0
    };
  } catch (error) {
    return { 
      success: false, 
      error: error.message,
      status: error.response?.status
    };
  }
}

router.get('/test-job-search', async (req, res) => {
  const { query = 'software engineer', location = 'remote' } = req.query;
  
  try {
    const results = {
      query,
      location,
      timestamp: new Date().toISOString(),
      sources: {}
    };
    
    // Test each API
    try {
      const adzunaJobs = await AdzunaService.getJobs(query, location, 1);
      results.sources.adzuna = {
        success: true,
        count: adzunaJobs.length,
        sample: adzunaJobs[0] || null
      };
    } catch (error) {
      results.sources.adzuna = {
        success: false,
        error: error.message
      };
    }
    
    try {
      const museJobs = await MuseService.getJobs(query, null, 1);
      results.sources.muse = {
        success: true,
        count: museJobs.length,
        sample: museJobs[0] || null
      };
    } catch (error) {
      results.sources.muse = {
        success: false,
        error: error.message
      };
    }
    
    try {
      const remoteJobs = await RemoteOKService.getJobs(query, 5);
      results.sources.remoteok = {
        success: true,
        count: remoteJobs.length,
        sample: remoteJobs[0] || null
      };
    } catch (error) {
      results.sources.remoteok = {
        success: false,
        error: error.message
      };
    }
    
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// All routes require authentication
router.use(auth);

// Debug and testing endpoints
router.get('/debug-ai', safeHandler(careerController.debugAI, 'debugAI'));
router.get('/debug-job-apis', safeHandler(careerController.debugJobAPIs, 'debugJobAPIs'));
router.get('/debug', safeHandler(careerController.debugCareer, 'debugCareer'));
router.get('/test', safeHandler(careerController.testConnection, 'testConnection'));

// Career suggestions
router.get('/suggestions', safeHandler(careerController.getCareerPathSuggestions, 'getCareerPathSuggestions'));
router.get('/path-suggestions', safeHandler(careerController.getCareerPathSuggestions, 'getCareerPathSuggestions'));

// Job search and recommendations
router.get('/jobs', safeHandler(careerController.getJobRecommendations, 'getJobRecommendations'));
router.get('/job-market', safeHandler(careerController.getJobMarketTrends, 'getJobMarketTrends'));

// Skill gap analysis with validation
router.post('/skill-gap', [
  check('targetRole', 'Target role is required').not().isEmpty().trim()
], safeHandler(careerController.getSkillGapAnalysis, 'getSkillGapAnalysis'));

router.post('/skill-gap-analysis', [
  check('targetRole', 'Target role is required').not().isEmpty().trim()
], safeHandler(careerController.getSkillGapAnalysis, 'getSkillGapAnalysis'));

// Resume analysis
router.post('/analyze-resume', safeHandler(careerController.analyzeResume, 'analyzeResume'));

// Saved jobs functionality - Fixed paths
router.get('/saved-jobs', safeHandler(savedJobsController.getSavedJobs, 'getSavedJobs'));
router.post('/save-job', [
  check('jobId', 'Job ID is required').notEmpty(),
  check('title', 'Job title is required').notEmpty(),
  check('company', 'Company name is required').notEmpty(),
  check('location', 'Location is required').notEmpty(),
  check('url', 'Job URL is required').isURL(),
  check('source', 'Job source is required').notEmpty()
], safeHandler(savedJobsController.saveJob, 'saveJob'));
router.delete('/saved-jobs/:jobId', safeHandler(savedJobsController.removeSavedJob, 'removeSavedJob'));

// Job applications
router.get('/job-applications', safeHandler(savedJobsController.getJobApplications, 'getJobApplications'));
router.put('/job-applications/:jobId', [
  check('status', 'Valid status required').optional().isIn(['saved', 'applied', 'interviewing', 'rejected', 'offer', 'hired'])
], safeHandler(savedJobsController.updateJobApplication, 'updateJobApplication'));

// LinkedIn integration routes
router.get('/linkedin/connect', safeHandler(careerController.connectLinkedIn, 'connectLinkedIn'));
router.get('/linkedin/callback', safeHandler(careerController.linkedInCallback, 'linkedInCallback'));
router.post('/linkedin/import-skills', safeHandler(careerController.importLinkedInSkills, 'importLinkedInSkills'));
router.delete('/linkedin/disconnect', safeHandler(careerController.disconnectLinkedIn, 'disconnectLinkedIn'));

// Mock test endpoints for development
router.get('/test-suggestions', (req, res) => {
  console.log('Career test-suggestions endpoint called');
  res.json({
    suggestions: [
      {
        title: 'Software Engineer',
        description: 'Design, develop, and maintain software applications.',
        score: 85,
        averageSalary: '$75,000 - $120,000',
        growthRate: 22,
        requiredSkills: ['JavaScript', 'Python', 'React', 'Node.js', 'Git'],
        nextSteps: [
          'Build a portfolio of projects',
          'Practice coding interviews',
          'Learn system design concepts'
        ]
      }
    ],
    metadata: {
      generatedAt: new Date(),
      source: 'mock-data',
      total: 1
    }
  });
});

router.get('/test-jobs', (req, res) => {
  console.log('Career test-jobs endpoint called');
  res.json({
    jobs: [
      {
        id: 'job-1',
        title: 'Junior Software Developer',
        company: 'TechCorp Inc.',
        location: 'Remote',
        description: 'Join our team as a Junior Software Developer.',
        salary: '$60,000 - $80,000',
        url: 'https://example.com/job1',
        source: 'Mock',
        postedAt: new Date().toISOString(),
        relevanceScore: 85
      }
    ],
    pagination: { page: 1, limit: 20, total: 1, pages: 1 }
  });
});

router.get('/debug-apis', async (req, res) => {
  try {
    const diagnostics = {
      timestamp: new Date().toISOString(),
      apis: {
        adzuna: {
          configured: !!(process.env.ADZUNA_APP_ID && process.env.ADZUNA_APP_KEY),
          appId: process.env.ADZUNA_APP_ID ? process.env.ADZUNA_APP_ID.substring(0, 4) + '...' : 'Not set',
          test: await testAdzunaAPI()
        },
        muse: {
          configured: true, // The Muse API is public
          test: await testMuseAPI()
        },
        remoteok: {
          configured: true, // RemoteOK is public
          test: await testRemoteOKAPI()
        }
      },
      environment: {
        nodeEnv: process.env.NODE_ENV,
        port: process.env.PORT || 3000
      }
    };
    
    res.json(diagnostics);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Health check for career routes
router.get('/health', (req, res) => {
  const health = {
    status: 'OK',
    timestamp: new Date().toISOString(),
    routes: {
      careerController: !!careerController,
      savedJobsController: !!savedJobsController
    },
    availableEndpoints: [
      'GET /career/debug',
      'GET /career/suggestions',
      'GET /career/jobs',
      'POST /career/skill-gap-analysis',
      'GET /career/saved-jobs',
      'POST /career/save-job',
      'GET /career/job-applications'
    ]
  };
  
  res.json(health);
});

// Error handling middleware for career routes
router.use((err, req, res, next) => {
  console.error('[CAREER ROUTE ERROR]', err);
  
  if (!res.headersSent) {
    res.status(err.status || 500).json({
      error: err.name || 'Internal Server Error',
      message: err.message || 'Something went wrong',
      path: req.path,
      method: req.method,
      timestamp: new Date().toISOString()
    });
  }
});

module.exports = router;