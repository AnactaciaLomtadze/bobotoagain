// routes/chat.js
const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const chatController = require('../controllers/chatController');
const auth = require('../middleware/auth');

// @route   GET api/chat/sessions
// @desc    Get all chat sessions for current user
// @access  Private
router.get('/sessions', auth, chatController.getSessions);

// @route   POST api/chat/sessions
// @desc    Create new chat session
// @access  Private
router.post('/sessions', auth, chatController.createSession);

// @route   GET api/chat/sessions/:sessionId/messages
// @desc    Get messages for a chat session
// @access  Private
router.get('/sessions/:sessionId/messages', auth, chatController.getMessages);

// @route   POST api/chat/sessions/:sessionId/messages
// @desc    Add message to chat session
// @access  Private
router.post(
  '/sessions/:sessionId/messages',
  [
    auth,
    [
      check('text', 'Message text is required').not().isEmpty()
    ]
  ],
  chatController.addMessage
);

// @route   DELETE api/chat/sessions/:sessionId
// @desc    Delete chat session
// @access  Private
router.delete('/sessions/:sessionId', auth, chatController.deleteSession);

// @route   PUT api/chat/sessions/:sessionId/save
// @desc    Save chat session as favorite
// @access  Private
router.put('/sessions/:sessionId/save', auth, chatController.saveSessionAsFavorite);

// @route   PUT api/chat/sessions/:sessionId/unsave
// @desc    Remove chat session from favorites
// @access  Private
router.put('/sessions/:sessionId/unsave', auth, chatController.removeSessionFromFavorites);

// @route   GET api/chat/search
// @desc    Search chat sessions
// @access  Private
router.get('/search', auth, chatController.searchSessions);

module.exports = router;