// models/Resume.js
const mongoose = require('mongoose');

const ResumeSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  filename: {
    type: String,
    required: true
  },
  content: {
    type: String,
    required: true
  },
  targetRole: {
    type: String,
    default: null
  },
  analysis: {
    assessment: {
      overallScore: {
        overall: Number,
        components: {
          skills: Number,
          experience: Number,
          education: Number
        }
      },
      skillCoverage: {
        coveragePercent: Number,
        missing: [String]
      }
    },
    improvements: [{
      suggestion: String,
      section: String,
      reason: String,
      priority: {
        type: String,
        enum: ['High', 'Medium', 'Low']
      }
    }],
    sections: {
      skills: [String],
      experience: [{
        company: String,
        role: String,
        duration: String,
        description: String
      }],
      education: [{
        institution: String,
        degree: String,
        field: String,
        year: String
      }]
    },
    strengths: [String],
    recommendations: [String]
  },
  analyzedAt: {
    type: Date,
    default: Date.now
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Resume', ResumeSchema);