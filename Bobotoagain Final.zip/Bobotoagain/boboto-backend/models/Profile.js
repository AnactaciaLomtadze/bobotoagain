const mongoose = require('mongoose');

// Define resource library item schema
const ResourceLibraryItemSchema = new mongoose.Schema({
  title: { type: String, required: true },
  url: { type: String, required: true },
  type: { type: String, required: true },
  subject: { type: String, required: true },
  addedAt: { type: Date, default: Date.now },
  completed: { type: Boolean, default: false },
  rating: { type: Number, min: 0, max: 5, default: 0 },
  notes: { type: String, default: '' }
});

// Define profile schema
const ProfileSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  // Personal & academic
  fullName: { type: String, required: true },
  phone: String,
  university: { type: String, required: true },
  major: { type: String, required: true },
  graduationYear: { type: Number, required: true },
  academicLevel: {
    type: String,
    required: true,
    enum: ['Undergraduate', 'Graduate', 'PhD', 'Postdoc']
  },
  bio: String,

  // Interests
  interests: [{ type: String }],

  // Skills
  skills: [{
    name: {
      type: String,
      required: true
    },
    category: {
      type: String,
      required: true,
      enum: ['technical', 'soft', 'academic', 'career']
    },
    level: {
      type: String,
      required: true,
      enum: ['Novice', 'Beginner', 'Intermediate', 'Advanced', 'Expert']
    },
    description: String,
    addedAt: {
      type: Date,
      default: Date.now
    },
    lastAssessed: Date,
    assessmentHistory: [{
      level: String,
      score: Number,
      frequency: String,
      confidence: Number,
      goals: String,
      date: {
        type: Date,
        default: Date.now
      },
      method: {
        type: String,
        enum: ['manual', 'assessment', 'ai-analysis']
      }
    }]
  }],

  // Work experience
  workExperience: [{
    company: String,
    position: String,
    duration: String,
    description: String,
    startDate: Date,
    endDate: Date,
    current: Boolean
  }],

  // Projects
  projects: [{
    title: String,
    description: String,
    technologies: [String],
    githubUrl: String,
    liveUrl: String,
    startDate: Date,
    endDate: Date
  }],

  // Career goals
  careerGoals: {
    shortTermGoal: String,
    midTermGoal: String,
    longTermGoal: String,
    shortTermTarget: Date,
    midTermTarget: Date,
    longTermTarget: Date,
    targetIndustry: String,
    secondaryIndustry: String,
    companySize: String,
    workEnvironment: String,
    dreamCompanies: String,
    skillsFocus: [String],
    locationPreference: String,
    salaryExpectations: String,
    primarySkillFocus: String,
    learningTimeCommitment: String,
    certificationGoals: String,
    certificationTimeline: Date,
    softSkillsPriorities: [String]
  },

  // Learning preferences
  learningPreferences: {
    learningStyle: [String],
    studySchedule: String,
    preferredLearningMedium: [String],
    difficultyLevel: String,
    studyDuration: String,
    certificationInterest: Boolean,
    practicalApplication: Boolean,
    mentorshipInterest: Boolean,
    studyGroupPreference: Boolean,
    preferredMaterials: [String],
    learningPace: String,
    technicalLevel: Number,
    theoryPractice: Number,
    explanationDepth: {
      type: String,
      enum: ['basic', 'intermediate', 'advanced', 'expert'],
      default: 'intermediate'
    },
    contentFormat: {
      type: String,
      enum: ['text', 'visual', 'interactive', 'mixed'],
      default: 'mixed'
    },
    subjectInterests: [String],
    learningChallenges: [String]
  },

  // Saved jobs
  savedJobs: [{
    id: String,
    savedAt: Date
  }],

  // Job applications
  jobApplications: [{
    jobTitle: String,
    company: String,
    jobDescription: String,
    applicationDate: { type: Date, default: Date.now },
    status: {
      type: String,
      enum: ['Applied', 'Interview', 'Offer', 'Rejected', 'Withdrawn', 'applied', 'interviewing', 'rejected', 'offer', 'hired'],
      default: 'applied'
    },
    notes: String,
    nextSteps: String,
    reminderDate: Date,
    url: String,
    source: String,
    appliedAt: Date,
    updatedAt: Date
  }],

  // LinkedIn profile integration
  linkedInProfile: {
    id: String,
    accessToken: String,
    expiresIn: Number,
    firstName: String,
    lastName: String,
    email: String,
    profile: mongoose.Schema.Types.Mixed,
    connectedAt: Date
  },

  // AI settings
  aiSettings: {
    model: String,
    temperature: Number,
    maxTokens: Number
  },

  // Academic tracking
  academicProgress: {
    subjects: [{
      name: String,
      proficiency: { type: Number, min: 0, max: 100, default: 0 },
      lastStudied: Date,
      topics: [{
        name: String,
        proficiency: { type: Number, min: 0, max: 100, default: 0 },
        materials: [{
          title: String,
          type: String,
          url: String,
          progress: { type: Number, min: 0, max: 100, default: 0 },
          completed: Boolean,
          notes: String
        }]
      }]
    }],
    studyTime: {
      total: { type: Number, default: 0 },
      bySubject: { type: Object, default: () => ({}) },
      dailyLog: [{
        date: Date,
        minutes: Number,
        subject: String
      }]
    }
  },

  // Learning resources
  resourceLibrary: [ResourceLibraryItemSchema],

  // Career assessments
  careerAssessments: {
    personalityType: String,
    strengths: [String],
    workValues: [String],
    preferredWorkEnvironment: String,
    assessmentDate: Date,
    assessmentResults: Object
  },

  // Networking
  networkContacts: {
    name: String,
    company: String,
    position: String,
    email: String,
    phone: String,
    notes: String,
    lastContactDate: Date,
    connectionType: {
      type: String,
      enum: ['LinkedIn', 'Conference', 'Referral', 'Other'],
      default: 'Other'
    }
  },

  // Timestamps
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Automatically update `updatedAt`
ProfileSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Profile', ProfileSchema);
