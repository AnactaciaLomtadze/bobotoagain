// models/SavedJob.js - Enhanced version with better validation
const mongoose = require('mongoose');

const SavedJobSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  jobId: {
    type: String,
    required: true,
    index: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  company: {
    type: String,
    required: true,
    trim: true
  },
  location: {
    type: String,
    required: true,
    trim: true
  },
  url: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return /^https?:\/\/.+/.test(v);
      },
      message: 'URL must be a valid HTTP/HTTPS URL'
    }
  },
  source: {
    type: String,
    required: true,
    enum: {
      values: ['Adzuna', 'The Muse', 'LinkedIn', 'RemoteOK', 'Profile'],
      message: '{VALUE} is not a valid job source'
    }
  },
  salary: {
    type: String,
    default: null,
    trim: true
  },
  description: {
    type: String,
    default: null,
    trim: true
  },
  notes: {
    type: String,
    default: null,
    trim: true
  },
  applicationStatus: {
    type: String,
    enum: {
      values: ['saved', 'applied', 'interviewing', 'rejected', 'offer', 'hired'],
      message: '{VALUE} is not a valid application status'
    },
    default: 'saved',
    index: true
  },
  savedAt: {
    type: Date,
    default: Date.now,
    index: true
  },
  appliedAt: {
    type: Date,
    default: null
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  // Additional metadata for better tracking
  tags: [{
    type: String,
    trim: true
  }],
  priority: {
    type: String,
    enum: ['low', 'medium', 'high'],
    default: 'medium'
  },
  // Tracking for reminders and follow-ups
  reminders: [{
    type: {
      type: String,
      enum: ['follow-up', 'interview', 'decision', 'custom']
    },
    message: String,
    scheduledFor: Date,
    completed: {
      type: Boolean,
      default: false
    }
  }]
});

// Compound index to prevent duplicate saves
SavedJobSchema.index({ user: 1, jobId: 1 }, { unique: true });

// Index for querying by status
SavedJobSchema.index({ user: 1, applicationStatus: 1 });

// Update the updatedAt field on save
SavedJobSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  
  // Set appliedAt when status changes to applied
  if (this.isModified('applicationStatus') && this.applicationStatus !== 'saved' && !this.appliedAt) {
    this.appliedAt = new Date();
  }
  
  next();
});

// Virtual to check if job has been applied to
SavedJobSchema.virtual('hasApplied').get(function() {
  return this.applicationStatus !== 'saved';
});

// Virtual to get days since saved
SavedJobSchema.virtual('daysSinceSaved').get(function() {
  const now = new Date();
  const saved = new Date(this.savedAt);
  const diffTime = Math.abs(now - saved);
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
});

// Instance method to add a reminder
SavedJobSchema.methods.addReminder = function(type, message, scheduledFor) {
  this.reminders.push({
    type,
    message,
    scheduledFor: new Date(scheduledFor)
  });
  return this.save();
};

// Instance method to update application status
SavedJobSchema.methods.updateStatus = function(newStatus, notes = null) {
  this.applicationStatus = newStatus;
  if (notes) {
    this.notes = notes;
  }
  return this.save();
};

// Static method to get user's saved jobs with filters
SavedJobSchema.statics.findByUser = function(userId, filters = {}) {
  const query = { user: userId };
  
  if (filters.status) {
    query.applicationStatus = filters.status;
  }
  
  if (filters.source) {
    query.source = filters.source;
  }
  
  if (filters.priority) {
    query.priority = filters.priority;
  }
  
  return this.find(query).sort({ savedAt: -1 });
};

// Static method to get application statistics
SavedJobSchema.statics.getApplicationStats = function(userId) {
  return this.aggregate([
    { $match: { user: new mongoose.Types.ObjectId(userId) } },
    {
      $group: {
        _id: '$applicationStatus',
        count: { $sum: 1 }
      }
    }
  ]);
};

module.exports = mongoose.model('SavedJob', SavedJobSchema);