#!/bin/bash
echo "Starting Boboto Backend..."
npm run dev