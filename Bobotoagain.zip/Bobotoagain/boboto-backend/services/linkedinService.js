// services/linkedInService.js
import axios from 'axios';

/**
 * LinkedIn API integration service for Boboto
 */
const LinkedInService = {
  /**
   * Initialize LinkedIn OAuth flow
   * @returns {Promise<string>} URL to redirect user for LinkedIn authorization
   */
  initiateOAuth: async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await axios.get('/api/career/linkedin/connect', {
        headers: {
          'x-auth-token': token
        }
      });
      
      return response.data.authUrl;
    } catch (error) {
      console.error('Error initiating LinkedIn OAuth:', error);
      throw error;
    }
  },
  
  /**
   * Check if user has connected LinkedIn
   * @returns {Promise<boolean>} True if user has connected LinkedIn
   */
  isConnected: async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const profileResponse = await axios.get('/api/profile', {
        headers: {
          'x-auth-token': token
        }
      });
      
      return !!profileResponse.data.linkedInProfile;
    } catch (error) {
      console.error('Error checking LinkedIn connection:', error);
      return false;
    }
  },
  
  /**
   * Get LinkedIn profile information
   * @returns {Promise<Object>} LinkedIn profile data
   */
  getProfileInfo: async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const profileResponse = await axios.get('/api/profile', {
        headers: {
          'x-auth-token': token
        }
      });
      
      return profileResponse.data.linkedInProfile || null;
    } catch (error) {
      console.error('Error getting LinkedIn profile:', error);
      return null;
    }
  },
  
  /**
   * Import skills from LinkedIn profile
   * @returns {Promise<Array>} Imported skills
   */
  importSkills: async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await axios.post('/api/career/linkedin/import-skills', null, {
        headers: {
          'x-auth-token': token
        }
      });
      
      return response.data.skills;
    } catch (error) {
      console.error('Error importing LinkedIn skills:', error);
      throw error;
    }
  },
  
  /**
   * Share job application to LinkedIn
   * @param {Object} job Job information
   * @returns {Promise<Object>} Share result
   */
  shareJobApplication: async (job) => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await axios.post('/api/career/linkedin/share', 
        { job },
        {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        }
      );
      
      return response.data;
    } catch (error) {
      console.error('Error sharing to LinkedIn:', error);
      throw error;
    }
  },
  
  /**
   * Disconnect LinkedIn integration
   * @returns {Promise<Object>} Disconnection result
   */
  disconnect: async () => {
    try {
      const token = localStorage.getItem('auth_token');
      const response = await axios.delete('/api/career/linkedin/disconnect', {
        headers: {
          'x-auth-token': token
        }
      });
      
      return response.data;
    } catch (error) {
      console.error('Error disconnecting LinkedIn:', error);
      throw error;
    }
  }
};

export default LinkedInService;