// routes/savedJobs.js
const express = require('express');
const router = express.Router();
const { check } = require('express-validator');
const savedJobsController = require('../controllers/savedJobsController');
const auth = require('../middleware/auth');

// @route   GET api/career/saved-jobs
// @desc    Get user's saved jobs
// @access  Private
router.get('/saved-jobs', auth, savedJobsController.getSavedJobs);

// @route   POST api/career/save-job
// @desc    Save a job to user's profile
// @access  Private
router.post(
  '/save-job',
  [
    auth,
    [
      check('jobId', 'Job ID is required').not().isEmpty()
    ]
  ],
  savedJobsController.saveJob
);

// @route   DELETE api/career/saved-jobs/:jobId
// @desc    Remove a saved job from user's profile
// @access  Private
router.delete('/saved-jobs/:jobId', auth, savedJobsController.removeSavedJob);

// @route   GET api/career/job-applications
// @desc    Get all job applications
// @access  Private
router.get('/job-applications', auth, savedJobsController.getJobApplications);

// @route   PUT api/career/job-applications/:jobId
// @desc    Update a job application status
// @access  Private
router.put(
  '/job-applications/:jobId',
  [
    auth,
    [
      check('status', 'Status is required').optional()
    ]
  ],
  savedJobsController.updateJobApplication
);

module.exports = router;