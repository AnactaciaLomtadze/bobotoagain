// routes/ai.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const deepseekController = require('../controllers/deepseekController');

// @route   POST api/ai/chat
// @desc    Generate AI response using DeepSeek
// @access  Private
router.post('/chat', auth, deepseekController.generateResponse);

// @route   GET api/ai/settings
// @desc    Get user's AI settings
// @access  Private
router.get('/settings', auth, deepseekController.getSettings);

// @route   PUT api/ai/settings
// @desc    Update user's AI settings
// @access  Private
router.put('/settings', auth, deepseekController.updateSettings);

module.exports = router;