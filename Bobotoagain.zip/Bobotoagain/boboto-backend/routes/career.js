// routes/career.js
const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const careerController = require('../controllers/careerController');

// All routes require authentication
router.use(auth);

// @route   GET /api/career/jobs
// @desc    Get job recommendations
// @access  Private
router.get('/jobs', careerController.getJobRecommendations);

// @route   GET /api/career/job-market
// @desc    Get job market trends  
// @access  Private
router.get('/job-market', careerController.getJobMarketTrends);

// @route   GET /api/career/path-suggestions
// @desc    Get career path suggestions
// @access  Private
router.get('/path-suggestions', careerController.getCareerPathSuggestions);

// @route   POST /api/career/skill-gap-analysis
// @desc    Get skill gap analysis for target role
// @access  Private
router.post('/skill-gap-analysis', careerController.getSkillGapAnalysis);

// @route   POST /api/career/analyze-resume
// @desc    Analyze uploaded resume
// @access  Private
router.post('/analyze-resume', careerController.analyzeResume);

module.exports = router;