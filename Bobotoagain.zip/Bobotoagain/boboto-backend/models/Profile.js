// models/Profile.js

const mongoose = require('mongoose');

// Define resource library item schema explicitly
const ResourceLibraryItemSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true
  },
  subject: {
    type: String,
    required: true
  },
  addedAt: {
    type: Date,
    default: Date.now
  },
  completed: {
    type: Boolean,
    default: false
  },
  rating: {
    type: Number,
    min: 0,
    max: 5,
    default: 0
  },
  notes: {
    type: String,
    default: ''
  }
});

const ProfileSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  phone: String,
  university: String,
  major: String,
  graduationYear: Number,
  academicLevel: String,
  bio: String,
  
  // Learning preferences
  learningPreferences: {
    learningStyle: String,
    preferredMaterials: [String],
    learningPace: String,
    technicalLevel: Number,
    theoryPractice: Number,
    explanationDepth: {
      type: String,
      enum: ['basic', 'intermediate', 'advanced', 'expert'],
      default: 'intermediate'
    },
    contentFormat: {
      type: String,
      enum: ['text', 'visual', 'interactive', 'mixed'],
      default: 'mixed'
    },
    subjectInterests: [String],
    learningChallenges: [String]
  },
  
  // Career goals
  careerGoals: {
    shortTermGoal: String,
    midTermGoal: String,
    longTermGoal: String,
    shortTermTarget: String,
    midTermTarget: String,
    longTermTarget: String,
    targetIndustry: String,
    secondaryIndustry: String,
    skillsFocus: [String],
    companySize: String,
    workEnvironment: String,
    dreamCompanies: String,
    locationPreference: String,
    salaryExpectations: String,
    softSkillsPriorities: [String]
  },
  
  // Skills array
  skills: [
    {
      name: String,
      level: {
        type: String,
        enum: ['Novice', 'Beginner', 'Intermediate', 'Advanced', 'Expert']
      },
      category: {
        type: String,
        enum: ['technical', 'soft', 'academic', 'career'],
        default: 'technical'
      },
      priority: {
        type: Number,
        default: 0
      },
      addedAt: {
        type: Date,
        default: Date.now
      },
      lastAssessed: {
        type: Date,
        default: Date.now
      },
      progressHistory: [{
        date: Date,
        level: String,
        note: String
      }]
    }
  ],
  
  // AI settings
  aiSettings: {
    model: String,
    temperature: Number,
    maxTokens: Number
  },
  
  // Academic study tracking - FIXED Map issue
  academicProgress: {
    subjects: [{
      name: String,
      proficiency: {
        type: Number,
        min: 0,
        max: 100,
        default: 0
      },
      lastStudied: Date,
      topics: [{
        name: String,
        proficiency: {
          type: Number,
          min: 0,
          max: 100,
          default: 0
        },
        materials: [{
          title: String,
          type: String,
          url: String,
          progress: {
            type: Number,
            min: 0,
            max: 100,
            default: 0
          },
          completed: Boolean,
          notes: String
        }]
      }]
    }],
    studyTime: {
      // Total study time in minutes
      total: {
        type: Number,
        default: 0
      },
      // Study time by subject - CHANGED from Map to Object
      bySubject: {
        type: Object,
        default: () => ({})
      },
      // Daily study time log
      dailyLog: [{
        date: Date,
        minutes: Number,
        subject: String
      }]
    }
  },
  
  // Learning resources library
  resourceLibrary: [ResourceLibraryItemSchema],
  
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  updatedAt: {
    type: Date,
    default: Date.now
  },
  // LinkedIn profile integration
linkedInProfile: {
  id: String,
  accessToken: String,
  expiresIn: Number,
  firstName: String,
  lastName: String,
  email: String,
  connectedAt: Date
},

// Job applications tracking
jobApplications: [
  {
    jobTitle: String,
    company: String,
    jobDescription: String,
    applicationDate: {
      type: Date,
      default: Date.now
    },
    status: {
      type: String,
      enum: ['Applied', 'Interview', 'Offer', 'Rejected', 'Withdrawn'],
      default: 'Applied'
    },
    notes: String,
    nextSteps: String,
    reminderDate: Date,
    url: String,
    source: String
  }
],

// Career assessments
careerAssessments: {
  personalityType: String,
  strengths: [String],
  workValues: [String],
  preferredWorkEnvironment: String,
  assessmentDate: Date,
  assessmentResults: Object
},

// Network contacts
networkContacts: 
  {
    name: String,
    company: String,
    position: String,
    email: String,
    phone: String,
    notes: String,
    lastContactDate: Date,
    connectionType: {
      type: String,
      enum: ['LinkedIn', 'Conference', 'Referral', 'Other'],
      default: 'Other'
    }
  }
});

module.exports = mongoose.model('Profile', ProfileSchema);