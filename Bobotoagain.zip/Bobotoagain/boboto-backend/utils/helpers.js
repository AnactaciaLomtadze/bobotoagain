// Helper function to format user profile data for AI context
exports.formatUserProfileForAI = (profile, user) => {
    if (!profile || !user) return "No profile information available.";
    
    return `
      Name: ${user.fullName || 'Student'}
      Education: ${profile.major || 'Computer Science'} ${profile.academicLevel || 'Student'}
      Learning Style: ${profile.learningPreferences?.learningStyles?.join(', ') || 'Not specified'}
      Subject Interests: ${profile.learningPreferences?.subjectInterests?.join(', ') || 'Not specified'}
      Technical Level: ${profile.learningPreferences?.technicalLevel || 'Intermediate'}
      Career Goals: 
        - Short-term: ${profile.careerGoals?.shortTermGoal || 'Not specified'}
        - Long-term: ${profile.careerGoals?.longTermGoal || 'Not specified'}
      Skills: ${profile.skills?.map(s => `${s.name} (${s.level})`).join(', ') || 'Not specified'}
    `;
  };
  
  // Helper function to format date
  exports.formatDate = (date) => {
    return new Date(date).toLocaleString('en-US', {
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };