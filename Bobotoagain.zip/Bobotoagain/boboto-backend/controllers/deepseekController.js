// controllers/deepseekController.js
const axios = require('axios');
const Profile = require('../models/Profile');
const User = require('../models/User');
require('dotenv').config();

// Check for DeepSeek API key (OpenRouter key in this case)
const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;
if (!OPENROUTER_API_KEY) {
  console.error('ERROR: OpenRouter API key is not configured in environment variables');
}

console.log('OpenRouter API Key configured:', OPENROUTER_API_KEY ? 'Yes (length: ' + OPENROUTER_API_KEY.length + ')' : 'No');

// OpenRouter API URL for DeepSeek
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const DEEPSEEK_MODEL = 'deepseek/deepseek-r1:free';

// Generate AI response using DeepSeek
exports.generateResponse = async (req, res) => {
  const { message, sessionId, chatHistory } = req.body;
  
  if (!message) {
    return res.status(400).json({ message: 'Message is required' });
  }
  
  try {
    console.log('Generating DeepSeek AI response for message:', message);
    
    // Get user profile for context
    const profile = await Profile.findOne({ user: req.user.id });
    const user = await User.findById(req.user.id).select('-password');
    
    console.log('Found user profile:', profile ? 'Yes' : 'No');
    console.log('Found user:', user ? 'Yes' : 'No');
    
    if (!profile || !user) {
      return res.status(404).json({ message: 'User profile not found' });
    }
    
    // Log chatHistory if provided
    if (chatHistory) {
      console.log('Chat history provided, length:', chatHistory.length);
    }
    
    // Prepare system message with user context
    const systemMessage = `You are Boboto, an academic and career AI assistant for students.
    
    Key capabilities:
    1. Personalized academic support based on learning style and knowledge level
    2. Clear explanation of complex concepts with examples matched to the student's field
    3. Tailored study recommendations and learning paths
    4. Career guidance based on current market trends
    5. Memory of past interactions to provide continuity
    
    User profile information:
    Name: ${user.fullName || 'Student'}
    Education: ${profile.major || 'Computer Science'} ${profile.academicLevel || 'Student'}
    Learning Style: ${profile.learningPreferences?.learningStyle || 'Not specified'}
    Technical Level: ${profile.learningPreferences?.technicalLevel || 'Intermediate'}
    Career Goals: 
      - Short-term: ${profile.careerGoals?.shortTermGoal || 'Not specified'}
      - Long-term: ${profile.careerGoals?.longTermGoal || 'Not specified'}
    Skills: ${profile.skills?.map(s => `${s.name} (${s.level})`).join(', ') || 'Not specified'}
    
    Today's date: ${new Date().toDateString()}
    
    Be concise but thorough. Use examples relevant to the student's field and interests.
    Maintain a professional but supportive tone. Offer specific resources when helpful.`;
    
    // Format the messages for OpenRouter API
    let messages = [
      { role: 'system', content: systemMessage }
    ];
    
    // Add chat history if provided
    if (chatHistory && Array.isArray(chatHistory)) {
      const formattedHistory = chatHistory.map(msg => ({
        role: msg.isUser ? 'user' : 'assistant',
        content: msg.text
      }));
      
      messages = [...messages, ...formattedHistory];
    }
    
    // Add the current message
    messages.push({ role: 'user', content: message });
    
    // Get user's AI settings or use defaults
    const aiSettings = profile.aiSettings || {};
    
    // Call OpenRouter API with DeepSeek model
    console.log('Calling OpenRouter API with DeepSeek...');
    
    const requestBody = {
      model: aiSettings.model || DEEPSEEK_MODEL,
      messages: messages,
      temperature: aiSettings.temperature || parseFloat(process.env.AI_TEMPERATURE || "0.7"),
      max_tokens: aiSettings.maxTokens || parseInt(process.env.AI_MAX_TOKENS || "1000"),
    };
    
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${OPENROUTER_API_KEY}`,
      'HTTP-Referer': process.env.SITE_URL || 'http://localhost:5000',
      'X-Title': process.env.SITE_NAME || 'Boboto - Academic AI Assistant'
    };
    
    const response = await axios.post(OPENROUTER_API_URL, requestBody, { headers });
    
    console.log('DeepSeek API response received');
    
    // Extract the response content
    const aiResponse = response.data.choices[0].message.content;
    
    res.json({ response: aiResponse });
  } catch (err) {
    console.error('DeepSeek error details:', err);
    console.error('Error message:', err.message);
    console.error('Error name:', err.name);

    if (err.response) {
      console.error('Response status:', err.response.status);
      console.error('Response data:', err.response.data);
    }

    // More detailed error information
    const errorInfo = {
      message: 'Error generating AI response',
      error: err.message,
      type: err.type || 'Unknown',
      code: err.code || 'Unknown'
    };
    
    console.error('Error info:', errorInfo);
    res.status(500).json(errorInfo);
  }
};

// Get user's AI settings
exports.getSettings = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Get settings or default values
    const aiSettings = profile.aiSettings || {};
    
    res.json({
      model: aiSettings.model || DEEPSEEK_MODEL,
      temperature: aiSettings.temperature || parseFloat(process.env.AI_TEMPERATURE || '0.7'),
      maxTokens: aiSettings.maxTokens || parseInt(process.env.AI_MAX_TOKENS || '1000')
    });
  } catch (err) {
    console.error('Get AI settings error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};

// Update user's AI settings
exports.updateSettings = async (req, res) => {
  const { model, temperature, maxTokens } = req.body;
  
  try {
    // Validate input
    if (temperature !== undefined && (temperature < 0 || temperature > 1)) {
      return res.status(400).json({ message: 'Temperature must be between 0 and 1' });
    }
    
    if (maxTokens !== undefined && (maxTokens < 100 || maxTokens > 4000)) {
      return res.status(400).json({ message: 'maxTokens must be between 100 and 4000' });
    }
    
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Initialize aiSettings if it doesn't exist
    if (!profile.aiSettings) {
      profile.aiSettings = {};
    }
    
    // Update settings
    if (model) profile.aiSettings.model = model;
    if (temperature !== undefined) profile.aiSettings.temperature = temperature;
    if (maxTokens !== undefined) profile.aiSettings.maxTokens = maxTokens;
    
    await profile.save();
    
    res.json(profile.aiSettings);
  } catch (err) {
    console.error('Update AI settings error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
};