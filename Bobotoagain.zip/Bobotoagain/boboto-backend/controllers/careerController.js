// controllers/careerController.js
const Profile = require('../models/Profile');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const multer = require('multer');
const { validationResult } = require('express-validator');
require('dotenv').config();

// API configuration with error handling and fallbacks
const ADZUNA_APP_ID = process.env.ADZUNA_APP_ID;
const ADZUNA_API_KEY = process.env.ADZUNA_API_KEY;
const MUSE_API_KEY = process.env.MUSE_API_KEY;
const LINKEDIN_CLIENT_ID = process.env.LINKEDIN_CLIENT_ID;
const LINKEDIN_CLIENT_SECRET = process.env.LINKEDIN_CLIENT_SECRET;
const REMOTOK_API_KEY = process.env.REMOTOK_API_KEY;
const API_TIMEOUT = 15000; // 15 second timeout for all API calls

// LinkedIn API configuration
const linkedInConfig = {
  client_id: LINKEDIN_CLIENT_ID,
  client_secret: LINKEDIN_CLIENT_SECRET,
  redirect_uri: process.env.LINKEDIN_REDIRECT_URI || 'http://localhost:5000/api/career/linkedin/callback',
  scope: 'r_liteprofile r_emailaddress w_member_social'
};

// Logger for API calls
const logApiCall = (api, endpoint, success, message) => {
  console.log(`[${new Date().toISOString()}] ${api} API call to ${endpoint}: ${success ? 'SUCCESS' : 'FAILED'} - ${message}`);
};

/**
 * Get job listings from Adzuna API
 * @param {Array} skills - Array of skill names
 * @param {String} location - Location for job search
 * @returns {Promise<Array>} - Array of job listings
 */
async function getAdzunaJobs(skills, location) {
  try {
    if (!ADZUNA_APP_ID || !ADZUNA_API_KEY) {
      logApiCall('Adzuna', 'jobs', false, 'Missing API credentials');
      return [];
    }

    // Determine country code based on location or default to 'us'
    let country = 'us';
    // Map of common countries to their country codes
    const countryCodes = {
      'united states': 'us', 'us': 'us', 'usa': 'us',
      'uk': 'gb', 'united kingdom': 'gb', 'great britain': 'gb',
      'canada': 'ca', 'australia': 'au', 'germany': 'de',
      'france': 'fr', 'spain': 'es', 'italy': 'it'
    };
    
    // Try to extract country code from location
    if (location) {
      const locationLower = location.toLowerCase();
      for (const [key, value] of Object.entries(countryCodes)) {
        if (locationLower.includes(key)) {
          country = value;
          break;
        }
      }
    }
    
    // Base URL for Adzuna API statistics endpoint
    const statsUrl = `https://api.adzuna.com/v1/api/jobs/${country}/history`;
    
    // Create promises for all API calls we need to make
    const apiPromises = [];
    const apiLabels = [];
    
    // Request histogram data for job counts by month (demand trends)
    apiPromises.push(
      axios.get(`${statsUrl}`, {
        params: {
          app_id: ADZUNA_APP_ID,
          app_key: ADZUNA_API_KEY,
          location0: location,
          category: industry,
          what: jobTitle,
          months: 6 // Get data for last 6 months
        },
        timeout: API_TIMEOUT
      }).catch(error => {
        logApiCall('Adzuna', 'demand trends', false, error.message);
        return { data: null };
      })
    );
    apiLabels.push('demandTrends');
    
    // Request salary trends
    apiPromises.push(
      axios.get(`${statsUrl}`, {
        params: {
          app_id: ADZUNA_APP_ID,
          app_key: ADZUNA_API_KEY,
          location0: location,
          category: industry,
          what: jobTitle,
          months: 6, // Get data for last 6 months
          salary: true // Include salary data
        },
        timeout: API_TIMEOUT
      }).catch(error => {
        logApiCall('Adzuna', 'salary trends', false, error.message);
        return { data: null };
      })
    );
    apiLabels.push('salaryTrends');
    
    // Request top categories data
    apiPromises.push(
      axios.get(`https://api.adzuna.com/v1/api/jobs/${country}/categories`, {
        params: {
          app_id: ADZUNA_APP_ID,
          app_key: ADZUNA_API_KEY
        },
        timeout: API_TIMEOUT
      }).catch(error => {
        logApiCall('Adzuna', 'categories', false, error.message);
        return { data: null };
      })
    );
    apiLabels.push('categories');
    
    // Make a search request to get job data for skill and location analysis
    apiPromises.push(
      axios.get(`https://api.adzuna.com/v1/api/jobs/${country}/search/1`, {
        params: {
          app_id: ADZUNA_APP_ID,
          app_key: ADZUNA_API_KEY,
          results_per_page: 50,
          what: jobTitle || (industry ? `${industry} jobs` : 'software developer'),
          location0: location
        },
        timeout: API_TIMEOUT
      }).catch(error => {
        logApiCall('Adzuna', 'job search', false, error.message);
        return { data: null };
      })
    );
    apiLabels.push('jobSearch');
    
    // Execute all API requests concurrently
    const apiResults = await Promise.all(apiPromises);
    
    // Process the results
    const resultsMap = {};
    apiResults.forEach((result, index) => {
      resultsMap[apiLabels[index]] = result.data;
    });
    
    // Process histogram data for demand trends
    const demandTrends = [];
    if (resultsMap.demandTrends && resultsMap.demandTrends.month) {
      const months = resultsMap.demandTrends.month;
      const monthKeys = Object.keys(months).sort(); // Sort chronologically
      
      monthKeys.forEach(monthKey => {
        const dateParts = monthKey.split('-');
        const formattedDate = new Date(dateParts[0], dateParts[1] - 1).toLocaleString('default', { 
          month: 'short', 
          year: 'numeric' 
        });
        
        demandTrends.push({
          period: formattedDate,
          jobCount: months[monthKey],
          // Calculate month-over-month growth if possible
          growth: monthKeys.indexOf(monthKey) > 0 
            ? calculateGrowthRate(months[monthKeys[monthKeys.indexOf(monthKey) - 1]], months[monthKey])
            : null
        });
      });
      
      logApiCall('Adzuna', 'demand trends', true, 'Successfully processed demand trends');
    } else {
      logApiCall('Adzuna', 'demand trends', false, 'No histogram data available');
    }
    
    // Process salary data
    const salaryTrends = [];
    if (resultsMap.salaryTrends && resultsMap.salaryTrends.month) {
      const months = resultsMap.salaryTrends.month;
      const monthKeys = Object.keys(months).sort(); // Sort chronologically
      
      monthKeys.forEach(monthKey => {
        const dateParts = monthKey.split('-');
        const formattedDate = new Date(dateParts[0], dateParts[1] - 1).toLocaleString('default', { 
          month: 'short', 
          year: 'numeric' 
        });
        
        // Get average salary for the month (if available)
        const monthData = months[monthKey];
        if (monthData && monthData.average) {
          salaryTrends.push({
            period: formattedDate,
            avgSalary: Math.round(monthData.average),
            // Calculate month-over-month salary growth if possible
            growth: monthKeys.indexOf(monthKey) > 0 && 
                    months[monthKeys[monthKeys.indexOf(monthKey) - 1]].average
              ? calculateGrowthRate(
                  months[monthKeys[monthKeys.indexOf(monthKey) - 1]].average, 
                  monthData.average
                )
              : null
          });
        }
      });
      
      logApiCall('Adzuna', 'salary trends', true, 'Successfully processed salary trends');
    } else {
      logApiCall('Adzuna', 'salary trends', false, 'No salary data available');
    }
    
    // Process top industries from categories
    const topIndustries = [];
    if (resultsMap.categories && resultsMap.categories.results) {
      resultsMap.categories.results
        .sort((a, b) => (b.count || 0) - (a.count || 0))
        .slice(0, 5)
        .forEach(category => {
          topIndustries.push({
            name: category.label,
            jobCount: category.count || 0,
            tag: category.tag || null,
            // Generate a growth rate based on historical data or use a placeholder
            growthRate: getRandomGrowthRate(5, 15, category.tag)
          });
        });
      
      logApiCall('Adzuna', 'top industries', true, 'Successfully processed top industries');
    } else {
      logApiCall('Adzuna', 'top industries', false, 'No category data available');
    }
    
    // Extract skills from job descriptions
    const topSkills = [];
    const locationInsights = [];
    
    if (resultsMap.jobSearch && resultsMap.jobSearch.results) {
      // Process top skills
      topSkills.push(...extractTopSkills(resultsMap.jobSearch.results));
      
      // Process location insights
      locationInsights.push(...getLocationInsights(resultsMap.jobSearch.results));
      
      logApiCall('Adzuna', 'job insights', true, 'Successfully processed job search results');
    } else {
      logApiCall('Adzuna', 'job insights', false, 'No job search results available');
    }
    
    return {
      demandTrends,
      salaryTrends,
      topIndustries,
      topSkills,
      locationInsights
    };
  } catch (error) {
    logApiCall('Adzuna', 'job trends', false, error.message);
    // Return empty data instead of failing completely
    return {
      demandTrends: [],
      salaryTrends: [],
      topIndustries: [],
      topSkills: [],
      locationInsights: []
    };
  }
}

/**
 * Calculate growth rate percentage between two values
 * @param {Number} oldValue - Original value
 * @param {Number} newValue - New value
 * @returns {Number} - Growth rate as a percentage
 */
function calculateGrowthRate(oldValue, newValue) {
  if (!oldValue || oldValue === 0) return null;
  return parseFloat(((newValue - oldValue) / oldValue * 100).toFixed(1));
}

/**
 * Generate a semi-random growth rate based on industry tag
 * To create more realistic and consistent data
 */
function getRandomGrowthRate(min, max, tag) {
  // Create a deterministic "random" number based on the tag
  let seed = 0;
  if (tag) {
    for (let i = 0; i < tag.length; i++) {
      seed += tag.charCodeAt(i);
    }
  }
  
  // Some industries are growing faster than others
  const growthBiases = {
    'it-jobs': 10,         // Tech tends to grow faster
    'engineering': 8,
    'scientific': 5,
    'healthcare': 7,
    'teaching': 3,
    'hr': 1,
    'accounting-finance': 2,
    'sales': 0,
    'creative-design': 4
  };
  
  // Apply bias based on industry tag
  const bias = tag && growthBiases[tag] ? growthBiases[tag] : 0;
  
  // Deterministic "random" value
  const baseValue = (seed % (max - min)) + min;
  
  // Final growth rate with bias
  return parseFloat((baseValue + bias).toFixed(1));
}

/**
 * Extract top skills from job listings
 * @param {Array} jobs - Array of job listings
 * @returns {Array} - Array of skills with metadata
 */
function extractTopSkills(jobs) {
  // Common technical skills to look for
  const commonSkills = [
    'javascript', 'python', 'java', 'c#', 'c++', 'ruby', 'go', 'rust',
    'react', 'angular', 'vue', 'node', 'django', 'flask', 'spring',
    'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform',
    'machine learning', 'data science', 'artificial intelligence', 'devops',
    'product management', 'ux design', 'ui design', 'cloud', 'agile', 'scrum',
    'sql', 'nosql', 'mongodb', 'postgresql', 'mysql', 'oracle',
    'git', 'ci/cd', 'jenkins', 'github actions', 'automation'
  ];
  
  // Count skill occurrences
  const skillCounts = {};
  
  jobs.forEach(job => {
    const description = (job.description || '').toLowerCase();
    
    commonSkills.forEach(skill => {
      if (description.includes(skill)) {
        skillCounts[skill] = (skillCounts[skill] || 0) + 1;
      }
    });
  });
  
  // Convert to array and calculate percentage
  const totalJobs = jobs.length || 1; // Avoid division by zero
  
  return Object.entries(skillCounts)
    .map(([name, count]) => {
      const percentageOfJobs = Math.round((count / totalJobs) * 100);
      
      let demand = 'Low';
      if (percentageOfJobs >= 60) demand = 'Very High';
      else if (percentageOfJobs >= 40) demand = 'High';
      else if (percentageOfJobs >= 20) demand = 'Medium';
      
      return {
        name: name.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '), // Title case
        demand,
        percentageOfJobs,
        source: 'Adzuna'
      };
    })
    .sort((a, b) => b.percentageOfJobs - a.percentageOfJobs)
    .slice(0, 10); // Top 10 skills
}

/**
 * Extract location insights from job listings
 * @param {Array} jobs - Array of job listings
 * @returns {Array} - Array of locations with metadata
 */
function getLocationInsights(jobs) {
  // Group jobs by location
  const locationGroups = {};
  
  jobs.forEach(job => {
    const location = job.location?.display_name || 'Unknown';
    
    if (!locationGroups[location]) {
      locationGroups[location] = {
        jobCount: 0,
        salaries: []
      };
    }
    
    locationGroups[location].jobCount++;
    
    // Add salary if available
    if (job.salary_min && job.salary_max) {
      const avgSalary = (job.salary_min + job.salary_max) / 2;
      locationGroups[location].salaries.push(avgSalary);
    }
  });
  
  // Calculate average salary for each location
  return Object.entries(locationGroups)
    .map(([location, data]) => {
      const avgSalary = data.salaries.length > 0
        ? Math.round(data.salaries.reduce((sum, val) => sum + val, 0) / data.salaries.length)
        : null;
      
      return {
        location,
        jobCount: data.jobCount,
        avgSalary: avgSalary ? avgSalary.toLocaleString() : 'Not specified',
        // Add a growth indicator based on location popularity
        growthIndicator: data.jobCount > 10 ? 'Growing' : 
                        data.jobCount > 5 ? 'Stable' : 'Limited Opportunities'
      };
    })
    .sort((a, b) => b.jobCount - a.jobCount)
    .slice(0, 5); // Top 5 locations
}

/**
 * Get job trends from The Muse API
 * @param {String} industry - Industry to filter by
 * @param {String} jobTitle - Job title to filter by
 * @returns {Promise<Object>} - Job trends data
 */
async function getMuseJobTrends(industry, jobTitle) {
  try {
    if (!MUSE_API_KEY) {
      logApiCall('The Muse', 'trends', false, 'Missing API key');
      return {
        topSkills: [],
        popularJobs: [],
        recentTrends: []
      };
    }

    // The Muse API endpoints
    const baseUrl = 'https://www.themuse.com/api/public/jobs';
    
    // Make several API calls to gather data for analysis
    const apiPromises = [];
    
    // If industry is provided, get industry-specific jobs
    if (industry) {
      const categoryMapping = {
        'technology': 'Engineering',
        'engineering': 'Engineering',
        'software': 'Engineering',
        'data': 'Data Science',
        'business': 'Business',
        'marketing': 'Marketing',
        'design': 'Design',
        'product': 'Product',
        'sales': 'Sales'
      };
      
      // Find matching category
      let category = null;
      const industryLower = industry.toLowerCase();
      for (const [key, value] of Object.entries(categoryMapping)) {
        if (industryLower.includes(key)) {
          category = value;
          break;
        }
      }
      
      if (category) {
        apiPromises.push(
          axios.get(baseUrl, {
            params: {
              category,
              page: 1,
              api_key: MUSE_API_KEY
            },
            timeout: API_TIMEOUT
          }).catch(error => {
            logApiCall('The Muse', 'industry jobs', false, error.message);
            return { data: null };
          })
        );
      }
    }
    
    // Get recent jobs across multiple categories
    apiPromises.push(
      axios.get(baseUrl, {
        params: {
          page: 1,
          api_key: MUSE_API_KEY
        },
        timeout: API_TIMEOUT
      }).catch(error => {
        logApiCall('The Muse', 'recent jobs', false, error.message);
        return { data: null };
      })
    );
    
    // If job title is provided, search for specific jobs
    if (jobTitle) {
      apiPromises.push(
        axios.get(baseUrl, {
          params: {
            page: 1,
            api_key: MUSE_API_KEY,
            // The Muse doesn't have a direct title search, but we can filter results later
          },
          timeout: API_TIMEOUT
        }).catch(error => {
          logApiCall('The Muse', 'title jobs', false, error.message);
          return { data: null };
        })
      );
    }
    
    // Execute all API requests concurrently
    const apiResults = await Promise.all(apiPromises);
    
    // Extract skills from job descriptions
    const skillMentions = {};
    const jobTitles = {};
    let totalJobs = 0;
    
    // Process the responses to extract trend data
    apiResults.forEach(response => {
      if (response.data && response.data.results) {
        totalJobs += response.data.results.length;
        
        response.data.results.forEach(job => {
          // Extract skills from description
          const description = (job.description || '').toLowerCase();
          
          // Check for common tech skills
          const skillsToCheck = [
            'javascript', 'python', 'java', 'c#', 'ruby', 'go', 'rust',
            'react', 'angular', 'vue', 'node', 'django', 'flask', 'spring',
            'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform',
            'machine learning', 'data science', 'artificial intelligence', 'devops',
            'product management', 'ux', 'ui', 'cloud', 'agile', 'scrum'
          ];
          
          skillsToCheck.forEach(skill => {
            if (description.includes(skill)) {
              skillMentions[skill] = (skillMentions[skill] || 0) + 1;
            }
          });
          
          // Track job titles if we have a job title search
          if (jobTitle) {
            // Only process jobs that match our search
            if (job.name.toLowerCase().includes(jobTitle.toLowerCase())) {
              // Extract simplified job title
              const simplifiedTitle = extractSimplifiedTitle(job.name);
              if (simplifiedTitle && simplifiedTitle.length > 3) {
                jobTitles[simplifiedTitle] = (jobTitles[simplifiedTitle] || 0) + 1;
              }
            }
          } else {
            // Process all job titles
            const simplifiedTitle = extractSimplifiedTitle(job.name);
            if (simplifiedTitle && simplifiedTitle.length > 3) {
              jobTitles[simplifiedTitle] = (jobTitles[simplifiedTitle] || 0) + 1;
            }
          }
        });
      }
    });
    
    logApiCall('The Muse', 'trends analysis', true, `Analyzed ${totalJobs} jobs, found ${Object.keys(skillMentions).length} unique skills`);
    
    // Convert skill mentions to array and sort by frequency
    const topSkills = Object.entries(skillMentions)
      .map(([name, count]) => {
        // Calculate a demand rating based on frequency
        let demand = 'Low';
        if (count > 10) demand = 'Very High';
        else if (count > 7) demand = 'High';
        else if (count > 3) demand = 'Medium';
        
        const percentageOfJobs = totalJobs > 0 ? Math.round((count / totalJobs) * 100) : 0;
        
        return {
          name: name.charAt(0).toUpperCase() + name.slice(1), // Capitalize name
          demand,
          percentageOfJobs,
          growthRate: parseFloat((Math.random() * 25 + 5).toFixed(1)), // 5-30% growth rate (simulated)
          source: 'The Muse'
        };
      })
      .sort((a, b) => {
        // Sort by demand rating
        const demandRanking = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
        return demandRanking[b.demand] - demandRanking[a.demand];
      })
      .slice(0, 10); // Top 10 skills
    
    // Convert job titles to array and sort by frequency
    const popularJobs = Object.entries(jobTitles)
      .filter(([title]) => title.length > 3) // Filter out short titles
      .map(([title, count]) => {
        // Calculate percentage
        const percentageOfJobs = totalJobs > 0 ? Math.round((count / totalJobs) * 100) : 0;
        
        return {
          title,
          count,
          percentageOfJobs,
          // Simulate other metrics
          growthRate: parseFloat((Math.random() * 20 + 5).toFixed(1)), // 5-25% growth rate (simulated)
          avgSalary: Math.round((Math.random() * 50000 + 80000) / 5000) * 5000 // $80k-$130k, rounded to nearest $5k (simulated)
        };
      })
      .sort((a, b) => b.count - a.count)
      .slice(0, 8); // Top 8 job titles
    
    // Recent trends analysis based on job descriptions
    // These are simulated but could be enhanced with actual ML/NLP in production
    const recentTrends = [
      { 
        trend: 'Remote Work', 
        impact: 'Significant increase in remote opportunities across all fields',
        percentageChange: 85,
        description: 'Companies are increasingly offering fully remote or hybrid work arrangements as standard options.'
      },
      { 
        trend: 'AI Integration', 
        impact: 'Growing demand for AI skills across traditional and new tech roles',
        percentageChange: 65,
        description: 'Organizations are seeking professionals who can implement AI solutions across various business functions.'
      },
      { 
        trend: 'Work-Life Balance', 
        impact: 'Companies emphasizing flexibility and wellbeing benefits',
        percentageChange: 60,
        description: 'Job listings now prominently feature mental health benefits and flexible scheduling as key perks.'
      },
      { 
        trend: 'Upskilling Programs', 
        impact: 'More companies investing in employee development and training',
        percentageChange: 55,
        description: 'Organizations are offering structured career development paths and continuous learning opportunities.'
      },
      { 
        trend: 'Contract Work', 
        impact: 'Rise in contract and project-based employment',
        percentageChange: 45,
        description: 'The gig economy continues to expand with more professionals taking on specialized contract roles.'
      }
    ];
    
    return {
      topSkills,
      popularJobs,
      recentTrends
    };
  } catch (error) {
    logApiCall('The Muse', 'trends', false, error.message);
    return {
      topSkills: [],
      popularJobs: [],
      recentTrends: []
    };
  }
}

/**
 * Extract a simplified job title by removing seniority and other modifiers
 * @param {String} fullTitle - Full job title
 * @returns {String} - Simplified job title
 */
function extractSimplifiedTitle(fullTitle) {
  if (!fullTitle) return null;
  
  // Remove level indicators and common prefixes/suffixes
  return fullTitle
    .replace(/\b(senior|sr|junior|jr|lead|principal|staff|associate|I|II|III|IV|V)\b/gi, '')
    .replace(/\([^)]*\)/g, '') // Remove anything in parentheses
    .replace(/\[[^\]]*\]/g, '') // Remove anything in brackets
    .replace(/\d+/g, '') // Remove numbers
    .replace(/[-–—]/g, ' ') // Replace dashes with spaces
    .trim();
}

/**
 * Combine top skills from multiple sources
 * @param {Array} adzunaSkills - Skills from Adzuna API
 * @param {Array} museSkills - Skills from The Muse API
 * @returns {Array} - Combined and deduplicated skills
 */
function combineTopSkills(adzunaSkills, museSkills) {
  // Combine skills from different sources and remove duplicates
  const allSkills = [...adzunaSkills, ...museSkills];
  
  // Group by skill name
  const skillGroups = {};
  
  allSkills.forEach(skill => {
    const skillKey = skill.name.toLowerCase();
    
    if (!skillGroups[skillKey]) {
      skillGroups[skillKey] = {
        name: skill.name,
        sources: [],
        demand: skill.demand || 'Medium',
        percentageOfJobs: skill.percentageOfJobs || 0,
        growthRate: skill.growthRate || 0
      };
    }
    
    // Add source if not already included
    const source = skill.source || (skill.percentageOfJobs ? 'Adzuna' : 'The Muse');
    if (!skillGroups[skillKey].sources.includes(source)) {
      skillGroups[skillKey].sources.push(source);
    }
    
    // Take highest demand rating
    const demandRanking = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
    const currentDemand = skillGroups[skillKey].demand || 'Low';
    const newDemand = skill.demand || 'Low';
    
    if (demandRanking[newDemand] > demandRanking[currentDemand]) {
      skillGroups[skillKey].demand = newDemand;
    }
    
    // Take highest growth rate
    if (skill.growthRate > skillGroups[skillKey].growthRate) {
      skillGroups[skillKey].growthRate = skill.growthRate;
    }
    
    // Take highest percentage
    if (skill.percentageOfJobs > skillGroups[skillKey].percentageOfJobs) {
      skillGroups[skillKey].percentageOfJobs = skill.percentageOfJobs;
    }
  });
  
  // Convert back to array and sort by demand and growthRate
  const combinedSkills = Object.values(skillGroups).sort((a, b) => {
    const demandRanking = { 'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1 };
    const demandDiff = demandRanking[b.demand] - demandRanking[a.demand];
    if (demandDiff !== 0) return demandDiff;
    return b.growthRate - a.growthRate;
  });

  return combinedSkills.slice(0, 15); // Return top 15 skills
}

/**
 * Get required skills for a specific job role
 * @param {String} targetRole - Target job role
 * @returns {Promise<Array>} - Array of required skills
 */
async function getRequiredSkillsForRole(targetRole) {
  try {
    // First check our predefined mapping for common roles
    const skillsByRole = {
      'software engineer': ['JavaScript', 'Python', 'Java', 'SQL', 'Git', 'Problem Solving', 'Data Structures', 'Algorithms', 'Cloud Services', 'CI/CD'],
      'frontend developer': ['HTML', 'CSS', 'JavaScript', 'React', 'Vue.js', 'TypeScript', 'UI/UX', 'Responsive Design', 'Web Performance', 'Testing'],
      'backend developer': ['Node.js', 'Python', 'Java', 'SQL', 'NoSQL', 'APIs', 'Authentication', 'Server Architecture', 'Cloud Services', 'Security'],
      'full stack developer': ['HTML', 'CSS', 'JavaScript', 'React', 'Node.js', 'SQL', 'NoSQL', 'Git', 'APIs', 'Cloud Services'],
      'data scientist': ['Python', 'R', 'SQL', 'Statistics', 'Machine Learning', 'Data Visualization', 'Big Data', 'Pandas', 'NumPy', 'TensorFlow'],
      'data analyst': ['SQL', 'Excel', 'Python', 'Data Visualization', 'Statistics', 'Business Intelligence', 'Tableau', 'Power BI', 'Communication'],
      'product manager': ['Market Research', 'Product Strategy', 'User Research', 'Agile', 'Communication', 'Analytics', 'Roadmapping', 'Stakeholder Management'],
      'ux designer': ['User Research', 'Wireframing', 'Prototyping', 'UI Design', 'Usability Testing', 'Figma', 'Sketch', 'Design Thinking', 'Information Architecture'],
      'devops engineer': ['Docker', 'Kubernetes', 'CI/CD', 'Cloud Platforms', 'Linux', 'Scripting', 'Monitoring', 'Infrastructure as Code', 'Security'],
      'machine learning engineer': ['Python', 'TensorFlow', 'PyTorch', 'Machine Learning', 'Deep Learning', 'Math', 'Statistics', 'Data Preprocessing', 'Model Deployment']
    };
    
    // Normalize the target role to lowercase for matching
    const targetRoleLower = targetRole.toLowerCase();
    
    // Check for exact match or partial match
    for (const [role, skills] of Object.entries(skillsByRole)) {
      if (targetRoleLower === role || targetRoleLower.includes(role)) {
        return skills;
      }
    }
    
    // If we don't have a predefined mapping, search job listings in real-time
    logApiCall('Skill Analysis', 'required skills', true, `No predefined skills for "${targetRole}", searching job listings...`);
    
    // Attempt to use Adzuna API to get real job listings for this role
    if (ADZUNA_APP_ID && ADZUNA_API_KEY) {
      try {
        const country = 'us'; // Default to US
        const searchUrl = `https://api.adzuna.com/v1/api/jobs/${country}/search/1`;
        
        const response = await axios.get(searchUrl, {
          params: {
            app_id: ADZUNA_APP_ID,
            app_key: ADZUNA_API_KEY,
            results_per_page: 20,
            what: targetRole
          },
          timeout: API_TIMEOUT
        });
        
        if (response.data && response.data.results && response.data.results.length > 0) {
          // Extract skills from job descriptions
          const extractedSkills = extractSkillsFromJobDescriptions(response.data.results);
          
          // If we found at least 5 skills, return them
          if (extractedSkills.length >= 5) {
            logApiCall('Skill Analysis', 'required skills', true, `Found ${extractedSkills.length} skills from job listings`);
            return extractedSkills;
          }
          
          // If we found some but fewer than 5 skills, supplement with common skills
          if (extractedSkills.length > 0) {
            const commonSkills = [
              'Communication', 'Problem Solving', 'Teamwork', 'Adaptability', 
              'Time Management', 'Critical Thinking', 'Attention to Detail'
            ];
            
            const combinedSkills = [
              ...extractedSkills,
              ...commonSkills.filter(skill => !extractedSkills.includes(skill))
            ].slice(0, 10); // Limit to 10 skills
            
            logApiCall('Skill Analysis', 'required skills', true, `Supplemented skills, total: ${combinedSkills.length}`);
            return combinedSkills;
          }
        }
      } catch (apiError) {
        logApiCall('Skill Analysis', 'required skills', false, `API error: ${apiError.message}`);
        // Fall through to default skills
      }
    }
    
    // If API fails or returns insufficient results, return generalized skills
    const defaultSkills = [
      'Communication', 'Problem Solving', 'Teamwork', 'Adaptability', 
      'Time Management', 'Technical Skills', 'Project Management', 
      'Analytical Thinking', 'Attention to Detail', 'Creativity'
    ];
    
    logApiCall('Skill Analysis', 'required skills', false, 'Using default skills set');
    return defaultSkills;
  } catch (error) {
    logApiCall('Skill Analysis', 'required skills', false, error.message);
    // Return a basic set of skills as fallback
    return ['Technical Skills', 'Communication', 'Problem Solving'];
  }
}

/**
 * Extract skills from job descriptions
 * @param {Array} jobs - Array of job listings
 * @returns {Array} - Array of extracted skills
 */
function extractSkillsFromJobDescriptions(jobs) {
  // Common skills to look for in job descriptions
  const commonSkills = [
    'JavaScript', 'Python', 'Java', 'C#', 'C++', 'Ruby', 'Go', 'Rust',
    'React', 'Angular', 'Vue', 'Node.js', 'Django', 'Flask', 'Spring',
    'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform',
    'Machine Learning', 'Data Science', 'Artificial Intelligence', 'DevOps',
    'Product Management', 'UX Design', 'UI Design', 'Cloud', 'Agile', 'Scrum',
    'SQL', 'NoSQL', 'MongoDB', 'PostgreSQL', 'MySQL', 'Oracle',
    'Git', 'CI/CD', 'Jenkins', 'GitHub Actions', 'Automation',
    'Communication', 'Problem Solving', 'Teamwork', 'Leadership',
    'Project Management', 'Analytical Thinking', 'Time Management', 'Adaptability',
    'HTML', 'CSS', 'TypeScript', 'PHP', 'Swift', 'Kotlin', 'R',
    'TensorFlow', 'PyTorch', 'Pandas', 'NumPy', 'Scikit-learn',
    'Power BI', 'Tableau', 'Excel', 'Data Analysis', 'Statistics',
    'Blockchain', 'Cybersecurity', 'Networking', 'Linux', 'Windows', 'MacOS',
    'SEO', 'Content Marketing', 'Social Media', 'Email Marketing',
    'CRM', 'Salesforce', 'HubSpot', 'Adobe Creative Suite', 'Photoshop',
    'Customer Service', 'Negotiation', 'Presentation Skills', 'Market Research',
    'Financial Analysis', 'Budgeting', 'Forecasting', 'Accounting'
  ];
  
  // Count skill occurrences
  const skillCounts = {};
  
  jobs.forEach(job => {
    const description = (job.description || '').toLowerCase();
    
    commonSkills.forEach(skill => {
      if (description.includes(skill.toLowerCase())) {
        skillCounts[skill] = (skillCounts[skill] || 0) + 1;
      }
    });
    
    // Also check for specific skill keywords in the title
    const title = (job.title || '').toLowerCase();
    commonSkills.forEach(skill => {
      if (title.includes(skill.toLowerCase())) {
        // Skills in the title get a higher count (more significant)
        skillCounts[skill] = (skillCounts[skill] || 0) + 2;
      }
    });
  });
  
  // Convert to array, sort by frequency, and return top skills
  return Object.entries(skillCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10) // Top 10 skills
    .map(([skill]) => skill);
}

/**
 * Get skill recommendations with learning resources
 * @param {Array} missingSkills - Skills the user is missing
 * @param {String} targetRole - Target job role
 * @returns {Promise<Array>} - Array of skill recommendations
 */
async function getSkillRecommendations(missingSkills, targetRole) {
  try {
    // For each missing skill, provide learning resources and recommendations
    return Promise.all(missingSkills.map(async skill => {
      // Get difficulty level
      const difficulty = estimateLearningDifficulty(skill);
      
      // Generate learning resources
      const resources = getLearningResources(skill);
      
      // Get market insight - in a production environment, this would use real data
      const insight = await getSkillMarketData(skill);
      
      // Return structured recommendation
      return {
        skill: skill,
        priority: getPriorityLevel(skill, targetRole),
        difficulty: difficulty,
        estimatedTimeToLearn: difficulty.estimatedTimeToLearn,
        marketInsight: insight.marketInsight,
        learningResources: resources
      };
    }));
  } catch (error) {
    logApiCall('Skill Recommendations', 'generate', false, error.message);
    return [];
  }
}

/**
 * Get market data for a skill from job APIs
 * @param {String} skill - Skill to analyze
 * @returns {Promise<Object>} - Market data for the skill
 */
async function getSkillMarketData(skill) {
  try {
    // If Adzuna API is configured, try to get real market data
    if (ADZUNA_APP_ID && ADZUNA_API_KEY) {
      try {
        const country = 'us';
        const searchUrl = `https://api.adzuna.com/v1/api/jobs/${country}/search/1`;
        
        const response = await axios.get(searchUrl, {
          params: {
            app_id: ADZUNA_APP_ID,
            app_key: ADZUNA_API_KEY,
            results_per_page: 1,
            what: skill,
            // Just get the count, not actual results
            what_and: 'jobs'
          },
          timeout: API_TIMEOUT / 2 // Use shorter timeout for this lookup
        });
        
        // Get the count of jobs mentioning this skill
        const jobCount = response.data?.count || 0;
        
        // Determine demand level based on job count
        let demand = 'Low';
        if (jobCount > 10000) demand = 'Very High';
        else if (jobCount > 5000) demand = 'High';
        else if (jobCount > 1000) demand = 'Medium';
        
        // Generate a growth rate (this would be based on historical data in production)
        const growthRate = 5 + Math.floor(Math.random() * 30); // 5-35% (placeholder)
        
        // Try to get historical data to calculate real growth
        try {
          const historyUrl = `https://api.adzuna.com/v1/api/jobs/${country}/history`;
          
          const historyResponse = await axios.get(historyUrl, {
            params: {
              app_id: ADZUNA_APP_ID,
              app_key: ADZUNA_API_KEY,
              what: skill,
              months: 3 // Get data for last 3 months
            },
            timeout: API_TIMEOUT / 2
          });
          
          if (historyResponse.data && historyResponse.data.month) {
            const months = Object.keys(historyResponse.data.month).sort();
            
            // Calculate growth rate if we have at least 2 months of data
            if (months.length >= 2) {
              const firstMonth = historyResponse.data.month[months[0]];
              const lastMonth = historyResponse.data.month[months[months.length - 1]];
              
              if (firstMonth > 0) {
                const calculatedGrowthRate = ((lastMonth - firstMonth) / firstMonth) * 100;
                // Use the calculated growth rate instead of the random one
                logApiCall('Skill Market Data', 'growth', true, `Real calculated growth rate: ${calculatedGrowthRate.toFixed(1)}%`);
                return {
                  demand,
                  growthRate: parseFloat(calculatedGrowthRate.toFixed(1)),
                  jobCount,
                  marketInsight: generateMarketInsight(demand, parseFloat(calculatedGrowthRate.toFixed(1)), jobCount)
                };
              }
            }
          }
        } catch (historyError) {
          logApiCall('Skill Market Data', 'history', false, historyError.message);
          // Continue with the simulated growth rate
        }
        
        logApiCall('Skill Market Data', 'count', true, `Job count: ${jobCount}, using simulated growth rate`);
        return {
          demand,
          growthRate,
          jobCount,
          marketInsight: generateMarketInsight(demand, growthRate, jobCount)
        };
      } catch (apiError) {
        logApiCall('Skill Market Data', 'API', false, apiError.message);
        // Fall through to simulated data
      }
    }
    
    // If we don't have API access or it failed, generate reasonable simulated data
    const commonSkillData = {
      'javascript': { demand: 'Very High', growthRate: 28 },
      'python': { demand: 'Very High', growthRate: 32 },
      'java': { demand: 'High', growthRate: 15 },
      'c#': { demand: 'High', growthRate: 12 },
      'react': { demand: 'Very High', growthRate: 30 },
      'angular': { demand: 'High', growthRate: 18 },
      'vue': { demand: 'High', growthRate: 25 },
      'node.js': { demand: 'High', growthRate: 22 },
      'aws': { demand: 'Very High', growthRate: 35 },
      'azure': { demand: 'High', growthRate: 29 },
      'docker': { demand: 'High', growthRate: 27 },
      'kubernetes': { demand: 'High', growthRate: 31 },
      'machine learning': { demand: 'Very High', growthRate: 40 },
      'data science': { demand: 'Very High', growthRate: 38 },
      'devops': { demand: 'High', growthRate: 33 },
      'sql': { demand: 'High', growthRate: 20 },
      'nosql': { demand: 'Medium', growthRate: 22 },
      'git': { demand: 'High', growthRate: 15 },
      'agile': { demand: 'Medium', growthRate: 18 },
      'scrum': { demand: 'Medium', growthRate: 16 }
    };
    
    // Check if we have pre-defined data for this skill
    const skillLower = skill.toLowerCase();
    if (commonSkillData[skillLower]) {
      const data = commonSkillData[skillLower];
      return {
        demand: data.demand,
        growthRate: data.growthRate,
        jobCount: null, // No actual count available
        marketInsight: generateMarketInsight(data.demand, data.growthRate)
      };
    }
    
    // Generate reasonable default values for other skills
    const demand = ['Low', 'Medium', 'High', 'Very High'][Math.floor(Math.random() * 4)];
    const growthRate = Math.floor(Math.random() * 30) + 5; // 5-35% (simulated)
    
    logApiCall('Skill Market Data', 'simulated', true, `Generated simulated data for ${skill}`);
    return {
      demand,
      growthRate,
      jobCount: null,
      marketInsight: generateMarketInsight(demand, growthRate)
    };
  } catch (error) {
    logApiCall('Skill Market Data', 'error', false, error.message);
    
    // Return fallback data
    const demand = 'Medium';
    const growthRate = 15;
    
    return {
      demand,
      growthRate,
      jobCount: null,
      marketInsight: generateMarketInsight(demand, growthRate)
    };
  }
}

/**
 * Generate market insight text for a skill
 * @param {String} demand - Demand level (Low, Medium, High, Very High)
 * @param {Number} growthRate - Growth rate percentage
 * @param {Number} jobCount - Number of job postings (optional)
 * @returns {String} - Market insight text
 */
function generateMarketInsight(demand, growthRate, jobCount = null) {
  const demandText = {
    'Very High': 'extremely high demand',
    'High': 'high demand',
    'Medium': 'moderate demand',
    'Low': 'lower demand'
  };
  
  const growthText = growthRate >= 25 ? 'rapidly growing' : 
                    growthRate >= 15 ? 'growing steadily' :
                    growthRate >= 5 ? 'showing stable growth' :
                    growthRate >= 0 ? 'maintaining consistent demand' :
                    'declining somewhat';
  
  let jobCountText = '';
  if (jobCount !== null) {
    jobCountText = ` with ${jobCount.toLocaleString()} current job postings`;
  }
  
  if (demand === 'Very High' && growthRate >= 20) {
    return `This skill is in ${demandText[demand]}${jobCountText} and ${growthText}, making it an excellent focus for career development.`;
  } else if ((demand === 'Very High' || demand === 'High') && growthRate >= 10) {
    return `With ${demandText[demand]}${jobCountText} that is ${growthText}, this skill offers strong career opportunities.`;
  } else if ((demand === 'Very High' || demand === 'High') && growthRate < 10) {
    return `This skill is in ${demandText[demand]}${jobCountText} currently, though growth is modest.`;
  } else if (demand === 'Medium' && growthRate >= 15) {
    return `While in ${demandText[demand]}${jobCountText} now, this skill is ${growthText} and may offer future opportunities.`;
  } else if (demand === 'Medium') {
    return `This skill has ${demandText[demand]}${jobCountText} in the current job market.`;
  } else if (demand === 'Low' && growthRate >= 20) {
    return `Though currently in ${demandText[demand]}${jobCountText}, this skill is ${growthText} and may be worth watching.`;
  } else {
    return `This skill shows ${demandText[demand]}${jobCountText} in the current job market.`;
  }
}

/**
 * Get priority level for a skill based on the target role
 * @param {String} skill - Skill to analyze
 * @param {String} targetRole - Target job role
 * @returns {String} - Priority level (High, Medium, Low)
 */
function getPriorityLevel(skill, targetRole) {
  // Normalize inputs
  const skillLower = skill.toLowerCase();
  const roleLower = targetRole.toLowerCase();
  
  // Core skills for common roles
  const coreSkillsByRole = {
    'software engineer': ['javascript', 'python', 'algorithms', 'data structures', 'git', 'apis'],
    'web developer': ['html', 'css', 'javascript', 'react', 'responsive', 'apis'],
    'frontend developer': ['html', 'css', 'javascript', 'react', 'ui', 'responsive'],
    'backend developer': ['apis', 'databases', 'sql', 'node.js', 'python', 'java', 'authentication'],
    'full stack developer': ['javascript', 'html', 'css', 'node.js', 'apis', 'databases'],
    'data scientist': ['python', 'statistics', 'machine learning', 'sql', 'data visualization'],
    'data analyst': ['sql', 'excel', 'data visualization', 'statistics', 'dashboards'],
    'product manager': ['product strategy', 'user research', 'agile', 'roadmap', 'requirements'],
    'ux designer': ['user research', 'wireframing', 'prototyping', 'usability testing'],
    'devops': ['docker', 'kubernetes', 'ci/cd', 'cloud', 'infrastructure', 'monitoring'],
    'machine learning': ['python', 'tensorflow', 'pytorch', 'machine learning', 'algorithms']
  };
  
  // Check if skill is core for target role
  for (const [role, skills] of Object.entries(coreSkillsByRole)) {
    if (roleLower.includes(role) && skills.some(s => skillLower.includes(s) || s.includes(skillLower))) {
      return 'High';
    }
  }
  
  // For less specific matching
  if (
    (skillLower.includes('java') && roleLower.includes('develop')) ||
    (skillLower.includes('python') && (roleLower.includes('data') || roleLower.includes('machine'))) ||
    (skillLower.includes('sql') && roleLower.includes('data')) ||
    (skillLower.includes('ui') && roleLower.includes('design')) ||
    (skillLower.includes('agile') && roleLower.includes('manager')) ||
    (skillLower.includes('cloud') && (roleLower.includes('devops') || roleLower.includes('infrastructure')))
  ) {
    return 'High';
  }
  
  // Check if skill is generally valuable (soft skills, general tech skills)
  const valuableSkills = [
    'communication', 'problem solving', 'teamwork', 'git', 'project management',
    'critical thinking', 'adaptability', 'time management', 'leadership',
    'collaboration', 'analytical thinking', 'creativity'
  ];
  
  if (valuableSkills.includes(skillLower)) {
    return 'Medium';
  }
  
  // Default priority
  return 'Medium';
}

/**
 * Get learning resources for a specific skill
 * @param {String} skill - Skill to find resources for
 * @returns {Array} - Array of learning resources
 */
function getLearningResources(skill) {
  // Normalize skill name
  const skillLower = skill.toLowerCase();
  
  // Common learning platforms
  const platforms = [
    { name: 'Udemy', url: 'https://www.udemy.com' },
    { name: 'Coursera', url: 'https://www.coursera.org' },
    { name: 'edX', url: 'https://www.edx.org' },
    { name: 'Pluralsight', url: 'https://www.pluralsight.com' },
    { name: 'LinkedIn Learning', url: 'https://www.linkedin.com/learning' },
    { name: 'freeCodeCamp', url: 'https://www.freecodecamp.org' },
    { name: 'YouTube', url: 'https://www.youtube.com' }
  ];
  
  // Specific resources for common skills
  const specificResources = {
    'javascript': [
      { name: 'JavaScript: Understanding the Weird Parts', platform: 'Udemy', url: 'https://www.udemy.com/course/understand-javascript/', rating: 4.8 },
      { name: 'Eloquent JavaScript', platform: 'Book', url: 'https://eloquentjavascript.net/', rating: 4.7 },
      { name: 'JavaScript30', platform: 'Free Course', url: 'https://javascript30.com/', rating: 4.9 }
    ],
    'python': [
      { name: 'Complete Python Bootcamp', platform: 'Udemy', url: 'https://www.udemy.com/course/complete-python-bootcamp/', rating: 4.6 },
      { name: 'Python for Everybody', platform: 'Coursera', url: 'https://www.coursera.org/specializations/python', rating: 4.8 },
      { name: 'Automate the Boring Stuff with Python', platform: 'Book', url: 'https://automatetheboringstuff.com/', rating: 4.7 }
    ],
    'react': [
      { name: 'React - The Complete Guide', platform: 'Udemy', url: 'https://www.udemy.com/course/react-the-complete-guide-incl-redux/', rating: 4.7 },
      { name: 'React Documentation', platform: 'Official Docs', url: 'https://reactjs.org/docs/getting-started.html', rating: 4.9 },
      { name: 'Full Stack Open', platform: 'Free Course', url: 'https://fullstackopen.com/en/', rating: 4.8 }
    ],
    'machine learning': [
      { name: 'Machine Learning by Andrew Ng', platform: 'Coursera', url: 'https://www.coursera.org/learn/machine-learning', rating: 4.9 },
      { name: 'Machine Learning A-Z', platform: 'Udemy', url: 'https://www.udemy.com/course/machinelearning/', rating: 4.6 },
      { name: 'TensorFlow Developer Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/tensorflow-in-practice', rating: 4.8 }
    ],
    'sql': [
      { name: 'The Complete SQL Bootcamp', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-sql-bootcamp/', rating: 4.7 },
      { name: 'SQL for Data Science', platform: 'Coursera', url: 'https://www.coursera.org/learn/sql-for-data-science', rating: 4.6 },
      { name: 'Mode SQL Tutorial', platform: 'Mode', url: 'https://mode.com/sql-tutorial/', rating: 4.8 }
    ],
    'data science': [
      { name: 'Data Science Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/jhu-data-science', rating: 4.6 },
      { name: 'Data Science A-Z', platform: 'Udemy', url: 'https://www.udemy.com/course/datascience/', rating: 4.5 },
      { name: 'DataCamp', platform: 'DataCamp', url: 'https://www.datacamp.com/tracks/data-scientist-with-python', rating: 4.7 }
    ],
    'docker': [
      { name: 'Docker & Kubernetes: The Practical Guide', platform: 'Udemy', url: 'https://www.udemy.com/course/docker-kubernetes-the-practical-guide/', rating: 4.8 },
      { name: 'Docker for Developers', platform: 'LinkedIn Learning', url: 'https://www.linkedin.com/learning/docker-for-developers', rating: 4.6 },
      { name: 'Docker Documentation', platform: 'Official Docs', url: 'https://docs.docker.com/get-started/', rating: 4.5 }
    ],
    'aws': [
      { name: 'AWS Certified Solutions Architect', platform: 'A Cloud Guru', url: 'https://acloudguru.com/course/aws-certified-solutions-architect-associate-saa-c02', rating: 4.8 },
      { name: 'AWS Fundamentals', platform: 'Coursera', url: 'https://www.coursera.org/specializations/aws-fundamentals', rating: 4.6 },
      { name: 'AWS Developer Guide', platform: 'Official Docs', url: 'https://docs.aws.amazon.com/sdk-for-javascript/index.html', rating: 4.7 }
    ],
    'cloud computing': [
      { name: 'Cloud Computing Specialization', platform: 'Coursera', url: 'https://www.coursera.org/specializations/cloud-computing', rating: 4.5 },
      { name: 'The Complete Cloud Computing Course', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-cloud-computing-course/', rating: 4.3 },
      { name: 'Cloud Fundamentals', platform: 'Pluralsight', url: 'https://www.pluralsight.com/paths/cloud-fundamentals', rating: 4.6 }
    ],
    'html': [
      { name: 'The Complete HTML & CSS Bootcamp', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-web-developer-bootcamp/', rating: 4.7 },
      { name: 'HTML & CSS is Hard', platform: 'Tutorial', url: 'https://www.internetingishard.com/html-and-css/', rating: 4.9 },
      { name: 'freeCodeCamp HTML Certification', platform: 'freeCodeCamp', url: 'https://www.freecodecamp.org/learn/responsive-web-design/', rating: 4.8 }
    ],
    'css': [
      { name: 'CSS - The Complete Guide', platform: 'Udemy', url: 'https://www.udemy.com/course/css-the-complete-guide-incl-flexbox-grid-sass/', rating: 4.7 },
      { name: 'CSS Tricks', platform: 'Website', url: 'https://css-tricks.com/', rating: 4.9 },
      { name: 'Learn CSS', platform: 'web.dev', url: 'https://web.dev/learn/css/', rating: 4.8 }
    ],
    'ux design': [
      { name: 'Google UX Design Professional Certificate', platform: 'Coursera', url: 'https://www.coursera.org/professional-certificates/google-ux-design', rating: 4.8 },
      { name: 'The Complete App Design Course', platform: 'Udemy', url: 'https://www.udemy.com/course/the-complete-app-design-course-ux-and-ui-design/', rating: 4.6 },
      { name: 'Design Lab UX Academy', platform: 'Design Lab', url: 'https://trydesignlab.com/ux-design-course/', rating: 4.7 }
    ]
  };
  
  // Return specific resources if available
  if (specificResources[skillLower]) {
    return specificResources[skillLower];
  }
  
  // For skills we need to find partial matches
  for (const [key, resources] of Object.entries(specificResources)) {
    if (skillLower.includes(key) || key.includes(skillLower)) {
      return resources;
    }
  }
  
  // Generate generic resources for other skills
  const randomPlatforms = [...platforms]
    .sort(() => 0.5 - Math.random())
    .slice(0, 3);
  
  return randomPlatforms.map(platform => ({
    name: `${skill} Fundamentals`,
    platform: platform.name,
    url: `${platform.url}/search?q=${encodeURIComponent(skill)}`,
    rating: (4 + Math.random()).toFixed(1) // Random rating between 4.0 and 5.0
  }));
}

/**
 * Estimate learning difficulty for a skill based on its name/category
 * @param {String} skillName - Skill to analyze
 * @returns {Object} - Difficulty assessment
 */
function estimateLearningDifficulty(skillName) {
  const skillLower = skillName.toLowerCase();

  const difficultSkills = new Set([
    'machine learning', 'artificial intelligence', 'deep learning', 'data science',
    'blockchain', 'quantum computing', 'neural networks', 'cybersecurity',
    'system architecture', 'microservices', 'devops', 'cloud architecture',
    'distributed systems', 'compiler design', 'cryptography', 'computer vision'
  ]);

  const moderateSkills = new Set([
    'python', 'javascript', 'java', 'c++', 'c#', 'react', 'angular', 'vue',
    'node.js', 'sql', 'database', 'aws', 'azure', 'cloud', 'docker',
    'kubernetes', 'data analysis', 'mobile development', 'backend',
    'testing', 'api development', 'web security', 'performance optimization',
    'algorithms', 'data structures', 'design patterns', 'responsive design'
  ]);

  let difficulty = 'easy';
  let level = 1;

  if (difficultSkills.has(skillLower)) {
    difficulty = 'hard';
    level = 3;
  } else if (moderateSkills.has(skillLower)) {
    difficulty = 'moderate';
    level = 2;
  }

  return {
    skill: skillName,
    difficulty,
    level // 1 = easy, 2 = moderate, 3 = hard
  };
}


/**
 * Get job listings from The Muse API
 * @param {Array} skills - Array of skill names
 * @param {String} industry - Industry to filter by
 * @returns {Promise<Array>} - Array of job listings
 */
async function getMuseJobs(skills, industry) {
  try {
    if (!MUSE_API_KEY) {
      logApiCall('The Muse', 'jobs', false, 'Missing API key');
      return [];
    }

    // The Muse API endpoints
    const baseUrl = 'https://www.themuse.com/api/public/jobs';
    
    // Convert industry to category parameter if present
    // The Muse uses specific category IDs, this is a simplified mapping
    const categoryMapping = {
      'technology': 'Engineering',
      'engineering': 'Engineering',
      'software': 'Engineering',
      'data': 'Data Science',
      'business': 'Business',
      'marketing': 'Marketing',
      'design': 'Design',
      'product': 'Product',
      'sales': 'Sales',
      'finance': 'Finance',
      'healthcare': 'Healthcare',
      'hr': 'Human Resources',
      'education': 'Education'
    };
    
    // Find matching category or default to Engineering
    let category = null;
    if (industry) {
      const industryLower = industry.toLowerCase();
      for (const [key, value] of Object.entries(categoryMapping)) {
        if (industryLower.includes(key)) {
          category = value;
          break;
        }
      }
    }
    
    const response = await axios.get(baseUrl, {
      params: {
        category: category || undefined,
        page: 1,
        api_key: MUSE_API_KEY,
        // The Muse may not directly support skill filtering via API params
        // We'll filter the results ourselves
      },
      timeout: API_TIMEOUT
    });
    
    if (!response.data || !response.data.results) {
      logApiCall('The Muse', 'jobs', false, 'No results found');
      return [];
    }
    
    logApiCall('The Muse', 'jobs', true, `Found ${response.data.results.length} jobs before filtering`);
    
    // Filter jobs based on skills match and map to standard format
    const skillKeywords = skills.map(skill => skill.toLowerCase());
    
    const filteredJobs = response.data.results
      .filter(job => {
        // Check if job description contains any of the skills
        const jobDescription = (job.description || '').toLowerCase();
        const jobName = (job.name || '').toLowerCase();
        
        return skillKeywords.some(skill => 
          jobDescription.includes(skill) || jobName.includes(skill)
        );
      })
      .map(job => ({
        id: job.id,
        title: job.name || 'Unknown Position',
        company: job.company?.name || 'Unknown Company',
        location: job.locations?.map(loc => loc.name).join(', ') || 'Location not specified',
        description: job.description || 'No description provided',
        salary: 'Salary not specified', // Muse doesn't provide salary info
        url: job.refs?.landing_page || '#',
        source: 'The Muse',
        postedAt: job.publication_date || new Date().toISOString()
      }));

    logApiCall('The Muse', 'jobs', true, `Found ${filteredJobs.length} jobs after filtering by skills`);
    return filteredJobs;
  } catch (error) {
    logApiCall('The Muse', 'jobs', false, error.message);
    return [];
  }
}

/**
 * Get job listings from Remotok API
 * @param {Array} skills - Array of skill names
 * @returns {Promise<Array>} - Array of job listings
 */
async function getRemotokJobs(skills) {
  try {
    if (!REMOTOK_API_KEY) {
      logApiCall('Remotok', 'jobs', false, 'Missing API key');
      return [];
    }

    // For Remotok, we're using a fallback approach if the API is unavailable
    // First try the official API
    const baseUrl = 'https://remotok.io/api/remote-jobs';
    
    try {
      const response = await axios.get(baseUrl, {
        headers: {
          'Authorization': `Bearer ${REMOTOK_API_KEY}`,
          'Content-Type': 'application/json'
        },
        timeout: API_TIMEOUT
      });
      
      if (!response.data || !Array.isArray(response.data)) {
        throw new Error('Invalid response format');
      }
      
      logApiCall('Remotok', 'jobs', true, `Found ${response.data.length} jobs before filtering`);
      
      // Filter by skills and map to standard format
      const skillKeywords = skills.map(skill => skill.toLowerCase());
      
      const filteredJobs = response.data
        .filter(job => {
          const jobTitle = (job.title || '').toLowerCase();
          const jobDescription = (job.description || '').toLowerCase();
          const jobSkills = (job.skills || []).map(s => s.toLowerCase());
          
          return skillKeywords.some(skill => 
            jobTitle.includes(skill) || 
            jobDescription.includes(skill) || 
            jobSkills.includes(skill)
          );
        })
        .map(job => ({
          id: job.id || `remotok-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          title: job.title || 'Remote Position',
          company: job.company_name || 'Unknown Company',
          location: 'Remote',
          description: job.description || 'No description provided',
          salary: job.salary || 'Salary not specified',
          url: job.url || '#',
          source: 'Remotok',
          postedAt: job.date || new Date().toISOString()
        }));

      logApiCall('Remotok', 'jobs', true, `Found ${filteredJobs.length} jobs after filtering by skills`);
      return filteredJobs;
    } catch (apiError) {
      // If official API fails, try the fallback to an alternative remote jobs listing
      logApiCall('Remotok', 'jobs - official API', false, apiError.message);
      logApiCall('Remotok', 'jobs', false, 'Attempting fallback to alternative remote jobs source');
      
      // Fallback to GitHub Jobs API or similar
      const fallbackResponse = await axios.get('https://remotive.com/api/remote-jobs', {
        timeout: API_TIMEOUT
      });
      
      if (!fallbackResponse.data || !fallbackResponse.data.jobs) {
        throw new Error('Fallback API returned invalid response');
      }
      
      // Filter and map fallback results
      const skillKeywords = skills.map(skill => skill.toLowerCase());
      
      const fallbackJobs = fallbackResponse.data.jobs
        .filter(job => {
          const jobTitle = (job.title || '').toLowerCase();
          const jobDescription = (job.description || '').toLowerCase();
          
          return skillKeywords.some(skill => 
            jobTitle.includes(skill) || jobDescription.includes(skill)
          );
        })
        .map(job => ({
          id: job.id || `remote-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          title: job.title || 'Remote Position',
          company: job.company_name || 'Unknown Company',
          location: 'Remote',
          description: job.description || 'No description provided',
          salary: job.salary || 'Salary not specified',
          url: job.url || job.apply_url || '#',
          source: 'Remotive (Fallback)',
          postedAt: job.publication_date || new Date().toISOString()
        }));

      logApiCall('Remotok', 'jobs - fallback', true, `Found ${fallbackJobs.length} jobs after filtering by skills`);
      return fallbackJobs;
    }
  } catch (error) {
    logApiCall('Remotok', 'jobs', false, error.message);
    return [];
  }
}

/**
 * Get job listings from LinkedIn API
 * @param {String} accessToken - LinkedIn access token
 * @param {Array} skills - Array of skill names
 * @param {String} location - Location for job search
 * @returns {Promise<Array>} - Array of job listings
 */
async function getLinkedInJobs(accessToken, skills, location) {
  try {
    if (!accessToken || !LINKEDIN_CLIENT_ID || !LINKEDIN_CLIENT_SECRET) {
      logApiCall('LinkedIn', 'jobs', false, 'Missing API credentials or access token');
      return [];
    }

    // Create search criteria based on skills
    const skillsQuery = skills.slice(0, 2).join(' ');
    
    // For LinkedIn, their Jobs Search API is actually very limited for third-party apps
    // This implementation assumes you have appropriate access level (which most apps won't have)
    
    // First validate that the token is still active
    try {
      const profileCheck = await axios.get('https://api.linkedin.com/v2/me', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        timeout: API_TIMEOUT
      });
      
      if (!profileCheck.data || !profileCheck.data.id) {
        throw new Error('LinkedIn token validation failed');
      }
      
      logApiCall('LinkedIn', 'token validation', true, 'Token is valid');
    } catch (tokenError) {
      logApiCall('LinkedIn', 'token validation', false, tokenError.message);
      throw new Error('LinkedIn access token is invalid or expired');
    }
    
    // Try to call Jobs Search API (note: this might not be available with standard API access)
    try {
      const response = await axios.get('https://api.linkedin.com/v2/jobSearch', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        params: {
          keywords: skillsQuery,
          location: location,
          count: 10
        },
        timeout: API_TIMEOUT
      });
      
      // Check if we received valid data
      if (!response.data || !response.data.elements) {
        throw new Error('LinkedIn API returned invalid response format');
      }
      
      logApiCall('LinkedIn', 'jobs', true, `Found ${response.data.elements.length} jobs`);
      
      return response.data.elements.map(job => ({
        id: job.entityUrn || `linkedin-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        title: job.title || 'Position at LinkedIn',
        company: job.companyDetails?.companyName || 'Company on LinkedIn',
        location: job.formattedLocation || location || 'Location not specified',
        description: job.description || 'No description provided',
        salary: 'Salary not specified',
        url: job.entityUrn ? `https://www.linkedin.com/jobs/view/${job.entityUrn.split(':').pop()}` : '#',
        source: 'LinkedIn',
        postedAt: job.listedAt || new Date().toISOString()
      }));
    } catch (apiError) {
      // If the Jobs Search API fails, we'll use a fallback approach
      logApiCall('LinkedIn', 'jobs API', false, apiError.message);
      logApiCall('LinkedIn', 'jobs', false, 'Using fallback approach for LinkedIn jobs');
      
      // Fallback: Return simulated LinkedIn job results based on the user's skills
      // In a production app, you'd want to implement an alternative LinkedIn integration
      
      // These are placeholder jobs that simulate what LinkedIn might return
      const simulatedJobs = [];
      const titles = [
        'Software Developer', 'Web Developer', 'Data Scientist', 
        'Product Manager', 'UX Designer', 'DevOps Engineer'
      ];
      
      const companies = [
        'TechCorp', 'InnovateSoft', 'DataDynamics', 
        'Global Solutions', 'CreativeMinds', 'CloudScale'
      ];
      
      // Generate simulated jobs based on user skills
      skills.forEach((skill, index) => {
        if (index < 3) { // Limit to 3 simulated jobs per skill
          simulatedJobs.push({
            id: `linkedin-sim-${Date.now()}-${index}`,
            title: `${titles[index % titles.length]} (${skill})`,
            company: companies[index % companies.length],
            location: location || 'Remote',
            description: `This position requires expertise in ${skill} and related technologies. Join our team to work on cutting-edge projects.`,
            salary: 'Competitive salary based on experience',
            url: 'https://www.linkedin.com/jobs/',
            source: 'LinkedIn (Simulated)',
            postedAt: new Date().toISOString()
          });
        }
      });
      
      logApiCall('LinkedIn', 'jobs fallback', true, `Generated ${simulatedJobs.length} simulated jobs`);
      return simulatedJobs;
    }
  } catch (error) {
    logApiCall('LinkedIn', 'jobs', false, error.message);
    return [];
  }
}

/**
 * Get personalized job recommendations based on user profile and preferences
 * @route   GET api/career/jobs
 * @desc    Get job recommendations
 * @access  Private
 */
exports.getJobRecommendations = async (req, res) => {
  try {
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Extract relevant data for job matching
    const { skills, careerGoals, linkedInProfile } = profile;
    const skillNames = skills.map(skill => skill.name);
    const location = careerGoals?.locationPreference || 'remote';
    
    // Check request parameters for filters
    const { source, limit, offset } = req.query;
    
    // Create API request promises based on filters
    const apiRequests = [];
    const apiSources = [];
    
    // If source filter is provided, only use that source
    if (source) {
      switch (source.toLowerCase()) {
        case 'adzuna':
          apiRequests.push(getAdzunaJobs(skillNames, location));
          apiSources.push('Adzuna');
          break;
        case 'muse':
        case 'themuse':
          apiRequests.push(getMuseJobs(skillNames, careerGoals?.targetIndustry));
          apiSources.push('The Muse');
          break;
        case 'remotok':
          apiRequests.push(getRemotokJobs(skillNames));
          apiSources.push('Remotok');
          break;
        case 'linkedin':
          if (linkedInProfile?.accessToken) {
            apiRequests.push(getLinkedInJobs(linkedInProfile.accessToken, skillNames, location));
            apiSources.push('LinkedIn');
          } else {
            return res.status(400).json({ 
              message: 'LinkedIn source requested but account not connected. Please connect your LinkedIn account first.' 
            });
          }
          break;
        default:
          return res.status(400).json({ message: 'Invalid source parameter' });
      }
    } else {
      // Otherwise use all available sources
      apiRequests.push(getAdzunaJobs(skillNames, location));
      apiSources.push('Adzuna');
      
      apiRequests.push(getMuseJobs(skillNames, careerGoals?.targetIndustry));
      apiSources.push('The Muse');
      
      apiRequests.push(getRemotokJobs(skillNames));
      apiSources.push('Remotok');
      
      // Only add LinkedIn if connected
      if (linkedInProfile?.accessToken) {
        apiRequests.push(getLinkedInJobs(linkedInProfile.accessToken, skillNames, location));
        apiSources.push('LinkedIn');
      }
    }
    
    // Execute all API requests concurrently
    const results = await Promise.allSettled(apiRequests);
    
    // Track API status for client diagnostics
    const apiStatus = {};
    
    // Combine results, handling rejected promises
    let allJobs = [];
    results.forEach((result, index) => {
      const sourceName = apiSources[index];
      
      if (result.status === 'fulfilled') {
        allJobs = [...allJobs, ...result.value];
        apiStatus[sourceName] = { 
          status: 'success', 
          count: result.value.length 
        };
      } else {
        apiStatus[sourceName] = { 
          status: 'failed', 
          error: result.reason.message 
        };
        console.error(`Error fetching jobs from ${sourceName}:`, result.reason);
      }
    });
    
    // Process and filter job recommendations
    const uniqueJobs = removeDuplicateJobs(allJobs);
    const rankedJobs = rankJobsByRelevance(uniqueJobs, profile);
    
    // Apply pagination
    const pageSize = parseInt(limit) || 15;
    const pageOffset = parseInt(offset) || 0;
    const paginatedJobs = rankedJobs.slice(pageOffset, pageOffset + pageSize);
    
    // Track this request in user profile for analytics
    try {
      // Initialize searchHistory if it doesn't exist
      if (!profile.searchHistory) {
        profile.searchHistory = [];
      }
      
      // Add search to history
      profile.searchHistory.push({
        timestamp: new Date(),
        query: {
          skills: skillNames,
          location: location,
          source: source || 'all'
        },
        results: uniqueJobs.length
      });
      
      // Keep only the last 20 searches
      if (profile.searchHistory.length > 20) {
        profile.searchHistory = profile.searchHistory.slice(-20);
      }
      
      await profile.save();
    } catch (historyError) {
      console.error('Failed to save search history:', historyError.message);
    }
    
    // Return jobs with metadata
    res.json({
      jobs: paginatedJobs,
      meta: {
        total: rankedJobs.length,
        offset: pageOffset,
        limit: pageSize,
        hasMore: (pageOffset + pageSize) < rankedJobs.length
      },
      stats: {
        total: allJobs.length,
        unique: uniqueJobs.length,
        sources: {
          adzuna: allJobs.filter(job => job.source === 'Adzuna').length,
          muse: allJobs.filter(job => job.source === 'The Muse').length,
          remotok: allJobs.filter(job => job.source.includes('Remot')).length,
          linkedin: allJobs.filter(job => job.source.includes('LinkedIn')).length
        }
      },
      apiStatus
    });
  } catch (err) {
    console.error('Job recommendations error:', err.message);
    res.status(500).json({ message: 'Server error getting job recommendations' });
  }
};

/**
 * Remove duplicate job listings from different sources
 * @param {Array} jobs - Array of job listings
 * @returns {Array} - Deduplicated array of job listings
 */
function removeDuplicateJobs(jobs) {
  const uniqueJobs = {};
  
  jobs.forEach(job => {
    // Create a unique key using title and company
    const key = `${job.title}-${job.company}`.toLowerCase().replace(/\s+/g, '');
    
    // If job doesn't exist or current job is newer, add/update it
    if (!uniqueJobs[key] || new Date(job.postedAt) > new Date(uniqueJobs[key].postedAt)) {
      uniqueJobs[key] = job;
    }
  });
  
  return Object.values(uniqueJobs);
}

/**
 * Rank jobs by relevance to user profile
 * @param {Array} jobs - Array of job listings
 * @param {Object} profile - User profile
 * @returns {Array} - Ranked array of job listings
 */
function rankJobsByRelevance(jobs, profile) {
  // Get user skills and preferences
  const userSkills = profile.skills.map(skill => skill.name.toLowerCase());
  const careerGoals = profile.careerGoals || {};
  
  // Score and rank jobs
  const scoredJobs = jobs.map(job => {
    let score = 0;
    
    // Check title relevance to career goals
    if (careerGoals.shortTermGoal && 
        job.title.toLowerCase().includes(careerGoals.shortTermGoal.toLowerCase())) {
      score += 30;
    }
    
    // Check industry match
    if (careerGoals.targetIndustry && 
        job.description.toLowerCase().includes(careerGoals.targetIndustry.toLowerCase())) {
      score += 20;
    }
    
    // Check location preference
    if (careerGoals.locationPreference === 'remote' && 
        job.location.toLowerCase().includes('remote')) {
      score += 15;
    } else if (careerGoals.locationPreference && 
               job.location.toLowerCase().includes(careerGoals.locationPreference.toLowerCase())) {
      score += 15;
    }
    
    // Check skills match
    userSkills.forEach(skill => {
      if (job.title.toLowerCase().includes(skill) || 
          job.description.toLowerCase().includes(skill)) {
        score += 10;
      }
    });
    
    // Check for salary info - jobs with salary info are slightly preferred
    if (job.salary && !job.salary.includes('not specified')) {
      score += 5;
    }
    
    // Recency bonus
    const daysAgo = (new Date() - new Date(job.postedAt)) / (1000 * 60 * 60 * 24);
    score += Math.max(0, 15 - daysAgo); // Newer jobs get higher scores
    
    return { ...job, relevanceScore: score };
  });
  
  // Sort by relevance score (descending)
  return scoredJobs.sort((a, b) => b.relevanceScore - a.relevanceScore);
}

/**
 * Get job market trends from Adzuna and other sources
 * @route   GET api/career/job-market
 * @desc    Get job market trends
 * @access  Private
 */
exports.getJobMarketTrends = async (req, res) => {
  try {
    // Parameters for filtering
    const { location, industry, jobTitle } = req.query;
    
    // Get job market trends from Adzuna API
    const adzunaTrends = await getAdzunaJobTrends(location, industry, jobTitle);
    
    // Get job market trends from The Muse API
    const museTrends = await getMuseJobTrends(industry, jobTitle);
    
    // Combine and process the data
    const jobMarketTrends = {
      demandTrends: adzunaTrends.demandTrends || [],
      salaryTrends: adzunaTrends.salaryTrends || [],
      topIndustries: adzunaTrends.topIndustries || [],
      topSkills: combineTopSkills(adzunaTrends.topSkills || [], museTrends.topSkills || []),
      popularJobs: museTrends.popularJobs || [],
      locationInsights: adzunaTrends.locationInsights || [],
      recentTrends: museTrends.recentTrends || []
    };
    
    // Add tracking for analytics
    try {
      // Get user profile
      const profile = await Profile.findOne({ user: req.user.id });
      if (profile) {
        // Initialize marketInsightHistory if it doesn't exist
        if (!profile.marketInsightHistory) {
          profile.marketInsightHistory = [];
        }

        // Add search to history
        profile.marketInsightHistory.push({
          timestamp: new Date(),
          query: { location, industry, jobTitle },
        });

        // Keep only the last 10 insights
        if (profile.marketInsightHistory.length > 10) {
          profile.marketInsightHistory = profile.marketInsightHistory.slice(-10);
        }

        await profile.save();
      }
    } catch (historyError) {
      console.error('Failed to save market insight history:', historyError.message);
    }
    
    res.json(jobMarketTrends);
  } catch (err) {
    console.error('Job market trends error:', err.message);
    res.status(500).json({ 
      message: 'Server error retrieving job market trends',
      error: err.message
    });
  }
};

/**
 * Get job trends from Adzuna API
 * @param {String} location - Location to filter by
 * @param {String} industry - Industry to filter by
 * @param {String} jobTitle - Job title to filter by
 * @returns {Promise<Object>} - Job trends data
 */
async function getAdzunaJobTrends(location, industry, jobTitle) {
  try {
    if (!ADZUNA_APP_ID || !ADZUNA_API_KEY) {
      logApiCall('Adzuna', 'trends', false, 'Missing API credentials');
      return {
        demandTrends: [],
        salaryTrends: [],
        topIndustries: [],
        topSkills: [],
        locationInsights: []
      };
    }
    
    // Determine country code based on location or default to 'us'
    let country = 'us';
    // Map of common countries to their country codes
    const countryMap = {
      'united states': 'us',
      'united kingdom': 'gb',
      'australia': 'au',
      'canada': 'ca',
      'germany': 'de',
      'france': 'fr',
      'india': 'in'
    };
    
    // Check if location matches any country names
    if (location) {
      const locationLower = location.toLowerCase();
      for (const [countryName, countryCode] of Object.entries(countryMap)) {
        if (locationLower.includes(countryName)) {
          country = countryCode;
          break;
        }
      }
    }
    
    // Build the API endpoint URLs for different data points
    const baseUrl = `https://api.adzuna.com/v1/api/jobs/${country}`;
    const authParams = `app_id=${ADZUNA_APP_ID}&app_key=${ADZUNA_API_KEY}`;
    
    // Prepare query parameters
    let queryParams = '';
    if (location && !Object.values(countryMap).includes(location.toLowerCase())) {
      queryParams += `&where=${encodeURIComponent(location)}`;
    }
    if (industry) {
      queryParams += `&category=${encodeURIComponent(industry)}`;
    }
    if (jobTitle) {
      queryParams += `&what=${encodeURIComponent(jobTitle)}`;
    }
    
    // Fetch historical trends data (last 6 months)
    const historyUrl = `${baseUrl}/history?${authParams}${queryParams}`;
    const historyResponse = await axios.get(historyUrl, { timeout: 10000 });
    logApiCall('Adzuna', 'history', true);
    
    // Fetch top categories/industries data
    const categoryUrl = `${baseUrl}/top_categories?${authParams}${queryParams}`;
    const categoryResponse = await axios.get(categoryUrl, { timeout: 10000 });
    logApiCall('Adzuna', 'categories', true);
    
    // Fetch location-based insights
    const geoUrl = `${baseUrl}/geodata?${authParams}${queryParams}`;
    const geoResponse = await axios.get(geoUrl, { timeout: 10000 });
    logApiCall('Adzuna', 'geodata', true);
    
    // Fetch current job listings to extract skills (limited to 100 results)
    const searchUrl = `${baseUrl}/search/1?${authParams}${queryParams}&results_per_page=100`;
    const searchResponse = await axios.get(searchUrl, { timeout: 10000 });
    logApiCall('Adzuna', 'search', true);
    
    // Process history data for demand and salary trends
    const historyData = historyResponse.data;
    const demandTrends = [];
    const salaryTrends = [];
    
    // Process the last 6 months of data
    const months = Object.keys(historyData.month).sort().slice(-6);
    
    months.forEach(month => {
      const formattedDate = formatMonthDate(month);
      
      // Add job count data
      if (historyData.month[month] && historyData.month[month].count !== undefined) {
        demandTrends.push({
          date: formattedDate,
          jobCount: historyData.month[month].count
        });
      }
      
      // Add salary data
      if (historyData.month[month] && historyData.month[month].average !== undefined) {
        salaryTrends.push({
          date: formattedDate,
          averageSalary: Math.round(historyData.month[month].average)
        });
      }
    });
    
    // Process top industries data
    const topIndustries = [];
    if (categoryResponse.data && categoryResponse.data.leaderboard) {
      categoryResponse.data.leaderboard.forEach(category => {
        topIndustries.push({
          name: category.label,
          count: category.count,
          averageSalary: Math.round(category.average)
        });
      });
    }
    
    // Process location insights
    const locationInsights = [];
    if (geoResponse.data && geoResponse.data.leaderboard) {
      geoResponse.data.leaderboard.forEach(location => {
        locationInsights.push({
          name: location.location.display_name,
          count: location.count,
          averageSalary: Math.round(location.average)
        });
      });
    }
    
    // Extract skills from job descriptions
    const topSkills = [];
    const skillsCount = {};
    
    if (searchResponse.data && searchResponse.data.results) {
      // Define common tech and soft skills to look for
      const skillsToMatch = [
        // Technical skills
        'python', 'javascript', 'java', 'c++', 'c#', '.net', 'ruby', 'php', 'golang', 'sql',
        'react', 'angular', 'vue', 'node.js', 'django', 'flask', 'spring', 'express',
        'aws', 'azure', 'gcp', 'docker', 'kubernetes', 'terraform', 'jenkins', 'git',
        'machine learning', 'ai', 'data science', 'big data', 'blockchain',
        // Soft skills
        'communication', 'leadership', 'teamwork', 'problem solving', 'project management',
        'agile', 'scrum', 'critical thinking', 'time management', 'presentation'
      ];
      
      // Process each job listing
      searchResponse.data.results.forEach(job => {
        if (job.description) {
          const description = job.description.toLowerCase();
          
          // Look for skills in the description
          skillsToMatch.forEach(skill => {
            if (description.includes(skill.toLowerCase())) {
              if (skillsCount[skill]) {
                skillsCount[skill]++;
              } else {
                skillsCount[skill] = 1;
              }
            }
          });
        }
      });
      
      // Convert skills count to sorted array
      for (const [skill, count] of Object.entries(skillsCount)) {
        topSkills.push({
          name: skill,
          count: count,
          difficulty: getDifficultyLevel(skill)
        });
      }
      
      // Sort by count (most in-demand first)
      topSkills.sort((a, b) => b.count - a.count);
      
      // Limit to top 20 skills
      if (topSkills.length > 20) {
        topSkills.length = 20;
      }
    }
    
    return {
      demandTrends,
      salaryTrends,
      topIndustries,
      topSkills,
      locationInsights
    };
    
  } catch (err) {
    console.error('Adzuna API error:', err.message);
    logApiCall('Adzuna', 'trends', false, err.message);
    
    // Return empty structure on error
    return {
      demandTrends: [],
      salaryTrends: [],
      topIndustries: [],
      topSkills: [],
      locationInsights: []
    };
  }
}

/**
 * Format month date from Adzuna format to readable format
 * @param {String} monthStr - Month string in format YYYY/MM
 * @returns {String} - Formatted date string (e.g. "Jan 2023")
 */
function formatMonthDate(monthStr) {
  const [year, month] = monthStr.split('/');
  const date = new Date(parseInt(year), parseInt(month) - 1, 1);
  return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
}

/**
 * Get difficulty level for a given skill
 * @param {String} skill - Skill name
 * @returns {Object} - Difficulty level information
 */
function getDifficultyLevel(skill) {
  const skillLower = skill.toLowerCase();
  
  // More complex skills with steeper learning curves
  const difficultSkills = [
    'machine learning', 'ai', 'data science', 'blockchain', 'kubernetes',
    'rust', 'scala', 'haskell', 'elixir', 'hadoop', 'spark', 'tensorflow',
    'pytorch', 'computer vision', 'nlp', 'microservices architecture',
    'cryptography', 'quantum computing', 'distributed systems'
  ];
  
  // Moderate difficulty skills
  const moderateSkills = [
    'python', 'javascript', 'java', 'c++', 'c#', '.net', 'ruby', 'php', 'golang',
    'sql', 'react', 'angular', 'vue', 'node.js', 'django', 'flask', 'spring',
    'express', 'aws', 'azure', 'gcp', 'docker', 'terraform', 'jenkins'
  ];
  
  // More accessible skills with gentler learning curves
  const accessibleSkills = [
    'html', 'css', 'git', 'ui design', 'ux design', 'agile', 'scrum',
    'project management', 'communication', 'wordpress', 'content management',
    'digital marketing', 'social media', 'spreadsheets', 'excel',
    'presentation skills', 'customer service', 'teamwork', 'time management',
    'problem solving', 'critical thinking', 'adaptability', 'creativity'
  ];
  
  // Check which category the skill falls into
  if (difficultSkills.some(diffSkill => skillLower.includes(diffSkill) || diffSkill.includes(skillLower))) {
    return {
      level: 'High',
      description: 'Typically requires significant time investment and background knowledge.',
      estimatedTimeToLearn: 'Several months to years for mastery, depending on prior experience.'
    };
  } else if (moderateSkills.some(modSkill => skillLower.includes(modSkill) || modSkill.includes(skillLower))) {
    return {
      level: 'Medium',
      description: 'Requires consistent effort and practice to learn effectively.',
      estimatedTimeToLearn: 'A few weeks to months for functional proficiency.'
    };
  } else if (accessibleSkills.some(accSkill => skillLower.includes(accSkill) || accSkill.includes(skillLower))) {
    return {
      level: 'Low',
      description: 'Generally has approachable entry points and gradual learning curve.',
      estimatedTimeToLearn: 'A few days to weeks for basic proficiency.'
    };
  } else {
    // Default for unknown skills
    return {
      level: 'Medium',
      description: 'Requires dedicated learning and practice.',
      estimatedTimeToLearn: 'Varies based on complexity and your background.'
    };
  }
}

/**
 * Get job listings from LinkedIn API
 * @param {String} accessToken - LinkedIn access token
 * @param {Array} skills - Array of skill names
 * @param {String} location - Location for job search
 * @returns {Promise<Array>} - Array of job listings
 */
async function getLinkedInJobs(accessToken, skills, location) {
  try {
    if (!accessToken || !LINKEDIN_CLIENT_ID || !LINKEDIN_CLIENT_SECRET) {
      logApiCall('LinkedIn', 'jobs', false, 'Missing API credentials or access token');
      return [];
    }

    // Create search criteria based on skills
    const skillsQuery = skills.slice(0, 2).join(' ');
    
    // For LinkedIn, their Jobs Search API is actually very limited for third-party apps
    // This implementation assumes you have appropriate access level (which most apps won't have)
    
    // First validate that the token is still active
    try {
      const profileCheck = await axios.get('https://api.linkedin.com/v2/me', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        timeout: API_TIMEOUT
      });
      
      if (!profileCheck.data || !profileCheck.data.id) {
        throw new Error('LinkedIn token validation failed');
      }
      
      logApiCall('LinkedIn', 'token validation', true, 'Token is valid');
    } catch (tokenError) {
      logApiCall('LinkedIn', 'token validation', false, tokenError.message);
      throw new Error('LinkedIn access token is invalid or expired');
    }
    
    // Try to call Jobs Search API (note: this might not be available with standard API access)
    try {
      const response = await axios.get('https://api.linkedin.com/v2/jobSearch', {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        params: {
          keywords: skillsQuery,
          location: location,
          count: 10
        },
        timeout: API_TIMEOUT
      });
      
      // Check if we received valid data
      if (!response.data || !response.data.elements) {
        throw new Error('LinkedIn API returned invalid response format');
      }
      
      logApiCall('LinkedIn', 'jobs', true, `Found ${response.data.elements.length} jobs`);
      
      return response.data.elements.map(job => ({
        id: job.entityUrn || `linkedin-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        title: job.title || 'Position at LinkedIn',
        company: job.companyDetails?.companyName || 'Company on LinkedIn',
        location: job.formattedLocation || location || 'Location not specified',
        description: job.description || 'No description provided',
        salary: 'Salary not specified',
        url: job.entityUrn ? `https://www.linkedin.com/jobs/view/${job.entityUrn.split(':').pop()}` : '#',
        source: 'LinkedIn',
        postedAt: job.listedAt || new Date().toISOString()
      }));
    } catch (apiError) {
      // If the Jobs Search API fails, we'll use a fallback approach
      logApiCall('LinkedIn', 'jobs API', false, apiError.message);
      logApiCall('LinkedIn', 'jobs', false, 'Using fallback approach for LinkedIn jobs');
      
      // Fallback: Return simulated LinkedIn job results based on the user's skills
      // In a production app, you'd want to implement an alternative LinkedIn integration
      
      // These are placeholder jobs that simulate what LinkedIn might return
      const simulatedJobs = [];
      const titles = [
        'Software Developer', 'Web Developer', 'Data Scientist', 
        'Product Manager', 'UX Designer', 'DevOps Engineer'
      ];
      
      const companies = [
        'TechCorp', 'InnovateSoft', 'DataDynamics', 
        'Global Solutions', 'CreativeMinds', 'CloudScale'
      ];
      
      // Generate simulated jobs based on user skills
      skills.forEach((skill, index) => {
        if (index < 3) { // Limit to 3 simulated jobs per skill
          simulatedJobs.push({
            id: `linkedin-sim-${Date.now()}-${index}`,
            title: `${titles[index % titles.length]} (${skill})`,
            company: companies[index % companies.length],
            location: location || 'Remote',
            description: `This position requires expertise in ${skill} and related technologies. Join our team to work on cutting-edge projects.`,
            salary: 'Competitive salary based on experience',
            url: 'https://www.linkedin.com/jobs/',
            source: 'LinkedIn (Simulated)',
            postedAt: new Date().toISOString()
          });
        }
      });
      
      logApiCall('LinkedIn', 'jobs fallback', true, `Generated ${simulatedJobs.length} simulated jobs`);
      return simulatedJobs;
    }
  } catch (error) {
    logApiCall('LinkedIn', 'jobs', false, error.message);
    return [];
  }
}

/**
 * Get personalized job recommendations based on user profile and preferences
 * @route   GET api/career/jobs
 * @desc    Get job recommendations
 * @access  Private
 */
exports.getJobRecommendations = async (req, res) => {
  try {
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Extract relevant data for job matching
    const { skills, careerGoals, linkedInProfile } = profile;
    const skillNames = skills.map(skill => skill.name);
    const location = careerGoals?.locationPreference || 'remote';
    
    // Check request parameters for filters
    const { source, limit, offset } = req.query;
    
    // Create API request promises based on filters
    const apiRequests = [];
    const apiSources = [];
    
    // If source filter is provided, only use that source
    if (source) {
      switch (source.toLowerCase()) {
        case 'adzuna':
          apiRequests.push(getAdzunaJobs(skillNames, location));
          apiSources.push('Adzuna');
          break;
        case 'muse':
        case 'themuse':
          apiRequests.push(getMuseJobs(skillNames, careerGoals?.targetIndustry));
          apiSources.push('The Muse');
          break;
        case 'remotok':
          apiRequests.push(getRemotokJobs(skillNames));
          apiSources.push('Remotok');
          break;
        case 'linkedin':
          if (linkedInProfile?.accessToken) {
            apiRequests.push(getLinkedInJobs(linkedInProfile.accessToken, skillNames, location));
            apiSources.push('LinkedIn');
          } else {
            return res.status(400).json({ 
              message: 'LinkedIn source requested but account not connected. Please connect your LinkedIn account first.' 
            });
          }
          break;
        default:
          return res.status(400).json({ message: 'Invalid source parameter' });
      }
    } else {
      // Otherwise use all available sources
      apiRequests.push(getAdzunaJobs(skillNames, location));
      apiSources.push('Adzuna');
      
      apiRequests.push(getMuseJobs(skillNames, careerGoals?.targetIndustry));
      apiSources.push('The Muse');
      
      apiRequests.push(getRemotokJobs(skillNames));
      apiSources.push('Remotok');
      
      // Only add LinkedIn if connected
      if (linkedInProfile?.accessToken) {
        apiRequests.push(getLinkedInJobs(linkedInProfile.accessToken, skillNames, location));
        apiSources.push('LinkedIn');
      }
    }
    
    // Execute all API requests concurrently
    const results = await Promise.allSettled(apiRequests);
    
    // Track API status for client diagnostics
    const apiStatus = {};
    
    // Combine results, handling rejected promises
    let allJobs = [];
    results.forEach((result, index) => {
      const sourceName = apiSources[index];
      
      if (result.status === 'fulfilled') {
        allJobs = [...allJobs, ...result.value];
        apiStatus[sourceName] = { 
          status: 'success', 
          count: result.value.length 
        };
      } else {
        apiStatus[sourceName] = { 
          status: 'failed', 
          error: result.reason.message 
        };
        console.error(`Error fetching jobs from ${sourceName}:`, result.reason);
      }
    });
    
    // Process and filter job recommendations
    const uniqueJobs = removeDuplicateJobs(allJobs);
    const rankedJobs = rankJobsByRelevance(uniqueJobs, profile);
    
    // Apply pagination
    const pageSize = parseInt(limit) || 15;
    const pageOffset = parseInt(offset) || 0;
    const paginatedJobs = rankedJobs.slice(pageOffset, pageOffset + pageSize);
    
    // Track this request in user profile for analytics
    try {
      // Initialize searchHistory if it doesn't exist
      if (!profile.searchHistory) {
        profile.searchHistory = [];
      }
      
      // Add search to history
      profile.searchHistory.push({
        timestamp: new Date(),
        query: {
          skills: skillNames,
          location: location,
          source: source || 'all'
        },
        results: uniqueJobs.length
      });
      
      // Keep only the last 20 searches
      if (profile.searchHistory.length > 20) {
        profile.searchHistory = profile.searchHistory.slice(-20);
      }
      
      await profile.save();
    } catch (historyError) {
      console.error('Failed to save search history:', historyError.message);
    }
    
    // Return jobs with metadata
    res.json({
      jobs: paginatedJobs,
      meta: {
        total: rankedJobs.length,
        offset: pageOffset,
        limit: pageSize,
        hasMore: (pageOffset + pageSize) < rankedJobs.length
      },
      stats: {
        total: allJobs.length,
        unique: uniqueJobs.length,
        sources: {
          adzuna: allJobs.filter(job => job.source === 'Adzuna').length,
          muse: allJobs.filter(job => job.source === 'The Muse').length,
          remotok: allJobs.filter(job => job.source.includes('Remot')).length,
          linkedin: allJobs.filter(job => job.source.includes('LinkedIn')).length
        }
      },
      apiStatus
    });
  } catch (err) {
    console.error('Job recommendations error:', err.message);
    res.status(500).json({ message: 'Server error getting job recommendations' });
  }
};

/**
 * Remove duplicate job listings from different sources
 * @param {Array} jobs - Array of job listings
 * @returns {Array} - Deduplicated array of job listings
 */
function removeDuplicateJobs(jobs) {
  const uniqueJobs = {};
  
  jobs.forEach(job => {
    // Create a unique key using title and company
    const key = `${job.title}-${job.company}`.toLowerCase().replace(/\s+/g, '');
    
    // If job doesn't exist or current job is newer, add/update it
    if (!uniqueJobs[key] || new Date(job.postedAt) > new Date(uniqueJobs[key].postedAt)) {
      uniqueJobs[key] = job;
    }
  });
  
  return Object.values(uniqueJobs);
}

/**
 * Rank jobs by relevance to user profile
 * @param {Array} jobs - Array of job listings
 * @param {Object} profile - User profile
 * @returns {Array} - Ranked array of job listings
 */
function rankJobsByRelevance(jobs, profile) {
  // Get user skills and preferences
  const userSkills = profile.skills.map(skill => skill.name.toLowerCase());
  const careerGoals = profile.careerGoals || {};
  
  // Score and rank jobs
  const scoredJobs = jobs.map(job => {
    let score = 0;
    
    // Check title relevance to career goals
    if (careerGoals.shortTermGoal && 
        job.title.toLowerCase().includes(careerGoals.shortTermGoal.toLowerCase())) {
      score += 30;
    }
    
    // Check industry match
    if (careerGoals.targetIndustry && 
        job.description.toLowerCase().includes(careerGoals.targetIndustry.toLowerCase())) {
      score += 20;
    }
    
    // Check location preference
    if (careerGoals.locationPreference === 'remote' && 
        job.location.toLowerCase().includes('remote')) {
      score += 15;
    } else if (careerGoals.locationPreference && 
               job.location.toLowerCase().includes(careerGoals.locationPreference.toLowerCase())) {
      score += 15;
    }
    
    // Check skills match
    userSkills.forEach(skill => {
      if (job.title.toLowerCase().includes(skill) || 
          job.description.toLowerCase().includes(skill)) {
        score += 10;
      }
    });
    
    // Check for salary info - jobs with salary info are slightly preferred
    if (job.salary && !job.salary.includes('not specified')) {
      score += 5;
    }
    
    // Recency bonus
    const daysAgo = (new Date() - new Date(job.postedAt)) / (1000 * 60 * 60 * 24);
    score += Math.max(0, 15 - daysAgo); // Newer jobs get higher scores
    
    return { ...job, relevanceScore: score };
  });
  
  // Sort by relevance score (descending)
  return scoredJobs.sort((a, b) => b.relevanceScore - a.relevanceScore);
}

/**
 * Get job market trends from Adzuna and other sources
 * @route   GET api/career/job-market
 * @desc    Get job market trends
 * @access  Private
 */
exports.getJobMarketTrends = async (req, res) => {
  try {
    // Parameters for filtering
    const { location, industry, jobTitle } = req.query;
    
    // Get job market trends from Adzuna API
    const adzunaTrends = await getAdzunaJobTrends(location, industry, jobTitle);
    
    // Get job market trends from The Muse API
    const museTrends = await getMuseJobTrends(industry, jobTitle);
    
    // Combine and process the data
    const jobMarketTrends = {
      demandTrends: adzunaTrends.demandTrends || [],
      salaryTrends: adzunaTrends.salaryTrends || [],
      topIndustries: adzunaTrends.topIndustries || [],
      topSkills: combineTopSkills(adzunaTrends.topSkills || [], museTrends.topSkills || []),
      popularJobs: museTrends.popularJobs || [],
      locationInsights: adzunaTrends.locationInsights || [],
      recentTrends: museTrends.recentTrends || []
    };
    
    // Add tracking for analytics
    try {
      // Get user profile
      const profile = await Profile.findOne({ user: req.user.id });
      if (profile) {
        // Initialize marketInsightHistory if it doesn't exist
        if (!profile.marketInsightHistory) {
          profile.marketInsightHistory = [];
        }

        // Add search to history
        profile.marketInsightHistory.push({
          timestamp: new Date(),
          query: { location, industry, jobTitle },
        });

        // Keep only the last 10 insights
        if (profile.marketInsightHistory.length > 10) {
          profile.marketInsightHistory = profile.marketInsightHistory.slice(-10);
        }

        await profile.save();
      }
    } catch (historyError) {
      console.error('Failed to save market insight history:', historyError.message);
    }
    
    res.json(jobMarketTrends);
  } catch (err) {
    console.error('Job market trends error:', err.message);
    res.status(500).json({ 
      message: 'Server error retrieving job market trends',
      error: err.message
    });
  }
};

/**
 * Get job listings from Adzuna API
 * @param {Array} skills - Array of skill names
 * @param {String} location - Location for job search
 * @returns {Promise<Array>} - Array of job listings
 */
async function getAdzunaJobs(skills, location) {
  try {
    if (!ADZUNA_APP_ID || !ADZUNA_API_KEY) {
      logApiCall('Adzuna', 'jobs', false, 'Missing API credentials');
      return [];
    }

    // Determine country code based on location or default to 'us'
    let country = 'us';
    const countryCodes = {
      'united states': 'us', 'us': 'us', 'usa': 'us',
      'uk': 'gb', 'united kingdom': 'gb', 'great britain': 'gb',
      'canada': 'ca', 'australia': 'au', 'germany': 'de',
      'france': 'fr', 'spain': 'es', 'italy': 'it'
    };
    
    // Try to extract country code from location
    if (location) {
      const locationLower = location.toLowerCase();
      for (const [key, value] of Object.entries(countryCodes)) {
        if (locationLower.includes(key)) {
          country = value;
          break;
        }
      }
    }
    
    // Create skills query string
    const skillsQuery = skills.join(' ');
    
    // Make API request
    const searchUrl = `https://api.adzuna.com/v1/api/jobs/${country}/search/1`;
    const response = await axios.get(searchUrl, {
      params: {
        app_id: ADZUNA_APP_ID,
        app_key: ADZUNA_API_KEY,
        results_per_page: 50,
        what: skillsQuery,
        where: location !== 'remote' ? location : undefined,
        // Add remote tag if remote is requested
        title_only: skillsQuery ? 1 : 0
      },
      timeout: API_TIMEOUT
    });
    
    if (!response.data || !response.data.results) {
      logApiCall('Adzuna', 'jobs', false, 'No results found');
      return [];
    }
    
    logApiCall('Adzuna', 'jobs', true, `Found ${response.data.results.length} jobs`);
    
    // Map to standard format
    return response.data.results.map(job => ({
      id: job.id || `adzuna-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      title: job.title || 'Unknown Position',
      company: job.company?.display_name || 'Unknown Company',
      location: job.location?.display_name || location || 'Location not specified',
      description: job.description || 'No description provided',
      salary: job.salary_min && job.salary_max ? 
        `${job.salary_min.toLocaleString()} - ${job.salary_max.toLocaleString()} ${job.salary_is_predicted ? '(estimated)' : ''}` : 
        'Salary not specified',
      url: job.redirect_url || '#',
      source: 'Adzuna',
      postedAt: job.created || new Date().toISOString()
    }));
  } catch (error) {
    logApiCall('Adzuna', 'jobs', false, error.message);
    return [];
  }
}

/**
 * Generate career path suggestions based on user interests and academic strengths
 * @param {Object} profile - User profile containing interests, skills, and academic background
 * @returns {Promise<Array>} - Array of suggested career paths
 */
async function getCareerPathSuggestions(profile) {
  try {
    // Extract relevant data from profile
    const { interests, skills, academicBackground, careerGoals } = profile;
    const userSkills = skills.map(skill => skill.name.toLowerCase());
    
    // Define career paths with required skills, interests, and academic backgrounds
    const careerPaths = {
      'Software Engineering': {
        interests: ['technology', 'problem solving', 'coding', 'innovation'],
        skills: ['javascript', 'python', 'java', 'algorithms', 'data structures'],
        academicFields: ['computer science', 'engineering', 'mathematics'],
        growthRate: 25,
        averageSalary: 95000,
        description: 'Build software applications and systems for various platforms',
        nextSteps: ['Learn a programming language', 'Build projects', 'Contribute to open source']
      },
      'Data Science': {
        interests: ['analytics', 'mathematics', 'research', 'patterns'],
        skills: ['python', 'r', 'statistics', 'machine learning', 'sql'],
        academicFields: ['mathematics', 'statistics', 'computer science', 'engineering'],
        growthRate: 35,
        averageSalary: 105000,
        description: 'Extract insights from data to inform business decisions',
        nextSteps: ['Learn Python/R', 'Study statistics', 'Work on data projects']
      },
      'UX Design': {
        interests: ['design', 'user experience', 'psychology', 'creativity'],
        skills: ['design thinking', 'user research', 'prototyping', 'ui design'],
        academicFields: ['design', 'psychology', 'art', 'human-computer interaction'],
        growthRate: 20,
        averageSalary: 80000,
        description: 'Create intuitive and engaging user experiences for digital products',
        nextSteps: ['Learn design tools', 'Study user psychology', 'Build a portfolio']
      },
      'Product Management': {
        interests: ['strategy', 'collaboration', 'innovation', 'leadership'],
        skills: ['communication', 'analytical thinking', 'project management', 'market research'],
        academicFields: ['business', 'engineering', 'economics', 'marketing'],
        growthRate: 30,
        averageSalary: 115000,
        description: 'Guide the development and strategy of products from conception to launch',
        nextSteps: ['Develop business acumen', 'Learn Agile methodologies', 'Practice stakeholder management']
      }
    };
    
    // Calculate match scores for each career path
    const careerMatchScores = Object.entries(careerPaths).map(([careerName, careerData]) => {
      let score = 0;
      
      // Check interest match
      if (interests) {
        const interestMatches = careerData.interests.filter(interest => 
          interests.some(userInterest => 
            userInterest.toLowerCase().includes(interest) || 
            interest.includes(userInterest.toLowerCase())
          )
        );
        score += interestMatches.length * 10;
      }
      
      // Check skill match
      const skillMatches = careerData.skills.filter(skill => 
        userSkills.some(userSkill => 
          userSkill.includes(skill) || skill.includes(userSkill)
        )
      );
      score += skillMatches.length * 15;
      
      // Check academic background match
      if (academicBackground && academicBackground.field) {
        const academicMatch = careerData.academicFields.some(field => 
          academicBackground.field.toLowerCase().includes(field) || 
          field.includes(academicBackground.field.toLowerCase())
        );
        if (academicMatch) score += 20;
      }
      
      // Consider career goals
      if (careerGoals && careerGoals.targetIndustry) {
        const industryMatch = careerName.toLowerCase().includes(careerGoals.targetIndustry.toLowerCase()) ||
                             careerGoals.targetIndustry.toLowerCase().includes(careerName.toLowerCase());
        if (industryMatch) score += 25;
      }
      
      return {
        careerPath: careerName,
        score,
        ...careerData,
        matchReasons: {
          interestMatches: careerData.interests.filter(interest => 
            interests && interests.some(userInterest => 
              userInterest.toLowerCase().includes(interest) || 
              interest.includes(userInterest.toLowerCase())
            )
          ),
          skillMatches: careerData.skills.filter(skill => 
            userSkills.some(userSkill => 
              userSkill.includes(skill) || skill.includes(userSkill)
            )
          ),
          missingSkills: careerData.skills.filter(skill => 
            !userSkills.some(userSkill => 
              userSkill.includes(skill) || skill.includes(userSkill)
            )
          )
        }
      };
    });
    
    // Sort by score and return top suggestions
    const sortedSuggestions = careerMatchScores
      .sort((a, b) => b.score - a.score)
      .slice(0, 5); 
    
    // Add market data for each suggestion
    const enrichedSuggestions = await Promise.all(
      sortedSuggestions.map(async suggestion => {
        const marketData = await getSkillMarketData(suggestion.careerPath);
        return {
          ...suggestion,
          marketData
        };
      })
    );
    
    logApiCall('Career Path Suggestions', 'generate', true, `Generated ${enrichedSuggestions.length} career path suggestions`);
    return enrichedSuggestions;
  } catch (error) {
    logApiCall('Career Path Suggestions', 'generate', false, error.message);
    return [];
  }
}

/**
 * Get career path suggestions for user
 * @route   GET api/career/path-suggestions
 * @desc    Get career path suggestions based on profile
 * @access  Private
 */
exports.getCareerPathSuggestions = async (req, res) => {
  try {
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Get career path suggestions
    const suggestions = await getCareerPathSuggestions(profile);
    
    // Track this request in user profile for analytics
    try {
      if (!profile.careerSuggestionHistory) {
        profile.careerSuggestionHistory = [];
      }
      
      profile.careerSuggestionHistory.push({
        timestamp: new Date(),
        suggestions: suggestions.slice(0, 3).map(s => s.careerPath) // Store top 3
      });
      
      if (profile.careerSuggestionHistory.length > 10) {
        profile.careerSuggestionHistory = profile.careerSuggestionHistory.slice(-10);
      }
      
      await profile.save();
    } catch (historyError) {
      console.error('Failed to save career suggestion history:', historyError.message);
    }
    
    res.json({
      suggestions,
      meta: {
        total: suggestions.length,
        algorithm: 'interest-skill-academic-match',
        timestamp: new Date().toISOString()
      }
    });
  } catch (err) {
    console.error('Career path suggestions error:', err.message);
    res.status(500).json({ message: 'Server error getting career path suggestions' });
  }
};

/**
 * Get skill gap analysis for a target role
 * @route   POST api/career/skill-gap-analysis
 * @desc    Analyze skill gaps for target role
 * @access  Private
 */
exports.getSkillGapAnalysis = async (req, res) => {
  try {
    const { targetRole } = req.body;
    
    if (!targetRole) {
      return res.status(400).json({ message: 'Target role is required' });
    }
    
    // Get user profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Get required skills for target role
    const requiredSkills = await getRequiredSkillsForRole(targetRole);
    const userSkills = profile.skills.map(skill => skill.name);
    
    // Identify missing skills
    const missingSkills = requiredSkills.filter(skill => 
      !userSkills.some(userSkill => 
        userSkill.toLowerCase().includes(skill.toLowerCase()) || 
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    );
    
    // Get skill recommendations for missing skills
    const skillRecommendations = await getSkillRecommendations(missingSkills, targetRole);
    
    // Calculate readiness score
    const matchedSkills = requiredSkills.filter(skill => 
      userSkills.some(userSkill => 
        userSkill.toLowerCase().includes(skill.toLowerCase()) || 
        skill.toLowerCase().includes(userSkill.toLowerCase())
      )
    );
    
    const readinessScore = Math.round((matchedSkills.length / requiredSkills.length) * 100);
    
    res.json({
      targetRole,
      readinessScore,
      requiredSkills,
      matchedSkills,
      missingSkills,
      skillRecommendations,
      analysis: {
        strengthAreas: matchedSkills,
        improvementAreas: missingSkills,
        estimatedTimeToReady: estimateTimeToReady(skillRecommendations)
      }
    });
  } catch (err) {
    console.error('Skill gap analysis error:', err.message);
    res.status(500).json({ message: 'Server error performing skill gap analysis' });
  }
};

/**
 * Estimate time needed to become ready for role
 * @param {Array} skillRecommendations - Array of skill recommendations
 * @returns {String} - Estimated time in human readable format
 */
function estimateTimeToReady(skillRecommendations) {
  let totalWeeks = 0;
  
  skillRecommendations.forEach(rec => {
    const difficulty = rec.difficulty.level;
    if (difficulty === 'High') totalWeeks += 16; // 4 months
    else if (difficulty === 'Medium') totalWeeks += 8; // 2 months  
    else totalWeeks += 4; // 1 month
  });
  
  // Account for parallel learning
  const adjustedWeeks = Math.ceil(totalWeeks * 0.7);
  
  if (adjustedWeeks < 4) return '1 month';
  else if (adjustedWeeks < 12) return `${Math.ceil(adjustedWeeks/4)} months`;
  else return `${Math.ceil(adjustedWeeks/12)} months to ${Math.ceil(adjustedWeeks/4)} months`;
}