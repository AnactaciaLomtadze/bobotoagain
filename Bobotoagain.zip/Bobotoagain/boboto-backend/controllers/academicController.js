// controllers/academicController.js
const Profile = require('../models/Profile');
const User = require('../models/User');
const mongoose = require('mongoose');
const axios = require('axios');
const { generateResponse } = require('./deepseekController'); // Use your existing AI function


class AcademicController {
  // Subject-specific Q&A
  async handleSubjectQA(req, res) {
    // This method remains unchanged
    const { subject, question, difficulty } = req.body;
    
    if (!subject || !question) {
      return res.status(400).json({ message: 'Subject and question are required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      const user = await User.findById(req.user.id).select('-password');
      
      const contextPrompt = `You are helping a ${profile?.academicLevel || 'student'} student with a ${subject} question.
        Subject: ${subject}
        Difficulty Level: ${difficulty || 'intermediate'}
        Student's major: ${profile?.major || 'not specified'}
        Student's learning style: ${profile?.learningPreferences?.learningStyle || 'mixed'}
        
        The student asked: "${question}"
        
        Please provide a clear, well-structured explanation that:
        1. Directly answers the question
        2. Includes relevant examples
        3. Uses terminology appropriate for the student's level
        4. Suggests related topics they might want to explore
        
        Tailor your explanation to match their learning style and academic level.`;
      
      // Create a temporary request for the AI response
      const tempReq = {
        ...req,
        body: {
          message: contextPrompt,
          chatHistory: []
        }
      };
      
      // Create a custom response object to capture the AI response
      let aiResponse;
      const tempRes = {
        json: (data) => {
          aiResponse = data.response;
          return res.json(data);
        },
        status: (code) => ({
          json: (data) => {
            res.status(code).json(data);
          }
        })
      };
      
      // Call the existing AI function
      await generateResponse(tempReq, tempRes);
      
    } catch (err) {
      console.error('Subject Q&A error:', err);
      res.status(500).json({ message: 'Error processing question' });
    }
  }
  
  // Concept explanation engine
  async explainConcept(req, res) {
    const { concept, context, breakdownLevel } = req.body;
    
    if (!concept) {
      return res.status(400).json({ message: 'Concept is required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      const explainPrompt = `Please explain the concept: "${concept}"
        Context: ${context || 'general explanation'}
        Breakdown Level: ${breakdownLevel || 'intermediate'}
        Student's background: ${profile.major || 'general'} student
        
        Provide the explanation in the following format:
        1. Brief Overview (1-2 sentences)
        2. Key Components (break down into 3-5 main parts)
        3. Step-by-Step Process (if applicable)
        4. Real-world Examples (at least 2)
        5. Common Misconceptions to Avoid
        6. Practice Suggestions
        7. Related Concepts to Explore
        
        Make the explanation progressive, building from simple to complex.`;
      
      const tempReq = {
        ...req,
        body: {
          message: explainPrompt,
          chatHistory: []
        }
      };
      
      let aiResponse;
      const tempRes = {
        json: (data) => {
          aiResponse = data.response;
          return res.json(data);
        },
        status: (code) => ({
          json: (data) => {
            res.status(code).json(data);
          }
        })
      };
      
      await generateResponse(tempReq, tempRes);
      
    } catch (err) {
      console.error('Concept explanation error:', err);
      res.status(500).json({ message: 'Error explaining concept' });
    }
  }
  
  // Study material recommendations
  async recommendStudyMaterials(req, res) {
    const { topic, materialTypes, learningLevel } = req.body;
    
    if (!topic) {
      return res.status(400).json({ message: 'Topic is required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      const recommendationPrompt = `Recommend study materials for: "${topic}"
        Student's level: ${learningLevel || profile.learningPreferences?.technicalLevel || 'intermediate'}
        Preferred material types: ${materialTypes || 'all types'}
        Student's learning style: ${profile.learningPreferences?.learningStyle || 'mixed'}
        
        Please provide recommendations in the following categories:
        1. Videos (YouTube channels, online courses)
        2. Books (textbooks, reference materials)
        3. Articles and Tutorials (blogs, documentation)
        4. Practice Resources (exercises, coding challenges, problem sets)
        5. Interactive Tools (simulators, visualizations)
        
        For each resource:
        - Include the title and brief description
        - Mention why it's good for this topic
        - Indicate the difficulty level
        - If possible, suggest a specific starting point
        
        Prioritize freely available resources but also mention premium options if they're particularly valuable.`;
      
      const tempReq = {
        ...req,
        body: {
          message: recommendationPrompt,
          chatHistory: []
        }
      };
      
      let aiResponse;
      const tempRes = {
        json: (data) => {
          aiResponse = data.response;
          return res.json(data);
        },
        status: (code) => ({
          json: (data) => {
            res.status(code).json(data);
          }
        })
      };
      
      await generateResponse(tempReq, tempRes);
      
    } catch (err) {
      console.error('Study material recommendation error:', err);
      res.status(500).json({ message: 'Error recommending materials' });
    }
  }
  
  // Homework and assignment help (with integrity boundaries)
  async assignmentHelp(req, res) {
    const { assignment, question, type } = req.body;
    
    if (!assignment || !question) {
      return res.status(400).json({ message: 'Assignment and question are required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      const assistancePrompt = `Help with assignment: "${assignment}"
        Question: "${question}"
        Assignment type: ${type || 'general'}
        
        IMPORTANT: Provide guidance without giving direct answers. Follow these principles:
        1. Help the student understand the concept
        2. Suggest approaches and methodologies
        3. Point out key principles to apply
        4. Provide similar examples (not the actual solution)
        5. Ask guiding questions to help them think through the problem
        
        Structure your response as:
        1. Understanding the Problem (what concepts are being tested)
        2. Approach Strategy (steps to solve, without actual solution)
        3. Key Concepts to Apply
        4. Similar Example (different problem, same concept)
        5. Guiding Questions (to help them solve it themselves)
        6. Resources for Further Study
        
        Remember: The goal is to help them learn, not to complete the assignment for them.`;
      
      const tempReq = {
        ...req,
        body: {
          message: assistancePrompt,
          chatHistory: []
        }
      };
      
      let aiResponse;
      const tempRes = {
        json: (data) => {
          aiResponse = data.response;
          return res.json(data);
        },
        status: (code) => ({
          json: (data) => {
            res.status(code).json(data);
          }
        })
      };
      
      await generateResponse(tempReq, tempRes);
      
    } catch (err) {
      console.error('Assignment help error:', err);
      res.status(500).json({ message: 'Error providing assignment help' });
    }
  }

  // Track study time
async trackStudyTime(req, res) {
    const { subject, minutes, date } = req.body;
    
    console.log('Track study time request received:', { subject, minutes, date });
    
    if (!subject || !minutes) {
      return res.status(400).json({ message: 'Subject and minutes are required' });
    }
    
    try {
      const studyDate = date ? new Date(date) : new Date();
      const minutesInt = parseInt(minutes);
      
      // Find the profile
      let profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        // Create a new profile if one doesn't exist
        console.log('Creating new profile for user:', req.user.id);
        
        const newProfile = new Profile({
          user: req.user.id,
          academicProgress: {
            subjects: [{
              name: subject,
              proficiency: 10,
              lastStudied: studyDate,
              topics: []
            }],
            studyTime: {
              total: minutesInt,
              bySubject: { [subject]: minutesInt },
              dailyLog: [{
                date: studyDate,
                minutes: minutesInt,
                subject
              }]
            }
          }
        });
        
        await newProfile.save();
        
        return res.json({
          message: 'Study time tracked successfully (new profile)',
          studyTime: newProfile.academicProgress.studyTime
        });
      }
      
      // Initialize academicProgress if needed
      if (!profile.academicProgress) {
        profile.academicProgress = {
          subjects: [{
            name: subject,
            proficiency: 10,
            lastStudied: studyDate,
            topics: []
          }],
          studyTime: {
            total: minutesInt,
            bySubject: { [subject]: minutesInt },
            dailyLog: [{
              date: studyDate,
              minutes: minutesInt,
              subject
            }]
          }
        };
      } else {
        // Initialize studyTime if needed
        if (!profile.academicProgress.studyTime) {
          profile.academicProgress.studyTime = {
            total: minutesInt,
            bySubject: { [subject]: minutesInt },
            dailyLog: [{
              date: studyDate,
              minutes: minutesInt,
              subject
            }]
          };
        } else {
          // Update total study time
          if (typeof profile.academicProgress.studyTime.total !== 'number') {
            profile.academicProgress.studyTime.total = minutesInt;
          } else {
            profile.academicProgress.studyTime.total += minutesInt;
          }
          
          // Update bySubject
          if (!profile.academicProgress.studyTime.bySubject) {
            profile.academicProgress.studyTime.bySubject = {};
          }
          
          const currentSubjectTime = profile.academicProgress.studyTime.bySubject[subject] || 0;
          profile.academicProgress.studyTime.bySubject[subject] = currentSubjectTime + minutesInt;
          
          // Update dailyLog
          if (!Array.isArray(profile.academicProgress.studyTime.dailyLog)) {
            profile.academicProgress.studyTime.dailyLog = [];
          }
          
          profile.academicProgress.studyTime.dailyLog.push({
            date: studyDate,
            minutes: minutesInt,
            subject
          });
        }
        
        // Ensure subject exists in subjects array
        if (!Array.isArray(profile.academicProgress.subjects)) {
          profile.academicProgress.subjects = [];
        }
        
        const subjectExists = profile.academicProgress.subjects.some(s => s.name === subject);
        
        if (!subjectExists) {
          profile.academicProgress.subjects.push({
            name: subject,
            proficiency: 10,
            lastStudied: studyDate,
            topics: []
          });
        } else {
          // Update lastStudied date for existing subject
          const subjectIndex = profile.academicProgress.subjects.findIndex(s => s.name === subject);
          if (subjectIndex !== -1) {
            profile.academicProgress.subjects[subjectIndex].lastStudied = studyDate;
          }
        }
      }
      
      // Save the updated profile
      await profile.save();
      
      return res.json({
        message: 'Study time tracked successfully',
        studyTime: profile.academicProgress.studyTime
      });
    } catch (err) {
      console.error('Study time tracking error:', err);
      return res.status(500).json({ 
        message: 'Error tracking study time',
        error: err.message 
      });
    }
  }

  // Add resource to library
  async addResource(req, res) {
    const { title, url, type, subject, notes } = req.body;
    
    console.log('Add resource request received:', {
      title, url, type, subject, hasNotes: !!notes
    });
    
    if (!title || !url || !type || !subject) {
      console.log('Validation failed: Missing required fields');
      return res.status(400).json({ message: 'Title, URL, type, and subject are required' });
    }
    
    try {
      // Find or create profile
      let profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        console.log('No profile found, creating new profile for user:', req.user.id);
        profile = new Profile({
          user: req.user.id,
          // Initialize with empty values
          resourceLibrary: [],
          skills: [],
          learningPreferences: {
            learningStyle: 'mixed',
            preferredMaterials: []
          }
        });
      }
      
      // Handle resourceLibrary not being defined or not being an array
      if (!profile.resourceLibrary || !Array.isArray(profile.resourceLibrary)) {
        console.log('Fixing resourceLibrary: was', typeof profile.resourceLibrary);
        profile.resourceLibrary = [];
      }
      
      // Create the new resource with proper structure
      const newResource = {
        title,
        url,
        type,
        subject,
        addedAt: new Date(),
        completed: false,
        rating: 0,
        notes: notes || ''
      };
      
      // Check if resource already exists by URL
      const existingIndex = profile.resourceLibrary.findIndex(r => r.url === url);
      
      if (existingIndex !== -1) {
        console.log('Updating existing resource at index:', existingIndex);
        // Update fields but preserve existing data
        const existingResource = profile.resourceLibrary[existingIndex];
        profile.resourceLibrary[existingIndex] = {
          ...existingResource,
          title,
          type,
          subject,
          notes: notes || existingResource.notes
        };
      } else {
        console.log('Adding new resource to library');
        profile.resourceLibrary.push(newResource);
      }
      
      // Save changes with additional error handling
      try {
        await profile.save();
        console.log('Profile saved successfully with updated resource library');
        
        return res.json({
          message: 'Resource added successfully',
          resource: existingIndex !== -1 ? profile.resourceLibrary[existingIndex] : newResource,
          resourceCount: profile.resourceLibrary.length
        });
      } catch (saveErr) {
        // Handle schema validation errors
        if (saveErr.name === 'ValidationError') {
          console.error('Validation error:', saveErr.message);
          
          // Try to fix the validation error by creating a clean resource
          // This handles cases where the schema doesn't match what's being saved
          if (saveErr.errors && saveErr.errors['resourceLibrary']) {
            console.log('Trying to fix resourceLibrary schema issue');
            
            // Create clean resourceLibrary by only including valid fields
            const cleanResource = {
              title: newResource.title,
              url: newResource.url,
              type: newResource.type,
              subject: newResource.subject,
              addedAt: newResource.addedAt,
              completed: false,
              rating: 0,
              notes: newResource.notes || ''
            };
            
            // Reset resourceLibrary with just this item
            if (existingIndex !== -1) {
              profile.resourceLibrary[existingIndex] = cleanResource;
            } else {
              // If it was a new resource, ensure we're dealing with a clean array
              if (!Array.isArray(profile.resourceLibrary)) {
                profile.resourceLibrary = [];
              }
              profile.resourceLibrary.push(cleanResource);
            }
            
            // Try one more time with clean data
            try {
              await profile.save();
              console.log('Successfully saved with cleaned resource');
              return res.json({
                message: 'Resource added successfully (after schema fix)',
                resource: cleanResource,
                resourceCount: profile.resourceLibrary.length
              });
            } catch (finalErr) {
              console.error('Still failed after schema fix:', finalErr.message);
              throw finalErr;
            }
          } else {
            throw saveErr;
          }
        } else {
          throw saveErr;
        }
      }
    } catch (err) {
      console.error('Add resource error:', err.name, err.message);
      console.error('Stack:', err.stack);
      
      return res.status(500).json({
        message: 'Error adding resource',
        error: err.message
      });
    }
  }
  
  // Get resources by subject
  async getResourcesBySubject(req, res) {
    const { subject } = req.query;
    
    if (!subject) {
      return res.status(400).json({ message: 'Subject is required' });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        return res.status(404).json({ message: 'Profile not found' });
      }
      
      // Filter resources by subject
      const resources = profile.resourceLibrary ? 
        profile.resourceLibrary.filter(
          r => r.subject.toLowerCase() === subject.toLowerCase()
        ) : [];
      
      res.json(resources);
    } catch (err) {
      console.error('Get resources error:', err);
      res.status(500).json({ message: 'Error getting resources' });
    }
  }
  
  // Generate study plan
  async generateStudyPlan(req, res) {
    const { subject, timeFrame, hoursPerWeek } = req.body;
    
    if (!subject || !timeFrame || !hoursPerWeek) {
      return res.status(400).json({ 
        message: 'Subject, time frame, and hours per week are required' 
      });
    }
    
    try {
      const profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        return res.status(404).json({ message: 'Profile not found' });
      }
      
      // Get user's learning preferences for context
      const learningStyle = profile.learningPreferences?.learningStyle || 'mixed';
      const preferredMaterials = profile.learningPreferences?.preferredMaterials || [];
      const technicalLevel = profile.learningPreferences?.technicalLevel || 3;
      
      // Format learning preferences for prompt
      let learningPrefText = `Learning Style: ${learningStyle}\n`;
      if (preferredMaterials.length > 0) {
        learningPrefText += `Preferred Materials: ${preferredMaterials.join(', ')}\n`;
      }
      
      // Determine difficulty level
      let difficultyLevel = 'intermediate';
      if (technicalLevel >= 4) {
        difficultyLevel = 'advanced';
      } else if (technicalLevel <= 2) {
        difficultyLevel = 'beginner';
      }
      
      // Create prompt for study plan
      const studyPlanPrompt = `Generate a structured study plan for: ${subject}
        Time Frame: ${timeFrame}
        Hours per Week: ${hoursPerWeek}
        Difficulty Level: ${difficultyLevel}
        ${learningPrefText}
        
        Please create a comprehensive study plan that includes:
        1. Clear learning objectives
        2. Weekly breakdown of topics to cover
        3. Recommended learning resources (books, videos, courses)
        4. Practice exercises
        5. Milestones and checkpoints
        6. Assessment methods
        
        Format the plan for clear readability with sections, bullet points, and a logical progression from fundamentals to more advanced topics. Suggest both theoretical learning and practical application approaches.`;
      
      // Generate study plan using DeepSeek
      const tempReq = {
        body: {
          message: studyPlanPrompt,
          chatHistory: []
        },
        user: req.user
      };
      
      let studyPlanResponse;
      const tempRes = {
        json: (data) => {
          studyPlanResponse = data.response;
          return res.json({
            subject,
            timeFrame,
            hoursPerWeek,
            studyPlan: data.response
          });
        },
        status: (code) => ({
          json: (data) => {
            res.status(code).json(data);
          }
        })
      };
      
      await generateResponse(tempReq, tempRes);
      
    } catch (err) {
      console.error('Generate study plan error:', err);
      res.status(500).json({ message: 'Error generating study plan' });
    }
  }

  //Patched method for adding resources
  async addResource(req, res) {
    console.log('Add resource request received:', req.body);
    const { title, url, type, subject, notes } = req.body;
    
    if (!title || !url || !type || !subject) {
      return res.status(400).json({ message: 'Title, URL, type, and subject are required' });
    }
    
    try {
      // Find the user's profile, or create a new one
      let profile = await Profile.findOne({ user: req.user.id });
      
      if (!profile) {
        console.log('No profile found for user, creating a new profile');
        profile = new Profile({
          user: req.user.id,
          resourceLibrary: []
        });
      }

      // Ensure resourceLibrary exists and is an array
      if (!profile.resourceLibrary) {
        console.log('Initializing resourceLibrary as an empty array');
        profile.resourceLibrary = [];
      } else if (!Array.isArray(profile.resourceLibrary)) {
        console.log('resourceLibrary exists but is not an array, resetting to empty array');
        profile.resourceLibrary = [];
      }
      
      // Create the new resource document
      const newResource = {
        title,
        url,
        type,
        subject,
        addedAt: new Date(),
        completed: false,
        rating: 0,
        notes: notes || ''
      };
      
      // Check if resource already exists by URL
      const existingIndex = profile.resourceLibrary.findIndex(
        r => r && r.url === url
      );
      
      if (existingIndex !== -1) {
        console.log('Updating existing resource at index', existingIndex);
        profile.resourceLibrary[existingIndex] = {
          ...profile.resourceLibrary[existingIndex],
          title,
          type,
          subject,
          notes: notes || profile.resourceLibrary[existingIndex].notes
        };
      } else {
        console.log('Adding new resource to library');
        profile.resourceLibrary.push(newResource);
      }
      
      // Save with detailed error handling
      try {
        await profile.save();
        console.log('Profile saved successfully with updated resourceLibrary');
        
        return res.json({
          message: 'Resource added successfully',
          resource: existingIndex !== -1 ? profile.resourceLibrary[existingIndex] : newResource,
          resourceCount: profile.resourceLibrary.length
        });
      } catch (saveErr) {
        console.error('Error saving profile:', saveErr);
        
        // If there's a validation error, try a more direct update approach
        if (saveErr.name === 'ValidationError' || saveErr.name === 'CastError') {
          console.log('Validation/Cast error, trying direct MongoDB update');
          
          // Use direct MongoDB operation as a fallback
          const result = await mongoose.connection.db.collection('profiles').updateOne(
            { _id: profile._id },
            existingIndex !== -1 
              ? { $set: { [`resourceLibrary.${existingIndex}`]: newResource } }
              : { $push: { resourceLibrary: newResource } }
          );
          
          console.log('Direct MongoDB update result:', result);
          
          if (result.modifiedCount > 0) {
            return res.json({
              message: 'Resource added successfully (via direct update)',
              resource: newResource,
              resourceCount: existingIndex !== -1 
                ? profile.resourceLibrary.length 
                : profile.resourceLibrary.length + 1
            });
          } else {
            throw new Error('Direct update failed');
          }
        } else {
          // Re-throw other errors
          throw saveErr;
        }
      }
    } catch (err) {
      console.error('Add resource error:', err);
      return res.status(500).json({ 
        message: 'Error adding resource',
        error: err.message 
      });
    }
  }
  
}

module.exports = new AcademicController();