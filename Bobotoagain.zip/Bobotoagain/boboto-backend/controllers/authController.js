// controllers/authController.js
const User = require('../models/User');
const Profile = require('../models/Profile');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const { OAuth2Client } = require('google-auth-library');
require('dotenv').config();

// Google OAuth client
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Email transporter
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: process.env.EMAIL_SECURE === 'true',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD
  }
});

// Generate JWT token
const generateToken = (userId) => {
  const payload = {
    user: {
      id: userId
    }
  };

  return new Promise((resolve, reject) => {
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '7d' },
      (err, token) => {
        if (err) reject(err);
        resolve(token);
      }
    );
  });
};

// Register a new user
exports.register = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: errors.array()[0].msg });
  }

  const { email, password, fullName } = req.body;

  try {
    // Check if user already exists
    let user = await User.findOne({ email });
    if (user) {
      return res.status(400).json({ message: 'User already exists with this email' });
    }

    // Create new user
    user = new User({
      fullName,
      email,
      password
    });

    // Save user
    await user.save();

    // Create empty profile for user
    const profile = new Profile({
      user: user.id
    });
    await profile.save();

    // Generate JWT
    const token = await generateToken(user.id);

    res.status(201).json({
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Registration error:', err.message);
    res.status(500).json({ message: 'Server error during registration' });
  }
};

// Login user
exports.login = async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: errors.array()[0].msg });
  }

  const { email, password } = req.body;

  try {
    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }

    // Generate JWT
    const token = await generateToken(user.id);

    res.json({
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        profilePictureUrl: user.profilePictureUrl
      }
    });
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ message: 'Server error during login' });
  }
};

//Google authentication controller
exports.googleAuth = async (req, res) => {
  const { idToken } = req.body;
  
  try {
    console.log('Google auth request received');
    
    if (!idToken) {
      console.error('No idToken provided in request');
      return res.status(400).json({ message: 'Google ID token is required' });
    }
    
    // Check if Google client is configured
    if (!process.env.GOOGLE_CLIENT_ID) {
      console.error('GOOGLE_CLIENT_ID environment variable not set');
      return res.status(500).json({ message: 'Google authentication not configured' });
    }
    
    console.log('Verifying Google token with Google Client ID:', process.env.GOOGLE_CLIENT_ID.substring(0, 10) + '...');
    
    // Verify Google token
    const ticket = await googleClient.verifyIdToken({
      idToken,
      audience: process.env.GOOGLE_CLIENT_ID
    });
    
    console.log('Token verified successfully');
    
    const payload = ticket.getPayload();
    if (!payload) {
      throw new Error('Failed to get payload from Google token');
    }
    
    const { email_verified, name, email, picture } = payload;
    
    // Check if email is verified
    if (!email_verified) {
      console.log('Google email not verified for:', email);
      return res.status(400).json({ message: 'Google email not verified' });
    }
    
    console.log('Looking for user with email:', email);
    
    // Find or create user
    let user = await User.findOne({ email });
    
    if (!user) {
      console.log('Creating new user for Google auth');
      
      // Create new user with Google credentials
      user = new User({
        fullName: name,
        email,
        googleId: ticket.getUserId(),
        profilePictureUrl: picture || '/images/default-avatar.png'
      });
      
      await user.save();
      console.log('New user created with ID:', user.id);
      
      // Create empty profile for user
      const profile = new Profile({
        user: user.id
      });
      await profile.save();
      console.log('Profile created for new user');
    } else {
      console.log('Existing user found:', user.id);
      
      // Update existing user with Google ID if not already set
      if (!user.googleId) {
        console.log('Updating existing user with Google ID');
        user.googleId = ticket.getUserId();
        
        // Update profile picture if using default
        if (user.profilePictureUrl === '/images/default-avatar.png') {
          user.profilePictureUrl = picture || user.profilePictureUrl;
        }
        await user.save();
      }
    }
    
    // Generate JWT
    const token = await generateToken(user.id);
    console.log('JWT generated for user:', user.id);
    
    res.json({
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        profilePictureUrl: user.profilePictureUrl
      }
    });
  } catch (err) {
    console.error('Google auth error details:', {
      message: err.message,
      stack: err.stack,
      name: err.name
    });
    
    // More specific error responses
    if (err.message.includes('Token used too early')) {
      return res.status(400).json({ message: 'Google token is not yet valid' });
    } else if (err.message.includes('Token used too late')) {
      return res.status(400).json({ message: 'Google token has expired' });
    } else if (err.message.includes('Invalid token signature')) {
      return res.status(400).json({ message: 'Invalid Google token' });
    }
    
    res.status(500).json({ message: 'Error authenticating with Google' });
  }
};

// Get current user
exports.getCurrentUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password -resetPasswordToken -resetPasswordExpire');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error('Get user error:', err.message);
    res.status(500).json({ message: 'Server error getting user data' });
  }
};


// Forgot password - send reset email
exports.forgotPassword = async (req, res) => {
  const { email } = req.body;
  
  try {
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(404).json({ message: 'No account with that email exists' });
    }
    
    // Generate reset token
    const resetToken = user.getResetPasswordToken();
    await user.save({ validateBeforeSave: false });
    
    // Create reset URL
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:5000'}/reset-password/${resetToken}`;
    
    // Create email message
    const message = `
      <h1>Password Reset Request</h1>
      <p>You have requested to reset your password. Please click the link below to reset it:</p>
      <a href="${resetUrl}" target="_blank">Reset Password</a>
      <p>This link will expire in 10 minutes.</p>
      <p>If you didn't request this, please ignore this email and your password will remain unchanged.</p>
    `;
    
    try {
      // Only try to send email if email configuration exists
      if (process.env.EMAIL_HOST && process.env.EMAIL_USER && process.env.EMAIL_PASSWORD) {
        // Create email transport
        const transporter = nodemailer.createTransport({
          host: process.env.EMAIL_HOST,
          port: process.env.EMAIL_PORT,
          secure: process.env.EMAIL_SECURE === 'true',
          auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASSWORD
          }
        });
        
        // Send email
        await transporter.sendMail({
          from: `${process.env.EMAIL_FROM_NAME || 'Boboto'} <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
          to: user.email,
          subject: 'Password Reset Request',
          html: message
        });
      } else {
        // In development, log the reset URL instead of sending email
        console.log('In development mode. Reset URL:', resetUrl);
      }
      
      res.json({ 
        message: 'Password reset email sent',
        // Include token in response for development purposes only
        resetToken: process.env.NODE_ENV === 'development' ? resetToken : undefined
      });
    } catch (emailError) {
      console.error('Email sending failed:', emailError);
      
      // Still return success in development, with the token
      if (process.env.NODE_ENV === 'development') {
        return res.json({ 
          message: 'Email sending failed, but reset token generated in development mode',
          resetToken: resetToken
        });
      }
      
      // In production, reset the token and return error
      user.resetPasswordToken = undefined;
      user.resetPasswordExpire = undefined;
      await user.save({ validateBeforeSave: false });
      
      return res.status(500).json({ message: 'Could not send reset email' });
    }
  } catch (err) {
    console.error('Password reset error:', err);
    res.status(500).json({ message: 'Server error during password reset' });
  }
};

// Reset password with token
exports.resetPassword = async (req, res) => {
  // Get hashed token
  const resetPasswordToken = crypto
    .createHash('sha256')
    .update(req.params.resetToken)
    .digest('hex');
  
  try {
    // Find user by token and check if token is still valid
    const user = await User.findOne({
      resetPasswordToken,
      resetPasswordExpire: { $gt: Date.now() }
    });
    
    if (!user) {
      return res.status(400).json({ message: 'Invalid or expired token' });
    }
    
    // Set new password
    user.password = req.body.password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();
    
    // Generate new token and return user data
    const token = await generateToken(user.id);
    
    res.json({
      token,
      user: {
        id: user.id,
        fullName: user.fullName,
        email: user.email,
        profilePictureUrl: user.profilePictureUrl
      }
    });
  } catch (err) {
    console.error('Reset password error:', err);
    res.status(500).json({ message: 'Server error during password reset' });
  }
};

// Change password while logged in
exports.changePassword = async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  
  try {
    const user = await User.findById(req.user.id);
    
    // Check if current password is correct
    const isMatch = await user.comparePassword(currentPassword);
    if (!isMatch) {
      return res.status(400).json({ message: 'Current password is incorrect' });
    }
    
    // Set new password
    user.password = newPassword;
    await user.save();
    
    res.json({ message: 'Password updated successfully' });
  } catch (err) {
    console.error('Change password error:', err);
    res.status(500).json({ message: 'Server error updating password' });
  }
};