// controllers/savedJobsController.js
const Profile = require('../models/Profile');
const { validationResult } = require('express-validator');

/**
 * Get user's saved jobs
 */
exports.getSavedJobs = async (req, res) => {
  try {
    // Find the user's profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Return saved job IDs
    const savedJobIds = profile.jobApplications
      .filter(job => job.status === 'Saved')
      .map(job => job.jobId);
    
    res.json(savedJobIds);
  } catch (err) {
    console.error('Error getting saved jobs:', err);
    res.status(500).json({ message: 'Server error getting saved jobs' });
  }
};

/**
 * Save a job to the user's profile
 */
exports.saveJob = async (req, res) => {
  try {
    const { jobId } = req.body;
    
    if (!jobId) {
      return res.status(400).json({ message: 'Job ID is required' });
    }
    
    // Find the user's profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Check if job is already saved
    const existingJobIndex = profile.jobApplications.findIndex(
      job => job.jobId === jobId
    );
    
    if (existingJobIndex !== -1) {
      return res.status(400).json({ message: 'Job already saved' });
    }
    
    // Add job to applications with "Saved" status
    profile.jobApplications.push({
      jobId,
      jobTitle: req.body.jobTitle || 'Untitled Job',
      company: req.body.company || 'Unknown Company',
      applicationDate: Date.now(),
      status: 'Saved',
      source: req.body.source || 'Job Board',
      url: req.body.url || ''
    });
    
    await profile.save();
    
    res.json({ message: 'Job saved successfully' });
  } catch (err) {
    console.error('Error saving job:', err);
    res.status(500).json({ message: 'Server error saving job' });
  }
};

/**
 * Remove a saved job from the user's profile
 */
exports.removeSavedJob = async (req, res) => {
  try {
    const { jobId } = req.params;
    
    if (!jobId) {
      return res.status(400).json({ message: 'Job ID is required' });
    }
    
    // Find the user's profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Remove job from applications
    profile.jobApplications = profile.jobApplications.filter(
      job => job.jobId !== jobId
    );
    
    await profile.save();
    
    res.json({ message: 'Job removed successfully' });
  } catch (err) {
    console.error('Error removing saved job:', err);
    res.status(500).json({ message: 'Server error removing saved job' });
  }
};

/**
 * Get all job applications (including saved jobs)
 */
exports.getJobApplications = async (req, res) => {
  try {
    // Find the user's profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Return all job applications
    res.json(profile.jobApplications);
  } catch (err) {
    console.error('Error getting job applications:', err);
    res.status(500).json({ message: 'Server error getting job applications' });
  }
};

/**
 * Update a job application status
 */
exports.updateJobApplication = async (req, res) => {
  try {
    const { jobId } = req.params;
    const { status, notes, nextSteps } = req.body;
    
    if (!jobId) {
      return res.status(400).json({ message: 'Job ID is required' });
    }
    
    // Find the user's profile
    const profile = await Profile.findOne({ user: req.user.id });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Find job application
    const jobIndex = profile.jobApplications.findIndex(
      job => job.jobId === jobId
    );
    
    if (jobIndex === -1) {
      return res.status(404).json({ message: 'Job application not found' });
    }
    
    // Update job application
    if (status) {
      profile.jobApplications[jobIndex].status = status;
    }
    
    if (notes) {
      profile.jobApplications[jobIndex].notes = notes;
    }
    
    if (nextSteps) {
      profile.jobApplications[jobIndex].nextSteps = nextSteps;
    }
    
    await profile.save();
    
    res.json(profile.jobApplications[jobIndex]);
  } catch (err) {
    console.error('Error updating job application:', err);
    res.status(500).json({ message: 'Server error updating job application' });
  }
};

module.exports = exports;