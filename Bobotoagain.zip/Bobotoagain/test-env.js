require('dotenv').config();

console.log('Environment Variable Test Results:');
console.log('=================================');
console.log('MONGODB_URI configured:', !!process.env.MONGODB_URI);
console.log('JWT_SECRET configured:', !!process.env.JWT_SECRET);
console.log('OPENAI_API_KEY configured:', !!process.env.OPENAI_API_KEY);
console.log('=================================');

// Optional: Check the first few characters of sensitive values
// This helps verify they're actually loaded without revealing the full values
if (process.env.MONGODB_URI) {
  console.log('MONGODB_URI starts with:', process.env.MONGODB_URI.substring(0, 12) + '...');
}
if (process.env.JWT_SECRET) {
  console.log('JWT_SECRET starts with:', process.env.JWT_SECRET.substring(0, 4) + '...');
}
if (process.env.OPENAI_API_KEY) {
  console.log('OPENAI_API_KEY starts with:', process.env.OPENAI_API_KEY.substring(0, 7) + '...');
}
