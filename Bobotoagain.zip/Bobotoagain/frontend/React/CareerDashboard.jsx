//frontend/React/ReactDashboard.jsx
import React, { useState } from 'react';
import CareerSuggestions from './CareerSuggestions';
import JobMarketTrends from './JobMarketTrends';
import ResumeAnalyzer from './ResumeAnalyzer';
import JobRecommendations from './JobRecommendations';

const CareerDashboard = () => {
  const [activeTab, setActiveTab] = useState('suggestions');

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Career Guidance</h1>
      
      {/* Navigation Tabs */}
      <div className="mb-8 border-b border-gray-200">
        <nav className="flex -mb-px space-x-8">
          <button
            className={`${
              activeTab === 'suggestions'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            onClick={() => setActiveTab('suggestions')}
          >
            Career Paths
          </button>
          <button
            className={`${
              activeTab === 'jobs'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            onClick={() => setActiveTab('jobs')}
          >
            Job Recommendations
          </button>
          <button
            className={`${
              activeTab === 'trends'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            onClick={() => setActiveTab('trends')}
          >
            Market Trends
          </button>
          <button
            className={`${
              activeTab === 'resume'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            onClick={() => setActiveTab('resume')}
          >
            Resume Analysis
          </button>
        </nav>
      </div>
      
      {/* Tab Content */}
      <div className="tab-content">
        {activeTab === 'suggestions' && <CareerSuggestions />}
        {activeTab === 'jobs' && <JobRecommendations />}
        {activeTab === 'trends' && <JobMarketTrends />}
        {activeTab === 'resume' && <ResumeAnalyzer />}
      </div>
    </div>
  );
};

export default CareerDashboard;