//frontend/React/ResumeAnalyzer.jsx
import React, { useState } from 'react';
import axios from 'axios';

const ResumeAnalyzer = () => {
  const [file, setFile] = useState(null);
  const [filePreview, setFilePreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [analysis, setAnalysis] = useState(null);
  const [targetRole, setTargetRole] = useState('');
  const [showPreview, setShowPreview] = useState(false);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      
      // Create preview URL for PDFs
      if (selectedFile.type === 'application/pdf') {
        const fileUrl = URL.createObjectURL(selectedFile);
        setFilePreview(fileUrl);
      } else {
        setFilePreview(null);
      }
    }
  };

  const handleAnalyzeClick = async () => {
    if (!file) {
      setError('Please upload a resume file first');
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const formData = new FormData();
      formData.append('resume', file);
      
      if (targetRole) {
        formData.append('targetRole', targetRole);
      }
      
      const token = localStorage.getItem('auth_token');
      
      const response = await axios.post('/api/career/analyze-resume', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'x-auth-token': token
        }
      });
      
      setAnalysis(response.data);
      setLoading(false);
      
    } catch (err) {
      console.error('Error analyzing resume:', err);
      setError(err.response?.data?.message || 'Failed to analyze resume. Please try again.');
      setLoading(false);
    }
  };

  const handleTogglePreview = () => {
    setShowPreview(!showPreview);
  };

  const getScoreClass = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPriorityClass = (priority) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-semibold mb-4">Resume Analyzer</h2>
        <p className="text-gray-600 mb-6">
          Upload your resume to get personalized feedback and improvement suggestions based on your career goals.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="resume-upload" className="block text-sm font-medium text-gray-700 mb-2">
              Upload Resume (PDF, DOC, DOCX, or TXT)
            </label>
            <div className="mt-1 flex items-center">
              <input
                id="resume-upload"
                name="resume"
                type="file"
                accept=".pdf,.doc,.docx,.txt,.odt"
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-md file:border-0
                  file:text-sm file:font-medium
                  file:bg-blue-50 file:text-blue-700
                  hover:file:bg-blue-100"
              />
            </div>
            {file && (
              <div className="mt-2 text-sm text-gray-500">
                Selected file: {file.name}
              </div>
            )}
          </div>
          
          <div>
            <label htmlFor="target-role" className="block text-sm font-medium text-gray-700 mb-2">
              Target Role (Optional)
            </label>
            <select
              id="target-role"
              name="targetRole"
              value={targetRole}
              onChange={(e) => setTargetRole(e.target.value)}
              className="block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
            >
              <option value="">Select a role (or leave blank)</option>
              <option value="Software Engineer">Software Engineer</option>
              <option value="Data Scientist">Data Scientist</option>
              <option value="Machine Learning Engineer">Machine Learning Engineer</option>
              <option value="DevOps Engineer">DevOps Engineer</option>
              <option value="Web Developer">Web Developer</option>
              <option value="AI Engineer">AI Engineer</option>
              <option value="Cybersecurity Analyst">Cybersecurity Analyst</option>
            </select>
            <p className="mt-2 text-sm text-gray-500">
              Selecting a specific role will provide tailored feedback for that position.
            </p>
          </div>
        </div>
        
        <div className="mt-6">
          <button
            type="button"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            onClick={handleAnalyzeClick}
            disabled={!file || loading}
          >
            {loading ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Analyzing Resume...
              </>
            ) : 'Analyze Resume'}
          </button>
          
          {filePreview && (
            <button
              type="button"
              className="ml-4 inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              onClick={handleTogglePreview}
            >
              {showPreview ? 'Hide Preview' : 'Show Preview'}
            </button>
          )}
        </div>
        
        {error && (
          <div className="mt-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
            {error}
          </div>
        )}
      </div>
      
      {showPreview && filePreview && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="border-b border-gray-200 px-4 py-3 flex justify-between items-center">
            <h3 className="text-lg font-medium">Resume Preview</h3>
            <button
              type="button"
              className="text-gray-400 hover:text-gray-500"
              onClick={handleTogglePreview}
            >
              <span className="sr-only">Close</span>
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="h-96">
            <iframe 
              src={filePreview} 
              className="w-full h-full" 
              title="Resume Preview"
            ></iframe>
          </div>
        </div>
      )}
      
      {analysis && (
        <div className="space-y-6">
          {/* Overall Assessment */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Resume Analysis Results</h2>
            
            <div className="flex items-center justify-between mb-6">
              <div className="text-lg">Overall Score</div>
              <div className="text-3xl font-bold flex items-center">
                <span className={getScoreClass(analysis.assessment.overallScore.overall)}>
                  {analysis.assessment.overallScore.overall}%
                </span>
                <span className="ml-2 text-sm text-gray-500 font-normal">({getScoreRating(analysis.assessment.overallScore.overall)})</span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500 mb-1">Skills Coverage</div>
                <div className="text-2xl font-bold mb-2 flex items-center">
                  <span className={getScoreClass(analysis.assessment.overallScore.components.skills)}>
                    {analysis.assessment.overallScore.components.skills}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${getProgressBarColor(analysis.assessment.overallScore.components.skills)}`} 
                    style={{ width: `${analysis.assessment.overallScore.components.skills}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500 mb-1">Experience Quality</div>
                <div className="text-2xl font-bold mb-2 flex items-center">
                  <span className={getScoreClass(analysis.assessment.overallScore.components.experience)}>
                    {analysis.assessment.overallScore.components.experience}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${getProgressBarColor(analysis.assessment.overallScore.components.experience)}`} 
                    style={{ width: `${analysis.assessment.overallScore.components.experience}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-4">
                <div className="text-sm text-gray-500 mb-1">Education Relevance</div>
                <div className="text-2xl font-bold mb-2 flex items-center">
                  <span className={getScoreClass(analysis.assessment.overallScore.components.education)}>
                    {analysis.assessment.overallScore.components.education}%
                  </span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className={`h-2.5 rounded-full ${getProgressBarColor(analysis.assessment.overallScore.components.education)}`} 
                    style={{ width: `${analysis.assessment.overallScore.components.education}%` }}
                  ></div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Improvement Suggestions */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Improvement Suggestions</h2>
            
            <div className="space-y-4">
              {analysis.improvements.map((suggestion, index) => (
                <div key={index} className="border-l-4 border-blue-500 bg-blue-50 p-4 rounded-r-md">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 mt-0.5">
                      <svg className="h-5 w-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div className="ml-3 flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="text-md font-medium">{suggestion.suggestion}</h3>
                        <span className={`ml-2 px-2 py-1 text-xs font-medium rounded-full ${getPriorityClass(suggestion.priority)}`}>
                          {suggestion.priority} Priority
                        </span>
                      </div>
                      <div className="mt-1 text-sm text-gray-600">
                        <span className="font-medium">Section:</span> {suggestion.section}
                      </div>
                      <div className="mt-1 text-sm text-gray-600">
                        <span className="font-medium">Why:</span> {suggestion.reason}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Extracted Skills */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Skills Analysis</h2>
            
            <div className="mb-4">
              <h3 className="text-lg font-medium mb-2">Skills Found in Resume</h3>
              <div className="flex flex-wrap gap-2">
                {analysis.sections.skills.map((skill, index) => (
                  <span key={index} className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="mb-4">
              <h3 className="text-lg font-medium mb-2">Skills Missing from Resume</h3>
              <div className="flex flex-wrap gap-2">
                {analysis.assessment.skillCoverage.missing.map((skill, index) => (
                  <span key={index} className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-medium mb-2">Skills Coverage</h3>
              <div className="flex items-center">
                <div className="flex-1">
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className={`h-2.5 rounded-full ${getProgressBarColor(analysis.assessment.skillCoverage.coveragePercent)}`} 
                      style={{ width: `${analysis.assessment.skillCoverage.coveragePercent}%` }}
                    ></div>
                  </div>
                </div>
                <div className="ml-4 text-lg font-medium">
                  <span className={getScoreClass(analysis.assessment.skillCoverage.coveragePercent)}>
                    {analysis.assessment.skillCoverage.coveragePercent}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper functions
function getScoreRating(score) {
  if (score >= 90) return 'Excellent';
  if (score >= 80) return 'Very Good';
  if (score >= 70) return 'Good';
  if (score >= 60) return 'Fair';
  if (score >= 50) return 'Needs Improvement';
  return 'Poor';
}

function getProgressBarColor(score) {
  if (score >= 80) return 'bg-green-600';
  if (score >= 60) return 'bg-yellow-500';
  return 'bg-red-500';
}

export default ResumeAnalyzer;