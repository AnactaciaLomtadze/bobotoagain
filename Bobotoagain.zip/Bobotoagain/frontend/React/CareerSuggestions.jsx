//frontend/React/CareerSuggestions.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const CareerSuggestions = () => {
  const [careerPaths, setCareerPaths] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedCareer, setSelectedCareer] = useState(null);

  useEffect(() => {
    const fetchCareerSuggestions = async () => {
      try {
        setLoading(true);
        const token = localStorage.getItem('auth_token');
        const response = await axios.get('/api/career/suggestions', {
          headers: {
            'x-auth-token': token
          }
        });
        setCareerPaths(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching career suggestions:', err);
        setError('Failed to load career suggestions. Please try again later.');
        setLoading(false);
      }
    };

    fetchCareerSuggestions();
  }, []);

  const handleCareerSelect = (career) => {
    setSelectedCareer(career);
  };

  const handleRequestSkillGap = async (career) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('auth_token');
      const response = await axios.post('/api/career/skill-gap', 
        { targetRole: career.title }, 
        {
          headers: {
            'x-auth-token': token,
            'Content-Type': 'application/json'
          }
        }
      );
      
      // Update the career with skill gap analysis
      const updatedCareer = { ...career, skillGapAnalysis: response.data };
      setSelectedCareer(updatedCareer);
      
      setLoading(false);
    } catch (err) {
      console.error('Error fetching skill gap analysis:', err);
      setError('Failed to load skill gap analysis. Please try again later.');
      setLoading(false);
    }
  };

  if (loading && careerPaths.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error && careerPaths.length === 0) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1">
        <div className="bg-white rounded-lg shadow">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-800">Career Matches</h2>
            <p className="text-sm text-gray-500">Based on your skills and interests</p>
          </div>
          <div className="p-2">
            {careerPaths.map((career, index) => (
              <div 
                key={index}
                className={`p-3 mb-2 rounded cursor-pointer transition duration-150 ${
                  selectedCareer && selectedCareer.title === career.title 
                    ? 'bg-blue-100 border-l-4 border-blue-500' 
                    : 'hover:bg-gray-50'
                }`}
                onClick={() => handleCareerSelect(career)}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-medium">{career.title}</h3>
                  <span className="bg-blue-500 text-white text-xs px-2.5 py-0.5 rounded-full">
                    {career.matchScore}% Match
                  </span>
                </div>
                <p className="text-sm text-gray-600 mt-1">{career.description.substring(0, 60)}...</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="lg:col-span-2">
        {selectedCareer ? (
          <div className="bg-white rounded-lg shadow">
            <div className="p-4 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-semibold text-gray-800">{selectedCareer.title}</h2>
                <span className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm">
                  {selectedCareer.matchScore}% Match
                </span>
              </div>
            </div>
            
            <div className="p-6">
              <p className="text-gray-700 mb-6">{selectedCareer.description}</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                  <h3 className="text-lg font-semibold mb-3">Required Skills</h3>
                  <ul className="space-y-2">
                    {selectedCareer.requiredSkills.map((skill, index) => (
                      <li key={index} className="flex items-center">
                        <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded">
                          {skill}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-3">Career Details</h3>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Salary Range:</span> {selectedCareer.salaryRange}</p>
                    <p><span className="font-medium">Growth Outlook:</span> {selectedCareer.growthOutlook}</p>
                    <p><span className="font-medium">Entry Requirements:</span> {selectedCareer.entryRequirements}</p>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-3">Recommended Next Steps</h3>
                <ul className="space-y-2">
                  {selectedCareer.nextSteps.map((step, index) => (
                    <li key={index} className="flex items-start">
                      <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              {selectedCareer.skillGapAnalysis ? (
                <div>
                  <h3 className="text-lg font-semibold mb-3">Skill Gap Analysis</h3>
                  <div className="bg-gray-50 p-4 rounded-lg mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Skill Match</span>
                      <span className="text-sm font-medium">{selectedCareer.skillGapAnalysis.skillMatchPercentage}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-blue-600 h-2.5 rounded-full" 
                        style={{ width: `${selectedCareer.skillGapAnalysis.skillMatchPercentage}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <h4 className="font-medium mb-2">Your Skills</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedCareer.skillGapAnalysis.userSkills.map((skill, index) => (
                          <span key={index} className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded">
                            {skill.name}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium mb-2">Missing Skills</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedCareer.skillGapAnalysis.missingSkills.map((skill, index) => (
                          <span key={index} className="bg-red-100 text-red-800 text-xs font-medium px-2.5 py-0.5 rounded">
                            {skill.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <h4 className="font-medium mb-2">Recommended Learning Resources</h4>
                  <div className="space-y-2">
                    {selectedCareer.skillGapAnalysis.recommendations.map((rec, index) => (
                      <div key={index} className="border rounded p-3">
                        <div className="flex items-center justify-between">
                          <h5 className="font-medium">{rec.skill}</h5>
                          <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                            rec.priority === 5 ? 'bg-red-100 text-red-800' :
                            rec.priority === 3 ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {rec.priority === 5 ? 'High' : rec.priority === 3 ? 'Medium' : 'Low'} Priority
                          </span>
                        </div>
                        <div className="mt-2">
                          <h6 className="text-sm font-medium mb-1">Recommended Resources:</h6>
                          <ul className="text-sm space-y-1">
                            {rec.resources.map((resource, i) => (
                              <li key={i}>
                                <a 
                                  href={resource.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-blue-600 hover:underline flex items-center"
                                >
                                  <span className="mr-1">{resource.title}</span>
                                  <span className="text-xs bg-gray-100 px-1 rounded">{resource.type}</span>
                                </a>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => handleRequestSkillGap(selectedCareer)}
                  className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition duration-150"
                >
                  {loading ? (
                    <span className="flex items-center justify-center">
                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Analyzing...
                    </span>
                  ) : "Perform Skill Gap Analysis"
                  }
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow p-6 flex items-center justify-center h-full">
            <div className="text-center">
              <svg className="h-16 w-16 text-gray-300 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
              <h3 className="text-lg font-medium text-gray-500">Select a career path to view details</h3>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CareerSuggestions;