// JS/profileManager.js - Fixed Profile Management System
/**
 * profileManager.js - Centralized profile management with proper synchronization
 */

class ProfileManager {
    constructor() {
        this.profileData = null;
        this.isLoading = false;
        this.hasLoadedOnce = false;
        this.syncPromise = null;
        
        // Initialize profile data on construction
        this.initialize();
    }
    
    async initialize() {
        // Always load from server if authenticated
        if (isAuthenticated()) {
            await this.loadProfile();
        } else {
            // Clear any existing profile data if not authenticated
            this.clearLocalProfile();
        }
        
        // Listen for authentication changes
        document.addEventListener('auth-changed', this.handleAuthChange.bind(this));
        document.addEventListener('profile-updated', this.handleProfileUpdate.bind(this));
    }
    
    // Handle authentication state changes
    async handleAuthChange(event) {
        const { isAuthenticated: newAuthState } = event.detail;
        
        if (newAuthState) {
            // User just logged in - load their profile
            await this.loadProfile();
        } else {
            // User logged out - clear profile data
            this.clearLocalProfile();
        }
    }
    
    // Handle profile updates from other parts of the app
    async handleProfileUpdate(event) {
        // Reload profile from server after updates
        if (isAuthenticated()) {
            await this.loadProfile();
        }
    }
    
    // Clear local profile data
    clearLocalProfile() {
        this.profileData = null;
        localStorage.removeItem('user_info');
        localStorage.removeItem('learning_preferences');
        localStorage.removeItem('career_goals');
        localStorage.removeItem('user_skills');
        
        // Emit event for UI updates
        const event = new CustomEvent('profile-cleared');
        document.dispatchEvent(event);
    }
    
    // Load profile data from server
    async loadProfile() {
        // Prevent multiple simultaneous loads
        if (this.isLoading) {
            return this.syncPromise;
        }
        
        this.isLoading = true;
        this.syncPromise = this._loadProfileData();
        
        try {
            await this.syncPromise;
        } finally {
            this.isLoading = false;
            this.syncPromise = null;
        }
    }
    
    async _loadProfileData() {
        try {
            window.logger.log('Loading profile data from server...');
            
            // Load main profile data
            const profileData = await API.Profile.get();
            
            if (!profileData) {
                throw new Error('No profile data returned from server');
            }
            
            // Set profile data
            this.profileData = profileData;
            
            // Load additional data in parallel
            const [learningPrefs, careerGoals, skills] = await Promise.all([
                API.Profile.getLearningPreferences().catch(err => {
                    console.warn('Failed to load learning preferences:', err);
                    return null;
                }),
                API.Profile.getCareerGoals().catch(err => {
                    console.warn('Failed to load career goals:', err);
                    return null;
                }),
                API.Profile.getSkills().catch(err => {
                    console.warn('Failed to load skills:', err);
                    return [];
                })
            ]);
            
            // Merge additional data into profile
            this.profileData.learningPreferences = learningPrefs || {};
            this.profileData.careerGoals = careerGoals || {};
            this.profileData.skills = skills || [];
            
            // Update localStorage with fresh data
            this.updateLocalStorage();
            
            // Update UI across all pages
            this.updateAllPageUIs();
            
            // Emit sync event
            const syncEvent = new CustomEvent('profile-synced', { 
                detail: this.profileData 
            });
            document.dispatchEvent(syncEvent);
            
            this.hasLoadedOnce = true;
            window.logger.log('Profile loaded successfully');
            
            return this.profileData;
            
        } catch (error) {
            console.error('Error loading profile:', error);
            
            // If profile load fails, try to use cached data
            if (!this.hasLoadedOnce) {
                this.loadFromLocalStorage();
            }
            
            throw error;
        }
    }
    
    // Update localStorage with current profile data
    updateLocalStorage() {
        if (!this.profileData) return;
        
        // Update user info
        const userInfo = {
            fullName: this.profileData.fullName,
            email: this.profileData.email,
            profilePictureUrl: this.profileData.profilePictureUrl
        };
        localStorage.setItem('user_info', JSON.stringify(userInfo));
        
        // Update other data
        if (this.profileData.learningPreferences) {
            localStorage.setItem('learning_preferences', JSON.stringify(this.profileData.learningPreferences));
        }
        
        if (this.profileData.careerGoals) {
            localStorage.setItem('career_goals', JSON.stringify(this.profileData.careerGoals));
        }
        
        if (this.profileData.skills) {
            localStorage.setItem('user_skills', JSON.stringify(this.profileData.skills));
        }
    }
    
    // Load profile from localStorage (fallback)
    loadFromLocalStorage() {
        try {
            const userInfo = JSON.parse(localStorage.getItem('user_info') || '{}');
            const learningPrefs = JSON.parse(localStorage.getItem('learning_preferences') || '{}');
            const careerGoals = JSON.parse(localStorage.getItem('career_goals') || '{}');
            const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
            
            if (userInfo && Object.keys(userInfo).length > 0) {
                this.profileData = {
                    ...userInfo,
                    learningPreferences: learningPrefs,
                    careerGoals: careerGoals,
                    skills: skills
                };
                
                this.updateAllPageUIs();
                
                // Try to sync with server in background
                if (isAuthenticated() && navigator.onLine) {
                    this.loadProfile().catch(err => {
                        console.warn('Background sync failed:', err);
                    });
                }
            }
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }
    
    // Update UI across all page types
    updateAllPageUIs() {
        if (!this.profileData) return;
        
        // Update sidebar user info (common across all pages)
        this.updateSidebarUserInfo();
        
        // Update page-specific content based on current page
        const currentPage = window.location.pathname.split('/').pop();
        
        switch (currentPage) {
            case 'bobotoProfile.html':
            case '':
                this.updateProfileDashboard();
                break;
            case 'bobotoPersonal.html':
                this.updatePersonalPage();
                break;
            case 'bobotoLearning.html':
                this.updateLearningPage();
                break;
            case 'bobotoCareer.html':
                this.updateCareerPage();
                break;
            case 'bobotoSkill.html':
                this.updateSkillsPage();
                break;
            case 'bobotoChat.html':
                this.updateChatPage();
                break;
            case 'bobotoChatHistory.html':
                this.updateChatHistoryPage();
                break;
        }
    }
    
    // Update sidebar user information (common across all pages)
    updateSidebarUserInfo() {
        if (!this.profileData) return;
        
        // Update user name
        document.querySelectorAll('.user-name').forEach(el => {
            el.textContent = this.profileData.fullName || 'User';
        });
        
        // Update profile picture
        document.querySelectorAll('.profile-picture img').forEach(el => {
            el.src = this.profileData.profilePictureUrl || '/api/placeholder/200/200';
            el.alt = `${this.profileData.fullName || 'User'}'s profile picture`;
        });
        
        // Update user details
        document.querySelectorAll('.user-details').forEach(el => {
            let detailsText = 'Student';
            if (this.profileData.major) {
                detailsText = this.profileData.major;
                if (this.profileData.academicLevel) {
                    detailsText += ' ' + this.profileData.academicLevel;
                }
                detailsText += ' Student';
            }
            el.textContent = detailsText;
        });
    }
    
    // Update profile dashboard
    updateProfileDashboard() {
        // Update personal info card
        const personalCard = document.querySelector('.card:has(.card-title:contains("Personal Information"))');
        if (personalCard) {
            const content = personalCard.querySelector('.card-content ul');
            if (content) {
                content.innerHTML = `
                    <li><span>Name:</span> <span>${this.profileData.fullName || 'Not set'}</span></li>
                    <li><span>Email:</span> <span>${this.profileData.email || 'Not set'}</span></li>
                    <li><span>Phone:</span> <span>${this.profileData.phone || 'Not set'}</span></li>
                `;
            }
        }
        
        // Update learning preferences card
        const learningCard = document.querySelector('.card:has(.card-title:contains("Learning Preferences"))');
        if (learningCard) {
            const content = learningCard.querySelector('.card-content ul');
            if (content) {
                const prefs = this.profileData.learningPreferences || {};
                content.innerHTML = `
                    <li><span>Learning Style:</span> <span>${prefs.learningStyle || 'Not set'}</span></li>
                    <li><span>Favorite Subjects:</span> <span>${prefs.subjectInterests?.join(', ') || 'Not set'}</span></li>
                    <li><span>Learning Pace:</span> <span>${prefs.learningPace || 'Not set'}</span></li>
                `;
            }
        }
        
        // Update career goals card
        const careerCard = document.querySelector('.card:has(.card-title:contains("Career Goals"))');
        if (careerCard) {
            const content = careerCard.querySelector('.card-content ul');
            if (content) {
                const goals = this.profileData.careerGoals || {};
                content.innerHTML = `
                    <li><span>Short-Term:</span> <span>${goals.shortTermGoal || 'Not set'}</span></li>
                    <li><span>Long-Term:</span> <span>${goals.longTermGoal || 'Not set'}</span></li>
                    <li><span>Skills Focus:</span> <span>${goals.skillsFocus?.join(', ') || 'Not set'}</span></li>
                `;
            }
        }
        
        // Update skills progress
        this.updateSkillsProgress();
    }
    
    // Update skills progress section
    updateSkillsProgress() {
        const progressSection = document.querySelector('.progress-section');
        if (!progressSection || !this.profileData.skills) return;
        
        const skills = this.profileData.skills;
        
        // Clear existing content
        progressSection.innerHTML = `
            <div class="progress-header">
                <h3 class="progress-title">Skills Progress</h3>
                <a href="bobotoSkill.html" class="btn btn-outline">View All Skills</a>
            </div>
        `;
        
        // Show top 3 skills or empty message
        if (skills.length === 0) {
            progressSection.innerHTML += '<p>No skills added yet. Add skills to track your progress.</p>';
        } else {
            // Sort and get top 3 skills
            const sortedSkills = [...skills].sort((a, b) => {
                const levels = { 'Expert': 90, 'Advanced': 75, 'Intermediate': 50, 'Beginner': 25, 'Novice': 10 };
                return (levels[b.level] || 0) - (levels[a.level] || 0);
            });
            
            const topSkills = sortedSkills.slice(0, 3);
            
            topSkills.forEach(skill => {
                const percentage = {
                    'Expert': 90, 'Advanced': 75, 'Intermediate': 50, 'Beginner': 25, 'Novice': 10
                }[skill.level] || 0;
                
                progressSection.innerHTML += `
                    <div class="progress-item">
                        <div class="progress-label">
                            <span>${skill.name}</span>
                            <span>${percentage}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-value" style="width: ${percentage}%;"></div>
                        </div>
                    </div>
                `;
            });
        }
    }
    
    // Update personal page
    updatePersonalPage() {
        // Fill basic info form
        const basicForm = document.getElementById('basicInfoForm');
        if (basicForm) {
            this.fillFormField('fullName', this.profileData.fullName);
            this.fillFormField('displayName', this.profileData.fullName?.split(' ')[0]);
            this.fillFormField('email', this.profileData.email);
            this.fillFormField('phone', this.profileData.phone);
            
            // Additional fields - might need to be added to schema
            this.fillFormField('birthdate', this.profileData.birthdate);
            this.fillFormField('location', this.profileData.location);
        }
        
        // Fill academic info form
        const academicForm = document.getElementById('academicInfoForm');
        if (academicForm) {
            this.fillFormField('institution', this.profileData.university);
            this.fillFormField('degree', this.profileData.degree || 'Bachelor of Science');
            this.fillFormField('major', this.profileData.major);
            this.fillFormField('graduationYear', this.profileData.graduationYear ? `${this.profileData.graduationYear}-05` : '');
            this.fillFormField('gpa', this.profileData.gpa);
            
            // Set academic status dropdown
            const statusSelect = document.getElementById('academicStatus');
            if (statusSelect && this.profileData.academicLevel) {
                // Map academicLevel to select options
                const levelMap = {
                    'Undergraduate': 'fullTime',
                    'Graduate': 'fullTime',
                    'PhD': 'fullTime'
                };
                statusSelect.value = levelMap[this.profileData.academicLevel] || 'fullTime';
            }
        }
        
        // Update profile picture
        const profilePicPreview = document.getElementById('currentProfilePic');
        if (profilePicPreview) {
            profilePicPreview.src = this.profileData.profilePictureUrl || '/api/placeholder/200/200';
        }
    }
    
    // Update learning page
    updateLearningPage() {
        const prefs = this.profileData.learningPreferences || {};
        
        // Update learning styles
        document.querySelectorAll('.learning-style-option').forEach(option => {
            const titleEl = option.querySelector('.learning-style-title');
            if (titleEl && prefs.learningStyles?.includes(titleEl.textContent)) {
                option.classList.add('selected');
            } else {
                option.classList.remove('selected');
            }
        });
        
        // Update subject interests
        this.updateTagsContainer('subjectTags', prefs.subjectInterests || []);
        
        // Update challenges
        this.updateTagsContainer('challengeTags', prefs.challenges || []);
        
        // Update form fields
        this.fillFormField('learningPace', prefs.learningPace);
        this.fillFormField('explanationDepth', prefs.explanationDepth);
        this.fillFormField('contentFormat', prefs.contentFormat);
        this.fillFormField('learningGoal', prefs.learningGoal);
        this.fillFormField('technicalLevel', prefs.technicalLevel);
        this.fillFormField('theoryPractice', prefs.theoryPractice);
        this.fillFormField('additionalNotes', prefs.additionalNotes);
    }
    
    // Update career page
    updateCareerPage() {
        const goals = this.profileData.careerGoals || {};
        
        // Update career milestones
        this.fillFormField('shortTermGoal', goals.shortTermGoal);
        this.fillFormField('midTermGoal', goals.midTermGoal);
        this.fillFormField('longTermGoal', goals.longTermGoal);
        this.fillFormField('shortTermTarget', goals.shortTermTarget);
        this.fillFormField('midTermTarget', goals.midTermTarget);
        this.fillFormField('longTermTarget', goals.longTermTarget);
        
        // Update industry focus
        this.fillFormField('primaryIndustry', goals.targetIndustry);
        this.fillFormField('secondaryIndustry', goals.secondaryIndustry);
        this.fillFormField('companySize', goals.companySize);
        this.fillFormField('workEnvironment', goals.workEnvironment);
        this.fillFormField('dreamCompanies', goals.dreamCompanies);
        
        // Update skills focus
        if (goals.skillsFocus) {
            goals.skillsFocus.forEach(skill => {
                const checkbox = document.querySelector(`input[type="checkbox"][value="${skill}"]`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        }
        
        // Update location and salary preferences
        this.fillFormField('locationPreference', goals.locationPreference);
        this.fillFormField('salaryExpectations', goals.salaryExpectations);
        
        // Update learning and certification goals
        this.fillFormField('primarySkillFocus', goals.primarySkillFocus);
        this.fillFormField('learningTimeCommitment', goals.learningTimeCommitment);
        this.fillFormField('certificationGoals', goals.certificationGoals);
        this.fillFormField('certificationTimeline', goals.certificationTimeline);
    }
    
    // Update skills page
    updateSkillsPage() {
        const skills = this.profileData.skills || [];
        
        // Update skills statistics
        const totalSkills = skills.length;
        const skillsByLevel = skills.reduce((acc, skill) => {
            acc[skill.level] = (acc[skill.level] || 0) + 1;
            return acc;
        }, {});
        
        const expertSkills = skillsByLevel['Expert'] || 0;
        const improvementSkills = (skillsByLevel['Beginner'] || 0) + (skillsByLevel['Novice'] || 0);
        
        // Calculate overall progress
        const totalWeightedScore = Object.entries(skillsByLevel).reduce((sum, [level, count]) => {
            const weights = { 'Expert': 90, 'Advanced': 75, 'Intermediate': 50, 'Beginner': 25, 'Novice': 10 };
            return sum + (weights[level] || 0) * count;
        }, 0);
        
        const overallProgress = totalSkills > 0 ? Math.round(totalWeightedScore / totalSkills) : 0;
        
        // Update stats display
        const statValues = document.querySelectorAll('.stat-value');
        if (statValues[0]) statValues[0].textContent = totalSkills;
        if (statValues[1]) statValues[1].textContent = `${overallProgress}%`;
        if (statValues[2]) statValues[2].textContent = expertSkills;
        if (statValues[3]) statValues[3].textContent = improvementSkills;
        
        // Update skill categories
        this.updateSkillCategories(skills);
    }
    
    // Update skill categories
    updateSkillCategories(skills) {
        const categories = ['technical', 'soft', 'academic', 'career'];
        
        categories.forEach(category => {
            const categorySkills = skills.filter(skill => skill.category === category);
            const skillGroup = document.getElementById(category);
            
            if (skillGroup) {
                // Clear existing skills except title
                const title = skillGroup.querySelector('.skill-group-title');
                skillGroup.innerHTML = '';
                if (title) skillGroup.appendChild(title);
                
                // Add skills
                categorySkills.forEach(skill => {
                    const skillCard = this.createSkillCard(skill);
                    skillGroup.appendChild(skillCard);
                });
                
                // Show empty state if no skills
                if (categorySkills.length === 0) {
                    skillGroup.innerHTML += '<p>No skills added yet.</p>';
                }
            }
        });
    }
    
    // Create skill card element
    createSkillCard(skill) {
        const div = document.createElement('div');
        div.className = 'skill-card';
        
        const percentage = {
            'Expert': 90, 'Advanced': 75, 'Intermediate': 50, 'Beginner': 25, 'Novice': 10
        }[skill.level] || 0;
        
        div.innerHTML = `
            <div class="skill-header">
                <h3 class="skill-title">${skill.name}</h3>
                <div class="skill-level">
                    <span class="skill-badge ${skill.level.toLowerCase()}">${skill.level}</span>
                </div>
            </div>
            <div class="skill-progress-label">
                <span>Current Level</span>
                <span>${percentage}%</span>
            </div>
            <div class="skill-progress-bar">
                <div class="skill-progress-value" style="width: ${percentage}%;"></div>
            </div>
        `;
        
        return div;
    }
    
    // Update chat page
    updateChatPage() {
        // Update welcome message if available
        const welcomeMsg = document.querySelector('.welcome-message h2');
        if (welcomeMsg && this.profileData.fullName) {
            const firstName = this.profileData.fullName.split(' ')[0];
            welcomeMsg.textContent = `Welcome, ${firstName}!`;
        }
    }
    
    // Update chat history page
    updateChatHistoryPage() {
        // No specific updates needed beyond sidebar
        // Chat history is loaded independently
    }
    
    // Helper methods
    fillFormField(fieldId, value) {
        const field = document.getElementById(fieldId);
        if (field && value !== undefined && value !== null) {
            field.value = value;
        }
    }
    
    updateTagsContainer(containerId, tags) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // Clear existing tags except input
        const inputGroup = container.querySelector('.add-tag-input');
        container.innerHTML = '';
        if (inputGroup) {
            container.appendChild(inputGroup);
        }
        
        // Add tags
        tags.forEach(tag => {
            const tagElement = document.createElement('span');
            tagElement.className = 'tag selected';
            tagElement.onclick = function() { toggleTag(this); };
            tagElement.innerHTML = `${tag}<span class="remove-tag" onclick="removeTag(event, this)">✕</span>`;
            container.appendChild(tagElement);
        });
    }
    
    // Public methods for updating profile data
    async updateProfile(updates) {
        try {
            // Update server
            const result = await API.Profile.update(updates);
            
            // Merge updates into local profile
            this.profileData = { ...this.profileData, ...result };
            
            // Update localStorage
            this.updateLocalStorage();
            
            // Update UI
            this.updateAllPageUIs();
            
            // Emit event
            const event = new CustomEvent('profile-updated', { detail: this.profileData });
            document.dispatchEvent(event);
            
            return true;
        } catch (error) {
            console.error('Error updating profile:', error);
            throw error;
        }
    }
    
    async updateLearningPreferences(preferences) {
        try {
            // Update server
            const result = await API.Profile.updateLearningPreferences(preferences);
            
            // Update local profile
            this.profileData.learningPreferences = result;
            
            // Update localStorage
            localStorage.setItem('learning_preferences', JSON.stringify(result));
            
            // Update UI
            this.updateLearningPage();
            
            return true;
        } catch (error) {
            console.error('Error updating learning preferences:', error);
            throw error;
        }
    }
    
    async updateCareerGoals(goals) {
        try {
            // Update server
            const result = await API.Profile.updateCareerGoals(goals);
            
            // Update local profile
            this.profileData.careerGoals = result;
            
            // Update localStorage
            localStorage.setItem('career_goals', JSON.stringify(result));
            
            // Update UI
            this.updateCareerPage();
            
            return true;
        } catch (error) {
            console.error('Error updating career goals:', error);
            throw error;
        }
    }
    
    async addSkill(name, level) {
        try {
            // Update server
            const result = await API.Profile.addSkill(name, level);
            
            // Update local profile
            this.profileData.skills = result;
            
            // Update localStorage
            localStorage.setItem('user_skills', JSON.stringify(result));
            
            // Update UI
            this.updateSkillsPage();
            this.updateSkillsProgress();
            
            return true;
        } catch (error) {
            console.error('Error adding skill:', error);
            throw error;
        }
    }
}

// Initialize profile manager
const profileManager = new ProfileManager();

// Export to window
window.profileManager = profileManager;

// Helper function to trigger auth change event
function triggerAuthChange(isAuthenticated) {
    const event = new CustomEvent('auth-changed', { 
        detail: { isAuthenticated } 
    });
    document.dispatchEvent(event);
}