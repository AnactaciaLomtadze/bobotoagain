// JS/serverConfig.js - Frontend configuration file
/**
 * serverConfig.js - Configuration for API endpoints and environment variables
 */

window.serverConfig = {
  // API Base URL - Update this for production
  apiUrl: 'http://localhost:5000/api',
    
  // Google OAuth client ID (if you're still using Google auth)
  googleClientId: '553695210966-n0ll7o356saoofcat2rlnvo6ln9u9njq.apps.googleusercontent.com',
    
  // AI Model Configuration
  aiModel: 'deepseek/deepseek-r1:free', // Default DeepSeek model
  
  // App version
  version: '1.0.0',
    
  // Frontend base URL - Used for reset password links
  frontendUrl: window.location.origin,
    
  // Debug mode
  debug: false
};

// Enable debug mode in development environment
if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
  window.serverConfig.debug = true;
}

// Logging utility
window.logger = {
  log: function(...args) {
    if (window.serverConfig.debug) {
      console.log('[Boboto]', ...args);
    }
  },
  error: function(...args) {
    console.error('[Boboto Error]', ...args);
  },
  warn: function(...args) {
    if (window.serverConfig.debug) {
      console.warn('[Boboto Warning]', ...args);
    }
  }
};