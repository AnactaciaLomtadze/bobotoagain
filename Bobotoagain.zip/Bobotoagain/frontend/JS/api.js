// JS/api.js - Corrected for DeepSeek integration
// API service for Boboto frontend

// Base configuration
const API_URL = window.serverConfig ? window.serverConfig.apiUrl : '/api';

// General API error handler
const handleApiError = (error) => {
  console.error('API Error:', error);
  
  if (error.response) {
    // Server responded with an error status
    return Promise.reject({
      status: error.response.status,
      message: error.response.data.message || 'An error occurred'
    });
  } else if (error.request) {
    // Request was made but no response received
    return Promise.reject({
      status: 0,
      message: 'No response from server. Please check your connection.'
    });
  } else {
    // Something else caused an error
    return Promise.reject({
      status: 0,
      message: error.message || 'An unexpected error occurred'
    });
  }
};

// Main API object
const API = {
  // Authentication methods
  Auth: {
    register: async (email, password, fullName) => {
      try {
        const response = await fetch(`${API_URL}/auth/register`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email, password, fullName })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    login: async (email, password) => {
      try {
        const response = await fetch(`${API_URL}/auth/login`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email, password })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    googleLogin: async (idToken) => {
      try {
        const response = await fetch(`${API_URL}/auth/google`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ idToken })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    forgotPassword: async (email) => {
      try {
        const response = await fetch(`${API_URL}/auth/forgot-password`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    resetPassword: async (resetToken, password) => {
      try {
        const response = await fetch(`${API_URL}/auth/reset-password/${resetToken}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ password })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    changePassword: async (currentPassword, newPassword) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/auth/change-password`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ currentPassword, newPassword })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getCurrentUser: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/auth`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // Profile methods
  Profile: {
    get: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    update: async (profileData) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(profileData)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getLearningPreferences: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/learning-preferences`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    updateLearningPreferences: async (preferences) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/learning-preferences`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(preferences)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getCareerGoals: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/career-goals`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    updateCareerGoals: async (goals) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/career-goals`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(goals)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getSkills: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/skills`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    addSkill: async (name, level) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/skills`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ name, level })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    removeSkill: async (skillId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/skills/${skillId}`, {
          method: 'DELETE',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    uploadProfilePicture: async (formData) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/profile/upload-picture`, {
          method: 'POST',
          headers: {
            'x-auth-token': token
          },
          body: formData
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
  // Chat methods
  Chat: {
    getSessions: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    createSession: async (title) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ title })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    getMessages: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions/${sessionId}/messages`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    addMessage: async (sessionId, text, isUser = true) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions/${sessionId}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ text, isUser })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    deleteSession: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions/${sessionId}`, {
          method: 'DELETE',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    saveSessionAsFavorite: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions/${sessionId}/save`, {
          method: 'PUT',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    removeSessionFromFavorites: async (sessionId) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/sessions/${sessionId}/unsave`, {
          method: 'PUT',
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    searchSessions: async (searchTerm) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/chat/search?searchTerm=${encodeURIComponent(searchTerm)}`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    }
  },
  
 // Academic methods
 Academic: {
  askQuestion: async (subject, question, difficulty) => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) throw new Error('No authentication token found');

      const response = await fetch(`${API_URL}/academic/question`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({ subject, question, difficulty })
      });

      const data = await response.json();
      if (!response.ok) throw { response: { status: response.status, data } };
      return data.response;
    } catch (error) {
      return handleApiError(error);
    }
  },

  explainConcept: async (concept, context, breakdownLevel) => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) throw new Error('No authentication token found');

      const response = await fetch(`${API_URL}/academic/explain`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({ concept, context, breakdownLevel })
      });

      const data = await response.json();
      if (!response.ok) throw { response: { status: response.status, data } };
      return data.response;
    } catch (error) {
      return handleApiError(error);
    }
  },

  recommendMaterials: async (topic, materialTypes, learningLevel) => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) throw new Error('No authentication token found');

      const response = await fetch(`${API_URL}/academic/materials`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({ topic, materialTypes, learningLevel })
      });

      const data = await response.json();
      if (!response.ok) throw { response: { status: response.status, data } };
      return data.response;
    } catch (error) {
      return handleApiError(error);
    }
  },

  assignmentHelp: async (assignment, question, type) => {
    try {
      const token = localStorage.getItem('auth_token');
      if (!token) throw new Error('No authentication token found');

      const response = await fetch(`${API_URL}/academic/assignment-help`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': token
        },
        body: JSON.stringify({ assignment, question, type })
      });

      const data = await response.json();
      if (!response.ok) throw { response: { status: response.status, data } };
      return data.response;
    } catch (error) {
      return handleApiError(error);
    }
  },
  // Get learning resources
  getLearningResources: async (topic, format) => {
    try {
      const token = localStorage.getItem('auth_token');
      
      if (!token) {
        throw new Error('No authentication token found');
      }
      
      const response = await fetch(`${API_URL}/academic/resources?topic=${encodeURIComponent(topic)}&format=${format || 'all'}`, {
        headers: {
          'x-auth-token': token
        }
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw { response: { status: response.status, data } };
      }
      
      return data;
    } catch (error) {
      return handleApiError(error);
    }
  }
  },
  
  // DeepSeek AI methods
  AI: {
    // Generate response using DeepSeek
    generateResponse: async (message, chatHistory) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/ai/chat`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify({ message, chatHistory })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        // Return the response directly
        return data.response || data;
      } catch (error) {
        console.error('DeepSeek API error:', error);
        throw error;
      }
    },
    
    // Get AI settings
    getSettings: async () => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/ai/settings`, {
          headers: {
            'x-auth-token': token
          }
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    // Update AI settings
    updateSettings: async (settings) => {
      try {
        const token = localStorage.getItem('auth_token');
        
        if (!token) {
          throw new Error('No authentication token found');
        }
        
        const response = await fetch(`${API_URL}/ai/settings`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'x-auth-token': token
          },
          body: JSON.stringify(settings)
        });
        
        const data = await response.json();
        
        if (!response.ok) {
          throw { response: { status: response.status, data } };
        }
        
        return data;
      } catch (error) {
        return handleApiError(error);
      }
    },
    
    // Get fallback response when API fails
    getFallbackResponse: (message) => {
      const lowerMsg = message.toLowerCase();
      
      if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('hey')) {
        return "Hello! I'm Boboto, your academic and career assistant powered by DeepSeek AI. How can I help you today?";
      } else if (lowerMsg.includes('study plan') || lowerMsg.includes('learning plan')) {
        return "Creating an effective study plan involves understanding your goals, current skill level, and learning style. I'd recommend starting with a clear objective, breaking it down into smaller topics, and allocating time for regular practice and revision. Would you like me to help you create a more detailed study plan for a specific subject?";
      } else if (lowerMsg.includes('career') || lowerMsg.includes('job')) {
        return "The tech field offers many career paths. Based on current trends, roles in AI/ML, cloud architecture, cybersecurity, and full-stack development are particularly in demand. To help you further, could you tell me more about your interests and current skills?";
      } else {
        return "That's an interesting question. I'm here to help with your academic and career development. Could you tell me more about what you're looking to learn or achieve?";
      }
    }
  }

  
};

// Authentication utilities for localStorage
// Store auth data in localStorage
function setAuthData(token, user) {
  localStorage.setItem('auth_token', token);
  localStorage.setItem('user_info', JSON.stringify(user));
}

// Clear auth data from localStorage
function clearAuthData() {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_info');
  localStorage.removeItem('learning_preferences');
  localStorage.removeItem('career_goals');
  localStorage.removeItem('user_skills');
  localStorage.removeItem('offline_changes');
}

// Show notification
function showNotification(message, type = 'info') {
  // Create notification element if it doesn't exist
  let notificationContainer = document.querySelector('.notification-container');
  
  if (!notificationContainer) {
    notificationContainer = document.createElement('div');
    notificationContainer.className = 'notification-container';
    document.body.appendChild(notificationContainer);
  }
  
  // Create notification
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</span>
    </div>
    <button class="notification-close">&times;</button>
  `;
  
  // Add to container
  notificationContainer.appendChild(notification);
  
  // Add close button functionality
  const closeBtn = notification.querySelector('.notification-close');
  closeBtn.addEventListener('click', () => {
    notification.classList.add('closing');
    setTimeout(() => {
      notificationContainer.removeChild(notification);
    }, 300);
  });
  
  // Auto close after 5 seconds
  setTimeout(() => {
    if (notification.parentNode) {
      notification.classList.add('closing');
      setTimeout(() => {
        if (notification.parentNode) {
          notificationContainer.removeChild(notification);
        }
      }, 300);
    }
  }, 5000);
}

// Export functions to window for global access
window.API = API;
window.setAuthData = setAuthData;
window.clearAuthData = clearAuthData;
window.showNotification = showNotification;