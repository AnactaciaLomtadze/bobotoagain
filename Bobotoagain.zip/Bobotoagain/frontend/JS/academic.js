// JS/academic.js
/**
 * academic.js - Academic dashboard functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', async () => {
    // Protect the page
    protectPage();
    
    // Update UI with user profile
    updateUserProfile();
    
    // Initialize dashboard
    initAcademicDashboard();
    
    // Setup event listeners
    setupEventListeners();
    
    // Initialize charts
    initializeCharts();
  });
  
  // Update user profile information
  async function updateUserProfile() {
    try {
      // Get user profile data
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        showNotification('Failed to load profile data', 'error');
        return;
      }
      
      // Update profile picture
      const profilePicture = document.getElementById('profilePicture');
      if (profilePicture && profileData.profilePictureUrl) {
        profilePicture.src = profileData.profilePictureUrl;
      }
      
      // Update user name
      const userName = document.getElementById('userName');
      if (userName) {
        userName.textContent = profileData.fullName || 'User';
      }
      
      // Update user details
      const userDetails = document.getElementById('userDetails');
      if (userDetails) {
        let detailsText = 'Student';
        if (profileData.major) {
          detailsText = profileData.major;
          if (profileData.academicLevel) {
            detailsText += ' ' + profileData.academicLevel;
          }
          detailsText += ' Student';
        }
        userDetails.textContent = detailsText;
      }
    } catch (error) {
      console.error('Error updating user profile:', error);
    }
  }
  
  // Initialize the academic dashboard
  async function initAcademicDashboard() {
    try {
      // Set today's date as default for study date input
      const studyDateInput = document.getElementById('studyDate');
      if (studyDateInput) {
        studyDateInput.valueAsDate = new Date();
      }
      
      // Load study statistics
      await loadStudyStatistics();
      
      // Load resources
      await loadResources();
      
      // Populate subject filter in resource section
      populateSubjectFilter();
      
    } catch (error) {
      console.error('Error initializing academic dashboard:', error);
      showNotification('Error loading academic data', 'error');
    }
  }
  
  // Setup event listeners
  function setupEventListeners() {
    // Study time form submission
    const studyTimeForm = document.getElementById('studyTimeForm');
    if (studyTimeForm) {
      studyTimeForm.addEventListener('submit', handleStudyTimeSubmit);
    }
    
    // Add resource form submission
    const addResourceForm = document.getElementById('addResourceForm');
    if (addResourceForm) {
      addResourceForm.addEventListener('submit', handleAddResourceSubmit);
    }
    
    // Resource filters
    const resourceFilters = document.querySelectorAll('.resource-filters select');
    resourceFilters.forEach(filter => {
      filter.addEventListener('change', filterResources);
    });
    
    // Study plan form submission
    const studyPlanForm = document.getElementById('studyPlanForm');
    if (studyPlanForm) {
      studyPlanForm.addEventListener('submit', handleStudyPlanSubmit);
    }
  }
  
  // Handle study time form submission
  async function handleStudyTimeSubmit(event) {
    event.preventDefault();
    
    const subject = document.getElementById('studySubject').value;
    const minutes = document.getElementById('studyMinutes').value;
    const date = document.getElementById('studyDate').value;
    
    if (!subject || !minutes) {
      showNotification('Please fill all required fields', 'error');
      return;
    }
    
    try {
      const response = await fetch(`${window.serverConfig.apiUrl}/academic/track-study`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token')
        },
        body: JSON.stringify({
          subject,
          minutes,
          date
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to track study time');
      }
      
      showNotification('Study time tracked successfully!', 'success');
      
      // Reset form
      document.getElementById('studyTimeForm').reset();
      
      // Set today's date again
      document.getElementById('studyDate').valueAsDate = new Date();
      
      // Reload statistics
      await loadStudyStatistics();
      
      // Update charts
      updateCharts();
      
    } catch (error) {
      console.error('Error tracking study time:', error);
      showNotification(error.message || 'Error tracking study time', 'error');
    }
  }
  
  // Load study statistics
  async function loadStudyStatistics() {
    try {
      const profile = await API.Profile.get();
      
      if (!profile || !profile.academicProgress) {
        // No academic progress data yet
        return;
      }
      
      const studyTime = profile.academicProgress.studyTime;
      
      // Update total study time
      const totalStudyTime = document.getElementById('totalStudyTime');
      if (totalStudyTime && studyTime.total) {
        const hours = Math.floor(studyTime.total / 60);
        const minutes = studyTime.total % 60;
        totalStudyTime.textContent = `${hours} hrs ${minutes} mins`;
      }
      
      // Update subjects count
      const subjectsCount = document.getElementById('subjectsCount');
      if (subjectsCount && profile.academicProgress.subjects) {
        subjectsCount.textContent = profile.academicProgress.subjects.length;
      }
      
      // Calculate study streak
      const studyStreak = document.getElementById('studyStreak');
      if (studyStreak && studyTime.dailyLog) {
        const streak = calculateStudyStreak(studyTime.dailyLog);
        studyStreak.textContent = `${streak} days`;
      }
      
      // Calculate weekly average
      const weeklyAverage = document.getElementById('weeklyAverage');
      if (weeklyAverage && studyTime.dailyLog) {
        const average = calculateWeeklyAverage(studyTime.dailyLog);
        weeklyAverage.textContent = `${average} hrs/week`;
      }
      
    } catch (error) {
      console.error('Error loading study statistics:', error);
    }
  }
  
  // Calculate study streak
  function calculateStudyStreak(dailyLog) {
    if (!dailyLog || dailyLog.length === 0) {
      return 0;
    }
    
    // Sort log by date (newest first)
    const sortedLog = [...dailyLog].sort((a, b) => 
      new Date(b.date) - new Date(a.date)
    );
    
    // Get today's date
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Check if studied today
    const latestDate = new Date(sortedLog[0].date);
    latestDate.setHours(0, 0, 0, 0);
    
    let streak = 0;
    let currentDate = today;
    
    // Find all consecutive days
    for (let i = 0; i < sortedLog.length; i++) {
      const logDate = new Date(sortedLog[i].date);
      logDate.setHours(0, 0, 0, 0);
      
      // Check if this log entry is for the current date we're checking
      if (logDate.getTime() === currentDate.getTime()) {
        streak++;
        
        // Move to previous day
        currentDate = new Date(currentDate);
        currentDate.setDate(currentDate.getDate() - 1);
      } else if (logDate.getTime() < currentDate.getTime()) {
        // We missed a day, streak is broken
        break;
      }
    }
    
    return streak;
  }
  
  // Calculate weekly average study hours
  function calculateWeeklyAverage(dailyLog) {
    if (!dailyLog || dailyLog.length === 0) {
      return 0;
    }
    
    // Get dates for the last 4 weeks
    const today = new Date();
    const fourWeeksAgo = new Date();
    fourWeeksAgo.setDate(today.getDate() - 28);
    
    // Filter logs from the last 4 weeks
    const recentLogs = dailyLog.filter(log => 
      new Date(log.date) >= fourWeeksAgo
    );
    
    // Calculate total minutes
    const totalMinutes = recentLogs.reduce((sum, log) => sum + log.minutes, 0);
    
    // Convert to average hours per week
    const avgHoursPerWeek = (totalMinutes / 60) / 4;
    
    return avgHoursPerWeek.toFixed(1);
  }
  
  // Handle add resource form submission
  async function handleAddResourceSubmit(event) {
    event.preventDefault();
    
    const title = document.getElementById('resourceTitle').value;
    const url = document.getElementById('resourceUrl').value;
    const type = document.getElementById('resourceType').value;
    const subject = document.getElementById('resourceSubject').value;
    const notes = document.getElementById('resourceNotes').value;
    
    if (!title || !url || !type || !subject) {
      showNotification('Please fill all required fields', 'error');
      return;
    }
    
    try {
      const response = await fetch(`${window.serverConfig.apiUrl}/academic/resources`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token')
        },
        body: JSON.stringify({
          title,
          url,
          type,
          subject,
          notes
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to add resource');
      }
      
      showNotification('Resource added successfully!', 'success');
      
      // Reset form
      document.getElementById('addResourceForm').reset();
      
      // Close modal
      closeModal('addResourceModal');
      
      // Reload resources
      await loadResources();
      
      // Update subject filter
      populateSubjectFilter();
      
    } catch (error) {
      console.error('Error adding resource:', error);
      showNotification(error.message || 'Error adding resource', 'error');
    }
  }
  
  // Load resources
  async function loadResources() {
    try {
      const profile = await API.Profile.get();
      
      if (!profile || !profile.resourceLibrary) {
        // No resources yet
        return;
      }
      
      const resources = profile.resourceLibrary;
      
      // Sort resources by date added (newest first)
      resources.sort((a, b) => new Date(b.addedAt) - new Date(a.addedAt));
      
      // Render resources
      renderResources(resources);
      
    } catch (error) {
      console.error('Error loading resources:', error);
    }
  }
  
  // Render resources
  function renderResources(resources) {
    const resourceList = document.getElementById('resourceList');
    if (!resourceList) return;
    
    if (!resources || resources.length === 0) {
      resourceList.innerHTML = `
        <div class="empty-state">
          <p>No resources found. Add your first learning resource!</p>
        </div>
      `;
      return;
    }
    
    let html = '';
    
    resources.forEach(resource => {
      // Determine resource completion status
      let statusClass = 'not-started';
      let statusText = 'Not Started';
      if (resource.completed) {
        statusClass = 'completed';
        statusText = 'Completed';
      } else if (resource.progress > 0) {
        statusClass = 'in-progress';
        statusText = 'In Progress';
      }
      
      // Determine resource type icon
      let typeIcon = '📄';
      switch (resource.type) {
        case 'book': typeIcon = '📚'; break;
        case 'video': typeIcon = '🎬'; break;
        case 'course': typeIcon = '👨‍🏫'; break;
        case 'article': typeIcon = '📰'; break;
        case 'tutorial': typeIcon = '📝'; break;
      }
      
      // Format date
      const addedDate = new Date(resource.addedAt).toLocaleDateString();
      
      html += `
        <div class="resource-item ${statusClass}" data-id="${resource._id}" data-subject="${resource.subject}" data-type="${resource.type}" data-status="${statusClass}">
          <div class="resource-icon">${typeIcon}</div>
          <div class="resource-details">
            <h4 class="resource-title">
              <a href="${resource.url}" target="_blank" rel="noopener noreferrer">${resource.title}</a>
            </h4>
            <div class="resource-meta">
              <span class="resource-subject">${resource.subject}</span>
              <span class="resource-date">Added: ${addedDate}</span>
            </div>
            ${resource.notes ? `<p class="resource-notes">${resource.notes}</p>` : ''}
          </div>
          <div class="resource-actions">
            <span class="resource-status ${statusClass}">${statusText}</span>
            <button class="btn-icon toggle-status" onclick="toggleResourceStatus('${resource._id}', ${!resource.completed})" title="${resource.completed ? 'Mark as not completed' : 'Mark as completed'}">
              ${resource.completed ? '✓' : '○'}
            </button>
          </div>
        </div>
      `;
    });
    
    resourceList.innerHTML = html;
  }
  
  // Populate subject filter
  function populateSubjectFilter() {
    const subjectFilter = document.getElementById('resourceSubjectFilter');
    if (!subjectFilter) return;
    
    // Clear existing options, keeping the "All Subjects" option
    subjectFilter.innerHTML = '<option value="">All Subjects</option>';
    
    // Get profile data from local storage
    const profile = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
    
    if (!profile || !profile.resourceLibrary) {
      return;
    }
    
    // Get unique subjects
    const subjects = new Set();
    profile.resourceLibrary.forEach(resource => {
      subjects.add(resource.subject);
    });
    
    // Add subject options
    subjects.forEach(subject => {
      const option = document.createElement('option');
      option.value = subject;
      option.textContent = subject;
      subjectFilter.appendChild(option);
    });
  }
  
  // Filter resources
  function filterResources() {
    const subjectFilter = document.getElementById('resourceSubjectFilter').value;
    const typeFilter = document.getElementById('resourceTypeFilter').value;
    const statusFilter = document.getElementById('resourceStatusFilter').value;
    
    const resources = document.querySelectorAll('.resource-item');
    
    resources.forEach(resource => {
      const subject = resource.getAttribute('data-subject');
      const type = resource.getAttribute('data-type');
      const status = resource.getAttribute('data-status');
      
      const matchesSubject = !subjectFilter || subject === subjectFilter;
      const matchesType = !typeFilter || type === typeFilter;
      const matchesStatus = !statusFilter || status === statusFilter;
      
      if (matchesSubject && matchesType && matchesStatus) {
        resource.style.display = 'flex';
      } else {
        resource.style.display = 'none';
      }
    });
  }
  
  // Toggle resource completion status
  async function toggleResourceStatus(resourceId, completed) {
    try {
      // Update resource status
      const response = await fetch(`${window.serverConfig.apiUrl}/academic/resources/${resourceId}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token')
        },
        body: JSON.stringify({ completed })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to update resource status');
      }
      
      // Reload resources
      await loadResources();
      
    } catch (error) {
      console.error('Error updating resource status:', error);
      showNotification(error.message || 'Error updating resource', 'error');
    }
  }
  
// Handle study plan form submission
async function handleStudyPlanSubmit(event) {
    event.preventDefault();
    
    const subject = document.getElementById('planSubject').value;
    const timeFrame = document.getElementById('planTimeFrame').value;
    const hoursPerWeek = document.getElementById('planHoursPerWeek').value;
    
    if (!subject || !timeFrame || !hoursPerWeek) {
      showNotification('Please fill all required fields', 'error');
      return;
    }
    
    try {
      // Show loading indicator
      document.getElementById('planSubject').disabled = true;
      document.getElementById('planTimeFrame').disabled = true;
      document.getElementById('planHoursPerWeek').disabled = true;
      document.querySelector('#studyPlanForm button[type="submit"]').textContent = 'Generating...';
      
      const response = await fetch(`${window.serverConfig.apiUrl}/academic/study-plan`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token')
        },
        body: JSON.stringify({
          subject,
          timeFrame,
          hoursPerWeek
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to generate study plan');
      }
      
      // Display the study plan
      document.getElementById('studyPlanSubject').textContent = subject;
      document.getElementById('studyPlanContent').innerHTML = data.studyPlan;
      
      // Open modal
      openModal('studyPlanModal');
      
    } catch (error) {
      console.error('Error generating study plan:', error);
      showNotification(error.message || 'Error generating study plan', 'error');
    } finally {
      // Reset form state
      document.getElementById('planSubject').disabled = false;
      document.getElementById('planTimeFrame').disabled = false;
      document.getElementById('planHoursPerWeek').disabled = false;
      document.querySelector('#studyPlanForm button[type="submit"]').textContent = 'Generate Plan';
    }
  }
  
  // Save generated study plan
  async function saveStudyPlan() {
    const subject = document.getElementById('studyPlanSubject').textContent;
    const content = document.getElementById('studyPlanContent').innerHTML;
    
    if (!subject || !content) {
      showNotification('No study plan to save', 'error');
      return;
    }
    
    try {
      // Save as a resource
      const response = await fetch(`${window.serverConfig.apiUrl}/academic/resources`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-auth-token': localStorage.getItem('auth_token')
        },
        body: JSON.stringify({
          title: `Study Plan: ${subject}`,
          url: '#', // Placeholder URL
          type: 'plan',
          subject: subject,
          notes: content,
          isStudyPlan: true
        })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Failed to save study plan');
      }
      
      showNotification('Study plan saved successfully!', 'success');
      
      // Close modal
      closeModal('studyPlanModal');
      
      // Reload resources
      await loadResources();
      
    } catch (error) {
      console.error('Error saving study plan:', error);
      showNotification(error.message || 'Error saving study plan', 'error');
    }
  }
  
  // Initialize charts
  function initializeCharts() {
    // Subject progress chart
    const ctx = document.getElementById('subjectProgressChart');
    if (!ctx) return;
    
    // Get profile data
    const profile = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
    
    if (!profile || !profile.academicProgress || !profile.academicProgress.subjects) {
      // No data yet, show placeholder chart
      createPlaceholderChart(ctx);
      return;
    }
    
    const subjects = profile.academicProgress.subjects;
    
    // Prepare data for chart
    const labels = subjects.map(subject => subject.name);
    const data = subjects.map(subject => subject.proficiency);
    const colors = generateColors(subjects.length);
    
    // Create chart
    window.subjectProgressChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Proficiency Level',
          data: data,
          backgroundColor: colors,
          borderColor: colors.map(color => color.replace('0.6', '1')),
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            title: {
              display: true,
              text: 'Proficiency Level (%)'
            }
          },
          x: {
            title: {
              display: true,
              text: 'Subject'
            }
          }
        },
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                return `Proficiency: ${context.raw}%`;
              }
            }
          }
        }
      }
    });
    
    // Create legend
    createChartLegend(labels, colors);
  }
  
  // Create placeholder chart
  function createPlaceholderChart(ctx) {
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Add your first subject to see progress!'],
        datasets: [{
          label: 'Proficiency Level',
          data: [0],
          backgroundColor: 'rgba(200, 200, 200, 0.6)',
          borderColor: 'rgba(200, 200, 200, 1)',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            max: 100,
            title: {
              display: true,
              text: 'Proficiency Level (%)'
            }
          }
        },
        plugins: {
          legend: {
            display: false
          }
        }
      }
    });
  }
  
  // Create chart legend
  function createChartLegend(labels, colors) {
    const legendContainer = document.getElementById('subjectProgressLegend');
    if (!legendContainer) return;
    
    let legendHtml = '';
    
    for (let i = 0; i < labels.length; i++) {
      legendHtml += `
        <div class="legend-item">
          <span class="legend-color" style="background-color: ${colors[i]}"></span>
          <span class="legend-label">${labels[i]}</span>
        </div>
      `;
    }
    
    legendContainer.innerHTML = legendHtml;
  }
  
  // Update charts
  function updateCharts() {
    // Get profile data
    const profile = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
    
    if (!profile || !profile.academicProgress || !profile.academicProgress.subjects) {
      return;
    }
    
    const subjects = profile.academicProgress.subjects;
    
    // Prepare data for chart
    const labels = subjects.map(subject => subject.name);
    const data = subjects.map(subject => subject.proficiency);
    const colors = generateColors(subjects.length);
    
    // Update chart if it exists
    if (window.subjectProgressChart) {
      window.subjectProgressChart.data.labels = labels;
      window.subjectProgressChart.data.datasets[0].data = data;
      window.subjectProgressChart.data.datasets[0].backgroundColor = colors;
      window.subjectProgressChart.data.datasets[0].borderColor = colors.map(color => color.replace('0.6', '1'));
      window.subjectProgressChart.update();
      
      // Update legend
      createChartLegend(labels, colors);
    } else {
      // Initialize chart if it doesn't exist
      initializeCharts();
    }
  }
  
  // Generate colors for chart
  function generateColors(count) {
    const colors = [];
    const baseColors = [
      'rgba(54, 162, 235, 0.6)',   // Blue
      'rgba(255, 99, 132, 0.6)',   // Red
      'rgba(75, 192, 192, 0.6)',   // Green
      'rgba(255, 206, 86, 0.6)',   // Yellow
      'rgba(153, 102, 255, 0.6)',  // Purple
      'rgba(255, 159, 64, 0.6)',   // Orange
      'rgba(199, 199, 199, 0.6)'   // Gray
    ];
    
    for (let i = 0; i < count; i++) {
      colors.push(baseColors[i % baseColors.length]);
    }
    
    return colors;
  }
  
  // Modal handling
  function openModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }
  
  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = 'auto';
    }
  }
  
  // Notification function
  function showNotification(message, type = 'info') {
    const notificationArea = document.getElementById('notificationArea');
    if (!notificationArea) return;
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    notificationArea.appendChild(notification);
    
    // Add transition effect
    setTimeout(() => {
      notification.classList.add('show');
    }, 10);
    
    // Auto remove after timeout
    setTimeout(() => {
      notification.classList.remove('show');
      setTimeout(() => {
        if (notification.parentNode) {
          notificationArea.removeChild(notification);
        }
      }, 300);
    }, 5000);
  }
  
  // Make functions available globally for HTML event handlers
  window.openModal = openModal;
  window.closeModal = closeModal;
  window.toggleResourceStatus = toggleResourceStatus;
  window.saveStudyPlan = saveStudyPlan;