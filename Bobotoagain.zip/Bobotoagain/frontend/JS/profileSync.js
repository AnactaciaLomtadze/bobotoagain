// JS/profileSync.js -  profile synchronization module

/**
 * ProfileSynchronizer - Responsible for ensuring user data consistency
 * across all pages and components in the Boboto application
 */
class ProfileSynchronizer {
  constructor() {
    this.profile = null;
    this.initialized = false;
    this.listeners = [];
    this.syncInProgress = false;
    this.lastSyncTime = null;
    this.offlineChanges = this.loadOfflineChanges();
    
    // Set up event listeners
    window.addEventListener('online', () => this.handleOnlineStatus());
    window.addEventListener('offline', () => this.handleOfflineStatus());
    
    // Custom event for auth state changes
    document.addEventListener('auth_state_changed', (e) => this.handleAuthStateChange(e.detail));
    
    // Initialize on construction if user is authenticated
    if (isAuthenticated()) {
      this.initialize();
    }
  }
  
  /**
   * Initialize the synchronizer
   */
  async initialize() {
    if (this.initialized) return;
    
    try {
      console.log('Initializing profile synchronizer...');
      await this.syncProfile();
      
      // Set up periodic sync (every 2 minutes)
      this.syncInterval = setInterval(() => {
        if (navigator.onLine && isAuthenticated() && !this.syncInProgress) {
          this.syncProfile(true); // silent sync
        }
      }, 120000);
      
      this.initialized = true;
      console.log('Profile synchronizer initialized');
      
      // Process any offline changes
      if (this.offlineChanges.length > 0) {
        this.processOfflineChanges();
      }
    } catch (error) {
      console.error('Failed to initialize profile synchronizer:', error);
    }
  }
  
  /**
   * Handle online status change
   */
  handleOnlineStatus() {
    console.log('🌐 App is online. Checking for offline changes...');
    this.processOfflineChanges();
  }
  
  /**
   * Handle offline status change
   */
  handleOfflineStatus() {
    console.log('📴 App is offline. Changes will be queued for later sync.');
  }
  
  /**
   * Handle authentication state change
   */
  handleAuthStateChange(authState) {
    if (authState.isAuthenticated) {
      console.log('User authenticated. Initializing profile sync...');
      this.initialize();
    } else {
      console.log('User logged out. Clearing profile data...');
      this.clearProfile();
      this.stopSync();
    }
  }
  
  /**
   * Stop synchronization
   */
  stopSync() {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    this.initialized = false;
  }
  
  /**
   * Clear profile data
   */
  clearProfile() {
    this.profile = null;
    // Notify listeners about profile change
    this.notifyListeners(null);
  }
  
  /**
   * Add listener for profile changes
   */
  addListener(callback) {
    if (typeof callback !== 'function') {
      console.error('Listener must be a function');
      return;
    }
    
    this.listeners.push(callback);
    
    // Immediately call with current profile if available
    if (this.profile) {
      callback(this.profile);
    }
    
    // Return function to remove listener
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== callback);
    };
  }
  
  /**
   * Notify all listeners about profile changes
   */
  notifyListeners(profile) {
    this.listeners.forEach(listener => {
      try {
        listener(profile);
      } catch (error) {
        console.error('Error in profile change listener:', error);
      }
    });
    
    // Also dispatch a custom event
    const event = new CustomEvent('profile_updated', { detail: profile });
    document.dispatchEvent(event);
  }
  
  /**
   * Load offline changes from localStorage
   */
  loadOfflineChanges() {
    try {
      return JSON.parse(localStorage.getItem('offline_changes') || '[]');
    } catch (error) {
      console.error('Error loading offline changes:', error);
      return [];
    }
  }
  
  /**
   * Save offline changes to localStorage
   */
  saveOfflineChanges() {
    localStorage.setItem('offline_changes', JSON.stringify(this.offlineChanges));
  }
  
  /**
   * Add a change to the offline queue
   */
  queueOfflineChange(type, data) {
    this.offlineChanges.push({
      type,
      data,
      timestamp: new Date().toISOString()
    });
    
    this.saveOfflineChanges();
    
    // Try to process immediately if online
    if (navigator.onLine && isAuthenticated()) {
      this.processOfflineChanges();
    }
  }
  
  /**
   * Process all queued offline changes
   */
  async processOfflineChanges() {
    if (!navigator.onLine || !isAuthenticated() || this.offlineChanges.length === 0 || this.syncInProgress) {
      return;
    }
    
    console.log(`Processing ${this.offlineChanges.length} offline changes...`);
    this.syncInProgress = true;
    
    const originalChanges = [...this.offlineChanges];
    const successfulChanges = [];
    
    for (const change of originalChanges) {
      try {
        console.log(`Processing change: ${change.type}`);
        
        switch (change.type) {
          case 'learningPreferences':
            await API.Profile.updateLearningPreferences(change.data);
            successfulChanges.push(change);
            break;
            
          case 'careerGoals':
            await API.Profile.updateCareerGoals(change.data);
            successfulChanges.push(change);
            break;
            
          case 'profile':
            await API.Profile.update(change.data);
            successfulChanges.push(change);
            break;
            
          case 'skill.add':
            await API.Profile.addSkill(change.data.name, change.data.level);
            successfulChanges.push(change);
            break;
            
          case 'skill.remove':
            await API.Profile.removeSkill(change.data.skillId);
            successfulChanges.push(change);
            break;
            
          default:
            console.warn(`Unknown change type: ${change.type}`);
        }
      } catch (error) {
        console.error(`Error processing offline change (${change.type}):`, error);
      }
    }
    
    // Remove successful changes from the queue
    if (successfulChanges.length > 0) {
      this.offlineChanges = this.offlineChanges.filter(
        change => !successfulChanges.includes(change)
      );
      this.saveOfflineChanges();
    }
    
    this.syncInProgress = false;
    
    // Sync profile to get latest data
    await this.syncProfile(true);
  }
  
  /**
   * Sync profile with server
   */
  async syncProfile(silent = false) {
    if (this.syncInProgress || !navigator.onLine || !isAuthenticated()) {
      return false;
    }
    
    try {
      if (!silent) {
        console.log('Syncing profile with server...');
      }
      
      this.syncInProgress = true;
      
      // Get profile data from server
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        throw new Error('Failed to fetch profile data');
      }
      
      // Get additional data
      const [learningPreferences, careerGoals, skills] = await Promise.all([
        API.Profile.getLearningPreferences().catch(() => ({})),
        API.Profile.getCareerGoals().catch(() => ({})),
        API.Profile.getSkills().catch(() => [])
      ]);
      
      // Combine all data
      const completeProfile = {
        ...profileData,
        learningPreferences,
        careerGoals,
        skills
      };
      
      // Update local storage cache
      localStorage.setItem('user_profile_data', JSON.stringify(completeProfile));
      
      if (learningPreferences) {
        localStorage.setItem('learning_preferences', JSON.stringify(learningPreferences));
      }
      
      if (careerGoals) {
        localStorage.setItem('career_goals', JSON.stringify(careerGoals));
      }
      
      if (skills) {
        localStorage.setItem('user_skills', JSON.stringify(skills));
      }
      
      // Update internal profile
      this.profile = completeProfile;
      
      // Update last sync time
      this.lastSyncTime = new Date();
      
      // Notify listeners about profile change
      this.notifyListeners(completeProfile);
      
      if (!silent) {
        console.log('Profile synced successfully');
      }
      
      return true;
    } catch (error) {
      console.error('Error syncing profile:', error);
      
      // Try to load from local storage as fallback
      const cachedProfile = this.loadCachedProfile();
      if (cachedProfile && !this.profile) {
        this.profile = cachedProfile;
        this.notifyListeners(cachedProfile);
      }
      
      return false;
    } finally {
      this.syncInProgress = false;
    }
  }
  
  /**
   * Load cached profile from localStorage
   */
  loadCachedProfile() {
    try {
      // First try to get complete profile
      const profileData = localStorage.getItem('user_profile_data');
      if (profileData) {
        return JSON.parse(profileData);
      }
      
      // Fallback to individual components
      const userInfo = getUserInfo();
      if (!userInfo) return null;
      
      return {
        ...userInfo,
        learningPreferences: JSON.parse(localStorage.getItem('learning_preferences') || '{}'),
        careerGoals: JSON.parse(localStorage.getItem('career_goals') || '{}'),
        skills: JSON.parse(localStorage.getItem('user_skills') || '[]')
      };
    } catch (error) {
      console.error('Error loading cached profile:', error);
      return null;
    }
  }
  
  /**
   * Get current profile
   */
  getProfile() {
    if (!this.profile) {
      // Try to load from cache
      this.profile = this.loadCachedProfile();
      
      // If online and authenticated, sync
      if (navigator.onLine && isAuthenticated() && !this.syncInProgress) {
        this.syncProfile();
      }
    }
    
    return this.profile;
  }
  
  /**
   * Update learning preferences
   */
  async updateLearningPreferences(preferences) {
    // Update local profile first
    if (this.profile) {
      this.profile.learningPreferences = {
        ...this.profile.learningPreferences,
        ...preferences
      };
      this.notifyListeners(this.profile);
    }
    
    // Save to localStorage
    try {
      const currentPrefs = JSON.parse(localStorage.getItem('learning_preferences') || '{}');
      const updatedPrefs = { ...currentPrefs, ...preferences };
      localStorage.setItem('learning_preferences', JSON.stringify(updatedPrefs));
      
      // Update user profile data cache
      const profileData = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
      profileData.learningPreferences = updatedPrefs;
      localStorage.setItem('user_profile_data', JSON.stringify(profileData));
    } catch (error) {
      console.error('Error updating cached learning preferences:', error);
    }
    
    // If online, update on server
    if (navigator.onLine && isAuthenticated()) {
      try {
        await API.Profile.updateLearningPreferences(preferences);
        return true;
      } catch (error) {
        console.error('Error updating learning preferences on server:', error);
        this.queueOfflineChange('learningPreferences', preferences);
        return false;
      }
    } else {
      // Queue for later sync
      this.queueOfflineChange('learningPreferences', preferences);
      return true;
    }
  }
  
  /**
   * Update career goals
   */
  async updateCareerGoals(goals) {
    // Update local profile first
    if (this.profile) {
      this.profile.careerGoals = {
        ...this.profile.careerGoals,
        ...goals
      };
      this.notifyListeners(this.profile);
    }
    
    // Save to localStorage
    try {
      const currentGoals = JSON.parse(localStorage.getItem('career_goals') || '{}');
      const updatedGoals = { ...currentGoals, ...goals };
      localStorage.setItem('career_goals', JSON.stringify(updatedGoals));
      
      // Update user profile data cache
      const profileData = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
      profileData.careerGoals = updatedGoals;
      localStorage.setItem('user_profile_data', JSON.stringify(profileData));
    } catch (error) {
      console.error('Error updating cached career goals:', error);
    }
    
    // If online, update on server
    if (navigator.onLine && isAuthenticated()) {
      try {
        await API.Profile.updateCareerGoals(goals);
        return true;
      } catch (error) {
        console.error('Error updating career goals on server:', error);
        this.queueOfflineChange('careerGoals', goals);
        return false;
      }
    } else {
      // Queue for later sync
      this.queueOfflineChange('careerGoals', goals);
      return true;
    }
  }
  
  /**
   * Update profile information
   */
  async updateProfile(profileData) {
    // Update local profile first
    if (this.profile) {
      this.profile = {
        ...this.profile,
        ...profileData
      };
      this.notifyListeners(this.profile);
    }
    
    // Update user info in localStorage
    try {
      const userInfo = getUserInfo();
      if (userInfo) {
        Object.assign(userInfo, profileData);
        localStorage.setItem('user_info', JSON.stringify(userInfo));
      }
      
      // Update user profile data cache
      const cachedProfile = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
      Object.assign(cachedProfile, profileData);
      localStorage.setItem('user_profile_data', JSON.stringify(cachedProfile));
    } catch (error) {
      console.error('Error updating cached profile data:', error);
    }
    
    // If online, update on server
    if (navigator.onLine && isAuthenticated()) {
      try {
        await API.Profile.update(profileData);
        return true;
      } catch (error) {
        console.error('Error updating profile on server:', error);
        this.queueOfflineChange('profile', profileData);
        return false;
      }
    } else {
      // Queue for later sync
      this.queueOfflineChange('profile', profileData);
      return true;
    }
  }
  
  /**
   * Add or update skill
   */
  async addOrUpdateSkill(name, level) {
    // Update local skills array
    let skillAdded = false;
    
    try {
      // Get current skills
      const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
      
      // Check if skill already exists
      const existingSkillIndex = skills.findIndex(
        s => s.name.toLowerCase() === name.toLowerCase()
      );
      
      if (existingSkillIndex >= 0) {
        // Update existing skill
        skills[existingSkillIndex].level = level;
      } else {
        // Add new skill
        skills.push({
          name,
          level,
          addedAt: new Date().toISOString(),
          _id: `temp_${Date.now()}` // Temporary ID
        });
      }
      
      // Save to localStorage
      localStorage.setItem('user_skills', JSON.stringify(skills));
      
      // Update user profile data cache
      const profileData = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
      profileData.skills = skills;
      localStorage.setItem('user_profile_data', JSON.stringify(profileData));
      
      // Update local profile if exists
      if (this.profile) {
        this.profile.skills = skills;
        this.notifyListeners(this.profile);
      }
      
      skillAdded = true;
    } catch (error) {
      console.error('Error updating cached skills:', error);
    }
    
    // If online, update on server
    if (navigator.onLine && isAuthenticated()) {
      try {
        await API.Profile.addSkill(name, level);
        // Refresh profile to get server-generated IDs
        this.syncProfile(true);
        return true;
      } catch (error) {
        console.error('Error adding/updating skill on server:', error);
        
        // Only queue if local update succeeded
        if (skillAdded) {
          this.queueOfflineChange('skill.add', { name, level });
        }
        
        return skillAdded;
      }
    } else {
      // Queue for later sync if local update succeeded
      if (skillAdded) {
        this.queueOfflineChange('skill.add', { name, level });
      }
      
      return skillAdded;
    }
  }
  
  /**
   * Remove skill
   */
  async removeSkill(skillId) {
    // Update local skills array
    let skillRemoved = false;
    
    try {
      // Get current skills
      const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
      
      // Filter out the skill
      const updatedSkills = skills.filter(
        skill => skill._id.toString() !== skillId.toString()
      );
      
      // Only proceed if a skill was actually removed
      if (updatedSkills.length < skills.length) {
        // Save to localStorage
        localStorage.setItem('user_skills', JSON.stringify(updatedSkills));
        
        // Update user profile data cache
        const profileData = JSON.parse(localStorage.getItem('user_profile_data') || '{}');
        profileData.skills = updatedSkills;
        localStorage.setItem('user_profile_data', JSON.stringify(profileData));
        
        // Update local profile if exists
        if (this.profile) {
          this.profile.skills = updatedSkills;
          this.notifyListeners(this.profile);
        }
        
        skillRemoved = true;
      }
    } catch (error) {
      console.error('Error updating cached skills:', error);
    }
    
    // If online, update on server
    if (navigator.onLine && isAuthenticated()) {
      try {
        await API.Profile.removeSkill(skillId);
        return true;
      } catch (error) {
        console.error('Error removing skill on server:', error);
        
        // Only queue if local update succeeded
        if (skillRemoved) {
          this.queueOfflineChange('skill.remove', { skillId });
        }
        
        return skillRemoved;
      }
    } else {
      // Queue for later sync if local update succeeded
      if (skillRemoved) {
        this.queueOfflineChange('skill.remove', { skillId });
      }
      
      return skillRemoved;
    }
  }
}

// Create singleton instance
const profileSynchronizer = new ProfileSynchronizer();

// Export functions for global access
window.profileSync = profileSynchronizer;

// Export functions that can be called directly
window.syncProfile = async () => await profileSynchronizer.syncProfile();
window.getProfile = () => profileSynchronizer.getProfile();
window.updateLearningPreferences = async (prefs) => await profileSynchronizer.updateLearningPreferences(prefs);
window.updateCareerGoals = async (goals) => await profileSynchronizer.updateCareerGoals(goals);
window.updateProfile = async (profileData) => await profileSynchronizer.updateProfile(profileData);
window.addOrUpdateSkill = async (name, level) => await profileSynchronizer.addOrUpdateSkill(name, level);
window.removeSkill = async (skillId) => await profileSynchronizer.removeSkill(skillId);

// Helper function to dispatch auth state change event
window.dispatchAuthStateChange = (isAuthenticated) => {
  const event = new CustomEvent('auth_state_changed', {
    detail: { isAuthenticated }
  });
  document.dispatchEvent(event);
};

// Export additional utility functions
window.addProfileChangeListener = (callback) => profileSynchronizer.addListener(callback);