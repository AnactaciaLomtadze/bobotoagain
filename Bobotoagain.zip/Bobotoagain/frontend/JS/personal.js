/**
 * personal.js - Personal information page functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', () => {
    // Protect the page - redirect if not logged in
    protectPage();
    
    // Initialize the page
    initPersonalInfoPage();
    
    // Setup form event listeners
    setupFormHandlers();
    
    // Setup profile picture upload
    setupProfilePictureUpload();
  });
  
  // Initialize the personal info page
  async function initPersonalInfoPage() {
    try {
      // Fetch the user's profile data
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        showNotification('Failed to load profile data', 'error');
        return;
      }
      
      // Update sidebar user information
      updateSidebarUserInfo(profileData);
      
      // Populate the basic details form
      populateBasicInfoForm(profileData);
      
      // Populate the academic information form
      populateAcademicInfoForm(profileData);
      
      // Update profile picture if available
      if (profileData.profilePictureUrl) {
        document.getElementById('currentProfilePic').src = profileData.profilePictureUrl;
      }
      
    } catch (error) {
      console.error('Error initializing personal info page:', error);
      showNotification('Error loading profile data', 'error');
    }
  }
  
  // Update sidebar user information
  function updateSidebarUserInfo(profileData) {
    // Update user name
    const userNameElement = document.querySelector('.user-name');
    if (userNameElement) {
      userNameElement.textContent = profileData.fullName;
    }
    
    // Update user details (major/academic level)
    const userDetailsElement = document.querySelector('.user-details');
    if (userDetailsElement) {
      let detailsText = 'Student';
      if (profileData.major) {
        detailsText = profileData.major;
        if (profileData.academicLevel) {
          detailsText += ' ' + profileData.academicLevel;
        }
        detailsText += ' Student';
      }
      userDetailsElement.textContent = detailsText;
    }
    
    // Update profile picture in sidebar
    const profilePicElement = document.querySelector('.profile-picture img');
    if (profilePicElement && profileData.profilePictureUrl) {
      profilePicElement.src = profileData.profilePictureUrl;
    }
  }
  
  // Populate the basic details form
  function populateBasicInfoForm(profileData) {
    // Get the form
    const basicForm = document.getElementById('basicInfoForm');
    if (!basicForm) return;
    
    // Set form values
    setFormValue(basicForm, 'fullName', profileData.fullName);
    setFormValue(basicForm, 'displayName', profileData.fullName?.split(' ')[0] || '');
    setFormValue(basicForm, 'email', profileData.email);
    setFormValue(basicForm, 'phone', profileData.phone || '');
    
    // These fields might not exist in our current schema, but they're in the HTML
    // In a real application, you would add these fields to your database schema
    setFormValue(basicForm, 'birthdate', '');
    setFormValue(basicForm, 'location', '');
  }
  
  // Populate the academic information form
  function populateAcademicInfoForm(profileData) {
    // Get the form
    const academicForm = document.getElementById('academicInfoForm');
    if (!academicForm) return;
    
    // Set form values
    setFormValue(academicForm, 'institution', profileData.university || '');
    setFormValue(academicForm, 'major', profileData.major || '');
    
    // Convert graduation year to month format if needed
    let gradYearMonth = '';
    if (profileData.graduationYear) {
      gradYearMonth = `${profileData.graduationYear}-05`; // Default to May
    }
    setFormValue(academicForm, 'graduationYear', gradYearMonth);
    
    // These fields might not exist in our current schema, but they're in the HTML
    setFormValue(academicForm, 'degree', 'Bachelor of Science');
    setFormValue(academicForm, 'gpa', '');
    
    // Set select element
    const academicStatus = academicForm.querySelector('#academicStatus');
    if (academicStatus && profileData.academicLevel) {
      // Map academicLevel to select options
      const levelMap = {
        'Undergraduate': 'fullTime',
        'Graduate': 'fullTime',
        'PhD': 'fullTime'
      };
      
      if (levelMap[profileData.academicLevel]) {
        academicStatus.value = levelMap[profileData.academicLevel];
      }
    }
  }
  
  // Helper function to set form input values
  function setFormValue(form, inputId, value) {
    const input = form.querySelector(`#${inputId}`);
    if (input && value !== undefined) {
      input.value = value;
    }
  }
  
  // Setup form event handlers
  function setupFormHandlers() {
    // Basic info form save handler
    const basicForm = document.getElementById('basicInfoForm');
    if (basicForm) {
      const saveBtn = basicForm.parentElement.querySelector('.form-actions .btn:not(.btn-outline)');
      if (saveBtn) {
        saveBtn.addEventListener('click', () => saveBasicInfo(basicForm));
      }
      
      const resetBtn = basicForm.parentElement.querySelector('.form-actions .btn-outline');
      if (resetBtn) {
        resetBtn.addEventListener('click', () => resetForm('basicInfoForm'));
      }
    }
    
    // Academic info form save handler
    const academicForm = document.getElementById('academicInfoForm');
    if (academicForm) {
      const saveBtn = academicForm.parentElement.querySelector('.form-actions .btn:not(.btn-outline)');
      if (saveBtn) {
        saveBtn.addEventListener('click', () => saveAcademicInfo(academicForm));
      }
      
      const resetBtn = academicForm.parentElement.querySelector('.form-actions .btn-outline');
      if (resetBtn) {
        resetBtn.addEventListener('click', () => resetForm('academicInfoForm'));
      }
    }
  }
  
  // Handle saving basic info
  async function saveBasicInfo(form) {
    try {
      // Get form data
      const fullName = form.querySelector('#fullName').value.trim();
      const phone = form.querySelector('#phone').value.trim();
      
      // Additional fields that may not be in our schema yet
      // In a full implementation, you would add these to your database
      const displayName = form.querySelector('#displayName').value.trim();
      const birthdate = form.querySelector('#birthdate').value;
      const location = form.querySelector('#location').value.trim();
      
      // Validate required fields
      if (!fullName) {
        showNotification('Full name is required', 'error');
        return;
      }
      
      // Save to API
      const result = await API.Profile.update({
        fullName,
        phone
        // Add additional fields when schema is updated
      });
      
      if (result) {
        showNotification('Basic details updated successfully!', 'success');
        
        // Update sidebar name
        const userNameElement = document.querySelector('.user-name');
        if (userNameElement) {
          userNameElement.textContent = fullName;
        }
      }
    } catch (error) {
      console.error('Error saving basic info:', error);
      showNotification('Error saving basic information', 'error');
    }
  }
  
  // Handle saving academic info
  async function saveAcademicInfo(form) {
    try {
      // Get form data
      const university = form.querySelector('#institution').value.trim();
      const major = form.querySelector('#major').value.trim();
      const graduationYear = form.querySelector('#graduationYear').value;
      const academicStatus = form.querySelector('#academicStatus').value;
      
      // Additional fields that may not be in our schema yet
      const degree = form.querySelector('#degree').value.trim();
      const gpa = form.querySelector('#gpa').value.trim();
      
      // Extract year from graduationYear input (which is in month format)
      let gradYear = null;
      if (graduationYear) {
        gradYear = parseInt(graduationYear.split('-')[0]);
      }
      
      // Map academicStatus to academicLevel
      let academicLevel = null;
      switch (academicStatus) {
        case 'fullTime':
        case 'partTime':
          academicLevel = 'Undergraduate';
          break;
        case 'exchange':
          academicLevel = 'Exchange';
          break;
        case 'graduation':
          academicLevel = 'Graduating';
          break;
      }
      
      // Save to API
      const result = await API.Profile.update({
        university,
        major,
        graduationYear: gradYear,
        academicLevel
        // Add additional fields when schema is updated
      });
      
      if (result) {
        showNotification('Academic information updated successfully!', 'success');
        
        // Update sidebar user details
        const userDetailsElement = document.querySelector('.user-details');
        if (userDetailsElement && major) {
          let detailsText = major;
          if (academicLevel) {
            detailsText += ' ' + academicLevel;
          }
          detailsText += ' Student';
          userDetailsElement.textContent = detailsText;
        }
      }
    } catch (error) {
      console.error('Error saving academic info:', error);
      showNotification('Error saving academic information', 'error');
    }
  }
  
  // Setup profile picture upload functionality
  function setupProfilePictureUpload() {
    // File input change handler
    const fileInput = document.getElementById('profilePicUpload');
    if (fileInput) {
      fileInput.addEventListener('change', previewImage);
    }
    
    // Upload button click handler
    const uploadButton = document.querySelector('.profile-picture-upload .btn');
    if (uploadButton) {
      uploadButton.addEventListener('click', uploadProfilePicture);
    }
  }
  
  // Preview selected image
  function previewImage() {
    const fileInput = document.getElementById('profilePicUpload');
    const previewImg = document.getElementById('currentProfilePic');
    
    if (fileInput && fileInput.files && fileInput.files[0] && previewImg) {
      const reader = new FileReader();
      
      reader.onload = function(e) {
        previewImg.src = e.target.result;
      };
      
      reader.readAsDataURL(fileInput.files[0]);
      showNotification('Click Upload to save your new profile picture', 'info');
    }
  }
  
  // Upload profile picture
  async function uploadProfilePicture() {
    const fileInput = document.getElementById('profilePicUpload');
    
    if (!fileInput || !fileInput.files || !fileInput.files[0]) {
      showNotification('Please select an image to upload', 'error');
      return;
    }
    
    try {
      // Upload file
      const result = await API.Profile.uploadPicture(fileInput.files[0]);
      
      if (result) {
        showNotification('Profile picture updated successfully!', 'success');
        
        // Update sidebar profile picture
        const sidebarPic = document.querySelector('.profile-picture img');
        if (sidebarPic) {
          sidebarPic.src = result.profilePictureUrl;
        }
      }
    } catch (error) {
      console.error('Error uploading profile picture:', error);
      showNotification('Error uploading profile picture', 'error');
    }
  }
  
  // Reset form to initial values
  function resetForm(formId) {
    // Reset the form and show notification
    document.getElementById(formId).reset();
    showNotification('Form has been reset', 'info');
    
    // Re-initialize the page to load original values
    initPersonalInfoPage();
  }