/**
 * profile.js - Profile management functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Protect the page - redirect if not logged in
  protectPage();
  
  // Sync profile data if authenticated
  if (isAuthenticated()) {
    try {
      await API.ProfileSync.syncProfile();
      console.log('Profile synchronized successfully');
    } catch (error) {
      console.error('Initial profile sync failed:', error);
      // Continue with locally stored data as fallback
    }
  }
  
  // Initialize profile dashboard
  initProfileDashboard();
  
  // Initialize tab switching functionality
  initTabs();
});

// Initialize profile dashboard with user data
async function initProfileDashboard() {
  try {
    // Get user profile data
    const profileData = await API.Profile.get();
    
    if (!profileData) {
      showNotification('Failed to load profile data', 'error');
      return;
    }
    
    // Update profile information on page
    updateProfileDisplay(profileData);
    
    // Load learning preferences
    const learningPrefs = await API.Profile.getLearningPreferences();
    if (learningPrefs) {
      updateLearningPreferencesDisplay(learningPrefs);
      // Store in localStorage for offline access
      localStorage.setItem('learning_preferences', JSON.stringify(learningPrefs));
    }
    
    // Load career goals
    const careerGoals = await API.Profile.getCareerGoals();
    if (careerGoals) {
      updateCareerGoalsDisplay(careerGoals);
      // Store in localStorage for offline access
      localStorage.setItem('career_goals', JSON.stringify(careerGoals));
    }
    
    // Load courses
    const courses = await API.Profile.getCourses();
    if (courses) {
      // This could be implemented for a courses section
      console.log('Courses loaded:', courses);
    }
    
    // Load interests/skills
    const skills = await API.Profile.getSkills();
    if (skills) {
      updateSkillsDisplay(skills);
      // Store in localStorage for offline access
      localStorage.setItem('user_skills', JSON.stringify(skills));
    }
    
  } catch (error) {
    console.error('Error initializing profile:', error);
    showNotification('Error loading profile', 'error');
  }
}

// Update profile display with user data
function updateProfileDisplay(profileData) {
  // Update user name and details
  const userNameElements = document.querySelectorAll('.user-name');
  userNameElements.forEach(element => {
    element.textContent = profileData.fullName;
  });
  
  // Update profile picture if available
  if (profileData.profilePictureUrl) {
    const profilePicElements = document.querySelectorAll('.profile-picture img');
    profilePicElements.forEach(element => {
      element.src = profileData.profilePictureUrl;
      element.alt = `${profileData.fullName}'s profile picture`;
    });
  }
  
  // Update personal info card if it exists
  const personalInfoCard = document.querySelector('.card:nth-child(1) .card-content ul');
  if (personalInfoCard) {
    personalInfoCard.innerHTML = `
      <li><span>Name:</span> <span>${profileData.fullName}</span></li>
      <li><span>Email:</span> <span>${profileData.email}</span></li>
      <li><span>Phone:</span> <span>${profileData.phone || 'Not set'}</span></li>
      ${profileData.university ? `<li><span>University:</span> <span>${profileData.university}</span></li>` : ''}
      ${profileData.major ? `<li><span>Major:</span> <span>${profileData.major}</span></li>` : ''}
      ${profileData.graduationYear ? `<li><span>Graduation Year:</span> <span>${profileData.graduationYear}</span></li>` : ''}
    `;
  }
  
  // Add academic description to user details if available
  const userDetails = document.querySelector('.user-details');
  if (userDetails && profileData.major) {
    userDetails.textContent = `${profileData.major} ${profileData.academicLevel || 'Student'}`;
  }
}

// Update learning preferences display
function updateLearningPreferencesDisplay(learningPrefs) {
  const learningPrefsCard = document.querySelector('.card:nth-child(2) .card-content ul');
  if (learningPrefsCard) {
    learningPrefsCard.innerHTML = `
      <li><span>Learning Style:</span> <span>${learningPrefs.learningStyle || 'Not set'}</span></li>
      <li><span>Favorite Materials:</span> <span>${learningPrefs.preferredMaterials?.join(', ') || 'Not set'}</span></li>
      <li><span>Learning Pace:</span> <span>${learningPrefs.learningPace || 'Not set'}</span></li>
    `;
  }
}

// UPDATED: Function to save learning preferences with synchronization
async function updateLearningPreferences(preferences) {
  try {
    // First update local storage
    const currentPrefs = JSON.parse(localStorage.getItem('learning_preferences') || '{}');
    const updatedPrefs = { ...currentPrefs, ...preferences };
    localStorage.setItem('learning_preferences', JSON.stringify(updatedPrefs));
    
    // Then push to server if authenticated
    if (isAuthenticated()) {
      await API.ProfileSync.pushLocalChanges('learningPreferences');
      showNotification('Learning preferences updated successfully', 'success');
      
      // Update UI to reflect changes
      updateLearningPreferencesDisplay(updatedPrefs);
    } else {
      showNotification('Learning preferences saved locally', 'info');
    }
  } catch (error) {
    console.error('Error updating learning preferences:', error);
    showNotification('Failed to update learning preferences', 'error');
  }
}

// UPDATED: Function to save career goals with synchronization
async function updateCareerGoals(goals) {
  try {
    // First update local storage
    const currentGoals = JSON.parse(localStorage.getItem('career_goals') || '{}');
    const updatedGoals = { ...currentGoals, ...goals };
    localStorage.setItem('career_goals', JSON.stringify(updatedGoals));
    
    // Then push to server if authenticated
    if (isAuthenticated()) {
      await API.ProfileSync.pushLocalChanges('careerGoals');
      showNotification('Career goals updated successfully', 'success');
      
      // Update UI to reflect changes
      updateCareerGoalsDisplay(updatedGoals);
    } else {
      showNotification('Career goals saved locally', 'info');
    }
  } catch (error) {
    console.error('Error updating career goals:', error);
    showNotification('Failed to update career goals', 'error');
  }
}

// Update career goals display
function updateCareerGoalsDisplay(careerGoals) {
  const careerGoalsCard = document.querySelector('.card:nth-child(3) .card-content ul');
  if (careerGoalsCard) {
    careerGoalsCard.innerHTML = `
      <li><span>Short-Term:</span> <span>${careerGoals.shortTermGoal || 'Not set'}</span></li>
      <li><span>Long-Term:</span> <span>${careerGoals.longTermGoal || 'Not set'}</span></li>
      <li><span>Skills Focus:</span> <span>${careerGoals.skillsFocus?.join(', ') || 'Not set'}</span></li>
      ${careerGoals.targetIndustry ? `<li><span>Target Industry:</span> <span>${careerGoals.targetIndustry}</span></li>` : ''}
    `;
  }
}

// UPDATED: Function to add/update skills with synchronization
async function addOrUpdateSkill(skillName, proficiencyLevel) {
  try {
    // First perform the API call if authenticated
    if (isAuthenticated()) {
      await API.Profile.addSkill(skillName, proficiencyLevel);
      
      // After successful API call, sync entire profile to get updated skills
      await API.ProfileSync.syncProfile();
      
      // Refresh the skills display
      const skills = await API.Profile.getSkills();
      updateSkillsDisplay(skills);
      
      showNotification('Skill added successfully', 'success');
    } else {
      // For offline use, store in localStorage
      const skills = JSON.parse(localStorage.getItem('user_skills') || '[]');
      
      // Check if skill already exists
      const existingSkillIndex = skills.findIndex(s => 
        s.name.toLowerCase() === skillName.toLowerCase()
      );
      
      if (existingSkillIndex >= 0) {
        // Update existing skill
        skills[existingSkillIndex].level = proficiencyLevel;
      } else {
        // Add new skill
        skills.push({
          name: skillName,
          level: proficiencyLevel,
          _id: 'temp_' + Date.now() // Temporary ID until synced
        });
      }
      
      localStorage.setItem('user_skills', JSON.stringify(skills));
      showNotification('Skill saved locally', 'info');
    }
  } catch (error) {
    console.error('Error adding/updating skill:', error);
    showNotification('Failed to add skill', 'error');
  }
}

// Update skills display
function updateSkillsDisplay(interests) {
  const progressSection = document.querySelector('.progress-section');
  if (!progressSection) return;
  
  // Filter interests to only include skills
  const skills = interests.filter(interest => interest.category === 'Skill');
  
  // If no skills, display a message
  if (skills.length === 0) {
    progressSection.innerHTML = `
      <div class="progress-header">
        <h3 class="progress-title">Skills Progress</h3>
        <a href="bobotoSkill.html" class="btn btn-outline">Add Skills</a>
      </div>
      <p>No skills have been added yet. Add skills to track your progress.</p>
    `;
    return;
  }
  
  // Sort skills by proficiency level (descending)
  skills.sort((a, b) => {
    const proficiencyValues = {
      'Expert': 90,
      'Advanced': 75,
      'Intermediate': 50,
      'Beginner': 25,
      'Novice': 10
    };
    
    const aValue = proficiencyValues[a.proficiency_level] || 0;
    const bValue = proficiencyValues[b.proficiency_level] || 0;
    
    return bValue - aValue;
  });
  
  // Limit to top 3 skills
  const topSkills = skills.slice(0, 3);
  
  // Generate progress bars
  let progressHtml = `
    <div class="progress-header">
      <h3 class="progress-title">Skills Progress</h3>
      <a href="bobotoSkill.html" class="btn btn-outline">View All Skills</a>
    </div>
  `;
  
  topSkills.forEach(skill => {
    // Convert proficiency level to percentage
    let percentage;
    switch (skill.proficiency_level) {
      case 'Expert': percentage = 90; break;
      case 'Advanced': percentage = 75; break;
      case 'Intermediate': percentage = 50; break;
      case 'Beginner': percentage = 25; break;
      case 'Novice': percentage = 10; break;
      default: percentage = 0;
    }
    
    progressHtml += `
      <div class="progress-item">
        <div class="progress-label">
          <span>${skill.interest_name}</span>
          <span>${percentage}%</span>
        </div>
        <div class="progress-bar">
          <div class="progress-value" style="width: ${percentage}%;"></div>
        </div>
      </div>
    `;
  });
  
  progressSection.innerHTML = progressHtml;
}

// Initialize tab switching functionality
function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  if (tabButtons.length === 0 || tabPanes.length === 0) return;
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      
      // Remove active class from all buttons and panes
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));
      
      // Add active class to current button and pane
      button.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    });
  });
  
  // Load tab content
  loadRecentActivity();
  loadUpcomingTasks();
  loadAIRecommendations();
}

// Load recent activity data
async function loadRecentActivity() {
  const activityList = document.querySelector('#recent-activity .activity-list');
  if (!activityList) return;
  
  try {
    // Placeholder for API call to get recent activity
    // In a real implementation, this would be an API call
    
    // For now, using static data
    const activities = [
      {
        time: 'Today, 10:35 AM',
        description: 'Completed AI Basics quiz with a score of 92%'
      },
      {
        time: 'Yesterday, 3:45 PM',
        description: 'Updated learning preferences'
      },
      {
        time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toLocaleDateString() + ', 2:15 PM',
        description: 'Chat session about machine learning career paths'
      }
    ];
    
    let activityHtml = '';
    activities.forEach(activity => {
      activityHtml += `
        <div class="activity-item">
          <div class="activity-time">${activity.time}</div>
          <div class="activity-description">${activity.description}</div>
        </div>
      `;
    });
    
    activityList.innerHTML = activityHtml;
  } catch (error) {
    console.error('Error loading recent activity:', error);
    activityList.innerHTML = '<p>Failed to load recent activity</p>';
  }
}

// Load upcoming tasks data
async function loadUpcomingTasks() {
  const taskList = document.querySelector('#upcoming-tasks .task-list');
  if (!taskList) return;
  
  try {
    // Placeholder for API call to get upcoming tasks
    // In a real implementation, this would be an API call
    
    // For now, using static data
    const tasks = [
      {
        id: 'task1',
        description: 'Complete Python assessment',
        dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toLocaleDateString()
      },
      {
        id: 'task2',
        description: 'Review recommended cloud computing resources',
        dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toLocaleDateString()
      },
      {
        id: 'task3',
        description: 'Update career goals for summer internships',
        dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toLocaleDateString()
      }
    ];
    
    let tasksHtml = '';
    tasks.forEach(task => {
      tasksHtml += `
        <div class="task-item">
          <input type="checkbox" id="${task.id}">
          <label for="${task.id}">${task.description} (Due: ${task.dueDate})</label>
        </div>
      `;
    });
    
    taskList.innerHTML = tasksHtml;
    
    // Add event listeners for task checkboxes
    document.querySelectorAll('.task-item input[type="checkbox"]').forEach(checkbox => {
      checkbox.addEventListener('change', function() {
        if (this.checked) {
          this.parentNode.classList.add('completed');
          // In a real app, you would send this to the server
          setTimeout(() => {
            showNotification('Task marked as completed!', 'success');
          }, 500);
        } else {
          this.parentNode.classList.remove('completed');
        }
      });
    });
  } catch (error) {
    console.error('Error loading upcoming tasks:', error);
    taskList.innerHTML = '<p>Failed to load upcoming tasks</p>';
  }
}

// Load AI recommendations data
async function loadAIRecommendations() {
  const recommendationsList = document.querySelector('#ai-recommendations .recommendations');
  if (!recommendationsList) return;
  
  try {
    // Placeholder for API call to get AI recommendations
    // In a real implementation, this would be an API call based on user data
    
    // For now, keep the existing static recommendations in the HTML
  } catch (error) {
    console.error('Error loading AI recommendations:', error);
    recommendationsList.innerHTML = '<p>Failed to load AI recommendations</p>';
  }
}