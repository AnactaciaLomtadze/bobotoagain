/**
 * skills.js - Skills assessment page functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', () => {
    // Protect the page
    protectPage();
    
    // Initialize skills page
    initSkillsPage();
    
    // Setup event listeners
    setupSkillsEventListeners();
    
    // Setup modals
    setupSkillModals();
  });
  
  // Initialize the skills page
  async function initSkillsPage() {
    try {
      // Fetch the user's profile data for sidebar
      const profileData = await API.Profile.get();
      
      if (!profileData) {
        showNotification('Failed to load profile data', 'error');
        return;
      }
      
      // Update sidebar user information
      updateSidebarUserInfo(profileData);
      
      // Fetch user skills
      const skills = await API.Profile.getSkills();
      
      if (skills) {
        loadUserSkills(skills);
        updateSkillsStats(skills);
      }
      
    } catch (error) {
      console.error('Error initializing skills page:', error);
      showNotification('Error loading skills data', 'error');
    }
  }
  
  // Update sidebar user information
  function updateSidebarUserInfo(profileData) {
    // Update user name
    const userNameElement = document.querySelector('.user-name');
    if (userNameElement) {
      userNameElement.textContent = profileData.fullName;
    }
    
    // Update user details
    const userDetailsElement = document.querySelector('.user-details');
    if (userDetailsElement) {
      let detailsText = 'Student';
      if (profileData.major) {
        detailsText = profileData.major;
        if (profileData.academicLevel) {
          detailsText += ' ' + profileData.academicLevel;
        }
        detailsText += ' Student';
      }
      userDetailsElement.textContent = detailsText;
    }
    
    // Update profile picture
    const profilePicElement = document.querySelector('.profile-picture img');
    if (profilePicElement && profileData.profilePictureUrl) {
      profilePicElement.src = profileData.profilePictureUrl;
    }
  }
  
  // Load user skills into the UI
  function loadUserSkills(skills) {
    // Update each skill category
    const categories = ['technical', 'soft', 'academic', 'career'];
    
    categories.forEach(category => {
      const categorySkills = skills.filter(skill => skill.category === category);
      updateSkillCategory(category, categorySkills);
    });
    
    // If no user skills exist, show empty state for each category
    if (skills.length === 0) {
      categories.forEach(category => {
        showEmptyCategory(category);
      });
    }
  }
  
  // Update skills for a specific category
  function updateSkillCategory(category, skills) {
    const skillGroup = document.getElementById(category);
    if (!skillGroup) return;
    
    // Clear existing skills (except title)
    const titleElement = skillGroup.querySelector('.skill-group-title');
    skillGroup.innerHTML = '';
    if (titleElement) {
      skillGroup.appendChild(titleElement);
    }
    
    // Add skills
    skills.forEach(skill => {
      const skillCard = createSkillCard(skill);
      skillGroup.appendChild(skillCard);
    });
    
    // Show empty state if no skills
    if (skills.length === 0) {
      showEmptyCategory(category);
    }
  }
  
  // Create a skill card element
  function createSkillCard(skill) {
    const skillCard = document.createElement('div');
    skillCard.className = 'skill-card';
    
    // Calculate percentage for progress bar
    let percentage = 0;
    switch (skill.level) {
      case 'Expert': percentage = 90; break;
      case 'Advanced': percentage = 75; break;
      case 'Intermediate': percentage = 50; break;
      case 'Beginner': percentage = 25; break;
      case 'Novice': percentage = 10; break;
      default: percentage = 0;
    }
    
    // Get skill badge class
    const badgeClass = skill.level.toLowerCase();
    
    skillCard.innerHTML = `
      <div class="skill-header">
        <h3 class="skill-title">${skill.name}</h3>
        <div class="skill-level">
          <span class="skill-badge ${badgeClass}">${skill.level}</span>
        </div>
      </div>
      <div class="skill-progress-label">
        <span>Current Level</span>
        <span>${percentage}%</span>
      </div>
      <div class="skill-progress-bar">
        <div class="skill-progress-value" style="width: ${percentage}%;"></div>
      </div>
      <div class="skill-info">
        <p>${generateSkillDescription(skill)}</p>
        <p class="last-assessment">Last assessed: ${formatDate(skill.addedAt || Date.now())}</p>
      </div>
      <div class="skill-resources">
        ${generateSkillResources(skill)}
      </div>
      <div class="skill-actions">
        <button class="btn btn-outline btn-small" onclick="openSkillModal('selfAssessmentModal', '${skill.name}')">Self-Assess</button>
        <button class="btn btn-small" onclick="openChatWithContext('${skill.name}')">Chat About This Skill</button>
      </div>
    `;
    
    return skillCard;
  }
  
  // Generate skill description
  function generateSkillDescription(skill) {
    const descriptions = {
      'Expert': 'You have mastered this skill and can teach others.',
      'Advanced': 'You have strong proficiency and can handle complex tasks.',
      'Intermediate': 'You have good understanding and can work independently.',
      'Beginner': 'You have basic knowledge and need supervised practice.',
      'Novice': 'You are just starting to learn this skill.'
    };
    
    return descriptions[skill.level] || 'Continue developing this skill to reach your goals.';
  }
  
  // Generate skill resources
  function generateSkillResources(skill) {
    // This would ideally come from a database or API
    const resources = {
      'Machine Learning': [
        { icon: '📚', text: 'Recommended course: Advanced Neural Networks', url: '#' },
        { icon: '🔗', text: 'Practice exercises: ML Classification Problems', url: '#' }
      ],
      'Data Structures': [
        { icon: '📚', text: 'Practice: Advanced Algorithm Challenges', url: '#' },
        { icon: '🔗', text: 'Resource: Competitive Programming Handbook', url: '#' }
      ],
      'Cloud Computing': [
        { icon: '📚', text: 'Recommended course: Cloud Computing Fundamentals', url: '#' },
        { icon: '🔗', text: 'Practice: AWS Free Tier Projects', url: '#' }
      ]
    };
    
    const skillResources = resources[skill.name] || [
      { icon: '📚', text: 'Find resources related to this skill', url: '#' }
    ];
    
    return skillResources.map(resource => `
      <a href="${resource.url}" class="resource-link">
        <span class="resource-icon">${resource.icon}</span>
        ${resource.text}
      </a>
    `).join('');
  }
  
  // Show empty category
  function showEmptyCategory(category) {
    const skillGroup = document.getElementById(category);
    if (!skillGroup) return;
    
    const emptyState = document.createElement('div');
    emptyState.className = 'empty-skills-state';
    emptyState.innerHTML = `
      <p>No ${category} skills added yet. Add skills to track your progress.</p>
      <button class="btn btn-primary" onclick="openAddSkillModal('${category}')">Add Skill</button>
    `;
    
    skillGroup.appendChild(emptyState);
  }
  
  // Update skills statistics
  function updateSkillsStats(skills) {
    // Calculate stats
    const totalSkills = skills.length;
    const skillsByLevel = skills.reduce((acc, skill) => {
      acc[skill.level] = (acc[skill.level] || 0) + 1;
      return acc;
    }, {});
    
    const experSkills = skillsByLevel['Expert'] || 0;
    const advancedSkills = skillsByLevel['Advanced'] || 0;
    const intermediateSkills = skillsByLevel['Intermediate'] || 0;
    const beginnerSkills = skillsByLevel['Beginner'] || 0;
    const noviceSkills = skillsByLevel['Novice'] || 0;
    
    // Calculate overall progress (weighted average)
    const totalWeightedScore = (
      (experSkills * 90) +
      (advancedSkills * 75) +
      (intermediateSkills * 50) +
      (beginnerSkills * 25) +
      (noviceSkills * 10)
    );
    
    const overallProgress = totalSkills > 0 ? Math.round(totalWeightedScore / totalSkills) : 0;
    
    // Update stats display
    const statsElements = {
      totalSkills: document.querySelectorAll('.stat-value')[0],
      overallProgress: document.querySelectorAll('.stat-value')[1],
      expertSkills: document.querySelectorAll('.stat-value')[2],
      improvementSkills: document.querySelectorAll('.stat-value')[3]
    };
    
    if (statsElements.totalSkills) statsElements.totalSkills.textContent = totalSkills;
    if (statsElements.overallProgress) statsElements.overallProgress.textContent = `${overallProgress}%`;
    if (statsElements.expertSkills) statsElements.expertSkills.textContent = experSkills;
    if (statsElements.improvementSkills) statsElements.improvementSkills.textContent = beginnerSkills + noviceSkills;
  }
  
  // Setup event listeners
  function setupSkillsEventListeners() {
    // Category buttons
    const categoryBtns = document.querySelectorAll('.category-btn');
    categoryBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Remove active class from all buttons and skill groups
        categoryBtns.forEach(b => b.classList.remove('active'));
        document.querySelectorAll('.skill-group').forEach(group => group.classList.remove('active'));
        
        // Add active class to clicked button and corresponding skill group
        btn.classList.add('active');
        const category = btn.getAttribute('data-category');
        document.getElementById(category).classList.add('active');
      });
    });
    
    // Action buttons
    const generatePdfBtn = document.getElementById('generatePdfBtn');
    if (generatePdfBtn) {
      generatePdfBtn.addEventListener('click', generateSkillsPDF);
    }
    
    // AI assessment button
    const aiAssessmentBtn = document.querySelector('[onclick="openModal(\'aiAssessmentModal\')"]');
    if (aiAssessmentBtn) {
      aiAssessmentBtn.onclick = () => openModal('aiAssessmentModal');
    }
  }
  
  // Setup skill modals
  function setupSkillModals() {
    // Self-assessment modal
    const selfAssessmentForm = document.getElementById('selfAssessmentForm');
    if (selfAssessmentForm) {
      selfAssessmentForm.addEventListener('submit', handleSelfAssessment);
    }
    
    // Add skill modal (if exists)
    const addSkillForm = document.getElementById('addSkillForm');
    if (addSkillForm) {
      addSkillForm.addEventListener('submit', handleAddSkill);
    }
  }
  
  // Open modal
  function openModal(modalId, skillTitle = '') {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    
    modal.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    if (modalId === 'selfAssessmentModal' && skillTitle) {
      const skillTitleElement = document.getElementById('assessmentSkillTitle');
      if (skillTitleElement) {
        skillTitleElement.textContent = skillTitle;
      }
    }
  }
  
  // Close modal
  function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (!modal) return;
    
    modal.classList.remove('active');
    document.body.style.overflow = 'auto';
  }
  
  // Handle self-assessment submission
  async function handleSelfAssessment(event) {
    event.preventDefault();
    
    const form = event.target;
    const skillName = document.getElementById('assessmentSkillTitle').textContent;
    const proficiency = form.proficiency.value;
    const frequency = form.frequency.value;
    const confidence = form.confidence.value;
    const improvement = form.improvement.value;
    const importance = form.importance.value;
    
    // Map proficiency to skill level
    const levelMap = {
      '1': 'Novice',
      '2': 'Beginner',
      '3': 'Intermediate',
      '4': 'Advanced'
    };
    
    const skillLevel = levelMap[proficiency] || 'Beginner';
    
    try {
      // Update skill using API
      await API.Profile.addSkill(skillName, skillLevel);
      
      showNotification(`Self-assessment for ${skillName} completed successfully!`, 'success');
      closeModal('selfAssessmentModal');
      
      // Refresh skills display
      const skills = await API.Profile.getSkills();
      loadUserSkills(skills);
      updateSkillsStats(skills);
      
    } catch (error) {
      console.error('Error submitting self-assessment:', error);
      showNotification('Failed to submit self-assessment', 'error');
    }
  }
  
  // Handle add skill
  async function handleAddSkill(event) {
    event.preventDefault();
    
    const form = event.target;
    const skillName = form.skillName.value;
    const skillLevel = form.skillLevel.value;
    const skillCategory = form.skillCategory.value;
    
    try {
      // Add skill using API (we need to modify the API to include category)
      await API.Profile.addSkill(skillName, skillLevel);
      
      showNotification(`${skillName} added successfully!`, 'success');
      closeModal('addSkillModal');
      
      // Refresh skills display
      const skills = await API.Profile.getSkills();
      loadUserSkills(skills);
      updateSkillsStats(skills);
      
    } catch (error) {
      console.error('Error adding skill:', error);
      showNotification('Failed to add skill', 'error');
    }
  }
  
  // Open add skill modal for specific category
  function openAddSkillModal(category) {
    const modal = document.getElementById('addSkillModal');
    if (!modal) {
      // If no add skill modal exists, use the general modal approach
      openModal('selfAssessmentModal');
      return;
    }
    
    // Pre-select the category
    const categorySelect = modal.querySelector('#skillCategory');
    if (categorySelect) {
      categorySelect.value = category;
    }
    
    openModal('addSkillModal');
  }
  
  // Open chat with skill context
  function openChatWithContext(skillContext) {
    // Navigate to chat page with skill context
    window.location.href = `bobotoChat.html?context=${encodeURIComponent(skillContext)}`;
  }
  
  // Generate skills PDF
  function generateSkillsPDF() {
    showNotification('Skills assessment PDF generation will be available soon', 'info');
    // TODO: Implement PDF generation
  }
  
  // Generate learning plan
  function generateLearningPlan() {
    closeModal('aiAssessmentModal');
    showNotification('Generating personalized learning plan...', 'info');
    // TODO: Navigate to learning plan page or generate plan
  }
  
  // Format date helper
  function formatDate(dateString) {
    const date = new Date(dateString);
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return date.toLocaleDateString(undefined, options);
  }
  
  // Export functions for global use
  window.openModal = openModal;
  window.closeModal = closeModal;
  window.openSkillModal = openModal;
  window.openChatWithContext = openChatWithContext;
  window.submitSelfAssessment = handleSelfAssessment;
  window.generateLearningPlan = generateLearningPlan;
  window.openAddSkillModal = openAddSkillModal;