/**
 * @typedef {Object} UserProfile
 * @property {string} _id - MongoDB ObjectId
 * @property {string} user - Reference to User ID
 * @property {string} major - User's academic major
 * @property {string} academicLevel - Current academic level
 * @property {string} university - User's university
 * @property {string} phone - Contact phone number
 * @property {number} graduationYear - Expected graduation year
 * @property {string} profilePictureUrl - URL to profile picture
 * @property {LearningPreferences} learningPreferences - Learning preferences
 * @property {CareerGoals} careerGoals - Career goals
 * @property {Skill[]} skills - User skills
 * @property {Course[]} courses - User courses
 * @property {Date} createdAt - Creation timestamp
 * @property {Date} updatedAt - Last update timestamp
 * @property {AISettings} aiSettings - OpenAI configuration settings
 */

/**
 * @typedef {Object} LearningPreferences
 * @property {string[]} learningStyles - Learning style preferences
 * @property {string[]} subjectInterests - Subjects of interest
 * @property {string[]} challenges - Learning challenges
 * @property {string} learningPace - Preferred learning pace
 * @property {string} explanationDepth - Preferred explanation depth
 * @property {string} contentFormat - Preferred content format
 * @property {string} learningGoal - Current learning goal
 * @property {number} technicalLevel - Technical proficiency level (1-5)
 * @property {number} theoryPractice - Theory vs. practice preference (1-5)
 * @property {string} additionalNotes - Additional learning preferences
 */

/**
 * @typedef {Object} CareerGoals
 * @property {string} shortTermGoal - Short-term career goal
 * @property {string} longTermGoal - Long-term career goal
 * @property {string[]} skillsFocus - Skills to develop
 * @property {string} targetIndustry - Target industry or sector
 */

/**
 * @typedef {Object} Skill
 * @property {string} _id - MongoDB ObjectId
 * @property {string} name - Skill name
 * @property {string} level - Proficiency level
 */

/**
 * @typedef {Object} Course
 * @property {string} _id - MongoDB ObjectId
 * @property {string} name - Course name
 * @property {string} provider - Course provider
 * @property {boolean} completed - Completion status
 * @property {Date} dateCompleted - Completion date
 */

/**
 * @typedef {Object} AISettings
 * @property {string} model - OpenAI model name
 * @property {number} temperature - Temperature parameter
 * @property {number} maxTokens - Maximum tokens
 */