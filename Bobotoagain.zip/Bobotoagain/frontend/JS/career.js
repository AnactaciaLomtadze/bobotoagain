/**
 * career.js - Career goals page functionality for Boboto
 */

document.addEventListener('DOMContentLoaded', () => {
  // Protect the page - redirect if not logged in
  protectPage();
  
  // Initialize the page
  initCareerGoalsPage();
  
  // Setup tab functionality
  setupCareerTabs();
  
  // Setup form event listeners
  setupCareerFormHandlers();
  
  // Setup drag and drop
  setupDragAndDrop();
});

// Initialize the career goals page
async function initCareerGoalsPage() {
  try {
    // Update auth UI
    updateAuthUI();
    
    // Fetch the user's profile data for sidebar
    const profileData = await API.Profile.get();
    
    if (!profileData) {
      showNotification('Failed to load profile data', 'error');
      return;
    }
    
    // Update sidebar user information
    updateSidebarUserInfo(profileData);
    
    // Fetch career goals
    const careerGoals = await API.Profile.getCareerGoals();
    
    if (careerGoals) {
      // Load career goals into the UI
      loadCareerGoals(careerGoals);
    }
    
    // Fetch user's skills for skills development tab
    const skills = await API.Profile.getSkills();
    
    if (skills) {
      loadUserSkills(skills);
    }
    
  } catch (error) {
    console.error('Error initializing career page:', error);
    showNotification('Error loading career data', 'error');
  }
}

// Update sidebar user information
function updateSidebarUserInfo(profileData) {
  // Update user name
  const userNameElement = document.querySelector('.user-name');
  if (userNameElement) {
    userNameElement.textContent = profileData.fullName;
  }
  
  // Update user details (major/academic level)
  const userDetailsElement = document.querySelector('.user-details');
  if (userDetailsElement) {
    let detailsText = 'Student';
    if (profileData.major) {
      detailsText = profileData.major;
      if (profileData.academicLevel) {
        detailsText += ' ' + profileData.academicLevel;
      }
      detailsText += ' Student';
    }
    userDetailsElement.textContent = detailsText;
  }
  
  // Update profile picture in sidebar
  const profilePicElement = document.querySelector('.profile-picture img');
  if (profilePicElement && profileData.profilePictureUrl) {
    profilePicElement.src = profileData.profilePictureUrl;
  }
}

// Load career goals into the UI
function loadCareerGoals(careerGoals) {
  // Short-term goal
  const shortTermGoalSelect = document.getElementById('shortTermGoal');
  if (shortTermGoalSelect && careerGoals.shortTermGoal) {
    shortTermGoalSelect.value = careerGoals.shortTermGoal;
  }
  
  // Mid-term goal
  const midTermGoalSelect = document.getElementById('midTermGoal');
  if (midTermGoalSelect && careerGoals.midTermGoal) {
    midTermGoalSelect.value = careerGoals.midTermGoal;
  }
  
  // Long-term goal
  const longTermGoalSelect = document.getElementById('longTermGoal');
  if (longTermGoalSelect && careerGoals.longTermGoal) {
    longTermGoalSelect.value = careerGoals.longTermGoal;
  }
  
  // Target dates
  const shortTermTarget = document.getElementById('shortTermTarget');
  if (shortTermTarget && careerGoals.shortTermTarget) {
    shortTermTarget.value = careerGoals.shortTermTarget;
  }
  
  const midTermTarget = document.getElementById('midTermTarget');
  if (midTermTarget && careerGoals.midTermTarget) {
    midTermTarget.value = careerGoals.midTermTarget;
  }
  
  const longTermTarget = document.getElementById('longTermTarget');
  if (longTermTarget && careerGoals.longTermTarget) {
    longTermTarget.value = careerGoals.longTermTarget;
  }
  
  // Industry focus
  const primaryIndustry = document.getElementById('primaryIndustry');
  if (primaryIndustry && careerGoals.targetIndustry) {
    primaryIndustry.value = careerGoals.targetIndustry;
  }
  
  // Other industry-related fields
  if (careerGoals.secondaryIndustry) {
    const secondaryIndustry = document.getElementById('secondaryIndustry');
    if (secondaryIndustry) secondaryIndustry.value = careerGoals.secondaryIndustry;
  }
  
  if (careerGoals.companySize) {
    const companySize = document.getElementById('companySize');
    if (companySize) companySize.value = careerGoals.companySize;
  }
  
  if (careerGoals.workEnvironment) {
    const workEnvironment = document.getElementById('workEnvironment');
    if (workEnvironment) workEnvironment.value = careerGoals.workEnvironment;
  }
  
  if (careerGoals.dreamCompanies) {
    const dreamCompanies = document.getElementById('dreamCompanies');
    if (dreamCompanies) dreamCompanies.value = careerGoals.dreamCompanies;
  }
  
  // Skills focus in skills development tab
  if (careerGoals.skillsFocus) {
    careerGoals.skillsFocus.forEach(skill => {
      markSkillAsSelected(skill);
    });
  }
  
  // Market insights tab fields
  if (careerGoals.locationPreference) {
    const locationPreference = document.getElementById('locationPreference');
    if (locationPreference) locationPreference.value = careerGoals.locationPreference;
  }
  
  if (careerGoals.salaryExpectations) {
    const salaryExpectations = document.getElementById('salaryExpectations');
    if (salaryExpectations) salaryExpectations.value = careerGoals.salaryExpectations;
  }
  
  // Learning plan fields
  if (careerGoals.primarySkillFocus) {
    const primarySkillFocus = document.getElementById('primarySkillFocus');
    if (primarySkillFocus) primarySkillFocus.value = careerGoals.primarySkillFocus;
  }
  
  if (careerGoals.learningTimeCommitment) {
    const learningTimeCommitment = document.getElementById('learningTimeCommitment');
    if (learningTimeCommitment) learningTimeCommitment.value = careerGoals.learningTimeCommitment;
  }
  
  if (careerGoals.certificationGoals) {
    const certificationGoals = document.getElementById('certificationGoals');
    if (certificationGoals) certificationGoals.value = careerGoals.certificationGoals;
  }
  
  if (careerGoals.certificationTimeline) {
    const certificationTimeline = document.getElementById('certificationTimeline');
    if (certificationTimeline) certificationTimeline.value = careerGoals.certificationTimeline;
  }
}

// Mark skill as selected
function markSkillAsSelected(skillName) {
  const skillItems = document.querySelectorAll('.skill-item');
  skillItems.forEach(item => {
    const nameElement = item.querySelector('.skill-name');
    if (nameElement && nameElement.textContent.trim() === skillName) {
      item.classList.add('selected');
    }
  });
}

// Setup career form handlers
function setupCareerFormHandlers() {
  // Save button
  const saveButton = document.querySelector('.btn-primary');
  if (saveButton) {
    saveButton.onclick = saveCareerGoals;
  }
  
  // Reset button
  const resetButton = document.querySelector('.btn-outline');
  if (resetButton) {
    resetButton.onclick = resetForm;
  }
  
  // Form change listeners for auto-validation
  const formElements = document.querySelectorAll('select, input, textarea');
  formElements.forEach(el => {
    el.addEventListener('change', () => {
      console.log('Form field changed:', el.id);
      // Could add real-time validation here
    });
  });
}

// Save career goals
async function saveCareerGoals() {
  try {
    // Get all form values
    const careerGoals = {
      shortTermGoal: document.getElementById('shortTermGoal').value,
      midTermGoal: document.getElementById('midTermGoal').value,
      longTermGoal: document.getElementById('longTermGoal').value,
      shortTermTarget: document.getElementById('shortTermTarget').value,
      midTermTarget: document.getElementById('midTermTarget').value,
      longTermTarget: document.getElementById('longTermTarget').value,
      targetIndustry: document.getElementById('primaryIndustry').value,
      secondaryIndustry: document.getElementById('secondaryIndustry').value,
      companySize: document.getElementById('companySize').value,
      workEnvironment: document.getElementById('workEnvironment').value,
      dreamCompanies: document.getElementById('dreamCompanies').value,
      // Skills focus
      skillsFocus: getSelectedSkills(),
      // Location and salary preferences
      locationPreference: document.getElementById('locationPreference')?.value,
      salaryExpectations: document.getElementById('salaryExpectations')?.value,
      // Learning and certification goals
      primarySkillFocus: document.getElementById('primarySkillFocus')?.value,
      learningTimeCommitment: document.getElementById('learningTimeCommitment')?.value,
      certificationGoals: document.getElementById('certificationGoals')?.value,
      certificationTimeline: document.getElementById('certificationTimeline')?.value,
      // Soft skills priorities
      softSkillsPriorities: getSoftSkillsPriorities()
    };
    
    // Save using API
    const result = await API.Profile.updateCareerGoals(careerGoals);
    
    if (result) {
      showNotification('Career goals saved successfully!', 'success');
    }
  } catch (error) {
    console.error('Error saving career goals:', error);
    showNotification('Error saving career goals', 'error');
  }
}

// Get selected skills
function getSelectedSkills() {
  const selectedSkills = [];
  const skillCheckboxes = document.querySelectorAll('.skill-item.selected');
  
  skillCheckboxes.forEach(skill => {
    const skillName = skill.querySelector('.skill-name').textContent;
    selectedSkills.push(skillName);
  });
  
  // Also check for other technical skills
  const otherTechSkills = document.getElementById('otherTechnicalSkills').value;
  if (otherTechSkills) {
    selectedSkills.push(...otherTechSkills.split(',').map(s => s.trim()).filter(s => s));
  }
  
  // Also check for other soft skills
  const otherSoftSkills = document.getElementById('otherSoftSkills').value;
  if (otherSoftSkills) {
    selectedSkills.push(...otherSoftSkills.split(',').map(s => s.trim()).filter(s => s));
  }
  
  return selectedSkills;
}

// Get soft skills priorities
function getSoftSkillsPriorities() {
  const priorities = [];
  const container = document.getElementById('softSkillsPriority');
  const items = container.querySelectorAll('.draggable-item');
  
  items.forEach(item => {
    const priorityText = item.querySelector('.skill-priority').textContent;
    const skillName = priorityText.split('. ')[1];
    priorities.push(skillName);
  });
  
  return priorities;
}

// Reset form
function resetForm() {
  if (confirm('Are you sure you want to reset all fields to their default values?')) {
    // Reset all form fields
    document.querySelectorAll('form').forEach(form => form.reset());
    
    // Reset skill selections
    document.querySelectorAll('.skill-item.selected').forEach(skill => {
      skill.classList.remove('selected');
    });
    
    // Reset soft skills order (to default)
    resetSoftSkillsOrder();
    
    showNotification('Form reset successfully', 'info');
  }
}

// Reset soft skills order
function resetSoftSkillsOrder() {
  const container = document.getElementById('softSkillsPriority');
  const defaultOrder = [
    '1. Leadership',
    '2. Communication',
    '3. Problem Solving',
    '4. Teamwork',
    '5. Time Management'
  ];
  
  const items = container.querySelectorAll('.draggable-item');
  items.forEach((item, index) => {
    const priorityDiv = item.querySelector('.skill-priority');
    priorityDiv.textContent = defaultOrder[index];
  });
}

// Setup tab functionality
function setupCareerTabs() {
  const tabButtons = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', () => {
      const tabId = button.getAttribute('data-tab');
      
      // Remove active class from all buttons and panes
      tabButtons.forEach(btn => btn.classList.remove('active'));
      tabPanes.forEach(pane => pane.classList.remove('active'));
      
      // Add active class to clicked button and corresponding pane
      button.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    });
  });
}

// Setup drag and drop functionality
function setupDragAndDrop() {
  // Make skills clickable for toggle
  const skillItems = document.querySelectorAll('.skill-item');
  skillItems.forEach(item => {
    item.addEventListener('click', () => toggleSkill(item));
  });
}

// Toggle skill selection
function toggleSkill(skillItem) {
  skillItem.classList.toggle('selected');
}

// Drag and drop functions
function allowDrop(ev) {
  ev.preventDefault();
  ev.currentTarget.classList.add('dragover');
  // Remove dragover class after a short delay
  setTimeout(() => {
    ev.currentTarget.classList.remove('dragover');
  }, 100);
}

function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
  ev.preventDefault();
  ev.currentTarget.classList.remove('dragover');
  
  const data = ev.dataTransfer.getData("text");
  const draggedElement = document.getElementById(data);
  const container = ev.currentTarget;
  
  // Get the position where the element was dropped
  const mouseY = ev.clientY;
  const children = Array.from(container.children);
  
  let insertAfter = null;
  
  // Find the element to insert after
  for (let i = 0; i < children.length; i++) {
    const child = children[i];
    if (child === draggedElement) continue; // Skip the dragged element itself
    
    const rect = child.getBoundingClientRect();
    const childMiddle = rect.top + rect.height / 2;
    
    if (mouseY < childMiddle) {
      insertAfter = child.previousElementSibling;
      break;
    } else {
      insertAfter = child;
    }
  }
  
  if (insertAfter === null) {
    container.prepend(draggedElement);
  } else {
    insertAfter.after(draggedElement);
  }
  
  // Update skill priorities
  updateSkillPriorities();
}

function updateSkillPriorities() {
  const container = document.getElementById('softSkillsPriority');
  const items = container.querySelectorAll('.draggable-item');
  
  items.forEach((item, index) => {
    const priorityDiv = item.querySelector('.skill-priority');
    const skillText = priorityDiv.textContent.split('. ')[1];
    priorityDiv.textContent = `${index + 1}. ${skillText}`;
  });
}

// Load user skills into the skills development tab
function loadUserSkills(skills) {
  const techSkillsGrid = document.querySelector('.skills-grid');
  if (!techSkillsGrid) return;
  
  // Reset all selections first
  document.querySelectorAll('.skill-item').forEach(skill => {
    skill.classList.remove('selected');
  });
  
  // Mark user's skills as selected and update progress bars
  skills.forEach(userSkill => {
    const skillItems = document.querySelectorAll('.skill-item');
    skillItems.forEach(skillItem => {
      const skillName = skillItem.querySelector('.skill-name').textContent;
      if (skillName.toLowerCase() === userSkill.name.toLowerCase()) {
        skillItem.classList.add('selected');
        
        // Update progress bar based on skill level
        const progressBar = skillItem.querySelector('.skill-level');
        if (progressBar) {
          let percentage = 0;
          switch (userSkill.level) {
            case 'Expert': percentage = 90; break;
            case 'Advanced': percentage = 75; break;
            case 'Intermediate': percentage = 50; break;
            case 'Beginner': percentage = 25; break;
            case 'Novice': percentage = 10; break;
            default: percentage = 50;
          }
          progressBar.style.width = `${percentage}%`;
        }
      }
    });
  });
}

// Show notification function
function showNotification(message, type = 'info') {
  const notificationArea = document.getElementById('notificationArea');
  if (!notificationArea) return;
  
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.innerHTML = `
    <span class="close-btn" onclick="this.parentElement.remove();">&times;</span>
    ${message}
  `;
  
  notificationArea.appendChild(notification);
  
  // Auto remove notification after 5 seconds
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove();
    }
  }, 5000);
}

// Export functions for global use
window.switchTab = switchTab;
window.toggleSkill = toggleSkill;
window.allowDrop = allowDrop;
window.drag = drag;
window.drop = drop;
window.saveCareerGoals = saveCareerGoals;
window.resetForm = resetForm;
window.toggleUserMenu = toggleUserMenu;