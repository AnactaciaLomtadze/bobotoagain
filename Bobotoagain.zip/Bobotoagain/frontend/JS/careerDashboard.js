class CareerDashboard {
    constructor() {
        this.currentTab = 'career-suggestions';
        this.components = {};
        this.init();
    }

    init() {
        this.setupTabHandlers();
        this.initializeComponents();
        this.loadActiveTab();
    }

    setupTabHandlers() {
        const tabButtons = document.querySelectorAll('[data-tab]');
        tabButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                const tabId = e.target.getAttribute('data-tab');
                this.switchTab(tabId);
            });
        });
    }

    switchTab(tabId) {
        // Hide all tabs
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });

        // Remove active class from all buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        // Show selected tab
        const selectedTab = document.getElementById(tabId);
        if (selectedTab) {
            selectedTab.classList.add('active');
        }

        // Activate selected button
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');

        // Load component if needed
        this.loadComponent(tabId);
        this.currentTab = tabId;
    }

    async loadComponent(tabId) {
        switch (tabId) {
            case 'career-suggestions':
                await this.loadCareerSuggestions();
                break;
            case 'job-recommendations':
                await this.loadJobRecommendations();
                break;
            case 'job-trends':
                await this.loadJobTrends();
                break;
            case 'resume-analyzer':
                await this.loadResumeAnalyzer();
                break;
        }
    }

    async loadCareerSuggestions() {
        const container = document.getElementById('career-suggestions');
        if (!container) return;

        try {
            const token = localStorage.getItem('auth_token');
            const response = await fetch('/api/career/path-suggestions', {
                headers: {
                    'x-auth-token': token
                }
            });
            
            const data = await response.json();
            this.renderCareerSuggestions(container, data.suggestions);
        } catch (error) {
            console.error('Error loading career suggestions:', error);
            container.innerHTML = '<div class="error">Failed to load career suggestions</div>';
        }
    }

    renderCareerSuggestions(container, suggestions) {
        const html = `
            <div class="career-suggestions-container">
                <div class="suggestions-grid">
                    ${suggestions.map((suggestion, index) => `
                        <div class="career-card" onclick="careerDashboard.selectCareer(${index})">
                            <div class="career-header">
                                <h3>${suggestion.careerPath}</h3>
                                <span class="match-score">${suggestion.score}% Match</span>
                            </div>
                            <p class="career-description">${suggestion.description}</p>
                            <div class="career-details">
                                <div class="career-stat">
                                    <span class="label">Growth:</span>
                                    <span class="value">${suggestion.growthRate}%</span>
                                </div>
                                <div class="career-stat">
                                    <span class="label">Avg. Salary:</span>
                                    <span class="value">$${suggestion.averageSalary.toLocaleString()}</span>
                                </div>
                            </div>
                            <div class="matched-skills">
                                ${suggestion.matchReasons.skillMatches.map(skill => 
                                    `<span class="skill-tag">${skill}</span>`
                                ).join('')}
                            </div>
                        </div>
                    `).join('')}
                </div>
                ${this.renderCareerDetails()}
            </div>
        `;
        container.innerHTML = html;
    }

    renderCareerDetails() {
        return `
            <div id="career-details" class="career-details-panel" style="display: none;">
                <!-- Career details will be populated when a career is selected -->
            </div>
        `;
    }

    selectCareer(index) {
        // Show career details
        const detailsPanel = document.getElementById('career-details');
        if (detailsPanel) {
            detailsPanel.style.display = 'block';
            // Populate details for selected career
            this.loadCareerDetails(index);
        }
    }

    async loadCareerDetails(index) {
        const token = localStorage.getItem('auth_token');
        const careerPath = this.components.careerSuggestions[index];
        
        try {
            const response = await fetch('/api/career/skill-gap-analysis', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'x-auth-token': token
                },
                body: JSON.stringify({ targetRole: careerPath.careerPath })
            });
            
            const gapAnalysis = await response.json();
            this.renderCareerDetails(careerPath, gapAnalysis);
        } catch (error) {
            console.error('Error loading career details:', error);
        }
    }

    renderCareerDetails(career, gapAnalysis) {
        const detailsPanel = document.getElementById('career-details');
        const html = `
            <div class="career-details-content">
                <h2>${career.careerPath}</h2>
                <p>${career.description}</p>
                
                <div class="gap-analysis">
                    <h3>Readiness Analysis</h3>
                    <div class="readiness-score">
                        <div class="score-circle">
                            <span class="score">${gapAnalysis.readinessScore}%</span>
                        </div>
                        <p>Ready</p>
                    </div>
                    
                    <div class="skills-breakdown">
                        <div class="skills-column">
                            <h4>You have:</h4>
                            <ul>
                                ${gapAnalysis.matchedSkills.map(skill => 
                                    `<li class="skill-item matched">${skill}</li>`
                                ).join('')}
                            </ul>
                        </div>
                        <div class="skills-column">
                            <h4>You need:</h4>
                            <ul>
                                ${gapAnalysis.missingSkills.map(skill => 
                                    `<li class="skill-item missing">${skill}</li>`
                                ).join('')}
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="next-steps">
                    <h3>Recommended Next Steps</h3>
                    <ul>
                        ${career.nextSteps.map(step => `<li>${step}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
        detailsPanel.innerHTML = html;
    }

    async loadJobRecommendations() {
        const container = document.getElementById('job-recommendations');
        if (!container) return;

        try {
            const token = localStorage.getItem('auth_token');
            const response = await fetch('/api/career/jobs', {
                headers: {
                    'x-auth-token': token
                }
            });
            
            const data = await response.json();
            this.renderJobRecommendations(container, data);
        } catch (error) {
            console.error('Error loading job recommendations:', error);
            container.innerHTML = '<div class="error">Failed to load job recommendations</div>';
        }
    }

    renderJobRecommendations(container, data) {
        const html = `
            <div class="job-recommendations-container">
                <div class="filters">
                    <input type="text" id="job-location-filter" placeholder="Location" />
                    <select id="job-source-filter">
                        <option value="all">All Sources</option>
                        <option value="Adzuna">Adzuna</option>
                        <option value="The Muse">The Muse</option>
                        <option value="LinkedIn">LinkedIn</option>
                    </select>
                </div>
                <div class="jobs-list">
                    ${data.jobs.map(job => `
                        <div class="job-card" onclick="careerDashboard.selectJob('${job.id}')">
                            <div class="job-header">
                                <h3>${job.title}</h3>
                                <span class="job-source">${job.source}</span>
                            </div>
                            <p class="company">${job.company}</p>
                            <p class="location">${job.location}</p>
                            <div class="job-stats">
                                <span class="salary">${job.salary}</span>
                                <span class="posted">${this.formatDate(job.postedAt)}</span>
                            </div>
                            ${job.relevanceScore ? `
                                <div class="relevance-score">
                                    <div class="score-bar" style="width: ${job.relevanceScore}%"></div>
                                    <span>${job.relevanceScore}% match</span>
                                </div>
                            ` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        container.innerHTML = html;
        this.setupJobFilters();
    }

    setupJobFilters() {
        const locationFilter = document.getElementById('job-location-filter');
        const sourceFilter = document.getElementById('job-source-filter');
        
        if (locationFilter) {
            locationFilter.addEventListener('input', () => this.filterJobs());
        }
        if (sourceFilter) {
            sourceFilter.addEventListener('change', () => this.filterJobs());
        }
    }

    filterJobs() {
        const location = document.getElementById('job-location-filter').value;
        const source = document.getElementById('job-source-filter').value;
        
        // Implement filtering logic
        const jobCards = document.querySelectorAll('.job-card');
        jobCards.forEach(card => {
            const cardText = card.textContent.toLowerCase();
            const locationMatch = !location || cardText.includes(location.toLowerCase());
            const sourceMatch = source === 'all' || cardText.includes(source);
            
            card.style.display = locationMatch && sourceMatch ? 'block' : 'none';
        });
    }

    async loadJobTrends() {
        const container = document.getElementById('job-trends');
        if (!container) return;

        try {
            const token = localStorage.getItem('auth_token');
            const response = await fetch('/api/career/job-market', {
                headers: {
                    'x-auth-token': token
                }
            });
            
            const data = await response.json();
            this.renderJobTrends(container, data);
        } catch (error) {
            console.error('Error loading job trends:', error);
            container.innerHTML = '<div class="error">Failed to load job market trends</div>';
        }
    }

    renderJobTrends(container, data) {
        const html = `
            <div class="job-trends-container">
                <div class="trends-grid">
                    <div class="trend-card">
                        <h3>Demand Trends</h3>
                        <canvas id="demand-chart" width="400" height="200"></canvas>
                    </div>
                    <div class="trend-card">
                        <h3>Top Skills</h3>
                        <div class="skills-list">
                            ${data.topSkills.map(skill => `
                                <div class="skill-trend">
                                    <span class="skill-name">${skill.name}</span>
                                    <div class="skill-bar">
                                        <div class="skill-progress" style="width: ${skill.percentageOfJobs || 50}%"></div>
                                    </div>
                                    <span class="skill-demand ${skill.demand.toLowerCase()}">${skill.demand}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="trend-card">
                        <h3>Salary Trends</h3>
                        <canvas id="salary-chart" width="400" height="200"></canvas>
                    </div>
                    <div class="trend-card">
                        <h3>Recent Market Insights</h3>
                        <div class="insights-list">
                            ${data.recentTrends.map(trend => `
                                <div class="trend-insight">
                                    <h4>${trend.trend}</h4>
                                    <p>${trend.impact}</p>
                                    <span class="trend-change">${trend.percentageChange}% change</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML = html;
        this.renderCharts(data);
    }

    renderCharts(data) {
        // Simple canvas-based charts (you can replace with Chart.js or similar library)
        this.drawDemandChart(data.demandTrends);
        this.drawSalaryChart(data.salaryTrends);
    }

    drawDemandChart(demandTrends) {
        const canvas = document.getElementById('demand-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        ctx.clearRect(0, 0, width, height);
        
        // Simple line chart implementation
        if (demandTrends && demandTrends.length > 0) {
            ctx.strokeStyle = '#3b82f6';
            ctx.lineWidth = 2;
            ctx.beginPath();
            
            demandTrends.forEach((trend, index) => {
                const x = (index / (demandTrends.length - 1)) * width;
                const y = height - (trend.jobCount / Math.max(...demandTrends.map(t => t.jobCount))) * height;
                
                if (index === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            });
            
            ctx.stroke();
        }
    }

    drawSalaryChart(salaryTrends) {
        const canvas = document.getElementById('salary-chart');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;
        
        ctx.clearRect(0, 0, width, height);
        
        // Simple bar chart implementation
        if (salaryTrends && salaryTrends.length > 0) {
            const barWidth = width / salaryTrends.length;
            const maxSalary = Math.max(...salaryTrends.map(t => t.averageSalary));
            
            salaryTrends.forEach((trend, index) => {
                const barHeight = (trend.averageSalary / maxSalary) * height;
                const x = index * barWidth;
                const y = height - barHeight;
                
                ctx.fillStyle = '#10b981';
                ctx.fillRect(x, y, barWidth - 2, barHeight);
            });
        }
    }

    async loadResumeAnalyzer() {
        const container = document.getElementById('resume-analyzer');
        if (!container) return;

        const html = `
            <div class="resume-analyzer-container">
                <div class="upload-section">
                    <h3>Resume Analysis</h3>
                    <div class="upload-area" onclick="document.getElementById('resume-file').click();">
                        <div class="upload-icon">📄</div>
                        <p>Click to upload your resume</p>
                        <p class="file-types">PDF, DOC, DOCX, or TXT</p>
                    </div>
                    <input type="file" id="resume-file" style="display: none;" accept=".pdf,.doc,.docx,.txt" />
                    
                    <div class="target-role-section">
                        <label for="target-role">Target Role (Optional)</label>
                        <select id="target-role">
                            <option value="">Select a role</option>
                            <option value="Software Engineer">Software Engineer</option>
                            <option value="Data Scientist">Data Scientist</option>
                            <option value="Machine Learning Engineer">Machine Learning Engineer</option>
                            <option value="DevOps Engineer">DevOps Engineer</option>
                        </select>
                    </div>
                    
                    <button id="analyze-btn" class="btn btn-primary" disabled>Analyze Resume</button>
                </div>
                
                <div id="analysis-results" class="analysis-results" style="display: none;">
                    <!-- Analysis results will be displayed here -->
                </div>
            </div>
        `;
        container.innerHTML = html;
        this.setupResumeAnalyzer();
    }

    setupResumeAnalyzer() {
        const fileInput = document.getElementById('resume-file');
        const analyzeBtn = document.getElementById('analyze-btn');
        const resultsDiv = document.getElementById('analysis-results');
        
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                analyzeBtn.disabled = false;
                analyzeBtn.textContent = `Analyze ${file.name}`;
            }
        });
        
        analyzeBtn.addEventListener('click', async () => {
            const file = fileInput.files[0];
            const targetRole = document.getElementById('target-role').value;
            
            if (!file) return;
            
            analyzeBtn.disabled = true;
            analyzeBtn.textContent = 'Analyzing...';
            
            const formData = new FormData();
            formData.append('resume', file);
            if (targetRole) formData.append('targetRole', targetRole);
            
            try {
                const token = localStorage.getItem('auth_token');
                const response = await fetch('/api/career/analyze-resume', {
                    method: 'POST',
                    headers: {
                        'x-auth-token': token
                    },
                    body: formData
                });
                
                const analysis = await response.json();
                this.renderResumeAnalysis(resultsDiv, analysis);
                resultsDiv.style.display = 'block';
            } catch (error) {
                console.error('Error analyzing resume:', error);
                resultsDiv.innerHTML = '<div class="error">Failed to analyze resume</div>';
                resultsDiv.style.display = 'block';
            } finally {
                analyzeBtn.disabled = false;
                analyzeBtn.textContent = 'Analyze Resume';
            }
        });
    }

    renderResumeAnalysis(container, analysis) {
        const html = `
            <div class="analysis-content">
                <h3>Analysis Results</h3>
                
                <div class="overall-score">
                    <div class="score-circle">
                        <span class="score">${analysis.assessment.overallScore.overall}%</span>
                    </div>
                    <p>Overall Score</p>
                </div>
                
                <div class="score-breakdown">
                    <div class="score-item">
                        <span class="label">Skills Coverage</span>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${analysis.assessment.overallScore.components.skills}%"></div>
                        </div>
                        <span class="score-value">${analysis.assessment.overallScore.components.skills}%</span>
                    </div>
                    <div class="score-item">
                        <span class="label">Experience Quality</span>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${analysis.assessment.overallScore.components.experience}%"></div>
                        </div>
                        <span class="score-value">${analysis.assessment.overallScore.components.experience}%</span>
                    </div>
                    <div class="score-item">
                        <span class="label">Education Relevance</span>
                        <div class="score-bar">
                            <div class="score-fill" style="width: ${analysis.assessment.overallScore.components.education}%"></div>
                        </div>
                        <span class="score-value">${analysis.assessment.overallScore.components.education}%</span>
                    </div>
                </div>
                
                <div class="improvements-section">
                    <h4>Improvement Suggestions</h4>
                    <div class="suggestions-list">
                        ${analysis.improvements.map(suggestion => `
                            <div class="suggestion-item ${suggestion.priority.toLowerCase()}">
                                <h5>${suggestion.suggestion}</h5>
                                <p><strong>Section:</strong> ${suggestion.section}</p>
                                <p><strong>Reason:</strong> ${suggestion.reason}</p>
                                <span class="priority-badge">${suggestion.priority} Priority</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="skills-analysis">
                    <h4>Skills Analysis</h4>
                    <div class="skills-grid">
                        <div class="skills-column">
                            <h5>Found Skills</h5>
                            <div class="skills-tags">
                                ${analysis.sections.skills.map(skill => 
                                    `<span class="skill-tag found">${skill}</span>`
                                ).join('')}
                            </div>
                        </div>
                        <div class="skills-column">
                            <h5>Missing Skills</h5>
                            <div class="skills-tags">
                                ${analysis.assessment.skillCoverage.missing.map(skill => 
                                    `<span class="skill-tag missing">${skill}</span>`
                                ).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML = html;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - date);
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) return 'Today';
        if (diffDays === 1) return 'Yesterday';
        if (diffDays < 7) return `${diffDays} days ago`;
        if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
        return date.toLocaleDateString();
    }

    initializeComponents() {
        this.components = {
            careerSuggestions: [],
            jobRecommendations: [],
            jobTrends: null,
            resumeAnalysis: null
        };
    }

    loadActiveTab() {
        this.loadComponent(this.currentTab);
    }
}

// Initialize the dashboard when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.careerDashboard = new CareerDashboard();
});